--
-- PostgreSQL database dump
--

\restrict AsfnlQgPmYjsq9vUK7ZqvLmHRVAPfccjWo2XCdLR6CHmojjhEyKpF58SSge1mkd

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS '';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: ActivityStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ActivityStatus" AS ENUM (
    'locked',
    'in_progress',
    'pending_assessment',
    'completed'
);


--
-- Name: ProblemType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ProblemType" AS ENUM (
    'internal',
    'external'
);


--
-- Name: ProjectRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ProjectRole" AS ENUM (
    'lead',
    'care',
    'coordinate'
);


--
-- Name: RiskLevel; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."RiskLevel" AS ENUM (
    'blue',
    'green',
    'yellow',
    'orange',
    'red'
);


--
-- Name: StudentStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."StudentStatus" AS ENUM (
    'ACTIVE',
    'RESIGNED',
    'TRANSFERRED',
    'GRADUATED'
);


--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."UserRole" AS ENUM (
    'system_admin',
    'school_admin',
    'class_teacher'
);


--
-- Name: gender; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.gender AS ENUM (
    'MALE',
    'FEMALE'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: academic_years; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.academic_years (
    id text NOT NULL,
    year integer NOT NULL,
    semester integer NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone NOT NULL,
    "isCurrent" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: activity_progress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.activity_progress (
    id text NOT NULL,
    "studentId" text NOT NULL,
    "phqResultId" text NOT NULL,
    "activityNumber" integer NOT NULL,
    status public."ActivityStatus" DEFAULT 'locked'::public."ActivityStatus" NOT NULL,
    "unlockedAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "scheduledDate" timestamp(3) without time zone,
    "teacherId" text,
    "teacherNotes" text,
    "internalProblems" text,
    "externalProblems" text,
    "problemType" public."ProblemType",
    "assessedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: counseling_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.counseling_sessions (
    id text NOT NULL,
    "studentId" text NOT NULL,
    "sessionNumber" integer NOT NULL,
    "sessionDate" timestamp(3) without time zone NOT NULL,
    "counselorName" text NOT NULL,
    summary text NOT NULL,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "academicYearId" text
);


--
-- Name: home_visit_photos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.home_visit_photos (
    id text NOT NULL,
    "homeVisitId" text NOT NULL,
    "fileName" text NOT NULL,
    "fileUrl" text NOT NULL,
    "fileType" text NOT NULL,
    "fileSize" integer NOT NULL,
    "uploadedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "idempotencyKey" uuid
);


--
-- Name: home_visits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.home_visits (
    id text NOT NULL,
    "studentId" text NOT NULL,
    "visitNumber" integer NOT NULL,
    "visitDate" timestamp(3) without time zone NOT NULL,
    description text NOT NULL,
    "nextScheduledDate" timestamp(3) without time zone,
    "teacherName" text NOT NULL,
    "teacherRole" text NOT NULL,
    "createdById" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "academicYearId" text
);


--
-- Name: password_reset_token; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.password_reset_token (
    id text NOT NULL,
    email text NOT NULL,
    token text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: phq_results; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phq_results (
    id text NOT NULL,
    "studentId" text NOT NULL,
    "academicYearId" text NOT NULL,
    "importedById" text NOT NULL,
    "assessmentRound" integer DEFAULT 1 NOT NULL,
    q1 integer NOT NULL,
    q2 integer NOT NULL,
    q3 integer NOT NULL,
    q4 integer NOT NULL,
    q5 integer NOT NULL,
    q6 integer NOT NULL,
    q7 integer NOT NULL,
    q8 integer NOT NULL,
    q9 integer NOT NULL,
    q9a boolean DEFAULT false NOT NULL,
    q9b boolean DEFAULT false NOT NULL,
    "totalScore" integer NOT NULL,
    "riskLevel" public."RiskLevel" NOT NULL,
    "referredToHospital" boolean DEFAULT false NOT NULL,
    "hospitalName" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: school_admin_invites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.school_admin_invites (
    id text NOT NULL,
    token text NOT NULL,
    email text NOT NULL,
    role public."UserRole" DEFAULT 'school_admin'::public."UserRole" NOT NULL,
    "usedAt" timestamp(3) without time zone,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: school_class_terms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.school_class_terms (
    id text NOT NULL,
    "schoolClassId" text NOT NULL,
    "academicYearId" text NOT NULL,
    "expectedStudentCount" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: school_classes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.school_classes (
    id text NOT NULL,
    "schoolId" text NOT NULL,
    name text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expectedStudentCount" integer DEFAULT 0 NOT NULL
);


--
-- Name: school_teacher_roster; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.school_teacher_roster (
    id text NOT NULL,
    "schoolId" text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    email text,
    age integer NOT NULL,
    "userRole" public."UserRole" NOT NULL,
    "advisoryClass" text NOT NULL,
    "schoolRole" text NOT NULL,
    "projectRole" public."ProjectRole" NOT NULL,
    "inviteSent" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: schools; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schools (
    id text NOT NULL,
    name text NOT NULL,
    province text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: student_referrals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.student_referrals (
    id text NOT NULL,
    "studentId" text NOT NULL,
    "fromTeacherUserId" text NOT NULL,
    "toTeacherUserId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: students; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.students (
    id text NOT NULL,
    "studentId" text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    gender public.gender,
    age integer,
    class text NOT NULL,
    "schoolId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "nationalId" character varying(13),
    status public."StudentStatus" DEFAULT 'ACTIVE'::public."StudentStatus" NOT NULL,
    "statusChangedAt" timestamp(3) without time zone,
    "leftAt" timestamp(3) without time zone
);


--
-- Name: system_admin_whitelist; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_admin_whitelist (
    id text NOT NULL,
    email text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: teacher_invites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.teacher_invites (
    id text NOT NULL,
    token text NOT NULL,
    email text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    age integer NOT NULL,
    "userRole" public."UserRole" NOT NULL,
    "advisoryClass" text NOT NULL,
    "schoolId" text NOT NULL,
    "schoolRole" text NOT NULL,
    "projectRole" public."ProjectRole" NOT NULL,
    "invitedById" text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "acceptedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: teachers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.teachers (
    id text NOT NULL,
    "userId" text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    age integer NOT NULL,
    "advisoryClass" text NOT NULL,
    "schoolRole" text NOT NULL,
    "projectRole" public."ProjectRole" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_sessions (
    id text NOT NULL,
    "sessionTokenHash" text NOT NULL,
    "userId" text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "lastActivityAt" timestamp(3) without time zone NOT NULL,
    "revokedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "tokenRotatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "userAgentLabel" text,
    "userAgentHash" text,
    "lastIpPrefix" text
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id text NOT NULL,
    name text,
    email text NOT NULL,
    "emailVerified" timestamp(3) without time zone,
    image text,
    password text,
    role public."UserRole" DEFAULT 'school_admin'::public."UserRole" NOT NULL,
    "isPrimary" boolean DEFAULT false NOT NULL,
    "schoolId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


--
-- Name: worksheet_uploads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.worksheet_uploads (
    id text NOT NULL,
    "activityProgressId" text NOT NULL,
    "worksheetNumber" integer DEFAULT 1 NOT NULL,
    "fileName" text NOT NULL,
    "fileUrl" text NOT NULL,
    "fileType" text NOT NULL,
    "fileSize" integer NOT NULL,
    "uploadedById" text NOT NULL,
    "uploadedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "idempotencyKey" uuid
);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
93eae297-c96d-4375-93fe-b60483781807	c441db3491ca2b27e6a49db84934312c627f6c35519aefb0184f4fd13746ca33	2026-06-01 12:18:29.721769+07	20260601111500_add_user_session_token_rotated_at	\N	\N	2026-06-01 12:18:29.714856+07	1
17ad7ff6-7419-4072-9e79-694c79b2218a	0b9c7fdb2d689ea438a568f4f7d3e4a8b40afe0540f674944c228544a328200f	2026-05-15 13:21:38.978+07	20260403041039_init	\N	\N	2026-05-15 13:21:38.746694+07	1
cb828d8e-64f3-4604-9d50-52ba00711bd2	38052148107b36b9657e5e873c4954ebb4aff8179f8792c7c28e47e12fafb777	2026-05-15 13:21:38.985903+07	20260403112500_add_home_visit_unique_number	\N	\N	2026-05-15 13:21:38.978949+07	1
82ade6b9-0598-4312-98a7-6ef195dd14b7	1af0843d8b5ab0f2c740111f3b7cb0acedf17a692ab06e1fa0e6230449843f24	2026-05-15 13:21:38.993225+07	20260403140000_add_phq_latest_risk_index	\N	\N	2026-05-15 13:21:38.986718+07	1
37d68834-c7bd-4a5e-9a1e-81645cff56b1	287672d7cc216787ffc9ea9a5e0c7d39faa25c01155512bee0bc303679dee6bd	2026-06-01 12:18:29.729063+07	20260601113000_add_user_session_metadata	\N	\N	2026-06-01 12:18:29.723372+07	1
26d40d2b-d49e-4ffa-9322-a7e3c8056cd0	75bab2e2707ed69a508a14181f5138dabaca9f7873635a1587b05a83bdd0710a	2026-05-15 13:21:39.000932+07	20260405103000_add_phq_analytics_indexes	\N	\N	2026-05-15 13:21:38.99409+07	1
5e6feadd-4bd7-416e-8362-570c0f4d068d	c865cf4c382e110b07f26172b3fc5632b310c398c58e3da6f01b9bf9ba1578c7	2026-05-15 13:21:39.010982+07	20260408102000_harden_invite_and_reset_concurrency	\N	\N	2026-05-15 13:21:39.002037+07	1
30e5ebd5-8515-4492-b0b6-28b4514414e2	8ca2cf33143704bd7d8a8951f6dc83d48bff84c957e68d79f4f4452840e756fa	2026-05-15 13:21:39.022353+07	20260430090000_add_student_national_id	\N	\N	2026-05-15 13:21:39.012132+07	1
98ffc69e-9803-48d2-aabe-9dce4c651779	60eac20e0f4fea9192a5497ba0c2b3b151d1818bd28b618e4fdf6d1f841fca15	2026-06-23 10:35:07.276753+07	20260623090000_add_upload_idempotency_keys	\N	\N	2026-06-23 10:35:07.23129+07	1
24882ce0-a8a9-46d8-8017-bdfaedc36b6d	83046524c4cd793402a6522bfaa84b9e43beb99e7637878c7a3295352389b077	2026-05-15 13:21:39.034609+07	20260512031355_remove_academic_year_from_teacher	\N	\N	2026-05-15 13:21:39.023769+07	1
c0c694f7-d7df-49c5-9658-4f60d4070151	da53fe97d2c04e264d17a4973bc90328addbdca8c09f41009f1311cf4b385f44	2026-05-15 13:21:39.043304+07	20260512043000_add_user_soft_delete	\N	\N	2026-05-15 13:21:39.036148+07	1
59274402-93bd-48e8-b4b3-325a357ba8ea	b341b338252a1a2df1e22ae17053d6dba65b231c0b6a453d8bdec4f45ba22141	2026-05-15 13:21:39.048953+07	20260512052000_add_school_class_expected_student_count	\N	\N	2026-05-15 13:21:39.04482+07	1
33069eaf-c24b-4bde-9e70-bcf816e77bc6	8b3350265ddc010765b5331435b02d28b29557a9d0ecf4aad0b9361f4c621f82	2026-06-28 14:12:53.36337+07	20260628130000_hash_invite_tokens	\N	\N	2026-06-28 14:12:53.330152+07	1
c58a8d56-945c-4076-8f21-a223ec130027	d6a152e579a154446ace9deab6e1683f3ccf5d783a5c09915057e94ea2727d03	2026-05-22 16:49:48.797632+07	20260522090000_add_school_class_terms	\N	\N	2026-05-22 16:49:48.732739+07	1
3e0dbecb-e6b3-4000-80dc-aa8f1b15cce4	87b86d0d2ee4e7617b7624205df66b0f65ba917430cb0f06acfd6b10c65438a8	2026-05-22 16:49:48.818407+07	20260522110000_add_academic_year_to_student_records	\N	\N	2026-05-22 16:49:48.799306+07	1
94c8963b-bfba-4bca-9580-037e10a4ccb0	e55a9fb990e3637ec5aa92e68f74502912be9e72b96c1a94e3652934037c6f63	2026-06-01 12:18:29.713841+07	20260601090000_add_user_sessions	\N	\N	2026-06-01 12:18:29.670847+07	1
\.


--
-- Data for Name: academic_years; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.academic_years (id, year, semester, "startDate", "endDate", "isCurrent", "createdAt", "updatedAt") FROM stdin;
cmp6j4rh20002jxuik5drdqtt	2569	1	2026-05-14 17:00:00	2026-10-14 17:00:00	t	2026-05-15 06:21:40.502	2026-07-06 04:41:09.235
\.


--
-- Data for Name: activity_progress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.activity_progress (id, "studentId", "phqResultId", "activityNumber", status, "unlockedAt", "completedAt", "scheduledDate", "teacherId", "teacherNotes", "internalProblems", "externalProblems", "problemType", "assessedAt", "createdAt", "updatedAt") FROM stdin;
cmprve8mc002vjx5q0fmh9ne0	cmprve8l50012jx5qj6qlzxu9	cmprve8lw001xjx5qrsnrzx1x	1	in_progress	2026-05-30 04:48:07.712	\N	\N	cmp6j8ifp0002jxdffdiyvvw3	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-06-23 02:28:02.533
cmprve8me0045jx5q9g86n4xm	cmprve8l5001gjx5qqjjvx9qi	cmprve8lw002bjx5qcy63me5z	1	in_progress	2026-05-30 04:48:07.712	\N	\N	cmp6j8ifp0002jxdffdiyvvw3	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-06-23 03:37:01.995
cmp6jb4vg000vjxdfjgavvk8z	cmp6jb4ux000mjxdf5pxamnft	cmp6jb4v8000qjxdfgf02117g	2	in_progress	2026-06-16 09:22:08.985	\N	\N	cmp6j8ifp0002jxdffdiyvvw3	อิอิ	\N	\N	\N	\N	2026-05-15 06:26:37.804	2026-06-26 11:50:45.653
cmqf02txa006ljxop8hhz7bqi	cmqf02twi005xjxop9todeqnc	cmqf02twx0066jxop7hee7txt	1	completed	2026-06-15 09:17:55.58	2026-06-26 08:55:30.592	2026-06-26 08:55:26.377	cmq0kyw85007kjx239k25z1ge	\N	ไม่มั่นใจในตัวเอง	ไม่มั่นใจในด้านการเรียน	internal	2026-06-26 08:58:01.1	2026-06-15 09:17:55.581	2026-06-26 08:58:01.101
cmp6jb4vg000wjxdfoc6rvjg0	cmp6jb4ux000mjxdf5pxamnft	cmp6jb4v8000qjxdfgf02117g	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-15 06:26:37.804	2026-05-15 06:26:37.804
cmp6jb4vg000xjxdfduvflo43	cmp6jb4ux000mjxdf5pxamnft	cmp6jb4v8000qjxdfgf02117g	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-15 06:26:37.804	2026-05-15 06:26:37.804
cmp6jb4vg000yjxdflocwmlj9	cmp6jb4ux000mjxdf5pxamnft	cmp6jb4v8000qjxdfgf02117g	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-15 06:26:37.804	2026-05-15 06:26:37.804
cmprve8mc0030jx5qfhqni19z	cmprve8l50013jx5q08thkxep	cmprve8lw001yjx5qvxwwhcyr	1	in_progress	2026-05-30 04:48:07.712	\N	\N	cmp6j8ifp0002jxdffdiyvvw3	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-06-09 12:09:02.875
cmqf02txa006yjxoppqr332ve	cmqf02twi0060jxopbq0u963r	cmqf02twx0069jxopew6sr4k5	2	in_progress	2026-06-26 08:58:52.772	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 09:17:55.581	2026-06-26 08:58:52.772
cmqep6tak00tgjxp5uiwbipcc	cmqep6t7y00hkjxp50bymz2pu	cmqep6t9600kejxp53go2qb09	2	completed	2026-06-19 13:14:24.749	2026-06-26 09:01:14.603	2026-06-26 09:01:12.454	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:01:14.604
cmpauvmza0008jxm5aaqn1ojj	cmpauvmyx0004jxm5zwck4o1s	cmpauvmz50005jxm5rgnfbphy	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-18 07:01:34.87	2026-05-18 07:01:34.87
cmpauvmza0009jxm5mplev2x5	cmpauvmyx0004jxm5zwck4o1s	cmpauvmz50005jxm5rgnfbphy	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-18 07:01:34.87	2026-05-18 07:01:34.87
cmqep6tai00r4jxp5hmzfu0rh	cmqep6t7y00gsjxp5mtilww6e	cmqep6t9500jmjxp5bsu40yub	3	in_progress	2026-06-26 09:02:23.693	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:02:23.693
cmp6jb4vg000rjxdfdy058obw	cmp6jb4ux000kjxdfnh0bkm21	cmp6jb4v8000ojxdf7u9738jx	1	completed	2026-05-15 06:26:37.803	2026-05-18 07:55:50.201	2026-05-18 07:55:27.76	cmp6j8ifp0002jxdffdiyvvw3	เอเอ๊ซักกะดุ๊ง ซักกะดิ๊ง	รับมา 500	ภูมิใจไทย	internal	2026-05-18 07:56:39.25	2026-05-15 06:26:37.804	2026-05-18 07:56:39.25
cmp6jb4vg000tjxdfzq969hzm	cmp6jb4ux000kjxdfnh0bkm21	cmp6jb4v8000ojxdf7u9738jx	5	completed	2026-05-22 11:04:10.418	2026-06-16 05:44:55.961	2026-06-16 05:44:53.043	cmp6j8ifp0002jxdffdiyvvw3	\N	\N	\N	\N	\N	2026-05-15 06:26:37.804	2026-06-16 05:44:55.962
cmqf02txa0071jxopdog77t1s	cmqf02twi0061jxopfw2ixih5	cmqf02twx006ajxop3fgj1itn	1	completed	2026-06-15 09:17:55.58	2026-06-26 09:01:24.252	2026-06-26 09:01:20.789	cmq0kyw85007kjx239k25z1ge	\N	ไม่มั่นใจในความสามารถพิเศษ	ปัญหาครอบครัว	internal	2026-06-26 09:03:15.952	2026-06-15 09:17:55.581	2026-06-26 09:03:15.953
cmprve8mc002ojx5q6u7fdpt3	cmprve8l5000yjx5qxjdz6rp8	cmprve8lv001tjx5qsk7gp8bh	2	in_progress	2026-06-16 05:51:12.554	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-06-16 05:51:12.554
cmprve8mc002njx5qe5b4id62	cmprve8l5000yjx5qxjdz6rp8	cmprve8lv001tjx5qsk7gp8bh	1	completed	2026-05-30 04:48:07.712	2026-06-16 05:51:12.548	2026-06-16 05:51:09.925	cmp6j8ifp0002jxdffdiyvvw3	\N	ดวดสด	กมเฝกฝก	internal	2026-06-16 05:51:21.543	2026-05-30 04:48:07.716	2026-06-16 05:51:21.544
cmpauvmza0006jxm5fjde095z	cmpauvmyx0004jxm5zwck4o1s	cmpauvmz50005jxm5rgnfbphy	1	completed	2026-05-18 07:01:34.869	2026-05-22 10:58:58.432	2026-05-27 00:00:00	cmp6j8ifp0002jxdffdiyvvw3	ไอ้ทุยยยยยยยยยยยยยย	ควายยยยย	เหี้ยยยยยยน	internal	2026-05-22 10:59:14.288	2026-05-18 07:01:34.87	2026-05-22 10:59:14.289
cmp6jb4vg000sjxdfmukrrspx	cmp6jb4ux000kjxdfnh0bkm21	cmp6jb4v8000ojxdf7u9738jx	2	completed	2026-05-18 07:55:50.205	2026-05-22 11:04:10.412	2026-05-22 11:04:07.589	cmp6j8ifp0002jxdffdiyvvw3	\N	\N	\N	\N	\N	2026-05-15 06:26:37.804	2026-05-22 11:04:10.412
cmr254jpo00hcjxctowlem2wr	cmr254jj6001ijxct0thvp7fd	cmr254jms009fjxctm2uqzgyg	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmpauvmza0007jxm5htpspi9z	cmpauvmyx0004jxm5zwck4o1s	cmpauvmz50005jxm5rgnfbphy	2	in_progress	2026-05-22 10:58:58.44	\N	\N	cmp6j8ifp0002jxdffdiyvvw3	\N	\N	\N	\N	\N	2026-05-18 07:01:34.87	2026-05-23 05:28:10.543
cmqep6tai00qkjxp5nous76nk	cmqep6t7y00gnjxp50tru9y0t	cmqep6t9500jhjxp5ee6zin61	2	completed	2026-06-19 12:53:35.344	2026-06-26 09:07:12.284	2026-06-26 09:07:09.884	cmq0kwit80066jx23pw930nx1	เสริมกำลังใจเพื่อหาคุณค่าในตัวเอง	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:07:12.286
cmpjfwomx002bjx2mepkorl3i	cmpjfwomm0026jx2m2dnegu2z	cmpjfwomt002ajx2ml4olpqtd	1	in_progress	2026-05-24 07:12:25.017	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-24 07:12:25.018	2026-05-24 07:12:25.018
cmpjfwomy002cjx2mjlk80sn9	cmpjfwomm0026jx2m2dnegu2z	cmpjfwomt002ajx2ml4olpqtd	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-24 07:12:25.018	2026-05-24 07:12:25.018
cmpjfwomy002djx2muronha7n	cmpjfwomm0026jx2m2dnegu2z	cmpjfwomt002ajx2ml4olpqtd	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-24 07:12:25.018	2026-05-24 07:12:25.018
cmqf02txa0075jxop3x8b5yvu	cmqf02twi0062jxop3z5jrxny	cmqf02twx006bjxopdyn7ss4z	1	completed	2026-06-15 09:17:55.58	2026-06-26 09:05:15.052	2026-06-26 09:05:08.043	cmq0kyw85007kjx239k25z1ge	\N	ไม่มีความมั่นใจในตัวเองมากพอ 	มีปัญหาด้านเพื่อน	internal	2026-06-26 09:09:03.416	2026-06-15 09:17:55.581	2026-06-26 09:09:03.417
cmqf02txb007cjxopmmred5yo	cmqf02twi0063jxopuqpquhah	cmqf02twx006cjxopbakfs0te	3	in_progress	2026-06-26 09:10:24.156	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 09:17:55.581	2026-06-26 09:10:24.157
cmprve8mc002pjx5qn818s17l	cmprve8l5000yjx5qxjdz6rp8	cmprve8lv001tjx5qsk7gp8bh	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8mc002qjx5q3h9z7qfb	cmprve8l50010jx5qlo0nyjtc	cmprve8lv001vjx5qi5tqmg6p	1	in_progress	2026-05-30 04:48:07.712	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8mc002rjx5qplmjwnmj	cmprve8l50010jx5qlo0nyjtc	cmprve8lv001vjx5qi5tqmg6p	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8mc002sjx5qzp4mi2od	cmprve8l50010jx5qlo0nyjtc	cmprve8lv001vjx5qi5tqmg6p	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8mc002tjx5q2hme2x4r	cmprve8l50010jx5qlo0nyjtc	cmprve8lv001vjx5qi5tqmg6p	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8mc002ujx5q6mjtpffl	cmprve8l50010jx5qlo0nyjtc	cmprve8lv001vjx5qi5tqmg6p	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8mc002wjx5q8khmbipe	cmprve8l50012jx5qj6qlzxu9	cmprve8lw001xjx5qrsnrzx1x	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8mc002xjx5q56rzfwf6	cmprve8l50012jx5qj6qlzxu9	cmprve8lw001xjx5qrsnrzx1x	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8mc002yjx5qpzv9rnc9	cmprve8l50012jx5qj6qlzxu9	cmprve8lw001xjx5qrsnrzx1x	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8mc002zjx5qky7er7d6	cmprve8l50012jx5qj6qlzxu9	cmprve8lw001xjx5qrsnrzx1x	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8mc0031jx5qm1gei1is	cmprve8l50013jx5q08thkxep	cmprve8lw001yjx5qvxwwhcyr	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmp6jb4vg000ujxdf34vopj68	cmp6jb4ux000mjxdf5pxamnft	cmp6jb4v8000qjxdfgf02117g	1	completed	2026-05-15 06:26:37.803	2026-06-16 09:22:08.979	2026-05-26 00:00:00	cmp6j8ifp0002jxdffdiyvvw3	\N	gsgdagadg	adhadhadhadh	internal	2026-06-16 09:22:15.968	2026-05-15 06:26:37.804	2026-06-16 09:22:15.969
cmqep6tae00l7jxp5p21vs13f	cmqep6t7x00f0jxp5gvfwi04n	cmqep6t9300hujxp557oed88p	1	completed	2026-06-15 04:13:05.592	2026-06-26 09:13:10.96	2026-06-26 09:13:09.321	cmq0kyw85007kjx239k25z1ge	\N	ไม่มั่นใจเรื่องการเรียนหนังสือ	ปัญหาครอบครัว	internal	2026-06-26 09:13:46.928	2026-06-15 04:13:05.602	2026-06-26 09:13:46.929
cmqep6tae00kvjxp506he1qdw	cmqep6t7x00ewjxp58q8ujqlw	cmqep6t9300hqjxp5w9e5hxew	2	completed	2026-06-26 09:21:00.814	2026-06-26 09:24:18.044	2026-06-26 09:23:32.456	cmq0kyw85007kjx239k25z1ge	อยากพัฒนาเรื่องการเรียน	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:24:18.045
cmprve8md0032jx5q7rsm7vi7	cmprve8l50013jx5q08thkxep	cmprve8lw001yjx5qvxwwhcyr	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md0033jx5qle4jtb8d	cmprve8l50013jx5q08thkxep	cmprve8lw001yjx5qvxwwhcyr	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md0034jx5qz56ftez2	cmprve8l50013jx5q08thkxep	cmprve8lw001yjx5qvxwwhcyr	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md0036jx5qnrm9utmm	cmprve8l50017jx5qc1g3ryzt	cmprve8lw0022jx5q17ojvv2g	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md0037jx5qh2h5whtb	cmprve8l50017jx5qc1g3ryzt	cmprve8lw0022jx5q17ojvv2g	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md0038jx5qxwx7c99h	cmprve8l50017jx5qc1g3ryzt	cmprve8lw0022jx5q17ojvv2g	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md0039jx5qgwpvmssc	cmprve8l50017jx5qc1g3ryzt	cmprve8lw0022jx5q17ojvv2g	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md003ajx5quio1t3dv	cmprve8l50018jx5q45abost6	cmprve8lw0023jx5q1rou1e2j	1	in_progress	2026-05-30 04:48:07.712	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md003bjx5qs6nrz622	cmprve8l50018jx5q45abost6	cmprve8lw0023jx5q1rou1e2j	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md003cjx5qm4il7vm8	cmprve8l50018jx5q45abost6	cmprve8lw0023jx5q1rou1e2j	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md003djx5qahej2q2i	cmprve8l50018jx5q45abost6	cmprve8lw0023jx5q1rou1e2j	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md003ejx5qp9e9j0mt	cmprve8l50018jx5q45abost6	cmprve8lw0023jx5q1rou1e2j	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md003sjx5q4lqwab79	cmprve8l5001cjx5qpmcf03xl	cmprve8lw0027jx5q18bf5xl8	1	in_progress	2026-05-30 04:48:07.712	\N	\N	cmp6j8ifp0002jxdffdiyvvw3	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-06-23 10:58:01.995
cmprve8md003gjx5qjrzp84wj	cmprve8l50019jx5qyzrvi13i	cmprve8lw0024jx5qor5979de	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md003hjx5qtlxka8of	cmprve8l50019jx5qyzrvi13i	cmprve8lw0024jx5qor5979de	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md003ijx5qqtmllq6z	cmprve8l50019jx5qyzrvi13i	cmprve8lw0024jx5qor5979de	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md003jjx5qiefg737a	cmprve8l5001ajx5qewbyvflm	cmprve8lw0025jx5qjaoxyfxp	1	in_progress	2026-05-30 04:48:07.712	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md003kjx5qbq6ghr58	cmprve8l5001ajx5qewbyvflm	cmprve8lw0025jx5qjaoxyfxp	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md003ljx5qzwtgqbyy	cmprve8l5001ajx5qewbyvflm	cmprve8lw0025jx5qjaoxyfxp	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md003mjx5q5o0ybba3	cmprve8l5001ajx5qewbyvflm	cmprve8lw0025jx5qjaoxyfxp	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md003njx5qyc5efviw	cmprve8l5001ajx5qewbyvflm	cmprve8lw0025jx5qjaoxyfxp	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md003ojx5qq7ff723q	cmprve8l5001bjx5qvwvekbo3	cmprve8lw0026jx5q4v0ioe5z	1	in_progress	2026-05-30 04:48:07.712	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md003pjx5q9hqxc0rq	cmprve8l5001bjx5qvwvekbo3	cmprve8lw0026jx5q4v0ioe5z	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md003qjx5q2lywract	cmprve8l5001bjx5qvwvekbo3	cmprve8lw0026jx5q4v0ioe5z	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md003rjx5q73zpq0yq	cmprve8l5001bjx5qvwvekbo3	cmprve8lw0026jx5q4v0ioe5z	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md003tjx5q01gxi9mi	cmprve8l5001cjx5qpmcf03xl	cmprve8lw0027jx5q18bf5xl8	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md003ujx5qfnhccs0y	cmprve8l5001cjx5qpmcf03xl	cmprve8lw0027jx5q18bf5xl8	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md003vjx5qhzhjfzkf	cmprve8l5001cjx5qpmcf03xl	cmprve8lw0027jx5q18bf5xl8	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md003wjx5qw3fipjz4	cmprve8l5001cjx5qpmcf03xl	cmprve8lw0027jx5q18bf5xl8	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md003yjx5qwuqfl57y	cmprve8l5001ejx5qyacdv8ge	cmprve8lw0029jx5ql8ykr8pd	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md003zjx5q7op907x5	cmprve8l5001ejx5qyacdv8ge	cmprve8lw0029jx5ql8ykr8pd	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md0040jx5qefkox4a8	cmprve8l5001ejx5qyacdv8ge	cmprve8lw0029jx5ql8ykr8pd	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me0041jx5qmxaz154w	cmprve8l5001fjx5qwrwbswpu	cmprve8lw002ajx5qtjgwem32	1	in_progress	2026-05-30 04:48:07.712	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me0042jx5q3cqiirap	cmprve8l5001fjx5qwrwbswpu	cmprve8lw002ajx5qtjgwem32	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me0043jx5qoij5b7gy	cmprve8l5001fjx5qwrwbswpu	cmprve8lw002ajx5qtjgwem32	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me0044jx5q2vcri1qr	cmprve8l5001fjx5qwrwbswpu	cmprve8lw002ajx5qtjgwem32	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmr254jpo00hdjxct4sxe3k0h	cmr254jj6001ijxct0thvp7fd	cmr254jms009fjxctm2uqzgyg	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmprve8me0046jx5qpasyux5w	cmprve8l5001gjx5qqjjvx9qi	cmprve8lw002bjx5qcy63me5z	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me0047jx5q1bop6393	cmprve8l5001gjx5qqjjvx9qi	cmprve8lw002bjx5qcy63me5z	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me0048jx5qct4ctryi	cmprve8l5001gjx5qqjjvx9qi	cmprve8lw002bjx5qcy63me5z	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me0049jx5qkmo1ceyk	cmprve8l5001gjx5qqjjvx9qi	cmprve8lw002bjx5qcy63me5z	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me004ajx5q43wrp60a	cmprve8l5001hjx5qbvppe3pc	cmprve8lw002cjx5qutnavt4a	1	in_progress	2026-05-30 04:48:07.712	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me004bjx5qpp57fkbf	cmprve8l5001hjx5qbvppe3pc	cmprve8lw002cjx5qutnavt4a	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me004cjx5qznol7u5e	cmprve8l5001hjx5qbvppe3pc	cmprve8lw002cjx5qutnavt4a	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me004djx5qg2mvnrl4	cmprve8l5001hjx5qbvppe3pc	cmprve8lw002cjx5qutnavt4a	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me004ejx5qp0ovpznr	cmprve8l5001jjx5qp7ocohgz	cmprve8lw002ejx5qjdoa7scn	1	in_progress	2026-05-30 04:48:07.712	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me004fjx5qwqs3nwd5	cmprve8l5001jjx5qp7ocohgz	cmprve8lw002ejx5qjdoa7scn	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me004gjx5qny85k3j4	cmprve8l5001jjx5qp7ocohgz	cmprve8lw002ejx5qjdoa7scn	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me004hjx5qc51yuxc6	cmprve8l5001jjx5qp7ocohgz	cmprve8lw002ejx5qjdoa7scn	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me004ijx5qz4vabr4m	cmprve8l5001ljx5q0277mh23	cmprve8lw002gjx5qio594g89	1	in_progress	2026-05-30 04:48:07.712	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me004jjx5qepmf36y5	cmprve8l5001ljx5q0277mh23	cmprve8lw002gjx5qio594g89	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me004kjx5qtv5g1qf6	cmprve8l5001ljx5q0277mh23	cmprve8lw002gjx5qio594g89	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me004ljx5qtyerwvlx	cmprve8l5001mjx5qqybqucjk	cmprve8lw002hjx5q3cidqmox	1	in_progress	2026-05-30 04:48:07.712	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me004mjx5qdiu34jcw	cmprve8l5001mjx5qqybqucjk	cmprve8lw002hjx5q3cidqmox	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md0035jx5q2nat2qem	cmprve8l50017jx5qc1g3ryzt	cmprve8lw0022jx5q17ojvv2g	1	in_progress	2026-05-30 04:48:07.712	\N	\N	cmp6j8ifp0002jxdffdiyvvw3	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-06-10 05:28:24.051
cmprve8md003xjx5q0rbny11o	cmprve8l5001ejx5qyacdv8ge	cmprve8lw0029jx5ql8ykr8pd	1	in_progress	2026-05-30 04:48:07.712	\N	\N	cmp6j8ifp0002jxdffdiyvvw3	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-06-13 09:34:45.015
cmprve8me004njx5qvip7rt0i	cmprve8l5001mjx5qqybqucjk	cmprve8lw002hjx5q3cidqmox	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me004ojx5qxzkp3dr4	cmprve8l5001mjx5qqybqucjk	cmprve8lw002hjx5q3cidqmox	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me004pjx5qnokkaj39	cmprve8l5001mjx5qqybqucjk	cmprve8lw002hjx5q3cidqmox	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me004qjx5qk67uhbao	cmprve8l5001njx5qjladhnpl	cmprve8lw002ijx5qgmmb9pq0	1	in_progress	2026-05-30 04:48:07.712	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me004rjx5qogki1tnf	cmprve8l5001njx5qjladhnpl	cmprve8lw002ijx5qgmmb9pq0	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me004sjx5qig28g9qy	cmprve8l5001njx5qjladhnpl	cmprve8lw002ijx5qgmmb9pq0	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me004tjx5qo3muqf29	cmprve8l5001njx5qjladhnpl	cmprve8lw002ijx5qgmmb9pq0	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me004ujx5q6hl9vrck	cmprve8l5001ojx5q9dn40x1c	cmprve8lw002jjx5qkqf1n4bi	1	in_progress	2026-05-30 04:48:07.712	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me004vjx5qkap0ma9r	cmprve8l5001ojx5q9dn40x1c	cmprve8lw002jjx5qkqf1n4bi	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me004wjx5qcz04vjxg	cmprve8l5001ojx5q9dn40x1c	cmprve8lw002jjx5qkqf1n4bi	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me004xjx5qllhhpbk1	cmprve8l5001ojx5q9dn40x1c	cmprve8lw002jjx5qkqf1n4bi	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me004yjx5q17o127yt	cmprve8l5001ojx5q9dn40x1c	cmprve8lw002jjx5qkqf1n4bi	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me004zjx5qr239z67r	cmprve8l5001pjx5qzq4cy4y9	cmprve8lw002kjx5qxq1ws06u	1	in_progress	2026-05-30 04:48:07.712	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8me0050jx5q0q4ufyxb	cmprve8l5001pjx5qzq4cy4y9	cmprve8lw002kjx5qxq1ws06u	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8mf0051jx5qvpe9041s	cmprve8l5001pjx5qzq4cy4y9	cmprve8lw002kjx5qxq1ws06u	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8mf0052jx5qg9oa9os0	cmprve8l5001pjx5qzq4cy4y9	cmprve8lw002kjx5qxq1ws06u	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-05-30 04:48:07.716
cmprve8md003fjx5qkdcj1phi	cmprve8l50019jx5qyzrvi13i	cmprve8lw0024jx5qor5979de	1	in_progress	2026-05-30 04:48:07.712	\N	\N	cmp6j8ifp0002jxdffdiyvvw3	\N	\N	\N	\N	\N	2026-05-30 04:48:07.716	2026-06-01 05:26:44.827
cmqep6tak00tejxp5vnccqcrj	cmqep6t7y00hjjxp5xa6i02q3	cmqep6t9500kdjxp5zbtb2lnz	5	completed	2026-06-26 08:48:47.128	2026-07-03 09:30:37.175	2026-07-03 09:30:32.75	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:30:37.176
cmpvn6tie003hjxjcfubvn9ra	cmpvn6thw002ojxjci1w6vzmy	cmpvn6ti60032jxjc0ft8evyd	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-01 20:09:29.318	2026-06-01 20:09:29.318
cmpvn6tie003ljxjcucphh2ys	cmpvn6thw002pjxjcpvv8b9pu	cmpvn6ti60033jxjc96zmm4j2	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-01 20:09:29.318	2026-06-01 20:09:29.318
cmpvn6tie003mjxjc4diovova	cmpvn6thw002pjxjcpvv8b9pu	cmpvn6ti60033jxjc96zmm4j2	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-01 20:09:29.318	2026-06-01 20:09:29.318
cmpvn6tie003pjxjc4gmtfpmz	cmpvn6thx002tjxjck9twdrt3	cmpvn6ti70037jxjcb1ujrzzf	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-01 20:09:29.318	2026-06-01 20:09:29.318
cmpvn6tie003sjxjcs55n4f8h	cmpvn6thx002ujxjc5a4bxgmx	cmpvn6ti70038jxjciazd9fky	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-01 20:09:29.318	2026-06-01 20:09:29.318
cmpvn6tie003tjxjcu6er5ow8	cmpvn6thx002vjxjca96funyx	cmpvn6ti70039jxjcqu708176	1	in_progress	2026-06-01 20:09:29.317	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-01 20:09:29.318	2026-06-01 20:09:29.318
cmpvn6tie003ujxjcsa3ocgcu	cmpvn6thx002vjxjca96funyx	cmpvn6ti70039jxjcqu708176	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-01 20:09:29.318	2026-06-01 20:09:29.318
cmpvn6tie003vjxjcjnvnt32y	cmpvn6thx002vjxjca96funyx	cmpvn6ti70039jxjcqu708176	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-01 20:09:29.318	2026-06-01 20:09:29.318
cmpvn6tie003wjxjc38rfejgx	cmpvn6thx002vjxjca96funyx	cmpvn6ti70039jxjcqu708176	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-01 20:09:29.318	2026-06-01 20:09:29.318
cmpvn6tie003xjxjcey015k39	cmpvn6thx002vjxjca96funyx	cmpvn6ti70039jxjcqu708176	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-01 20:09:29.318	2026-06-01 20:09:29.318
cmpvn6tie003gjxjc3e7mj8aw	cmpvn6thw002ojxjci1w6vzmy	cmpvn6ti60032jxjc0ft8evyd	2	in_progress	2026-06-08 04:36:53.529	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-01 20:09:29.318	2026-06-08 04:36:53.53
cmpvn6tie003ijxjce90vzloi	cmpvn6thw002pjxjcpvv8b9pu	cmpvn6ti60033jxjc96zmm4j2	1	completed	2026-06-01 20:09:29.317	2026-06-01 20:14:12.9	2026-06-01 20:13:58.222	cmpmdmbqv000kjxgmprk5t2o6	\N	ผผผ	ปปป	internal	2026-06-01 20:14:32.396	2026-06-01 20:09:29.318	2026-06-01 20:14:32.397
cmpvn6tie003fjxjc0hu1emp7	cmpvn6thw002ojxjci1w6vzmy	cmpvn6ti60032jxjc0ft8evyd	1	completed	2026-06-01 20:09:29.317	2026-06-08 04:36:53.524	2026-06-08 04:36:51.724	cmpmdmbqv000kjxgmprk5t2o6	\N	า	นร่ย่	internal	2026-06-08 04:36:58.728	2026-06-01 20:09:29.318	2026-06-08 04:36:58.729
cmpvn6tie003jjxjcbjh21oa7	cmpvn6thw002pjxjcpvv8b9pu	cmpvn6ti60033jxjc96zmm4j2	2	completed	2026-06-01 20:14:12.908	2026-06-03 18:39:40.62	2026-06-03 18:39:28.454	cmpmdmbqv000kjxgmprk5t2o6	าาา	\N	\N	\N	\N	2026-06-01 20:09:29.318	2026-06-03 18:39:40.621
cmpvn6tie003kjxjcb0pesww3	cmpvn6thw002pjxjcpvv8b9pu	cmpvn6ti60033jxjc96zmm4j2	3	in_progress	2026-06-03 18:39:40.628	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-01 20:09:29.318	2026-06-03 18:39:40.629
cmpvn6tie003cjxjcyu4v1g5p	cmpvn6thw002njxjc3ne9m690	cmpvn6ti60031jxjcnkgbehbu	1	completed	2026-06-01 20:09:29.317	2026-06-08 04:53:08.523	2026-06-08 04:53:04.878	cmpmdmbqv000kjxgmprk5t2o6	\N	ไืไำานเนรำไเ้ยนำๆ	กดำนยเ่ยนๆ	internal	2026-06-08 04:53:19.401	2026-06-01 20:09:29.318	2026-06-08 04:53:19.402
cmpvn6tie003qjxjceen74w8z	cmpvn6thx002ujxjc5a4bxgmx	cmpvn6ti70038jxjciazd9fky	1	completed	2026-06-01 20:09:29.317	2026-06-17 04:00:14.341	2026-06-17 04:00:06.198	cmpmdmbqv000kjxgmprk5t2o6	\N	Aaa	Ccc	internal	2026-06-17 04:00:33.701	2026-06-01 20:09:29.318	2026-06-17 04:00:33.702
cmpvn6tie003djxjc76yah9fb	cmpvn6thw002njxjc3ne9m690	cmpvn6ti60031jxjcnkgbehbu	2	completed	2026-06-08 04:53:08.538	2026-06-08 04:54:44.232	2026-06-08 04:54:42.851	cmpmdmbqv000kjxgmprk5t2o6	าืสา่ส่ร	\N	\N	\N	\N	2026-06-01 20:09:29.318	2026-06-08 04:54:50.526
cmqalpibn006mjxp5ryqqirsk	cmqalpi960012jxp5rhx9ouoz	cmqalpiam003ujxp5npq54s70	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn006njxp5k9nk03fn	cmqalpi960012jxp5rhx9ouoz	cmqalpiam003ujxp5npq54s70	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn006ojxp5d9pt78kl	cmqalpi960012jxp5rhx9ouoz	cmqalpiam003ujxp5npq54s70	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn006pjxp57wbpqm95	cmqalpi960012jxp5rhx9ouoz	cmqalpiam003ujxp5npq54s70	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn006qjxp5u7pa352y	cmqalpi960013jxp5wuog0od9	cmqalpiam003vjxp57o098r5p	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn006rjxp5mr0i5y4f	cmqalpi960013jxp5wuog0od9	cmqalpiam003vjxp57o098r5p	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn006sjxp5ld0mxlfe	cmqalpi960013jxp5wuog0od9	cmqalpiam003vjxp57o098r5p	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn006tjxp5xexwfx2r	cmqalpi960014jxp5tl5up5la	cmqalpiam003wjxp51a4ruaqh	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn006ujxp5i0jfumup	cmqalpi960014jxp5tl5up5la	cmqalpiam003wjxp51a4ruaqh	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn006vjxp5zeew7kvj	cmqalpi960014jxp5tl5up5la	cmqalpiam003wjxp51a4ruaqh	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmpvn6tie003ejxjcpcnnbkqh	cmpvn6thw002njxjc3ne9m690	cmpvn6ti60031jxjcnkgbehbu	5	completed	2026-06-08 04:54:44.235	2026-06-17 03:30:14.215	2026-06-17 03:30:10.411	cmpmdmbqv000kjxgmprk5t2o6	\N	\N	\N	\N	\N	2026-06-01 20:09:29.318	2026-06-17 03:30:14.216
cmpvn6tie003njxjcqcpjbirf	cmpvn6thx002tjxjck9twdrt3	cmpvn6ti70037jxjcb1ujrzzf	1	completed	2026-06-01 20:09:29.317	2026-06-17 03:54:34.766	2026-06-17 03:54:25.648	cmpmdmbqv000kjxgmprk5t2o6	\N	\N	\N	\N	\N	2026-06-01 20:09:29.318	2026-06-17 03:54:34.767
cmpvn6tie003ojxjclr77cuqa	cmpvn6thx002tjxjck9twdrt3	cmpvn6ti70037jxjcb1ujrzzf	2	in_progress	2026-06-17 03:54:34.774	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-01 20:09:29.318	2026-06-17 03:54:34.776
cmpvn6tie003rjxjcr9giqx5a	cmpvn6thx002ujxjc5a4bxgmx	cmpvn6ti70038jxjciazd9fky	2	in_progress	2026-06-17 04:00:14.35	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-01 20:09:29.318	2026-06-17 04:00:14.351
cmqalpibn006wjxp5k6txqx7y	cmqalpi960015jxp5nwmfy5v6	cmqalpiam003xjxp5112lq1ag	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn006xjxp53tm3p737	cmqalpi960015jxp5nwmfy5v6	cmqalpiam003xjxp5112lq1ag	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn006yjxp5j5xy6yuk	cmqalpi960015jxp5nwmfy5v6	cmqalpiam003xjxp5112lq1ag	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn006zjxp5pulnvqdf	cmqalpi960016jxp5cra084p3	cmqalpiam003yjxp5jbogpimw	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn0070jxp5yh2cl53w	cmqalpi960016jxp5cra084p3	cmqalpiam003yjxp5jbogpimw	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn0071jxp51c5tkj08	cmqalpi960016jxp5cra084p3	cmqalpiam003yjxp5jbogpimw	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn0072jxp52see5geg	cmqalpi960017jxp50ebbggjc	cmqalpiam003zjxp51r2sl929	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn0073jxp52w7kk1y2	cmqalpi960017jxp50ebbggjc	cmqalpiam003zjxp51r2sl929	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn0074jxp5098e4hfn	cmqalpi960017jxp50ebbggjc	cmqalpiam003zjxp51r2sl929	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn0075jxp54lub6v1x	cmqalpi960017jxp50ebbggjc	cmqalpiam003zjxp51r2sl929	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn0076jxp56vztifls	cmqalpi96001ajxp5uqzy8g52	cmqalpiam0042jxp5wovp55io	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn0077jxp55vji0k9p	cmqalpi96001ajxp5uqzy8g52	cmqalpiam0042jxp5wovp55io	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn0078jxp5wvdn6lwy	cmqalpi96001ajxp5uqzy8g52	cmqalpiam0042jxp5wovp55io	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn0079jxp52f2hjbdo	cmqalpi96001ajxp5uqzy8g52	cmqalpiam0042jxp5wovp55io	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn007ajxp5da3pbism	cmqalpi96001cjxp5trw9j8uz	cmqalpiam0044jxp5xh6s3kj4	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn007bjxp5crw9954f	cmqalpi96001cjxp5trw9j8uz	cmqalpiam0044jxp5xh6s3kj4	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn007cjxp5zxub0r46	cmqalpi96001cjxp5trw9j8uz	cmqalpiam0044jxp5xh6s3kj4	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn007djxp5ze8fzyiu	cmqalpi96001gjxp54ob73o79	cmqalpiam0048jxp5j4jhr774	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn007ejxp51vrxv8i2	cmqalpi96001gjxp54ob73o79	cmqalpiam0048jxp5j4jhr774	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn007fjxp5vmjh6ip6	cmqalpi96001gjxp54ob73o79	cmqalpiam0048jxp5j4jhr774	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn007gjxp5cstgtbdi	cmqalpi96001gjxp54ob73o79	cmqalpiam0048jxp5j4jhr774	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn007hjxp5ezsp2jrb	cmqalpi96001hjxp5d80gmqv6	cmqalpiam0049jxp5222k74tx	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn007ijxp5nqht4v34	cmqalpi96001hjxp5d80gmqv6	cmqalpiam0049jxp5222k74tx	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn007jjxp5n2mwfozf	cmqalpi96001hjxp5d80gmqv6	cmqalpiam0049jxp5222k74tx	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibn007kjxp5jexxv4mh	cmqalpi96001ijxp509o2ix3a	cmqalpiam004ajxp51zvhqkmp	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo007ljxp51r33yz72	cmqalpi96001ijxp509o2ix3a	cmqalpiam004ajxp51zvhqkmp	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo007mjxp5wcx7xl8i	cmqalpi96001ijxp509o2ix3a	cmqalpiam004ajxp51zvhqkmp	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo007njxp5uziyr1dm	cmqalpi96001kjxp5tzyt114n	cmqalpiam004cjxp531zu2nlg	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo007ojxp54x7mg8zl	cmqalpi96001kjxp5tzyt114n	cmqalpiam004cjxp531zu2nlg	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo007pjxp52olsoh3p	cmqalpi96001kjxp5tzyt114n	cmqalpiam004cjxp531zu2nlg	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo007qjxp5shrhbkej	cmqalpi96001kjxp5tzyt114n	cmqalpiam004cjxp531zu2nlg	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo007rjxp51adolkcf	cmqalpi96001ljxp5lana3l03	cmqalpian004djxp5gz7v0lt8	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo007sjxp5qda4w5hj	cmqalpi96001ljxp5lana3l03	cmqalpian004djxp5gz7v0lt8	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo007tjxp5ywz15agx	cmqalpi96001ljxp5lana3l03	cmqalpian004djxp5gz7v0lt8	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo007ujxp5mngj1u8d	cmqalpi96001ljxp5lana3l03	cmqalpian004djxp5gz7v0lt8	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo007vjxp5gue9lzz1	cmqalpi96001ljxp5lana3l03	cmqalpian004djxp5gz7v0lt8	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo007wjxp5zonctupc	cmqalpi96001mjxp5o6bktrmr	cmqalpian004ejxp511wcwaq7	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo007xjxp5f6r2686s	cmqalpi96001mjxp5o6bktrmr	cmqalpian004ejxp511wcwaq7	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo007yjxp5z8krm6oe	cmqalpi96001mjxp5o6bktrmr	cmqalpian004ejxp511wcwaq7	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo007zjxp53c3minwc	cmqalpi96001pjxp5l0fi6jmt	cmqalpian004hjxp5b5a7k1w3	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo0080jxp56z2icl33	cmqalpi96001pjxp5l0fi6jmt	cmqalpian004hjxp5b5a7k1w3	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo0081jxp5ycgvydr4	cmqalpi96001pjxp5l0fi6jmt	cmqalpian004hjxp5b5a7k1w3	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo0082jxp51shy2137	cmqalpi96001pjxp5l0fi6jmt	cmqalpian004hjxp5b5a7k1w3	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo0083jxp59w5r3loe	cmqalpi96001pjxp5l0fi6jmt	cmqalpian004hjxp5b5a7k1w3	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo0084jxp555kbmlcp	cmqalpi96001rjxp588l8e3vd	cmqalpian004jjxp5505zeaon	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo0085jxp51995xw5m	cmqalpi96001rjxp588l8e3vd	cmqalpian004jjxp5505zeaon	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo0086jxp5m9gk8k9h	cmqalpi96001rjxp588l8e3vd	cmqalpian004jjxp5505zeaon	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo0087jxp55yfbdt6u	cmqalpi96001sjxp5vwnpfxot	cmqalpian004kjxp5aogjkn88	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo0088jxp5sqgn7mn3	cmqalpi96001sjxp5vwnpfxot	cmqalpian004kjxp5aogjkn88	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo0089jxp5i2zbprf4	cmqalpi96001sjxp5vwnpfxot	cmqalpian004kjxp5aogjkn88	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo008ajxp57nl6gj33	cmqalpi96001tjxp5fdpniekj	cmqalpian004ljxp59c7tejh4	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo008bjxp5wipqomj6	cmqalpi96001tjxp5fdpniekj	cmqalpian004ljxp59c7tejh4	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo008cjxp5z0ywpsrq	cmqalpi96001tjxp5fdpniekj	cmqalpian004ljxp59c7tejh4	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo008djxp5h5so6rza	cmqalpi96001tjxp5fdpniekj	cmqalpian004ljxp59c7tejh4	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo008ejxp5v0to7ryj	cmqalpi96001ujxp5tu4c79kh	cmqalpian004mjxp5hiw9mn6x	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo008fjxp5csfkauw3	cmqalpi96001ujxp5tu4c79kh	cmqalpian004mjxp5hiw9mn6x	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo008gjxp5pgl9furc	cmqalpi96001ujxp5tu4c79kh	cmqalpian004mjxp5hiw9mn6x	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo008hjxp5juixzn0a	cmqalpi96001ujxp5tu4c79kh	cmqalpian004mjxp5hiw9mn6x	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo008ijxp5c009thtt	cmqalpi96001ujxp5tu4c79kh	cmqalpian004mjxp5hiw9mn6x	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo008jjxp5n7ryrr4o	cmqalpi97001vjxp5sdz06dbq	cmqalpian004njxp57fc45mr1	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo008kjxp5ic3f8x1p	cmqalpi97001vjxp5sdz06dbq	cmqalpian004njxp57fc45mr1	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo008ljxp5rmjiaon7	cmqalpi97001vjxp5sdz06dbq	cmqalpian004njxp57fc45mr1	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo008mjxp5jnctsb0x	cmqalpi97001wjxp5xshf4tfm	cmqalpian004ojxp5k7p6z47m	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo008njxp5szz7o4n2	cmqalpi97001wjxp5xshf4tfm	cmqalpian004ojxp5k7p6z47m	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo008ojxp576k6pz8p	cmqalpi97001wjxp5xshf4tfm	cmqalpian004ojxp5k7p6z47m	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo008pjxp5ynokf6bc	cmqalpi97001xjxp5j5wfn9ue	cmqalpian004pjxp5934wheos	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo008qjxp56qud89by	cmqalpi97001xjxp5j5wfn9ue	cmqalpian004pjxp5934wheos	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo008rjxp5l1081dy0	cmqalpi97001xjxp5j5wfn9ue	cmqalpian004pjxp5934wheos	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo008sjxp5edo57fnk	cmqalpi97001xjxp5j5wfn9ue	cmqalpian004pjxp5934wheos	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo008tjxp5aqu1j766	cmqalpi97001yjxp51saawq2l	cmqalpian004qjxp5c2kv1zag	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo008ujxp57i4kxwk3	cmqalpi97001yjxp51saawq2l	cmqalpian004qjxp5c2kv1zag	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo008vjxp5ouzjfy32	cmqalpi97001yjxp51saawq2l	cmqalpian004qjxp5c2kv1zag	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo008wjxp59bmphnk7	cmqalpi97001zjxp5qg7w9o1c	cmqalpian004rjxp5b5hv7yyj	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo008xjxp5xrd8dgiq	cmqalpi97001zjxp5qg7w9o1c	cmqalpian004rjxp5b5hv7yyj	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo008yjxp511xek5hz	cmqalpi97001zjxp5qg7w9o1c	cmqalpian004rjxp5b5hv7yyj	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo008zjxp5me71npbd	cmqalpi970022jxp5miadisl2	cmqalpian004ujxp5qf1h0wn0	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo0090jxp55nyqxajl	cmqalpi970022jxp5miadisl2	cmqalpian004ujxp5qf1h0wn0	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo0091jxp530zdj915	cmqalpi970022jxp5miadisl2	cmqalpian004ujxp5qf1h0wn0	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo0092jxp5mdcgidsn	cmqalpi970024jxp54fdsncne	cmqalpian004wjxp5jal8n4zr	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo0093jxp5qhif2gsn	cmqalpi970024jxp54fdsncne	cmqalpian004wjxp5jal8n4zr	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo0094jxp5sy4ih7j2	cmqalpi970024jxp54fdsncne	cmqalpian004wjxp5jal8n4zr	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo0095jxp52krnakxm	cmqalpi970024jxp54fdsncne	cmqalpian004wjxp5jal8n4zr	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibo0096jxp5b41hxdkm	cmqalpi970024jxp54fdsncne	cmqalpian004wjxp5jal8n4zr	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp0097jxp5ahlc6lcb	cmqalpi970025jxp5qkdn2a9m	cmqalpian004xjxp5p0aoty6o	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp0098jxp53gcl8eje	cmqalpi970025jxp5qkdn2a9m	cmqalpian004xjxp5p0aoty6o	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp0099jxp5t8pkn54i	cmqalpi970025jxp5qkdn2a9m	cmqalpian004xjxp5p0aoty6o	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp009ajxp5zzmpsa8h	cmqalpi970029jxp5r8fs4om9	cmqalpian0051jxp50smslat2	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp009bjxp5bn22kvih	cmqalpi970029jxp5r8fs4om9	cmqalpian0051jxp50smslat2	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp009cjxp5enxd9eyb	cmqalpi970029jxp5r8fs4om9	cmqalpian0051jxp50smslat2	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp009djxp5egtcrb81	cmqalpi97002ajxp55fljalc9	cmqalpian0052jxp5pi1f2zu7	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp009ejxp5qj9vthdf	cmqalpi97002ajxp55fljalc9	cmqalpian0052jxp5pi1f2zu7	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp009fjxp5zwh3flvc	cmqalpi97002ajxp55fljalc9	cmqalpian0052jxp5pi1f2zu7	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp009gjxp5em4zwxen	cmqalpi97002ajxp55fljalc9	cmqalpian0052jxp5pi1f2zu7	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp009hjxp54yfycbgm	cmqalpi97002djxp56b8fbyjn	cmqalpian0055jxp5v0oansfe	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp009ijxp5w3ha3f0o	cmqalpi97002djxp56b8fbyjn	cmqalpian0055jxp5v0oansfe	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp009jjxp5jj2g1hob	cmqalpi97002djxp56b8fbyjn	cmqalpian0055jxp5v0oansfe	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp009kjxp5v86oh5ou	cmqalpi97002ijxp5xf6xzhce	cmqalpiao005ajxp5zxrry8ix	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp009ljxp5xw8qzizp	cmqalpi97002ijxp5xf6xzhce	cmqalpiao005ajxp5zxrry8ix	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp009mjxp5hk3j0y0r	cmqalpi97002ijxp5xf6xzhce	cmqalpiao005ajxp5zxrry8ix	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp009njxp53vu2esfq	cmqalpi97002kjxp5soq40s2v	cmqalpiao005cjxp5qph8q0wh	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp009ojxp5ehm7bn6f	cmqalpi97002kjxp5soq40s2v	cmqalpiao005cjxp5qph8q0wh	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp009pjxp5msupxb2m	cmqalpi97002kjxp5soq40s2v	cmqalpiao005cjxp5qph8q0wh	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp009qjxp54yckz3vp	cmqalpi97002mjxp5omcyzqus	cmqalpiao005ejxp5sz1e80ev	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp009rjxp5f776mo0x	cmqalpi97002mjxp5omcyzqus	cmqalpiao005ejxp5sz1e80ev	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp009sjxp51j8n13j9	cmqalpi97002mjxp5omcyzqus	cmqalpiao005ejxp5sz1e80ev	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp009tjxp5nn6eb3vg	cmqalpi97002ojxp5z2jqvz3k	cmqalpiao005gjxp5vwrlk2xr	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp009ujxp5apjgtz44	cmqalpi97002ojxp5z2jqvz3k	cmqalpiao005gjxp5vwrlk2xr	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp009vjxp5depi5coq	cmqalpi97002ojxp5z2jqvz3k	cmqalpiao005gjxp5vwrlk2xr	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp009wjxp5tb9ksirx	cmqalpi97002pjxp5i6820dlh	cmqalpiao005hjxp50adev3a8	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp009xjxp53tgw7lo1	cmqalpi97002pjxp5i6820dlh	cmqalpiao005hjxp50adev3a8	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp009yjxp5p9w759rw	cmqalpi97002pjxp5i6820dlh	cmqalpiao005hjxp50adev3a8	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp009zjxp5or0yiv10	cmqalpi97002pjxp5i6820dlh	cmqalpiao005hjxp50adev3a8	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp00a0jxp54ftklebl	cmqalpi97002rjxp5oe53oyfe	cmqalpiao005jjxp5ksdvf6ff	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp00a1jxp5vzl6xhoo	cmqalpi97002rjxp5oe53oyfe	cmqalpiao005jjxp5ksdvf6ff	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp00a2jxp5wqm042l1	cmqalpi97002rjxp5oe53oyfe	cmqalpiao005jjxp5ksdvf6ff	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp00a3jxp5w2ngc6a4	cmqalpi97002rjxp5oe53oyfe	cmqalpiao005jjxp5ksdvf6ff	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp00a4jxp5af7z6aa3	cmqalpi97002sjxp51p4tohag	cmqalpiao005kjxp59h52pxpr	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp00a5jxp5yz310z0b	cmqalpi97002sjxp51p4tohag	cmqalpiao005kjxp59h52pxpr	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp00a6jxp54xt7hdx4	cmqalpi97002sjxp51p4tohag	cmqalpiao005kjxp59h52pxpr	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp00a7jxp5y70qv38j	cmqalpi97002tjxp5ot7zb1bq	cmqalpiao005ljxp5lpeau6s7	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp00a8jxp5iuzfpfs4	cmqalpi97002tjxp5ot7zb1bq	cmqalpiao005ljxp5lpeau6s7	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp00a9jxp58ergoe2e	cmqalpi97002tjxp5ot7zb1bq	cmqalpiao005ljxp5lpeau6s7	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp00aajxp5xh5pzvul	cmqalpi97002wjxp5yfhgkmvu	cmqalpiao005ojxp5qyrboba4	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp00abjxp5bxtsrn9i	cmqalpi97002wjxp5yfhgkmvu	cmqalpiao005ojxp5qyrboba4	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp00acjxp51dlrt5l9	cmqalpi97002wjxp5yfhgkmvu	cmqalpiao005ojxp5qyrboba4	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp00adjxp5j9mdxs9f	cmqalpi97002wjxp5yfhgkmvu	cmqalpiao005ojxp5qyrboba4	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp00aejxp58zq8fkeh	cmqalpi97002xjxp5egkpnxmv	cmqalpiao005pjxp5kpxd8gjk	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp00afjxp5f404kgkd	cmqalpi97002xjxp5egkpnxmv	cmqalpiao005pjxp5kpxd8gjk	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp00agjxp5xkcf76w8	cmqalpi97002xjxp5egkpnxmv	cmqalpiao005pjxp5kpxd8gjk	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp00ahjxp5d528svbv	cmqalpi970030jxp5glg0t3do	cmqalpiao005sjxp5rulk7n5y	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp00aijxp5rico0e5b	cmqalpi970030jxp5glg0t3do	cmqalpiao005sjxp5rulk7n5y	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp00ajjxp5x53mtquh	cmqalpi970030jxp5glg0t3do	cmqalpiao005sjxp5rulk7n5y	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp00akjxp5d9xthe0f	cmqalpi970031jxp598n1gxtn	cmqalpiao005tjxp5qnk4oazd	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp00aljxp5nnczgmef	cmqalpi970031jxp598n1gxtn	cmqalpiao005tjxp5qnk4oazd	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp00amjxp52qggbkr9	cmqalpi970031jxp598n1gxtn	cmqalpiao005tjxp5qnk4oazd	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp00anjxp5iedxnh7p	cmqalpi970034jxp51mt5i7yj	cmqalpiao005wjxp5j2t1rj0j	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp00aojxp5tufw671k	cmqalpi970034jxp51mt5i7yj	cmqalpiao005wjxp5j2t1rj0j	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp00apjxp50m6j9fqf	cmqalpi970034jxp51mt5i7yj	cmqalpiao005wjxp5j2t1rj0j	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibp00aqjxp58mr6f3a8	cmqalpi970034jxp51mt5i7yj	cmqalpiao005wjxp5j2t1rj0j	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00arjxp5hj6q6v3h	cmqalpi970034jxp51mt5i7yj	cmqalpiao005wjxp5j2t1rj0j	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00asjxp5i5yhgob1	cmqalpi970037jxp5tv1t3skz	cmqalpiao005zjxp5korr084z	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00atjxp53h0znfcz	cmqalpi970037jxp5tv1t3skz	cmqalpiao005zjxp5korr084z	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00aujxp5z71d0jtv	cmqalpi970037jxp5tv1t3skz	cmqalpiao005zjxp5korr084z	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00avjxp50xm1uxz3	cmqalpi970037jxp5tv1t3skz	cmqalpiao005zjxp5korr084z	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00awjxp5bg1zzq1t	cmqalpi970038jxp54ol4raxk	cmqalpiap0060jxp5792o4veb	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00axjxp576rtzp9x	cmqalpi970038jxp54ol4raxk	cmqalpiap0060jxp5792o4veb	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00ayjxp5vwe1hnjj	cmqalpi970038jxp54ol4raxk	cmqalpiap0060jxp5792o4veb	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00azjxp55b44w3gc	cmqalpi98003ajxp50mzuheex	cmqalpiap0062jxp5pabemo09	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00b0jxp528yrnpw9	cmqalpi98003ajxp50mzuheex	cmqalpiap0062jxp5pabemo09	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00b1jxp5o0ztdjve	cmqalpi98003ajxp50mzuheex	cmqalpiap0062jxp5pabemo09	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00b2jxp5zgfa76wx	cmqalpi98003bjxp5juah0t8r	cmqalpiap0063jxp52wwbs86z	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00b3jxp5nagrztf5	cmqalpi98003bjxp5juah0t8r	cmqalpiap0063jxp52wwbs86z	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00b4jxp5nk8h8z9i	cmqalpi98003bjxp5juah0t8r	cmqalpiap0063jxp52wwbs86z	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00b5jxp543dmhbzw	cmqalpi98003cjxp5qjgexcqv	cmqalpiap0064jxp54a4qcjxz	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00b6jxp5n7t2y434	cmqalpi98003cjxp5qjgexcqv	cmqalpiap0064jxp54a4qcjxz	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00b7jxp5fwa7ca7u	cmqalpi98003cjxp5qjgexcqv	cmqalpiap0064jxp54a4qcjxz	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00b8jxp5gspfz35v	cmqalpi98003fjxp5cttap7kg	cmqalpiap0067jxp50yrk8vvq	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00b9jxp5tefzhmzo	cmqalpi98003fjxp5cttap7kg	cmqalpiap0067jxp50yrk8vvq	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00bajxp5bzg0tcs9	cmqalpi98003fjxp5cttap7kg	cmqalpiap0067jxp50yrk8vvq	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00bbjxp5w86t5xob	cmqalpi98003fjxp5cttap7kg	cmqalpiap0067jxp50yrk8vvq	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00bcjxp5bsrod7n7	cmqalpi98003gjxp557e7wlie	cmqalpiap0068jxp5qi1gn70f	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00bdjxp5pi9zui82	cmqalpi98003gjxp557e7wlie	cmqalpiap0068jxp5qi1gn70f	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00bejxp5eme8zkpd	cmqalpi98003gjxp557e7wlie	cmqalpiap0068jxp5qi1gn70f	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00bfjxp5g9slsuds	cmqalpi98003gjxp557e7wlie	cmqalpiap0068jxp5qi1gn70f	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00bgjxp5v7fs80my	cmqalpi98003gjxp557e7wlie	cmqalpiap0068jxp5qi1gn70f	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00bhjxp5om63g6ur	cmqalpi98003hjxp5lfvhux50	cmqalpiap0069jxp5smss5gd6	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00bijxp5bb78j14q	cmqalpi98003hjxp5lfvhux50	cmqalpiap0069jxp5smss5gd6	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00bjjxp5bt0s5ue9	cmqalpi98003hjxp5lfvhux50	cmqalpiap0069jxp5smss5gd6	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00bkjxp59962bz4f	cmqalpi98003kjxp5xicb7mfw	cmqalpiap006cjxp5vb2j986z	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00bljxp5xtygbd4f	cmqalpi98003kjxp5xicb7mfw	cmqalpiap006cjxp5vb2j986z	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00bmjxp5vd65ery4	cmqalpi98003kjxp5xicb7mfw	cmqalpiap006cjxp5vb2j986z	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00bnjxp5vpml57in	cmqalpi98003ljxp5s5sb19tr	cmqalpiap006djxp5xpi9sy25	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00bojxp5d7czg2ax	cmqalpi98003ljxp5s5sb19tr	cmqalpiap006djxp5xpi9sy25	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00bpjxp514swjbfl	cmqalpi98003ljxp5s5sb19tr	cmqalpiap006djxp5xpi9sy25	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00bqjxp53km80p84	cmqalpi98003mjxp5wd31a19h	cmqalpiap006ejxp5ik2avft6	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00brjxp54swef94d	cmqalpi98003mjxp5wd31a19h	cmqalpiap006ejxp5ik2avft6	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00bsjxp57viuia0q	cmqalpi98003mjxp5wd31a19h	cmqalpiap006ejxp5ik2avft6	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00btjxp5p323n3lj	cmqalpi98003mjxp5wd31a19h	cmqalpiap006ejxp5ik2avft6	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00bujxp5rh0n0zfn	cmqalpi98003njxp5d5xli0u8	cmqalpiap006fjxp5yha0vscy	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00bvjxp5wvg9h2hr	cmqalpi98003njxp5d5xli0u8	cmqalpiap006fjxp5yha0vscy	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00bwjxp56uak6aw7	cmqalpi98003njxp5d5xli0u8	cmqalpiap006fjxp5yha0vscy	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00bxjxp5vynkr350	cmqalpi98003njxp5d5xli0u8	cmqalpiap006fjxp5yha0vscy	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00byjxp5z1v2oslz	cmqalpi98003pjxp5wlyaqmir	cmqalpiap006hjxp5dbk9jxqw	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00bzjxp5i5e4wyle	cmqalpi98003pjxp5wlyaqmir	cmqalpiap006hjxp5dbk9jxqw	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00c0jxp56l4mpjv4	cmqalpi98003pjxp5wlyaqmir	cmqalpiap006hjxp5dbk9jxqw	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00c1jxp53zqylaxw	cmqalpi98003qjxp5u7nbs1ow	cmqalpiap006ijxp5j5xkrsld	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00c2jxp5b67wm6cl	cmqalpi98003qjxp5u7nbs1ow	cmqalpiap006ijxp5j5xkrsld	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00c3jxp5b1s1iqcd	cmqalpi98003qjxp5u7nbs1ow	cmqalpiap006ijxp5j5xkrsld	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00c4jxp54ixklri6	cmqalpi98003qjxp5u7nbs1ow	cmqalpiap006ijxp5j5xkrsld	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00c5jxp5d4q0db2h	cmqalpi98003qjxp5u7nbs1ow	cmqalpiap006ijxp5j5xkrsld	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00c6jxp5on6xtzdp	cmqalpi98003tjxp5mlq4tasj	cmqalpiap006ljxp53beojhnj	1	in_progress	2026-06-12 07:24:34.684	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00c7jxp5e2kkr22y	cmqalpi98003tjxp5mlq4tasj	cmqalpiap006ljxp53beojhnj	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqalpibq00c8jxp59t70ewoo	cmqalpi98003tjxp5mlq4tasj	cmqalpiap006ljxp53beojhnj	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-12 07:24:34.69	2026-06-12 07:24:34.69
cmqcf7l4a00dnjxp5gxsj72tz	cmqcf7l3t00djjxp5hga3flde	cmqcf7l4300dljxp5nlmr0p94	1	in_progress	2026-06-13 13:58:13.161	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-13 13:58:13.162	2026-06-13 13:58:13.162
cmqcf7l4a00dojxp54pek7qd7	cmqcf7l3t00djjxp5hga3flde	cmqcf7l4300dljxp5nlmr0p94	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-13 13:58:13.162	2026-06-13 13:58:13.162
cmqcf7l4a00dpjxp5lw9y7g06	cmqcf7l3t00djjxp5hga3flde	cmqcf7l4300dljxp5nlmr0p94	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-13 13:58:13.162	2026-06-13 13:58:13.162
cmqcf7l4a00dqjxp58flpdgwi	cmqcf7l3t00dkjxp5b81qqau5	cmqcf7l4300dmjxp59dznc6ta	1	in_progress	2026-06-13 13:58:13.161	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-13 13:58:13.162	2026-06-13 13:58:13.162
cmqcf7l4a00drjxp5qcnj4ao2	cmqcf7l3t00dkjxp5b81qqau5	cmqcf7l4300dmjxp59dznc6ta	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-13 13:58:13.162	2026-06-13 13:58:13.162
cmqcf7l4a00dsjxp5jccmhtlr	cmqcf7l3t00dkjxp5b81qqau5	cmqcf7l4300dmjxp59dznc6ta	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-13 13:58:13.162	2026-06-13 13:58:13.162
cmr254jpo00hejxctj8v1v5pi	cmr254jj6001ijxct0thvp7fd	cmr254jms009fjxctm2uqzgyg	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpo00hfjxctdqu2molk	cmr254jj6001jjxctvt06lll6	cmr254jms009gjxct8vs5ndn6	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpo00hgjxctz0b28ey0	cmr254jj6001jjxctvt06lll6	cmr254jms009gjxct8vs5ndn6	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6tae00kkjxp5vegcivof	cmqep6t7x00esjxp5cbdmqqex	cmqep6t9300hmjxp57kf2hh40	5	completed	2026-06-26 09:31:36.617	2026-07-03 09:40:45.991	2026-07-03 09:40:44.496	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:40:45.992
cmqep6tae00ktjxp54hnktjq0	cmqep6t7x00evjxp5vhoesa20	cmqep6t9300hpjxp5m0ic3656	5	completed	2026-06-26 09:29:20.736	2026-07-03 09:40:52.601	2026-07-03 09:40:50.756	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:40:52.601
cmqep6tae00kxjxp5kvpnyld6	cmqep6t7x00ewjxp58q8ujqlw	cmqep6t9300hqjxp5w9e5hxew	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tae00l4jxp57emsbq7h	cmqep6t7x00ezjxp5vlltxpho	cmqep6t9300htjxp5xv8jqt3o	1	in_progress	2026-06-15 04:13:05.592	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tae00l5jxp5uu2rvpbw	cmqep6t7x00ezjxp5vlltxpho	cmqep6t9300htjxp5xv8jqt3o	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tae00l6jxp54k7l0vxd	cmqep6t7x00ezjxp5vlltxpho	cmqep6t9300htjxp5xv8jqt3o	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tae00kujxp5dnxertgl	cmqep6t7x00ewjxp58q8ujqlw	cmqep6t9300hqjxp5w9e5hxew	1	completed	2026-06-15 04:13:05.592	2026-06-26 09:21:00.81	2026-06-26 09:20:58.054	cmq0kyw85007kjx239k25z1ge	\N	ไม่มั่นใจในรูปร่างของตัวเอง	ปัญหาครอบครัว	internal	2026-06-26 09:21:57.324	2026-06-15 04:13:05.602	2026-06-26 09:21:57.325
cmqep6tae00kmjxp5mwqtzbh5	cmqep6t7x00etjxp5oklc37y3	cmqep6t9300hnjxp5ojniwclr	2	completed	2026-06-26 09:13:23.971	2026-06-26 09:26:13.775	2026-06-26 09:23:19.149	cmq0kyw85007kjx239k25z1ge	มีความไม่มั่นใจ 	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:26:13.775
cmqep6tae00kwjxp5q4kywaog	cmqep6t7x00ewjxp58q8ujqlw	cmqep6t9300hqjxp5w9e5hxew	3	in_progress	2026-06-26 09:24:18.047	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:24:18.048
cmqep6tae00ksjxp5zeym81zm	cmqep6t7x00evjxp5vhoesa20	cmqep6t9300hpjxp5m0ic3656	2	completed	2026-06-26 09:25:25.576	2026-06-26 09:29:20.732	2026-06-26 09:29:19.097	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:29:20.733
cmqep6tad00kijxp521e73zq0	cmqep6t7x00esjxp5cbdmqqex	cmqep6t9300hmjxp57kf2hh40	1	completed	2026-06-15 04:13:05.592	2026-06-26 09:30:19.429	2026-06-26 09:30:17.742	cmq0khs5m000wjx23jyhqhgkv	\N	ขาดความมั่นใจ	ปัญหาครอบครัว	external	2026-06-26 09:30:47.836	2026-06-15 04:13:05.602	2026-06-26 09:30:47.837
cmqep6tae00l1jxp5258qfq4b	cmqep6t7x00eyjxp55zwq78jl	cmqep6t9300hsjxp5mqoxbs0l	1	completed	2026-06-15 04:13:05.592	2026-06-26 09:30:50.842	2026-06-26 09:30:46.577	cmq0khs5m000wjx23jyhqhgkv	\N	ขาดความมั่นใจในตัวเอง ยังค้นหาตัวเองไม่เจอ	ไม่มี	internal	2026-06-26 09:31:42.953	2026-06-15 04:13:05.602	2026-06-26 09:31:42.954
cmqep6tad00kfjxp5oyn4ub93	cmqep6t7x00erjxp54fnk3xqy	cmqep6t9300hljxp5tig3rlk1	1	completed	2026-06-15 04:13:05.592	2026-06-26 09:37:46.738	2026-06-26 09:37:26.875	cmq0khs5m000wjx23jyhqhgkv	\N	ยังค้นหาตัวเองยังไม่เจอ	ไม่มี	internal	2026-06-26 09:39:21.945	2026-06-15 04:13:05.602	2026-06-26 09:39:21.946
cmqep6tad00khjxp5vxk4fqmj	cmqep6t7x00erjxp54fnk3xqy	cmqep6t9300hljxp5tig3rlk1	5	in_progress	2026-06-26 09:41:04.49	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:41:04.491
cmqep6tae00kyjxp5564s6uu3	cmqep6t7x00exjxp5g48uiw9v	cmqep6t9300hrjxp5teg19y90	1	completed	2026-06-15 04:13:05.592	2026-06-26 09:50:04.138	2026-06-26 09:50:00.748	cmq0khs5m000wjx23jyhqhgkv	\N	ขาดความมั่นใจในตัวเอง	ไม่มี	internal	2026-06-26 09:50:34.54	2026-06-15 04:13:05.602	2026-06-26 09:50:34.541
cmqep6tae00kzjxp552fvi9nx	cmqep6t7x00exjxp5g48uiw9v	cmqep6t9300hrjxp5teg19y90	2	completed	2026-06-26 09:50:04.143	2026-06-26 09:52:08.044	2026-06-26 09:51:45.211	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:52:08.045
cmr254jpo00hhjxctjydhj1a5	cmr254jj6001jjxctvt06lll6	cmr254jms009gjxct8vs5ndn6	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6tah00pbjxp5kd3b100j	cmqep6t7y00g8jxp5e5io1j25	cmqep6t9400j2jxp58h2t12fu	5	completed	2026-06-26 08:46:26.657	2026-07-03 09:31:58.007	2026-07-03 09:31:35.539	cmq0kyw85007kjx239k25z1ge	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:31:58.008
cmqep6taf00m7jxp5c4hqpylg	cmqep6t7x00fbjxp5c1fz5ppe	cmqep6t9300i5jxp543jcx65k	5	completed	2026-06-26 09:36:12.317	2026-07-03 09:35:43.189	2026-07-03 09:35:41.092	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:35:43.19
cmqep6taf00lrjxp5a1zzam9g	cmqep6t7x00f5jxp5kn6gv1ni	cmqep6t9300hzjxp5z36ifwwm	5	completed	2026-06-26 09:46:27.363	2026-07-03 09:36:21.437	2026-07-03 09:36:18.827	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:36:21.438
cmqep6taf00majxp5xypczcw6	cmqep6t7x00fcjxp5slrtarvk	cmqep6t9300i6jxp5titg9cgh	5	completed	2026-06-26 09:33:35.093	2026-07-03 09:36:30.212	2026-07-03 09:36:28.66	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:36:30.213
cmqep6taf00m1jxp50bmzdv1r	cmqep6t7x00f8jxp55qj3x2vc	cmqep6t9300i2jxp5qo3m1pbo	5	completed	2026-06-26 09:53:25.165	2026-07-03 09:39:20.282	2026-07-03 09:39:16.259	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:39:20.283
cmqep6tag00mhjxp5xc1b8b4b	cmqep6t7x00fejxp5o7dl7di4	cmqep6t9400i8jxp575ybjipq	5	completed	2026-06-26 09:52:55.376	2026-07-03 09:45:47.958	2026-07-03 09:45:44.322	cmq0kyw85007kjx239k25z1ge	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:45:47.959
cmqep6taf00lgjxp5wxyyxhay	cmqep6t7x00f2jxp5sh03nooy	cmqep6t9300hwjxp5k2345ah9	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6taf00lhjxp5xxfix6af	cmqep6t7x00f2jxp5sh03nooy	cmqep6t9300hwjxp5k2345ah9	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tag00msjxp5octar0qh	cmqep6t7x00fhjxp5fpnrj4l7	cmqep6t9400ibjxp5g6u6nf0y	5	completed	2026-06-26 09:54:03.315	2026-07-03 09:45:59.87	2026-07-03 09:45:54.798	cmq0kyw85007kjx239k25z1ge	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:45:59.871
cmqep6taf00lojxp59xuai3f4	cmqep6t7x00f4jxp5ifdridnj	cmqep6t9300hyjxp5dd1qz18y	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6taf00lvjxp5te5znj0d	cmqep6t7x00f6jxp5ryay9b35	cmqep6t9300i0jxp58q6bdjuy	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tag00mejxp583vmmvni	cmqep6t7x00fdjxp5phrwrenn	cmqep6t9300i7jxp5czcjfas0	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tag00mljxp5sh23pqez	cmqep6t7x00ffjxp5qxsn29jv	cmqep6t9400i9jxp5v1vpi65s	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tae00ldjxp5yytzy8qi	cmqep6t7x00f2jxp5sh03nooy	cmqep6t9300hwjxp5k2345ah9	1	completed	2026-06-15 04:13:05.592	2026-06-26 09:17:46.97	2026-06-26 09:17:45.211	cmq0khs5m000wjx23jyhqhgkv	\N	ไม่มีความมั่นใจในตัวเองมากพอ	มีปัญหาด้านครอบครัวและค่าครองชีพ	internal	2026-06-26 09:20:06.17	2026-06-15 04:13:05.602	2026-06-26 09:20:06.171
cmqep6tag00mpjxp58mdw2pcg	cmqep6t7x00fgjxp5q4q2sqhp	cmqep6t9400iajxp5szt1pb8v	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6taf00lfjxp5e6k81v0k	cmqep6t7x00f2jxp5sh03nooy	cmqep6t9300hwjxp5k2345ah9	3	in_progress	2026-06-26 09:22:05.832	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:22:05.833
cmqep6tag00mijxp5k0mcbru7	cmqep6t7x00ffjxp5qxsn29jv	cmqep6t9400i9jxp5v1vpi65s	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:31:11.892	2026-06-19 13:31:09.595	cmq0khs5m000wjx23jyhqhgkv	\N	ขาดความมั่นใจในตัวเอง ใส่ใจเฉพาะกีฬา	ไม่มี	internal	2026-06-19 13:32:25.128	2026-06-15 04:13:05.602	2026-06-19 13:32:25.129
cmqep6taf00lwjxp5yqeihwvy	cmqep6t7x00f7jxp5l3oii2qb	cmqep6t9300i1jxp596rewf7k	1	completed	2026-06-15 04:13:05.592	2026-06-26 09:21:26.249	2026-06-26 09:21:24.686	cmq0khs5m000wjx23jyhqhgkv	\N	ขาดความมั่นใจ	ไม่มี	internal	2026-06-26 09:22:07.413	2026-06-15 04:13:05.602	2026-06-26 09:22:07.414
cmqep6tag00mdjxp5vd1vwjz4	cmqep6t7x00fdjxp5phrwrenn	cmqep6t9300i7jxp5czcjfas0	3	in_progress	2026-06-26 09:22:52.321	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:22:52.322
cmqep6taf00m2jxp58agqvld9	cmqep6t7x00f9jxp5wi3o0rdy	cmqep6t9300i3jxp5puoo5th4	1	completed	2026-06-15 04:13:05.592	2026-06-26 09:24:56.052	2026-06-26 09:24:54.031	cmq0khs5m000wjx23jyhqhgkv	\N	ขาดความมั่นใจ	ไม่มี	internal	2026-06-26 09:26:10.686	2026-06-15 04:13:05.602	2026-06-26 09:26:10.687
cmqep6taf00lxjxp5hyf8ebmi	cmqep6t7x00f7jxp5l3oii2qb	cmqep6t9300i1jxp596rewf7k	2	completed	2026-06-26 09:21:26.253	2026-06-26 09:23:28.354	2026-06-26 09:23:19.565	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:23:28.355
cmqep6taf00lmjxp585xu8d0b	cmqep6t7x00f4jxp5ifdridnj	cmqep6t9300hyjxp5dd1qz18y	2	completed	2026-06-26 09:25:52.457	2026-06-26 09:27:37.444	2026-06-26 09:27:35.228	cmq0kyw85007kjx239k25z1ge	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:27:37.445
cmqep6tae00lajxp5h4zdtjc5	cmqep6t7x00f1jxp5twcea6w7	cmqep6t9300hvjxp5teazesc6	1	completed	2026-06-15 04:13:05.592	2026-06-26 09:27:36.875	2026-06-26 09:27:35.328	cmq0kyw85007kjx239k25z1ge	\N	ยังขาดความมั่นใจในการเรียน	ปัญหาด้านครอบครัว	internal	2026-06-26 09:29:20.6	2026-06-15 04:13:05.602	2026-06-26 09:29:20.601
cmqep6taf00m4jxp53n5f5xi9	cmqep6t7x00f9jxp5wi3o0rdy	cmqep6t9300i3jxp5puoo5th4	5	in_progress	2026-06-26 09:27:31.477	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:27:31.478
cmqep6taf00lnjxp5b4p7icj4	cmqep6t7x00f4jxp5ifdridnj	cmqep6t9300hyjxp5dd1qz18y	3	in_progress	2026-06-26 09:27:37.448	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:27:37.449
cmqep6tae00lbjxp5y4x8nkgy	cmqep6t7x00f1jxp5twcea6w7	cmqep6t9300hvjxp5teazesc6	2	completed	2026-06-26 09:27:36.88	2026-06-26 09:37:14.834	2026-06-26 09:31:21.947	cmq0kyw85007kjx239k25z1ge	มีความรู้สึกว่าเห็นคุณค่าในตัวเอง	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:37:14.835
cmqep6taf00lujxp54g7omibu	cmqep6t7x00f6jxp5ryay9b35	cmqep6t9300i0jxp58q6bdjuy	3	in_progress	2026-06-26 09:35:07.287	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:35:07.288
cmqep6taf00m8jxp54rg3cm83	cmqep6t7x00fcjxp5slrtarvk	cmqep6t9300i6jxp5titg9cgh	1	completed	2026-06-15 04:13:05.592	2026-06-26 09:32:33.683	2026-06-26 09:32:26.65	cmq0khs5m000wjx23jyhqhgkv	\N	ขาดความมั่นใจ	ไม่มี	internal	2026-06-26 09:32:45.298	2026-06-15 04:13:05.602	2026-06-26 09:32:45.299
cmqep6taf00m5jxp5w2tp8ov6	cmqep6t7x00fbjxp5c1fz5ppe	cmqep6t9300i5jxp543jcx65k	1	completed	2026-06-15 04:13:05.592	2026-06-26 09:34:11.73	2026-06-26 09:34:06.027	cmq0khs5m000wjx23jyhqhgkv	\N	ยังค้นหาตัวเองยังไม่เจอ	ไม่มี	internal	2026-06-26 09:34:37.722	2026-06-15 04:13:05.602	2026-06-26 09:34:37.723
cmqep6taf00lpjxp5tc5l73qs	cmqep6t7x00f5jxp5kn6gv1ni	cmqep6t9300hzjxp5z36ifwwm	1	completed	2026-06-15 04:13:05.592	2026-06-26 09:42:27.912	2026-06-26 09:42:25.033	cmq0kyw85007kjx239k25z1ge	\N	ไม่มั่นใจในตัวเอง	มีปัญหาด้านค่าครองชีพ	internal	2026-06-26 09:44:00.727	2026-06-15 04:13:05.602	2026-06-26 09:44:00.728
cmqep6tag00mkjxp5e8b5fi2r	cmqep6t7x00ffjxp5qxsn29jv	cmqep6t9400i9jxp5v1vpi65s	3	in_progress	2026-06-26 09:45:04.331	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:45:04.332
cmqep6taf00lzjxp5bwjlk05a	cmqep6t7x00f8jxp55qj3x2vc	cmqep6t9300i2jxp5qo3m1pbo	1	completed	2026-06-15 04:13:05.592	2026-06-26 09:49:50.919	2026-06-26 09:49:41.15	cmq0kyw85007kjx239k25z1ge	\N	ไม่มั่นใจเรื่องรูปลักษณ์ภายนอก\n	มีปัญหาการค่าครองชีพและด้านครอบครัว	internal	2026-06-26 09:51:11.034	2026-06-15 04:13:05.602	2026-06-26 09:51:11.035
cmqep6tag00mojxp5yl3hu12r	cmqep6t7x00fgjxp5q4q2sqhp	cmqep6t9400iajxp5szt1pb8v	3	in_progress	2026-06-26 09:51:42.979	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:51:42.98
cmqep6taf00lijxp5e139svam	cmqep6t7x00f3jxp5synf5gsg	cmqep6t9300hxjxp5p4kf2gyr	1	completed	2026-06-15 04:13:05.592	2026-06-26 09:53:44.276	2026-06-26 09:53:36.543	cmq0khs5m000wjx23jyhqhgkv	\N	ยังค้นหาตัวเองไม่เจอ	ไม่มี	internal	2026-06-26 09:54:09.069	2026-06-15 04:13:05.602	2026-06-26 09:54:09.07
cmqep6tag00mrjxp5zhqy9rpu	cmqep6t7x00fhjxp5fpnrj4l7	cmqep6t9400ibjxp5g6u6nf0y	2	completed	2026-06-19 13:26:17.39	2026-06-26 09:54:03.312	2026-06-26 09:54:01.819	cmq0kwit80066jx23pw930nx1	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:54:03.312
cmqep6tah00objxp5hoz9uj64	cmqep6t7x00fyjxp5gd0tiz6q	cmqep6t9400isjxp5q3gysgu2	3	in_progress	2026-06-26 09:35:21.308	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:35:21.308
cmr254jpo00hijxctumxjg1vl	cmr254jj6001kjxct1wt4ieey	cmr254jms009hjxctxqc1jcyl	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6tag00mwjxp5rb5e3ex5	cmqep6t7x00fijxp5jyyrjuz8	cmqep6t9400icjxp563x2ubdm	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tah00o2jxp5ia9u39bd	cmqep6t7x00fvjxp5jwtduygo	cmqep6t9400ipjxp5mi3lxvqs	3	in_progress	2026-06-26 09:38:52.507	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:38:52.508
cmqep6tag00mzjxp5rga1q0cm	cmqep6t7x00fjjxp51to2rjq7	cmqep6t9400idjxp53hqq2voi	3	in_progress	2026-06-26 09:39:02.801	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:39:02.802
cmr254jpo00hjjxct017cjvf6	cmr254jj6001kjxct1wt4ieey	cmr254jms009hjxctxqc1jcyl	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6tag00n0jxp57r38hhst	cmqep6t7x00fjjxp51to2rjq7	cmqep6t9400idjxp53hqq2voi	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tag00n1jxp5dwdo55id	cmqep6t7x00fjjxp51to2rjq7	cmqep6t9400idjxp53hqq2voi	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tag00nbjxp5x6j0nouk	cmqep6t7x00fnjxp5bqhzrp6l	cmqep6t9400ihjxp5z57lkkn2	3	in_progress	2026-06-26 09:41:03.033	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:41:03.034
cmqep6tah00o7jxp5c19j5391	cmqep6t7x00fwjxp5he7659eh	cmqep6t9400iqjxp5ray5vlwm	3	in_progress	2026-06-26 09:44:24.424	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:44:24.425
cmr254jpo00hkjxctouepmny5	cmr254jj6001kjxct1wt4ieey	cmr254jms009hjxctxqc1jcyl	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6tag00n5jxp5ci5hfd2a	cmqep6t7x00fkjxp5dokcsihq	cmqep6t9400iejxp54gkhmb1r	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tag00nrjxp5nlkd00hm	cmqep6t7x00fsjxp5s3lf3hkn	cmqep6t9400imjxp523k3l27b	3	in_progress	2026-06-26 09:42:26.949	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:42:26.95
cmqep6tag00mvjxp5df1p0p20	cmqep6t7x00fijxp5jyyrjuz8	cmqep6t9400icjxp563x2ubdm	3	in_progress	2026-06-26 09:46:42.886	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:46:42.887
cmqep6tag00ngjxp5so1mfgn3	cmqep6t7x00fpjxp5afe8hyp4	cmqep6t9400ijjxp59w5gpf1i	3	in_progress	2026-06-26 09:48:04.966	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:48:04.967
cmqep6tag00nkjxp590m7r80m	cmqep6t7x00fqjxp5np9idghm	cmqep6t9400ikjxp5hxoelt9l	3	in_progress	2026-06-26 09:49:30.53	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:49:30.531
cmqep6tag00nwjxp5gegzdelr	cmqep6t7x00ftjxp5qcd2510h	cmqep6t9400injxp5fr38gk7o	5	completed	2026-06-26 09:52:41.53	2026-07-03 09:39:27.543	2026-07-03 09:39:25.893	cmq0kyw85007kjx239k25z1ge	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:39:27.544
cmqep6tag00ncjxp5c3ivjkf7	cmqep6t7x00fnjxp5bqhzrp6l	cmqep6t9400ihjxp5z57lkkn2	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tag00ndjxp5cr4tfn8j	cmqep6t7x00fnjxp5bqhzrp6l	cmqep6t9400ihjxp5z57lkkn2	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tag00n3jxp54lh5wami	cmqep6t7x00fkjxp5dokcsihq	cmqep6t9400iejxp54gkhmb1r	2	completed	2026-06-19 13:32:11.752	2026-06-26 09:49:01.252	2026-06-26 09:49:00.137	cmq0kwit80066jx23pw930nx1	มีความมั่นใจเห็นคุณค่าในตัวเอง	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:49:01.253
cmqep6tah00nzjxp58hfzih0t	cmqep6t7x00fujxp5lzrwcrc9	cmqep6t9400iojxp535rm9rat	5	completed	2026-06-26 09:57:30.655	2026-07-03 09:44:27.342	2026-07-03 09:44:21.967	cmq0kyw85007kjx239k25z1ge	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:44:27.343
cmqep6tag00nhjxp5tyt1ybmz	cmqep6t7x00fpjxp5afe8hyp4	cmqep6t9400ijjxp59w5gpf1i	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tag00nvjxp5jlwom1ah	cmqep6t7x00ftjxp5qcd2510h	cmqep6t9400injxp5fr38gk7o	2	completed	2026-06-19 13:24:10.167	2026-06-26 09:52:41.526	2026-06-26 09:52:38.657	cmq0kwit80066jx23pw930nx1	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:52:41.527
cmqep6tag00n8jxp5di8qwinb	cmqep6t7x00fljxp5cyty19cb	cmqep6t9400ifjxp53w1mo3fo	5	completed	2026-06-26 09:58:04.983	2026-07-03 09:44:53.778	2026-07-03 09:44:41.672	cmq0kyw85007kjx239k25z1ge	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:44:53.779
cmqep6tag00nljxp5250cwfkd	cmqep6t7x00fqjxp5np9idghm	cmqep6t9400ikjxp5hxoelt9l	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tag00nsjxp5ee40jtxu	cmqep6t7x00fsjxp5s3lf3hkn	cmqep6t9400imjxp523k3l27b	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tag00ntjxp55364mrwc	cmqep6t7x00fsjxp5s3lf3hkn	cmqep6t9400imjxp523k3l27b	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tah00o3jxp5dsk4l2tt	cmqep6t7x00fvjxp5jwtduygo	cmqep6t9400ipjxp5mi3lxvqs	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tah00o4jxp5ebttg6rb	cmqep6t7x00fvjxp5jwtduygo	cmqep6t9400ipjxp5mi3lxvqs	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tah00o8jxp5y83qpk2g	cmqep6t7x00fwjxp5he7659eh	cmqep6t9400iqjxp5ray5vlwm	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tah00ocjxp5rgzum5bt	cmqep6t7x00fyjxp5gd0tiz6q	cmqep6t9400isjxp5q3gysgu2	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tah00odjxp51u9oiu7g	cmqep6t7x00fyjxp5gd0tiz6q	cmqep6t9400isjxp5q3gysgu2	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tag00nmjxp542ai2iju	cmqep6t7x00frjxp5y0vdu581	cmqep6t9400iljxp56hadyq5z	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:27:32.304	2026-06-19 13:27:30.764	cmq0khs5m000wjx23jyhqhgkv	\N	รู้สึกขาดความมั่นใจ	ไม่มี	internal	2026-06-19 13:28:25.625	2026-06-15 04:13:05.602	2026-06-19 13:28:25.626
cmqep6tag00nxjxp5l6c9g8j0	cmqep6t7x00fujxp5lzrwcrc9	cmqep6t9400iojxp535rm9rat	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:29:24.7	2026-06-19 13:29:22.823	cmq0kyw85007kjx239k25z1ge	\N	ไม่มั่นใจในการเรียน	ไม่ค่อยมีค่าครองชีพ	internal	2026-06-19 13:30:13.304	2026-06-15 04:13:05.602	2026-06-19 13:30:13.305
cmqep6tah00o5jxp51uqmmh97	cmqep6t7x00fwjxp5he7659eh	cmqep6t9400iqjxp5ray5vlwm	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:31:24.241	2026-06-19 13:31:18.142	cmq0khs5m000wjx23jyhqhgkv	\N	ขาดความมั่นใจในตัวเอง	ด้านการเรียน	internal	2026-06-19 13:32:31.805	2026-06-15 04:13:05.602	2026-06-19 13:32:31.805
cmqep6tag00nejxp5t5xdacb2	cmqep6t7x00fpjxp5afe8hyp4	cmqep6t9400ijjxp59w5gpf1i	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:33:47.147	2026-06-19 13:33:43.268	cmq0kwit80066jx23pw930nx1	\N	ไม่มี	ไม่มี	internal	2026-06-19 13:35:03.216	2026-06-15 04:13:05.602	2026-06-19 13:35:03.216
cmqep6tag00n2jxp5l6efpj4t	cmqep6t7x00fkjxp5dokcsihq	cmqep6t9400iejxp54gkhmb1r	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:32:11.747	2026-06-19 13:32:09.975	cmq0kyw85007kjx239k25z1ge	\N	ไม่มั่นใจในลายมือ	เพื่อนบลูลี่	external	2026-06-19 13:35:26.043	2026-06-15 04:13:05.602	2026-06-19 13:35:26.044
cmqep6tag00nijxp5mr9x9803	cmqep6t7x00fqjxp5np9idghm	cmqep6t9400ikjxp5hxoelt9l	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:34:41.882	2026-06-19 13:34:39.938	cmq0khs5m000wjx23jyhqhgkv	\N	ขาดความมั่นใจในตัวเอง เข้าข้างตัวเอง	ไม่มี	internal	2026-06-19 13:36:02.063	2026-06-15 04:13:05.602	2026-06-19 13:36:02.064
cmqep6tah00o9jxp5hmnr19ba	cmqep6t7x00fyjxp5gd0tiz6q	cmqep6t9400isjxp5q3gysgu2	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:39:16.125	2026-06-19 13:39:09.468	cmq0kwit80066jx23pw930nx1	\N	ด้านอารมณ์	ครอบครัวไม่ค่อยอยากอยู่กลับครอบครัว	external	2026-06-19 13:40:22.812	2026-06-15 04:13:05.602	2026-06-19 13:40:22.812
cmqep6tag00npjxp5dzn5jhit	cmqep6t7x00fsjxp5s3lf3hkn	cmqep6t9400imjxp523k3l27b	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:44:10.71	2026-06-19 13:44:09.272	cmq0khs5m000wjx23jyhqhgkv	\N	มีความมั่นใจในตัวเอง	ด้านครอบครัว ด้านการเงิน	internal	2026-06-19 13:44:51.057	2026-06-15 04:13:05.602	2026-06-19 13:44:51.058
cmqep6tag00n9jxp52xc0a3gs	cmqep6t7x00fnjxp5bqhzrp6l	cmqep6t9400ihjxp5z57lkkn2	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:44:10.619	2026-06-19 13:44:09.488	cmq0khs5m000wjx23jyhqhgkv	\N	รู้สึกไม่มั่นใจ หาทางออกให้ตัวเอง\nสร้างฝันให้กับตัวเอง	ไม่มี	internal	2026-06-19 13:46:48.434	2026-06-15 04:13:05.602	2026-06-19 13:46:48.435
cmqep6tah00p7jxp53nbp6cru	cmqep6t7y00g7jxp5dadbmh4c	cmqep6t9400j1jxp5niy42x68	2	completed	2026-06-19 06:50:02.764	2026-06-26 08:45:30.037	2026-06-26 08:45:28.982	cmq0kwit80066jx23pw930nx1	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:45:30.038
cmr254jpo00hljxctgfopjfwi	cmr254jj6001ljxct3dsq8br7	cmr254jms009ijxctejyw577w	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6tah00ohjxp5q7fw1xv1	cmqep6t7x00fzjxp54fjcjtah	cmqep6t9400itjxp58wqnqblq	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tah00oijxp5xk1q80cs	cmqep6t7x00fzjxp54fjcjtah	cmqep6t9400itjxp58wqnqblq	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tah00pajxp54kn6sbhs	cmqep6t7y00g8jxp5e5io1j25	cmqep6t9400j2jxp58h2t12fu	2	completed	2026-06-19 12:47:03.228	2026-06-26 08:46:26.651	2026-06-26 08:46:25.446	cmq0kwit80066jx23pw930nx1	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:46:26.652
cmr254jpo00hmjxctlmfvdcy5	cmr254jj6001ljxct3dsq8br7	cmr254jms009ijxctejyw577w	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6tai00ppjxp5rgbfcf31	cmqep6t7y00gdjxp59lrmb5t2	cmqep6t9400j7jxp5zb2zuhrm	2	completed	2026-06-19 13:00:50.367	2026-06-26 08:52:00.842	2026-06-26 08:51:52.878	cmq0kwit80066jx23pw930nx1	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:52:00.843
cmqep6tah00phjxp5cv6jvy22	cmqep6t7y00gajxp56csicf0x	cmqep6t9400j4jxp52hwv21c8	5	completed	2026-06-26 08:48:39.034	2026-07-03 09:27:07.623	2026-07-03 09:26:57.949	cmq0kyw85007kjx239k25z1ge	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:27:07.624
cmqep6tah00pmjxp56x3pm3aq	cmqep6t7y00gcjxp545zm4dej	cmqep6t9400j6jxp54seruv6b	2	completed	2026-06-19 12:58:48.88	2026-06-26 08:51:10.943	2026-06-26 08:51:09.21	cmq0kwit80066jx23pw930nx1	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:51:10.944
cmqep6tah00p8jxp5pcqv2mzs	cmqep6t7y00g7jxp5dadbmh4c	cmqep6t9400j1jxp5niy42x68	5	completed	2026-06-26 08:45:30.04	2026-07-03 09:29:16.053	2026-07-03 09:29:10.317	cmq0kyw85007kjx239k25z1ge	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:29:16.053
cmqep6tah00pejxp5jzau997h	cmqep6t7y00g9jxp5yihqococ	cmqep6t9400j3jxp5vvixk3ea	5	completed	2026-06-26 08:47:09.318	2026-07-03 09:29:23.143	2026-07-03 09:29:18.795	cmq0kyw85007kjx239k25z1ge	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:29:23.144
cmqep6tai00pqjxp5iwbppnif	cmqep6t7y00gdjxp59lrmb5t2	cmqep6t9400j7jxp5zb2zuhrm	5	completed	2026-06-26 08:52:00.847	2026-07-03 09:34:14.894	2026-07-03 09:34:12.253	cmq0kyw85007kjx239k25z1ge	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:34:14.895
cmqep6tah00ogjxp58xed7ppf	cmqep6t7x00fzjxp54fjcjtah	cmqep6t9400itjxp58wqnqblq	3	in_progress	2026-06-26 09:36:54.715	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:36:54.716
cmqep6tai00ptjxp5ynbr7fhg	cmqep6t7y00gejxp5hwiyumv6	cmqep6t9400j8jxp57qqo0m42	5	completed	2026-06-26 08:52:52.597	2026-07-03 09:36:18.916	2026-07-03 09:36:16.119	cmq0kyw85007kjx239k25z1ge	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:36:18.917
cmqep6tah00p1jxp594ux1tet	cmqep6t7y00g5jxp53scmw13t	cmqep6t9400izjxp5kkrzband	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tah00p2jxp5o9w8vc5g	cmqep6t7y00g5jxp53scmw13t	cmqep6t9400izjxp5kkrzband	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tah00p0jxp5jajc5adv	cmqep6t7y00g5jxp53scmw13t	cmqep6t9400izjxp5kkrzband	3	in_progress	2026-06-26 09:42:05.425	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:42:05.426
cmqep6tah00oujxp5of76dk71	cmqep6t7y00g3jxp5y3q080vj	cmqep6t9400ixjxp5vstdjxdp	5	completed	2026-06-26 09:56:18.006	2026-07-03 09:40:53.639	2026-07-03 09:40:52.144	cmq0kyw85007kjx239k25z1ge	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:40:53.639
cmqep6tah00p4jxp5y7vlgu2v	cmqep6t7y00g6jxp5voah6fkg	cmqep6t9400j0jxp5yejmpcsg	2	completed	2026-06-19 13:29:06.329	2026-06-26 09:54:32.492	2026-06-26 09:54:31.637	cmq0kwit80066jx23pw930nx1	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:54:32.493
cmqep6tah00p5jxp5qfx8zw2o	cmqep6t7y00g6jxp5voah6fkg	cmqep6t9400j0jxp5yejmpcsg	5	completed	2026-06-26 09:54:32.497	2026-07-03 09:41:29.972	2026-07-03 09:41:28.034	cmq0kyw85007kjx239k25z1ge	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:41:29.972
cmqep6tah00owjxp5hu9r2sji	cmqep6t7y00g4jxp56txcwtrq	cmqep6t9400iyjxp5rtvgdkja	2	completed	2026-06-19 13:27:04.949	2026-06-26 09:54:57.18	2026-06-26 09:54:55.896	cmq0kwit80066jx23pw930nx1	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:54:57.181
cmqep6tah00onjxp58m3vccb3	cmqep6t7x00g1jxp5xksr1is3	cmqep6t9400ivjxp5t3h4go5l	2	completed	2026-06-19 13:29:34.777	2026-06-26 09:55:33.793	2026-06-26 09:55:32.681	cmq0kwit80066jx23pw930nx1	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:55:33.794
cmqep6tah00oojxp5tziu8leu	cmqep6t7x00g1jxp5xksr1is3	cmqep6t9400ivjxp5t3h4go5l	5	completed	2026-06-26 09:55:33.798	2026-07-03 09:42:33.78	2026-07-03 09:42:32.067	cmq0kyw85007kjx239k25z1ge	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:42:33.781
cmqep6tah00orjxp5efmibx3o	cmqep6t7x00g2jxp55u0n4faa	cmqep6t9400iwjxp5r5qe1j3u	5	completed	2026-06-26 09:55:48.489	2026-07-03 09:43:04.333	2026-07-03 09:43:02.915	cmq0kyw85007kjx239k25z1ge	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:43:04.334
cmqep6tah00pcjxp5m95u1coe	cmqep6t7y00g9jxp5yihqococ	cmqep6t9400j3jxp5vvixk3ea	1	completed	2026-06-15 04:13:05.592	2026-06-19 12:52:09.576	2026-06-19 12:52:01.938	cmq0khs5m000wjx23jyhqhgkv	\N	ยังกังวลกับตัวเอง	ไม่มี	internal	2026-06-19 12:52:40.934	2026-06-15 04:13:05.602	2026-06-19 12:52:40.935
cmqep6tah00pfjxp5spm3q8j2	cmqep6t7y00gajxp56csicf0x	cmqep6t9400j4jxp52hwv21c8	1	completed	2026-06-15 04:13:05.592	2026-06-19 12:54:34.48	2026-06-19 12:54:32.381	cmq0khs5m000wjx23jyhqhgkv	\N	ไม่มีความชัดเจนกับตัวเอง	ไม่มี	internal	2026-06-19 12:57:01.886	2026-06-15 04:13:05.602	2026-06-19 12:57:01.887
cmqep6tai00pyjxp5ebctdlu8	cmqep6t7y00ggjxp5lamjmi4s	cmqep6t9400jajxp57smqjf8x	2	in_progress	2026-06-19 12:56:15.423	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-19 12:56:15.423
cmqep6tai00pxjxp5fj8n0t6o	cmqep6t7y00ggjxp5lamjmi4s	cmqep6t9400jajxp57smqjf8x	1	completed	2026-06-15 04:13:05.592	2026-06-19 12:56:15.419	2026-06-19 12:55:07.081	cmq0kwit80066jx23pw930nx1	\N	ต้องการพัฒนาให้ตัวเองเรียนให้เก่งขึ้น	ยังไม่พอใจกับผลการเรียนของตนเอง	internal	2026-06-19 12:59:15.4	2026-06-15 04:13:05.602	2026-06-19 12:59:15.401
cmqep6tai00pojxp54bmndmvi	cmqep6t7y00gdjxp59lrmb5t2	cmqep6t9400j7jxp5zb2zuhrm	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:00:50.355	2026-06-19 13:00:47.629	cmq0khs5m000wjx23jyhqhgkv	\N	มีความภูมิใจในตัวเองมาก	ไม่มี	internal	2026-06-19 13:01:45.876	2026-06-15 04:13:05.602	2026-06-19 13:01:45.877
cmqep6tai00pujxp5oyhlxnf0	cmqep6t7y00gfjxp567zr1gct	cmqep6t9400j9jxp5qsnw08cm	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:00:58.485	2026-06-19 13:00:56.519	cmq0khs5m000wjx23jyhqhgkv	\N	ขาดความมั่นใจ	ไม่มี	internal	2026-06-19 13:02:07.921	2026-06-15 04:13:05.602	2026-06-19 13:02:07.922
cmqep6tai00prjxp5k5ki8rv2	cmqep6t7y00gejxp5hwiyumv6	cmqep6t9400j8jxp57qqo0m42	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:03:31.56	2026-06-19 13:03:29.861	cmq0khs5m000wjx23jyhqhgkv	\N	ขาดความมั่นใจ คนรอบข้างมีอิทธิพลมาก	ไม่มี	internal	2026-06-19 13:03:52.71	2026-06-15 04:13:05.602	2026-06-19 13:03:52.711
cmqep6tah00ovjxp5vhgzu8de	cmqep6t7y00g4jxp56txcwtrq	cmqep6t9400iyjxp5rtvgdkja	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:27:04.945	2026-06-19 13:26:51.632	cmq0kwit80066jx23pw930nx1	\N	ไม่มี	ไม่มี	external	2026-06-19 13:27:42.748	2026-06-15 04:13:05.602	2026-06-19 13:27:42.749
cmqep6tah00osjxp5mjo9f31e	cmqep6t7y00g3jxp5y3q080vj	cmqep6t9400ixjxp5vstdjxdp	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:29:31.39	2026-06-19 13:29:22.089	cmq0khs5m000wjx23jyhqhgkv	\N	มีความมั่นใจ กล้าแสดงออก	ไม่มี	internal	2026-06-19 13:29:59.867	2026-06-15 04:13:05.602	2026-06-19 13:29:59.868
cmqep6tah00p3jxp56fosqqz5	cmqep6t7y00g6jxp5voah6fkg	cmqep6t9400j0jxp5yejmpcsg	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:29:06.324	2026-06-19 13:28:58.667	cmq0khs5m000wjx23jyhqhgkv	\N	ขาดความมั่นใจในตัวเอง	ไม่มี	internal	2026-06-19 13:29:28.114	2026-06-15 04:13:05.602	2026-06-19 13:29:28.114
cmqep6tah00omjxp5xpfrqi59	cmqep6t7x00g1jxp5xksr1is3	cmqep6t9400ivjxp5t3h4go5l	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:29:34.774	2026-06-19 13:29:29.133	cmq0kwit80066jx23pw930nx1	\N	ไม่มี	ครอบครัวเเยกทางกัน	external	2026-06-19 13:30:56.779	2026-06-15 04:13:05.602	2026-06-19 13:30:56.78
cmqep6tah00oejxp5b93u9tei	cmqep6t7x00fzjxp54fjcjtah	cmqep6t9400itjxp58wqnqblq	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:38:36.056	2026-06-19 13:38:35.057	cmq0khs5m000wjx23jyhqhgkv	\N	ขาดความมั่นใจในตัวเอง  	กังวลในรูปร่างตัวเอง	internal	2026-06-19 13:39:50.562	2026-06-15 04:13:05.602	2026-06-19 13:39:50.563
cmqep6tai00pzjxp5shk3ts58	cmqep6t7y00ggjxp5lamjmi4s	cmqep6t9400jajxp57smqjf8x	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tai00r7jxp5uy4yb2v5	cmqep6t7y00gtjxp5zntc9qfk	cmqep6t9500jnjxp5yvcdf15m	2	completed	2026-06-19 13:08:24.674	2026-06-26 08:45:12.256	2026-06-26 08:45:09.845	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:45:12.257
cmr254jpo00hnjxctjicgjwcz	cmr254jj6001ljxct3dsq8br7	cmr254jms009ijxctejyw577w	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6tai00rajxp50xwn83zl	cmqep6t7y00gvjxp59jqt3gqm	cmqep6t9500jpjxp5enw820v2	2	completed	2026-06-19 13:09:09.526	2026-06-26 08:46:48.315	2026-06-26 08:46:44.241	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:46:48.316
cmr254jpo00hojxctblnvoord	cmr254jj6001mjxcttgoon3hz	cmr254jms009jjxct23t8tn0b	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6tai00r3jxp58ltfatzw	cmqep6t7y00gsjxp5mtilww6e	cmqep6t9500jmjxp5bsu40yub	2	completed	2026-06-19 13:01:44.9	2026-06-26 09:02:23.688	2026-06-26 09:02:13.695	cmq0kwit80066jx23pw930nx1	ค้นหาคุณค่าในตัวเองทางด้านบวกมากขึ้น	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:02:23.689
cmqep6taj00rijxp557niep4u	cmqep6t7y00gyjxp50orak3f8	cmqep6t9500jsjxp5ef2erjmm	2	completed	2026-06-19 13:09:56.276	2026-06-26 08:49:46.091	2026-06-26 08:49:42.742	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:49:46.092
cmr254jpo00hpjxctkt2x3axc	cmr254jj6001mjxcttgoon3hz	cmr254jms009jjxct23t8tn0b	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6tai00qajxp5hptf4qut	cmqep6t7y00gkjxp5h4f0156z	cmqep6t9500jejxp5atgprn20	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tai00qxjxp532bbvrud	cmqep6t7y00gqjxp5i3yv7iln	cmqep6t9500jkjxp51baz0r1h	2	completed	2026-06-19 12:58:40.628	2026-06-26 08:50:27.36	2026-06-26 08:50:25.488	cmq0kwit80066jx23pw930nx1	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:50:27.361
cmqep6tai00q9jxp52ljpy483	cmqep6t7y00gkjxp5h4f0156z	cmqep6t9500jejxp5atgprn20	3	in_progress	2026-06-26 08:56:03.24	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:56:03.241
cmqep6tai00rejxp5iliqozw7	cmqep6t7y00gwjxp50vs32gfn	cmqep6t9500jqjxp55fr44i9j	3	completed	2026-06-26 09:08:20.032	2026-07-03 09:50:32.032	2026-07-03 09:49:36.317	cmq0kyw85007kjx239k25z1ge	พูดคุย ปรับความคิด	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:50:32.033
cmqep6tai00q4jxp5kyz686pg	cmqep6t7y00gjjxp59b9xkcrz	cmqep6t9500jdjxp5plj8wi0g	2	completed	2026-06-19 12:47:05.527	2026-06-26 08:56:05.309	2026-06-26 08:55:52.077	cmq0kwit80066jx23pw930nx1	เด็กค้นหาคุณค่าในตัวเองทางด้านบวกมากขึ้น	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:56:05.309
cmqep6tai00qdjxp5ofl8ae82	cmqep6t7y00gljxp5et9f6y0c	cmqep6t9500jfjxp5vl7ugm1d	3	completed	2026-06-19 12:57:51.415	2026-06-26 08:59:59.062	2026-06-26 08:59:56.54	cmq0kwit80066jx23pw930nx1	มีคุณค่าทางด้านบวกมากขึ้น	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:59:59.063
cmqep6taj00rjjxp5gs75w40x	cmqep6t7y00gyjxp50orak3f8	cmqep6t9500jsjxp5ef2erjmm	5	completed	2026-06-26 08:49:46.095	2026-07-03 09:29:34.35	2026-07-03 09:29:32.14	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:29:34.351
cmqep6tai00qpjxp5pvas09k2	cmqep6t7y00gojxp5v1t19fiv	cmqep6t9500jijxp5fmhyucyx	2	completed	2026-06-19 13:01:17.997	2026-06-26 09:01:29.389	2026-06-26 09:01:27.368	cmq0kwit80066jx23pw930nx1	มีความอดทนมากขึ้น	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:01:29.39
cmqep6tai00qqjxp58ovfu1kj	cmqep6t7y00gojxp5v1t19fiv	cmqep6t9500jijxp5fmhyucyx	3	completed	2026-06-26 09:01:29.394	2026-07-03 09:48:27.174	2026-07-03 09:48:24.994	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:48:27.175
cmqep6tai00qnjxp5e288ye9w	cmqep6t7y00gnjxp50tru9y0t	cmqep6t9500jhjxp5ee6zin61	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tai00qhjxp5imuvvhe8	cmqep6t7y00gmjxp5w0cyfz8a	cmqep6t9500jgjxp54oyob17b	3	completed	2026-06-26 09:01:07.113	2026-07-03 09:55:26.765	2026-07-03 09:55:19.236	cmq0khs5m000wjx23jyhqhgkv	เสริมสร้างกำลังใจ	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:55:26.766
cmqep6tai00qujxp5eb5gc2fj	cmqep6t7y00gpjxp5s7zduyel	cmqep6t9500jjjxp59xh7ckl7	3	in_progress	2026-06-26 09:04:31.967	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:04:31.968
cmqep6tai00qmjxp5nci2joos	cmqep6t7y00gnjxp50tru9y0t	cmqep6t9500jhjxp5ee6zin61	4	in_progress	2026-07-03 09:59:35.501	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:59:35.502
cmqep6tai00qvjxp5yd0sp0c9	cmqep6t7y00gpjxp5s7zduyel	cmqep6t9500jjjxp59xh7ckl7	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tai00qijxp5y4w2qnsm	cmqep6t7y00gmjxp5w0cyfz8a	cmqep6t9500jgjxp54oyob17b	5	in_progress	2026-07-03 09:55:26.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:55:26.77
cmqep6tai00q6jxp5s5i4t63f	cmqep6t7y00gjjxp59b9xkcrz	cmqep6t9500jdjxp5plj8wi0g	5	in_progress	2026-07-03 10:01:31.377	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 10:01:31.378
cmqep6tai00qejxp5mn4249yf	cmqep6t7y00gljxp5et9f6y0c	cmqep6t9500jfjxp5vl7ugm1d	5	in_progress	2026-06-26 08:59:59.067	\N	\N	cmq0khs5m000wjx23jyhqhgkv	ใช้เวลาว่างให้เกิดประโยชน์	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 10:02:25.959
cmqep6tai00r5jxp5s597ugol	cmqep6t7y00gsjxp5mtilww6e	cmqep6t9500jmjxp5bsu40yub	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6taj00rgjxp561k88x9g	cmqep6t7y00gwjxp50vs32gfn	cmqep6t9500jqjxp55fr44i9j	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tai00q0jxp5n901ajlc	cmqep6t7y00ghjxp58tgg12zq	cmqep6t9500jbjxp5vxqfjko9	1	completed	2026-06-15 04:13:05.592	2026-06-19 12:47:02.952	2026-06-19 12:46:17.657	cmq0khs5m000wjx23jyhqhgkv	\N	เด็กมีความมั่นใจในตัวเอง	ไม่มี	internal	2026-06-19 12:49:07.919	2026-06-15 04:13:05.602	2026-06-19 12:49:07.92
cmqep6tai00qwjxp5c96eje9e	cmqep6t7y00gqjxp5i3yv7iln	cmqep6t9500jkjxp51baz0r1h	1	completed	2026-06-15 04:13:05.592	2026-06-19 12:58:40.621	2026-06-19 12:58:38.913	cmq0khs5m000wjx23jyhqhgkv	\N	ขาดความมั่นใจ	ไม่มี	internal	2026-06-19 12:59:19.662	2026-06-15 04:13:05.602	2026-06-19 12:59:19.663
cmqep6tai00qzjxp5ag9h6oxy	cmqep6t7y00grjxp5xaus94pp	cmqep6t9500jljxp5kexpgbim	1	completed	2026-06-15 04:13:05.592	2026-06-19 12:51:48.778	2026-06-19 12:51:40.549	cmq0khs5m000wjx23jyhqhgkv	\N	มีความมั่นใจในตัวเอง	ไม่มี	internal	2026-06-19 12:52:48.477	2026-06-15 04:13:05.602	2026-06-19 12:52:48.478
cmqep6tai00qbjxp5s7cp3vn7	cmqep6t7y00gljxp5et9f6y0c	cmqep6t9500jfjxp5vl7ugm1d	1	completed	2026-06-15 04:13:05.592	2026-06-19 12:54:16.434	2026-06-19 12:54:13.949	cmq0kyw85007kjx239k25z1ge	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-19 12:54:16.435
cmqep6tai00qcjxp5o7jklvp8	cmqep6t7y00gljxp5et9f6y0c	cmqep6t9500jfjxp5vl7ugm1d	2	completed	2026-06-19 12:54:16.438	2026-06-19 12:57:51.411	2026-06-19 12:57:50.069	cmq0kyw85007kjx239k25z1ge	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-19 12:57:51.412
cmqep6tai00r2jxp5utjyurzv	cmqep6t7y00gsjxp5mtilww6e	cmqep6t9500jmjxp5bsu40yub	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:01:44.895	2026-06-19 13:01:25.807	cmq0kwit80066jx23pw930nx1	\N	ไม่มี	ปัญหาด้านครอบครัว พ่อแม่่ไม่ค่อยฟังเหตุผลลูก	external	2026-06-19 13:05:36.988	2026-06-15 04:13:05.602	2026-06-19 13:05:36.989
cmqep6taj00rhjxp5ez1hp62e	cmqep6t7y00gyjxp50orak3f8	cmqep6t9500jsjxp5ef2erjmm	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:09:56.272	2026-06-19 13:09:53.835	cmq0kwit80066jx23pw930nx1	\N	ขาดความมั่นใจ ในการเรียน	ไม่มี	internal	2026-06-19 13:10:52.477	2026-06-15 04:13:05.602	2026-06-19 13:10:52.478
cmqep6tai00r6jxp5r5r0quj7	cmqep6t7y00gtjxp5zntc9qfk	cmqep6t9500jnjxp5yvcdf15m	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:08:24.669	2026-06-19 13:08:20.11	cmq0khs5m000wjx23jyhqhgkv	\N	ยังค้นหาตัวเองไม่เจอ	ไม่มี	internal	2026-06-19 13:09:46.316	2026-06-15 04:13:05.602	2026-06-19 13:09:46.316
cmqep6tai00rcjxp5dnaav6je	cmqep6t7y00gwjxp50vs32gfn	cmqep6t9500jqjxp55fr44i9j	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:19:06.469	2026-06-19 13:18:56.533	cmq0khs5m000wjx23jyhqhgkv	\N	ขาดความมั่นใจ โดนเพื่อนบลูลี่	ถูกกลั่นแกล้ง	external	2026-06-19 13:20:18.939	2026-06-15 04:13:05.602	2026-06-19 13:20:18.941
cmqep6taj00stjxp5f5mpxrl6	cmqep6t7y00hcjxp5o0okg8br	cmqep6t9500k6jxp57h4lamza	2	completed	2026-06-19 13:09:32.421	2026-06-26 08:47:40.41	2026-06-26 08:47:12.455	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:47:40.41
cmr254jpo00hqjxctx72x5tv8	cmr254jj6001mjxcttgoon3hz	cmr254jms009jjxct23t8tn0b	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6taj00rojxp5y15oon7x	cmqep6t7y00gzjxp5ymu2sdwq	cmqep6t9500jtjxp5auvusch8	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6taj00t0jxp5oknq0hgl	cmqep6t7y00hejxp5jx21o02o	cmqep6t9500k8jxp5f61o1mj3	2	completed	2026-06-19 13:09:41.698	2026-06-26 08:50:58.032	2026-06-26 08:50:55.83	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:50:58.033
cmr254jpo00hrjxcttpdhzlb0	cmr254jj6001njxctguuj6dv1	cmr254jms009kjxctyq1lkvfe	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6taj00rnjxp5skmyz46e	cmqep6t7y00gzjxp5ymu2sdwq	cmqep6t9500jtjxp5auvusch8	4	in_progress	2026-07-03 09:52:18.281	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:52:18.281
cmqep6taj00rrjxp5x1c7gucn	cmqep6t7y00h0jxp5b6k9d2ql	cmqep6t9500jujxp5pardkvru	5	completed	2026-06-26 08:52:25.582	2026-07-03 09:30:41.572	2026-07-03 09:30:38.048	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:30:41.573
cmqep6taj00sfjxp5wz9pc3x8	cmqep6t7y00h7jxp5aomv3xif	cmqep6t9500k1jxp5ntanhqsd	5	completed	2026-06-26 09:00:12.524	2026-07-03 09:32:31.896	2026-07-03 09:32:25.138	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:32:31.897
cmqep6taj00rwjxp5epmmcbo7	cmqep6t7y00h1jxp5kcbzvnst	cmqep6t9500jvjxp5bt8vbsww	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6tah00pnjxp5v8fgelut	cmqep6t7y00gcjxp545zm4dej	cmqep6t9400j6jxp54seruv6b	5	completed	2026-06-26 08:51:10.947	2026-07-03 09:32:59.509	2026-07-03 09:32:55.296	cmq0kyw85007kjx239k25z1ge	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:32:59.509
cmqep6taj00snjxp5m60e1szu	cmqep6t7y00hajxp53xjfiwp0	cmqep6t9500k4jxp58jv5ogik	5	in_progress	2026-06-26 08:54:20.384	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:54:20.385
cmqep6tai00qyjxp5hcnc89ts	cmqep6t7y00gqjxp5i3yv7iln	cmqep6t9500jkjxp51baz0r1h	5	completed	2026-06-26 08:50:27.365	2026-07-03 09:35:15.095	2026-07-03 09:35:11.133	cmq0kyw85007kjx239k25z1ge	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:35:15.096
cmqep6taj00s3jxp5qcism2d4	cmqep6t7y00h3jxp5nsmq0bu1	cmqep6t9500jxjxp5c9llkurt	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6taj00sajxp5apttdphx	cmqep6t7y00h6jxp5lq2ohp8z	cmqep6t9500k0jxp51dcqlx2y	1	completed	2026-06-15 04:13:05.592	2026-06-26 08:57:23.818	2026-06-26 08:57:22.234	cmq0khs5m000wjx23jyhqhgkv	\N	รู้สึกไร้ค่า	ด้านการเรียน	internal	2026-06-26 08:57:58.402	2026-06-15 04:13:05.602	2026-06-26 08:57:58.403
cmqep6taj00syjxp58l5jyyv8	cmqep6t7y00hdjxp51yn11mxr	cmqep6t9500k7jxp51y56x4wo	5	in_progress	2026-07-03 09:54:19.449	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:54:19.45
cmqep6taj00sjjxp508pmkq6b	cmqep6t7y00h9jxp5ov6rpkzw	cmqep6t9500k3jxp52ot5274r	4	in_progress	2026-07-03 09:55:02.595	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:55:02.596
cmqep6taj00sqjxp5609dzmb2	cmqep6t7y00hbjxp5na2uvdzn	cmqep6t9500k5jxp5jdi00gvp	3	completed	2026-06-26 09:06:06.429	2026-07-03 09:56:00.796	2026-07-03 09:55:42.232	cmq0kyw85007kjx239k25z1ge	เป็นกำลังใจให้	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:56:00.797
cmqep6taj00rvjxp52kr4h07f	cmqep6t7y00h1jxp5kcbzvnst	cmqep6t9500jvjxp5bt8vbsww	4	in_progress	2026-07-03 09:57:02.146	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:57:02.147
cmqep6taj00s7jxp5r40tmtpe	cmqep6t7y00h5jxp53x65440u	cmqep6t9500jzjxp5mvj6bhcg	1	completed	2026-06-15 04:13:05.592	2026-06-26 08:56:07.31	2026-06-26 08:56:05.092	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:56:07.311
cmqf02txa006njxopq8rggf5r	cmqf02twi005xjxop9todeqnc	cmqf02twx0066jxop7hee7txt	5	in_progress	2026-06-26 08:59:27.703	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 09:17:55.581	2026-06-26 08:59:27.704
cmqep6taj00skjxp564khdanf	cmqep6t7y00h9jxp5ov6rpkzw	cmqep6t9500k3jxp52ot5274r	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-15 04:13:05.602
cmqep6taj00s8jxp5qxz0kup1	cmqep6t7y00h5jxp53x65440u	cmqep6t9500jzjxp5mvj6bhcg	2	completed	2026-06-26 08:56:07.314	2026-06-26 08:59:36.668	2026-06-26 08:59:32.874	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:59:36.669
cmqep6taj00sojxp5lc75s9he	cmqep6t7y00hbjxp5na2uvdzn	cmqep6t9500k5jxp5jdi00gvp	1	completed	2026-06-15 04:13:05.592	2026-06-26 09:02:57.003	2026-06-26 09:02:54.2	cmq0khs5m000wjx23jyhqhgkv	\N	ขาดความมั่นใจในตัวเอง	ไม่มี	internal	2026-06-26 09:03:28.564	2026-06-15 04:13:05.602	2026-06-26 09:03:28.565
cmqep6taj00swjxp5vif4iinb	cmqep6t7y00hdjxp51yn11mxr	cmqep6t9500k7jxp51y56x4wo	2	completed	2026-06-19 13:16:09.807	2026-06-26 09:02:37.192	2026-06-26 09:02:17.271	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:02:37.193
cmqep6taj00s2jxp5osu1ykux	cmqep6t7y00h3jxp5nsmq0bu1	cmqep6t9500jxjxp5c9llkurt	3	in_progress	2026-06-26 09:04:08.572	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:04:08.573
cmqep6taj00rsjxp5u3dk66t6	cmqep6t7y00h1jxp5kcbzvnst	cmqep6t9500jvjxp5bt8vbsww	1	completed	2026-06-15 04:13:05.592	2026-06-26 09:09:43.975	2026-06-26 09:09:18.426	cmq0khs5m000wjx23jyhqhgkv	\N	รู้สึกไร้ค่า	ปัญหาการเรียน	internal	2026-06-26 09:10:23.779	2026-06-15 04:13:05.602	2026-06-26 09:10:23.78
cmqep6taj00rpjxp50nreu26u	cmqep6t7y00h0jxp5b6k9d2ql	cmqep6t9500jujxp5pardkvru	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:11:22.862	2026-06-19 13:11:21.629	cmq0khs5m000wjx23jyhqhgkv	\N	ไม่มั่นใจในตัวเอง	ไม่มี	internal	2026-06-19 13:12:33.475	2026-06-15 04:13:05.602	2026-06-19 13:12:33.476
cmqep6taj00sljxp5cpo760li	cmqep6t7y00hajxp53xjfiwp0	cmqep6t9500k4jxp58jv5ogik	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:12:21.427	2026-06-19 13:12:19.026	cmq0kwit80066jx23pw930nx1	\N	ไม่หมั่นใจในตนเองง	ไม่มี	internal	2026-06-19 13:13:41.74	2026-06-15 04:13:05.602	2026-06-19 13:13:41.741
cmqep6taj00rxjxp5rbgwkpys	cmqep6t7y00h2jxp5gb0okmzi	cmqep6t9500jwjxp5qugh2ett	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:13:00.389	2026-06-19 13:12:59.29	cmq0kyw85007kjx239k25z1ge	\N	ไม่มั่นใจในการตัดสินใจซื้อมือถือและการแก้ร.	มีปัญหาด้านการเรียน	internal	2026-06-19 13:14:33.758	2026-06-15 04:13:05.602	2026-06-19 13:14:33.759
cmqep6taj00rljxp5bwtc826w	cmqep6t7y00gzjxp5ymu2sdwq	cmqep6t9500jtjxp5auvusch8	2	completed	2026-06-19 13:16:57.875	2026-06-26 09:08:05.811	2026-06-26 09:07:58.52	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:08:05.812
cmqep6taj00t2jxp5wdtn0ady	cmqep6t7y00hgjxp51uc3pwty	cmqep6t9500kajxp58wj2pelo	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:13:41.858	2026-06-19 13:13:40.315	cmq0khs5m000wjx23jyhqhgkv	\N	เห็นความสำคัญของตัวเอง	ไม่มี	internal	2026-06-19 13:14:29.2	2026-06-15 04:13:05.602	2026-06-19 13:14:29.201
cmqep6taj00sdjxp55omhcud3	cmqep6t7y00h7jxp5aomv3xif	cmqep6t9500k1jxp5ntanhqsd	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:14:33.514	2026-06-19 13:14:32.13	cmq0kwit80066jx23pw930nx1	\N	ต้องการพัฒนาการเล่นบอล	ยังต้องพัฒนาการทำงาน	external	2026-06-19 13:16:58.069	2026-06-15 04:13:05.602	2026-06-19 13:16:58.07
cmqep6taj00sgjxp5zb6x2opq	cmqep6t7y00h9jxp5ov6rpkzw	cmqep6t9500k3jxp52ot5274r	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:17:30.87	2026-06-19 13:17:29.438	cmq0khs5m000wjx23jyhqhgkv	\N	รู้สึกไร้ค่า 	ปัญหาด้านการเรียน การเงิน	internal	2026-06-19 13:18:12.167	2026-06-15 04:13:05.602	2026-06-19 13:18:12.168
cmqep6taj00svjxp5f2j1fghe	cmqep6t7y00hdjxp51yn11mxr	cmqep6t9500k7jxp51y56x4wo	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:16:09.803	2026-06-19 13:15:50.709	cmq0kwit80066jx23pw930nx1	\N	ไม่มั่นใจในตนเอง รู้ไร้ค่า	ไม่มี	internal	2026-06-19 13:18:37.039	2026-06-15 04:13:05.602	2026-06-19 13:18:37.04
cmqep6taj00shjxp5zp07hdae	cmqep6t7y00h9jxp5ov6rpkzw	cmqep6t9500k3jxp52ot5274r	2	completed	2026-06-19 13:17:30.874	2026-06-26 09:09:30.609	2026-06-26 09:09:26.68	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:09:30.61
cmqep6taj00rtjxp5sm52leb4	cmqep6t7y00h1jxp5kcbzvnst	cmqep6t9500jvjxp5bt8vbsww	2	completed	2026-06-26 09:09:43.98	2026-06-26 09:12:26.897	2026-06-26 09:11:45.629	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:12:26.898
cmr254jpo00hsjxct7xed43ft	cmr254jj6001njxctguuj6dv1	cmr254jms009kjxctyq1lkvfe	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6tak00tdjxp5p1i6es6k	cmqep6t7y00hjjxp5xa6i02q3	cmqep6t9500kdjxp5zbtb2lnz	2	completed	2026-06-19 13:09:15.579	2026-06-26 08:48:47.124	2026-06-26 08:48:26.771	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:48:47.124
cmqep6tak00tajxp5hhcp9r8i	cmqep6t7y00hijxp5mgitskzp	cmqep6t9500kcjxp5ckg6g2ce	2	completed	2026-06-19 13:11:20.596	2026-06-26 08:52:01.774	2026-06-26 08:51:53.779	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:52:01.775
cmqep6tak00t7jxp5c79eljfj	cmqep6t7y00hhjxp595rvk6sq	cmqep6t9500kbjxp5qesv8hdv	3	completed	2026-06-26 09:06:16.389	2026-07-03 09:50:05.41	2026-07-03 09:49:58.913	cmq0kyw85007kjx239k25z1ge	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:50:05.411
cmqep6taj00rqjxp5eyutrxxk	cmqep6t7y00h0jxp5b6k9d2ql	cmqep6t9500jujxp5pardkvru	2	completed	2026-06-19 13:11:22.865	2026-06-26 08:52:25.578	2026-06-26 08:52:21.492	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:52:25.579
cmqexode400vkjxp5pma8v41q	cmqexodd500twjxp5ozjix5p3	cmqexoddo00uqjxp599ehqyun	1	in_progress	2026-06-15 08:10:41.738	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400vljxp537zjmehv	cmqexodd500twjxp5ozjix5p3	cmqexoddo00uqjxp599ehqyun	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400vmjxp5djnxqv22	cmqexodd500twjxp5ozjix5p3	cmqexoddo00uqjxp599ehqyun	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400vnjxp574y76clu	cmqexodd500tzjxp5ey8cx4bn	cmqexoddo00utjxp5c7c4todp	1	in_progress	2026-06-15 08:10:41.738	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400vojxp5hrgmd32z	cmqexodd500tzjxp5ey8cx4bn	cmqexoddo00utjxp5c7c4todp	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400vpjxp5z23wwbs6	cmqexodd500tzjxp5ey8cx4bn	cmqexoddo00utjxp5c7c4todp	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400vqjxp5bo9ddlov	cmqexodd500tzjxp5ey8cx4bn	cmqexoddo00utjxp5c7c4todp	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400vrjxp5a9j8uva2	cmqexodd500u1jxp5fygnoo9b	cmqexoddo00uvjxp59yjwxcvw	1	in_progress	2026-06-15 08:10:41.738	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400vsjxp5solhkc8j	cmqexodd500u1jxp5fygnoo9b	cmqexoddo00uvjxp59yjwxcvw	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400vtjxp5l7k6vyht	cmqexodd500u1jxp5fygnoo9b	cmqexoddo00uvjxp59yjwxcvw	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400vujxp5gzdkqtle	cmqexodd500u2jxp5vou9mtno	cmqexoddo00uwjxp5y14j6083	1	in_progress	2026-06-15 08:10:41.738	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400vvjxp59xegkj6o	cmqexodd500u2jxp5vou9mtno	cmqexoddo00uwjxp5y14j6083	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400vwjxp58t0hdn07	cmqexodd500u2jxp5vou9mtno	cmqexoddo00uwjxp5y14j6083	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400vxjxp54ar4f39r	cmqexodd500u3jxp5o7xdka1n	cmqexoddo00uxjxp53u0glqzh	1	in_progress	2026-06-15 08:10:41.738	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400vyjxp5w0qx43ea	cmqexodd500u3jxp5o7xdka1n	cmqexoddo00uxjxp53u0glqzh	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400vzjxp576h6j74n	cmqexodd500u3jxp5o7xdka1n	cmqexoddo00uxjxp53u0glqzh	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400w0jxp5egifl70v	cmqexodd500u3jxp5o7xdka1n	cmqexoddo00uxjxp53u0glqzh	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400w1jxp53tvmwznt	cmqexodd600u4jxp5hx4r479y	cmqexoddo00uyjxp5pewiq24u	1	in_progress	2026-06-15 08:10:41.738	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400w2jxp5wmp861vk	cmqexodd600u4jxp5hx4r479y	cmqexoddo00uyjxp5pewiq24u	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400w3jxp5h11w13q4	cmqexodd600u4jxp5hx4r479y	cmqexoddo00uyjxp5pewiq24u	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400w4jxp5nno07uc4	cmqexodd600u4jxp5hx4r479y	cmqexoddo00uyjxp5pewiq24u	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400w5jxp5tfg206tx	cmqexodd600u5jxp5ysyqeaup	cmqexoddo00uzjxp509rdw4i4	1	in_progress	2026-06-15 08:10:41.738	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400w6jxp59mfpox5v	cmqexodd600u5jxp5ysyqeaup	cmqexoddo00uzjxp509rdw4i4	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400w7jxp5eigqlxy6	cmqexodd600u5jxp5ysyqeaup	cmqexoddo00uzjxp509rdw4i4	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400w8jxp5jm4rk18g	cmqexodd600u9jxp5gg5gxyhi	cmqexoddo00v3jxp5qml3h8jb	1	in_progress	2026-06-15 08:10:41.738	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400w9jxp5fwpn9qbd	cmqexodd600u9jxp5gg5gxyhi	cmqexoddo00v3jxp5qml3h8jb	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400wajxp5a73kycfh	cmqexodd600u9jxp5gg5gxyhi	cmqexoddo00v3jxp5qml3h8jb	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400wbjxp5kzljhygp	cmqexodd600u9jxp5gg5gxyhi	cmqexoddo00v3jxp5qml3h8jb	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400wcjxp5fcnwie1k	cmqexodd600ubjxp5392pe7yt	cmqexoddo00v5jxp5tdqrt3e5	1	in_progress	2026-06-15 08:10:41.738	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400wdjxp5mn9nnvai	cmqexodd600ubjxp5392pe7yt	cmqexoddo00v5jxp5tdqrt3e5	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400wejxp55rmvza22	cmqexodd600ubjxp5392pe7yt	cmqexoddo00v5jxp5tdqrt3e5	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400wfjxp5wkq9a29z	cmqexodd600ubjxp5392pe7yt	cmqexoddo00v5jxp5tdqrt3e5	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400wgjxp52awdb4wy	cmqexodd600uejxp5pmwcsj0o	cmqexoddo00v8jxp5085i81o3	1	in_progress	2026-06-15 08:10:41.738	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400whjxp5ubf381gy	cmqexodd600uejxp5pmwcsj0o	cmqexoddo00v8jxp5085i81o3	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400wijxp5ec9hrps9	cmqexodd600uejxp5pmwcsj0o	cmqexoddo00v8jxp5085i81o3	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400wjjxp5hjfxw3cg	cmqexodd600ufjxp5lg8ivxwe	cmqexoddo00v9jxp5tlwy5kka	1	in_progress	2026-06-15 08:10:41.738	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400wkjxp5y4w8oh78	cmqexodd600ufjxp5lg8ivxwe	cmqexoddo00v9jxp5tlwy5kka	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400wljxp5vosjsoc2	cmqexodd600ufjxp5lg8ivxwe	cmqexoddo00v9jxp5tlwy5kka	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400wmjxp5o5oeh449	cmqexodd600ufjxp5lg8ivxwe	cmqexoddo00v9jxp5tlwy5kka	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400wnjxp5zhzzrtfk	cmqexodd600ugjxp53cp800t1	cmqexoddo00vajxp5nqsk3mei	1	in_progress	2026-06-15 08:10:41.738	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400wojxp5lp2iofy6	cmqexodd600ugjxp53cp800t1	cmqexoddo00vajxp5nqsk3mei	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400wpjxp568y8ql2e	cmqexodd600ugjxp53cp800t1	cmqexoddo00vajxp5nqsk3mei	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400wqjxp58aom103n	cmqexodd600ugjxp53cp800t1	cmqexoddo00vajxp5nqsk3mei	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode400wrjxp5lkuxn38t	cmqexodd600uhjxp5exu9cft6	cmqexoddo00vbjxp597bp1148	1	in_progress	2026-06-15 08:10:41.738	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqep6tak00tfjxp53xrvbsqt	cmqep6t7y00hkjxp50bymz2pu	cmqep6t9600kejxp53go2qb09	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:14:24.745	2026-06-19 13:14:23.353	cmq0khs5m000wjx23jyhqhgkv	\N	มีความมั่นใจในตัวเองพอประมาณ	ไม่มี	internal	2026-06-19 13:14:59.85	2026-06-15 04:13:05.602	2026-06-19 13:14:59.851
cmqep6tak00t5jxp5z92erwcp	cmqep6t7y00hhjxp595rvk6sq	cmqep6t9500kbjxp5qesv8hdv	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:17:55.705	2026-06-19 13:17:48.914	cmq0kyw85007kjx239k25z1ge	\N	ไม่มั่นใจในตัวเอง	เรียนไม่เข้าใจ	internal	2026-06-19 13:19:02.479	2026-06-15 04:13:05.602	2026-06-19 13:19:02.48
cmqexode400wsjxp5w9nip6i2	cmqexodd600uhjxp5exu9cft6	cmqexoddo00vbjxp597bp1148	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode500wtjxp5igmhwhye	cmqexodd600uhjxp5exu9cft6	cmqexoddo00vbjxp597bp1148	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode500wujxp5q0ztmmlz	cmqexodd600uhjxp5exu9cft6	cmqexoddo00vbjxp597bp1148	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode500wvjxp5t43sxnt9	cmqexodd600uijxp5pim3mba1	cmqexoddo00vcjxp5w8xm1re2	1	in_progress	2026-06-15 08:10:41.738	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode500wwjxp5mpu1hymx	cmqexodd600uijxp5pim3mba1	cmqexoddo00vcjxp5w8xm1re2	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode500wxjxp57635fbwz	cmqexodd600uijxp5pim3mba1	cmqexoddo00vcjxp5w8xm1re2	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode500wyjxp5m7jeow34	cmqexodd600uijxp5pim3mba1	cmqexoddo00vcjxp5w8xm1re2	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode500wzjxp5upabdqaj	cmqexodd600ujjxp55j4o61zk	cmqexoddo00vdjxp5nadj3dk1	1	in_progress	2026-06-15 08:10:41.738	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode500x0jxp5e48v6grk	cmqexodd600ujjxp55j4o61zk	cmqexoddo00vdjxp5nadj3dk1	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode500x1jxp5dvlbh64g	cmqexodd600ujjxp55j4o61zk	cmqexoddo00vdjxp5nadj3dk1	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode500x2jxp5k7gfjwis	cmqexodd600umjxp5dlcm8f78	cmqexoddo00vgjxp5ogrl99lm	1	in_progress	2026-06-15 08:10:41.738	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode500x3jxp50bo83ax1	cmqexodd600umjxp5dlcm8f78	cmqexoddo00vgjxp5ogrl99lm	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode500x4jxp56v6k2mjj	cmqexodd600umjxp5dlcm8f78	cmqexoddo00vgjxp5ogrl99lm	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode500x5jxp5muemfm5g	cmqexodd600umjxp5dlcm8f78	cmqexoddo00vgjxp5ogrl99lm	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode500x6jxp5v51qn57k	cmqexodd600uojxp55el16rgl	cmqexoddo00vijxp58wvle1w9	1	in_progress	2026-06-15 08:10:41.738	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode500x7jxp5m6u2k986	cmqexodd600uojxp55el16rgl	cmqexoddo00vijxp58wvle1w9	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqexode500x8jxp5k74tq6eo	cmqexodd600uojxp55el16rgl	cmqexoddo00vijxp58wvle1w9	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 08:10:41.74	2026-06-15 08:10:41.74
cmqep6tai00pvjxp5u8lovby9	cmqep6t7y00gfjxp567zr1gct	cmqep6t9400j9jxp5qsnw08cm	2	completed	2026-06-19 13:00:58.489	2026-06-26 08:52:20.679	2026-06-26 08:52:19.477	cmq0kwit80066jx23pw930nx1	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:52:20.68
cmr254jpo00htjxct5zzyljsv	cmr254jj6001njxctguuj6dv1	cmr254jms009kjxctyq1lkvfe	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpo00hujxctbtmlvny7	cmr254jj6001ojxct93uhsc2s	cmr254jms009ljxctgi2zbnzc	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqf02txa006tjxopdeesu8su	cmqf02twi005zjxop5kafgs6v	cmqf02twx0068jxopyix3b9jl	1	completed	2026-06-15 09:17:55.58	2026-06-26 08:55:23.671	2026-06-26 08:55:15.241	cmq0kyw85007kjx239k25z1ge	\N	ขาดความมั่นใจในตัวเอง	มีปัญหาด้านการเรียน	internal	2026-06-26 08:57:18.502	2026-06-15 09:17:55.581	2026-06-26 08:57:18.503
cmr254jpo00hvjxctciyiav6h	cmr254jj6001ojxct93uhsc2s	cmr254jms009ljxctgi2zbnzc	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqf02txa006kjxopge58267l	cmqf02twi005wjxop1suc7kpd	cmqf02twx0065jxopks12xh9e	5	in_progress	2026-07-03 09:52:18.537	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 09:17:55.581	2026-07-03 09:52:18.538
cmqf02txa006qjxop9aptfy8z	cmqf02twi005yjxopdari537w	cmqf02twx0067jxop3imvllx8	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 09:17:55.581	2026-06-15 09:17:55.581
cmqf02txa006rjxopeua17hom	cmqf02twi005yjxopdari537w	cmqf02twx0067jxop3imvllx8	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 09:17:55.581	2026-06-15 09:17:55.581
cmqf02txa006sjxopyn4dh1kb	cmqf02twi005yjxopdari537w	cmqf02twx0067jxop3imvllx8	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 09:17:55.581	2026-06-15 09:17:55.581
cmqf02txa006vjxopxrray4h1	cmqf02twi005zjxop5kafgs6v	cmqf02twx0068jxopyix3b9jl	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 09:17:55.581	2026-06-15 09:17:55.581
cmqf02txa006wjxopw2zf8brm	cmqf02twi005zjxop5kafgs6v	cmqf02twx0068jxopyix3b9jl	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 09:17:55.581	2026-06-15 09:17:55.581
cmqf02txa006zjxopesda3cmi	cmqf02twi0060jxopbq0u963r	cmqf02twx0069jxopew6sr4k5	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 09:17:55.581	2026-06-15 09:17:55.581
cmqf02txa0070jxopxxxz2ml4	cmqf02twi0060jxopbq0u963r	cmqf02twx0069jxopew6sr4k5	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 09:17:55.581	2026-06-15 09:17:55.581
cmqf02txa0074jxopetyd7w8z	cmqf02twi0061jxopfw2ixih5	cmqf02twx006ajxop3fgj1itn	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 09:17:55.581	2026-06-15 09:17:55.581
cmqf02txb0077jxopzf901xd3	cmqf02twi0062jxop3z5jrxny	cmqf02twx006bjxopdyn7ss4z	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 09:17:55.581	2026-06-15 09:17:55.581
cmqf02txb0078jxop8qwre5ah	cmqf02twi0062jxop3z5jrxny	cmqf02twx006bjxopdyn7ss4z	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 09:17:55.581	2026-06-15 09:17:55.581
cmqf02txb0079jxopqnk9z31g	cmqf02twi0062jxop3z5jrxny	cmqf02twx006bjxopdyn7ss4z	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 09:17:55.581	2026-06-15 09:17:55.581
cmqf02txb007djxop8yaqnp4s	cmqf02twi0063jxopuqpquhah	cmqf02twx006cjxopbakfs0te	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 09:17:55.581	2026-06-15 09:17:55.581
cmqgdycof003fjxy9qg95193z	cmqgdycn8001djxy9h4tbxdxf	cmqgdyco0002ejxy9a6u4trlc	1	in_progress	2026-06-16 08:34:07.405	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycof003gjxy9axohl62j	cmqgdycn8001djxy9h4tbxdxf	cmqgdyco0002ejxy9a6u4trlc	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycof003hjxy900vw6mzp	cmqgdycn8001djxy9h4tbxdxf	cmqgdyco0002ejxy9a6u4trlc	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqf02txa006xjxopxlgsu7s0	cmqf02twi0060jxopbq0u963r	cmqf02twx0069jxopew6sr4k5	1	completed	2026-06-15 09:17:55.58	2026-06-26 08:58:52.767	2026-06-26 08:58:40.193	cmq0kyw85007kjx239k25z1ge	\N	ไม่มั่นใจในตัวเอง	ไม่มีความมั่นใจในการเล่นกีฬา	internal	2026-06-26 08:59:38.848	2026-06-15 09:17:55.581	2026-06-26 08:59:38.849
cmqf02txa006mjxop8n28wa17	cmqf02twi005xjxop9todeqnc	cmqf02twx0066jxop7hee7txt	2	completed	2026-06-26 08:55:30.597	2026-06-26 08:59:27.7	2026-06-26 08:59:26.144	cmq0kyw85007kjx239k25z1ge	\N	\N	\N	\N	\N	2026-06-15 09:17:55.581	2026-06-26 08:59:27.701
cmqf02tx9006ejxop4z9mgpb7	cmqf02twi005vjxoph6si1y7m	cmqf02twx0064jxops0zutopk	2	completed	2026-06-19 12:54:19.378	2026-06-26 08:59:59.197	2026-06-26 08:59:55.725	cmq0kwit80066jx23pw930nx1	\N	\N	\N	\N	\N	2026-06-15 09:17:55.581	2026-06-26 08:59:59.198
cmqf02txa006ojxopsrzv36nb	cmqf02twi005yjxopdari537w	cmqf02twx0067jxop3imvllx8	1	completed	2026-06-15 09:17:55.58	2026-06-26 09:01:38.744	2026-06-26 09:01:36.114	cmq0kyw85007kjx239k25z1ge	\N	ไม่มั่นใจในตัวเองและด้านการเรียน	มีปัญหาด้านการเรียน	internal	2026-06-26 09:03:04.023	2026-06-15 09:17:55.581	2026-06-26 09:03:04.024
cmqf02txa006pjxopclng9l5q	cmqf02twi005yjxopdari537w	cmqf02twx0067jxop3imvllx8	2	in_progress	2026-06-26 09:01:38.747	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 09:17:55.581	2026-06-26 09:01:38.748
cmqf02txa0073jxopwxuge8mi	cmqf02twi0061jxopfw2ixih5	cmqf02twx006ajxop3fgj1itn	3	in_progress	2026-06-26 09:05:46.86	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 09:17:55.581	2026-06-26 09:05:46.861
cmqf02txb0076jxop726f55xr	cmqf02twi0062jxop3z5jrxny	cmqf02twx006bjxopdyn7ss4z	2	in_progress	2026-06-26 09:05:15.056	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 09:17:55.581	2026-06-26 09:05:15.057
cmqf02txb007ajxopj9xm39oc	cmqf02twi0063jxopuqpquhah	cmqf02twx006cjxopbakfs0te	1	completed	2026-06-15 09:17:55.58	2026-06-26 09:06:46.514	2026-06-26 09:06:41.687	cmq0kyw85007kjx239k25z1ge	\N	ไม่มั่นใจในความสามารถพิเศษ	ปัญหาครอบครัว	internal	2026-06-26 09:08:07.438	2026-06-15 09:17:55.581	2026-06-26 09:08:07.439
cmqf02txb007bjxopcpogputz	cmqf02twi0063jxopuqpquhah	cmqf02twx006cjxopbakfs0te	2	completed	2026-06-26 09:06:46.519	2026-06-26 09:10:24.149	2026-06-26 09:09:46.755	cmq0kyw85007kjx239k25z1ge	เห็นคุณค่าในตัวเองน้อย	\N	\N	\N	\N	2026-06-15 09:17:55.581	2026-06-26 09:10:24.15
cmqgdycof003ijxy9lh9g20bj	cmqgdycn8001djxy9h4tbxdxf	cmqgdyco0002ejxy9a6u4trlc	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycof003jjxy9tmml7txg	cmqgdycn8001ejxy9exoa7t0x	cmqgdyco0002fjxy99y54h81h	1	in_progress	2026-06-16 08:34:07.405	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycof003kjxy923cv8ohu	cmqgdycn8001ejxy9exoa7t0x	cmqgdyco0002fjxy99y54h81h	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycof003ljxy9rhsa7sf2	cmqgdycn8001ejxy9exoa7t0x	cmqgdyco0002fjxy99y54h81h	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycof003mjxy99f8ux6js	cmqgdycn8001fjxy9zly679kv	cmqgdyco0002gjxy97c0bugel	1	in_progress	2026-06-16 08:34:07.405	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycof003njxy93ufbpgq3	cmqgdycn8001fjxy9zly679kv	cmqgdyco0002gjxy97c0bugel	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycof003ojxy95ba45b48	cmqgdycn8001fjxy9zly679kv	cmqgdyco0002gjxy97c0bugel	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycof003pjxy9vndkpnf8	cmqgdycn9001gjxy9v9cuoe6b	cmqgdyco0002hjxy96b90xtlz	1	in_progress	2026-06-16 08:34:07.405	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycof003qjxy90yu3y8s1	cmqgdycn9001gjxy9v9cuoe6b	cmqgdyco0002hjxy96b90xtlz	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycof003rjxy91f4y975b	cmqgdycn9001gjxy9v9cuoe6b	cmqgdyco0002hjxy96b90xtlz	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycof003sjxy9pdz257u7	cmqgdycn9001kjxy99e4tek05	cmqgdyco0002ljxy9963618gy	1	in_progress	2026-06-16 08:34:07.405	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycof003tjxy9mne29v1c	cmqgdycn9001kjxy99e4tek05	cmqgdyco0002ljxy9963618gy	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog003ujxy981xk6pmh	cmqgdycn9001kjxy99e4tek05	cmqgdyco0002ljxy9963618gy	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog003vjxy9l8qnkdnv	cmqgdycn9001mjxy9ljnm3a73	cmqgdyco0002njxy9067tf3mt	1	in_progress	2026-06-16 08:34:07.405	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog003wjxy9ybocnali	cmqgdycn9001mjxy9ljnm3a73	cmqgdyco0002njxy9067tf3mt	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog003xjxy939jv4cgc	cmqgdycn9001mjxy9ljnm3a73	cmqgdyco0002njxy9067tf3mt	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog003yjxy9a45zy3ot	cmqgdycn9001ojxy9g54zqow0	cmqgdyco0002pjxy9unla8xwt	1	in_progress	2026-06-16 08:34:07.405	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog003zjxy9w6w7smn1	cmqgdycn9001ojxy9g54zqow0	cmqgdyco0002pjxy9unla8xwt	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog0040jxy9mc1hfxx7	cmqgdycn9001ojxy9g54zqow0	cmqgdyco0002pjxy9unla8xwt	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog0041jxy9blyk30i5	cmqgdycn9001qjxy9jz62rob0	cmqgdyco0002rjxy9ok1r299a	1	in_progress	2026-06-16 08:34:07.405	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog0042jxy9qgr5v47m	cmqgdycn9001qjxy9jz62rob0	cmqgdyco0002rjxy9ok1r299a	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog0043jxy95zrd7axp	cmqgdycn9001qjxy9jz62rob0	cmqgdyco0002rjxy9ok1r299a	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog0044jxy9p1wkn516	cmqgdycn9001rjxy9ktr4obzg	cmqgdyco0002sjxy9iicluirx	1	in_progress	2026-06-16 08:34:07.405	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog0045jxy9wwuq8gke	cmqgdycn9001rjxy9ktr4obzg	cmqgdyco0002sjxy9iicluirx	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog0046jxy962z2yqlg	cmqgdycn9001rjxy9ktr4obzg	cmqgdyco0002sjxy9iicluirx	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog0047jxy9olj9wmg0	cmqgdycn9001sjxy9jz4l3nkr	cmqgdyco0002tjxy9hd3y4mhl	1	in_progress	2026-06-16 08:34:07.405	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog0048jxy9so8gt4g2	cmqgdycn9001sjxy9jz4l3nkr	cmqgdyco0002tjxy9hd3y4mhl	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog0049jxy9gruz6ozz	cmqgdycn9001sjxy9jz4l3nkr	cmqgdyco0002tjxy9hd3y4mhl	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog004ajxy9gnd32m2b	cmqgdycn9001zjxy9d4tpzbfh	cmqgdyco00030jxy9teaxzpfj	1	in_progress	2026-06-16 08:34:07.405	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog004bjxy9gvvg8e3p	cmqgdycn9001zjxy9d4tpzbfh	cmqgdyco00030jxy9teaxzpfj	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog004cjxy9hll9ctpj	cmqgdycn9001zjxy9d4tpzbfh	cmqgdyco00030jxy9teaxzpfj	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog004djxy99dok7rby	cmqgdycn90023jxy9l3qdzxdj	cmqgdyco10034jxy92bimj0kn	1	in_progress	2026-06-16 08:34:07.405	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog004ejxy9sty9jmjf	cmqgdycn90023jxy9l3qdzxdj	cmqgdyco10034jxy92bimj0kn	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog004fjxy9spfom2rt	cmqgdycn90023jxy9l3qdzxdj	cmqgdyco10034jxy92bimj0kn	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog004gjxy9s6a1l9ci	cmqgdycn90026jxy90k7aemar	cmqgdyco10037jxy92f2vx90v	1	in_progress	2026-06-16 08:34:07.405	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog004hjxy93gxus9zr	cmqgdycn90026jxy90k7aemar	cmqgdyco10037jxy92f2vx90v	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog004ijxy9x164n4xt	cmqgdycn90026jxy90k7aemar	cmqgdyco10037jxy92f2vx90v	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog004jjxy9pz8v732t	cmqgdycn90027jxy9acp4i59f	cmqgdyco10038jxy9xbogk5nx	1	in_progress	2026-06-16 08:34:07.405	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog004kjxy9k2241w4e	cmqgdycn90027jxy9acp4i59f	cmqgdyco10038jxy9xbogk5nx	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog004ljxy9589b35yo	cmqgdycn90027jxy9acp4i59f	cmqgdyco10038jxy9xbogk5nx	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog004mjxy9vcqb5kyg	cmqgdycn90027jxy9acp4i59f	cmqgdyco10038jxy9xbogk5nx	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog004njxy9rk6p19qa	cmqgdycn90028jxy94fnhfaz0	cmqgdyco10039jxy9uzqhgq3t	1	in_progress	2026-06-16 08:34:07.405	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog004ojxy9lie6xn80	cmqgdycn90028jxy94fnhfaz0	cmqgdyco10039jxy9uzqhgq3t	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog004pjxy9n8nohvc4	cmqgdycn90028jxy94fnhfaz0	cmqgdyco10039jxy9uzqhgq3t	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog004qjxy9a3xxsuxd	cmqgdycn90028jxy94fnhfaz0	cmqgdyco10039jxy9uzqhgq3t	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgdycog004rjxy9zhbvznyj	cmqgdycn90028jxy94fnhfaz0	cmqgdyco10039jxy9uzqhgq3t	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:34:07.407	2026-06-16 08:34:07.407
cmqgem6aa001kjxxt0cxbnj00	cmqgem69r0010jxxt97z9hkxb	cmqgem6a3001ajxxty5bb7q6o	1	in_progress	2026-06-16 08:52:38.865	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqgem6aa001ljxxt9690rvmr	cmqgem69r0010jxxt97z9hkxb	cmqgem6a3001ajxxty5bb7q6o	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqgem6aa001mjxxtm50p5iuh	cmqgem69r0010jxxt97z9hkxb	cmqgem6a3001ajxxty5bb7q6o	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqgem6aa001njxxt1t0epn08	cmqgem69r0011jxxtuazyo8z8	cmqgem6a3001bjxxtouyfylnx	1	in_progress	2026-06-16 08:52:38.865	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqgem6aa001ojxxtg6lbx8fz	cmqgem69r0011jxxtuazyo8z8	cmqgem6a3001bjxxtouyfylnx	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqgem6aa001pjxxt4r23lgof	cmqgem69r0011jxxtuazyo8z8	cmqgem6a3001bjxxtouyfylnx	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqgem6aa001qjxxta6h64umj	cmqgem69r0011jxxtuazyo8z8	cmqgem6a3001bjxxtouyfylnx	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqgem6aa001rjxxtodf8x9sg	cmqgem69r0012jxxtc7jpe7n4	cmqgem6a3001cjxxtwnh9cj0i	1	in_progress	2026-06-16 08:52:38.865	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqgem6aa001sjxxtne44t1m8	cmqgem69r0012jxxtc7jpe7n4	cmqgem6a3001cjxxtwnh9cj0i	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqgem6aa001tjxxtstclqn79	cmqgem69r0012jxxtc7jpe7n4	cmqgem6a3001cjxxtwnh9cj0i	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqgem6aa001ujxxtr6m413n3	cmqgem69r0012jxxtc7jpe7n4	cmqgem6a3001cjxxtwnh9cj0i	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqgem6aa001vjxxtvo6dv5t9	cmqgem69r0013jxxt66actfu5	cmqgem6a3001djxxt0pdkf5b7	1	in_progress	2026-06-16 08:52:38.865	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqgem6aa001wjxxtup910xrj	cmqgem69r0013jxxt66actfu5	cmqgem6a3001djxxt0pdkf5b7	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqgem6aa001xjxxt6l3z0kih	cmqgem69r0013jxxt66actfu5	cmqgem6a3001djxxt0pdkf5b7	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqgem6aa001yjxxtwu19jhuj	cmqgem69r0014jxxtf48r06rr	cmqgem6a3001ejxxttgu7rmvt	1	in_progress	2026-06-16 08:52:38.865	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqgem6aa001zjxxthfnrcbmx	cmqgem69r0014jxxtf48r06rr	cmqgem6a3001ejxxttgu7rmvt	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqgem6aa0020jxxt9zvtkael	cmqgem69r0014jxxtf48r06rr	cmqgem6a3001ejxxttgu7rmvt	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqgem6aa0021jxxttt9b7y1x	cmqgem69r0015jxxtaduu4v33	cmqgem6a3001fjxxt3rqpz4yd	1	in_progress	2026-06-16 08:52:38.865	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqgem6aa0022jxxt3oxa87s6	cmqgem69r0015jxxtaduu4v33	cmqgem6a3001fjxxt3rqpz4yd	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqgem6aa0023jxxtav9q40ke	cmqgem69r0015jxxtaduu4v33	cmqgem6a3001fjxxt3rqpz4yd	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqgem6aa0024jxxti9blj5ao	cmqgem69r0016jxxt04rvuch5	cmqgem6a3001gjxxt29m9dntc	1	in_progress	2026-06-16 08:52:38.865	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqgem6aa0025jxxteb4v3hzj	cmqgem69r0016jxxt04rvuch5	cmqgem6a3001gjxxt29m9dntc	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqgem6aa0026jxxtk2mt5ro8	cmqgem69r0016jxxt04rvuch5	cmqgem6a3001gjxxt29m9dntc	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqgem6aa0027jxxtjwgxxgpx	cmqgem69r0017jxxtki2eprim	cmqgem6a3001hjxxt4x3kaovn	1	in_progress	2026-06-16 08:52:38.865	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqgem6aa0028jxxtfo2enmb2	cmqgem69r0017jxxtki2eprim	cmqgem6a3001hjxxt4x3kaovn	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqgem6aa0029jxxtecuraj4w	cmqgem69r0017jxxtki2eprim	cmqgem6a3001hjxxt4x3kaovn	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqgem6aa002ajxxt6iau49k7	cmqgem69s0018jxxtpuo45d2u	cmqgem6a3001ijxxtnw7lkcno	1	in_progress	2026-06-16 08:52:38.865	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqgem6aa002bjxxtz1p3rpe1	cmqgem69s0018jxxtpuo45d2u	cmqgem6a3001ijxxtnw7lkcno	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqgem6ab002cjxxt3v71jnx4	cmqgem69s0018jxxtpuo45d2u	cmqgem6a3001ijxxtnw7lkcno	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqgem6ab002djxxt1m9yp0o7	cmqgem69s0019jxxt0vx6c2m4	cmqgem6a3001jjxxtlhelaabe	1	in_progress	2026-06-16 08:52:38.865	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqgem6ab002ejxxt4wbx46pi	cmqgem69s0019jxxt0vx6c2m4	cmqgem6a3001jjxxtlhelaabe	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqgem6ab002fjxxt37swj436	cmqgem69s0019jxxt0vx6c2m4	cmqgem6a3001jjxxtlhelaabe	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-16 08:52:38.866	2026-06-16 08:52:38.866
cmqep6tah00pdjxp58355pnvb	cmqep6t7y00g9jxp5yihqococ	cmqep6t9400j3jxp5vvixk3ea	2	completed	2026-06-19 12:52:09.581	2026-06-26 08:47:09.314	2026-06-26 08:47:07.599	cmq0kwit80066jx23pw930nx1	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:47:09.314
cmqep6tah00p6jxp5p8gfttcn	cmqep6t7y00g7jxp5dadbmh4c	cmqep6t9400j1jxp5niy42x68	1	completed	2026-06-15 04:13:05.592	2026-06-19 06:50:02.755	2026-06-19 06:49:59.583	cmq0kyw85007kjx239k25z1ge	\N	เป็นนักเรียนที่ช่วยเหลือกิจกรรมดี	เป็นนักเรียนที่ช่วยเหลือกิจกรรมดี	external	2026-06-19 06:53:31.573	2026-06-15 04:13:05.602	2026-06-19 06:53:31.574
cmqep6tai00q1jxp5ma2ex0y8	cmqep6t7y00ghjxp58tgg12zq	cmqep6t9500jbjxp5vxqfjko9	2	completed	2026-06-19 12:47:02.959	2026-06-26 08:45:51.055	2026-06-26 08:45:48.634	cmq0kwit80066jx23pw930nx1	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:45:51.056
cmqep6taj00ryjxp5e48c123c	cmqep6t7y00h2jxp5gb0okmzi	cmqep6t9500jwjxp5qugh2ett	2	completed	2026-06-19 13:13:00.393	2026-06-26 08:53:23.543	2026-06-26 08:53:21.353	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:53:23.544
cmqep6tai00r0jxp5o79femym	cmqep6t7y00grjxp5xaus94pp	cmqep6t9500jljxp5kexpgbim	2	completed	2026-06-19 12:51:48.783	2026-06-26 08:47:07.065	2026-06-26 08:47:05.117	cmq0kwit80066jx23pw930nx1	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:47:07.065
cmr254jpo00hwjxctmkk3bbpc	cmr254jj6001ojxct93uhsc2s	cmr254jms009ljxctgi2zbnzc	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6tah00p9jxp5t7c8whwm	cmqep6t7y00g8jxp5e5io1j25	cmqep6t9400j2jxp58h2t12fu	1	completed	2026-06-15 04:13:05.592	2026-06-19 12:47:03.222	2026-06-19 12:46:32.262	cmq0khs5m000wjx23jyhqhgkv	\N	เด็กมีความชื่นชอบตัวเอง	ไม่มี	internal	2026-06-19 12:49:07.466	2026-06-15 04:13:05.602	2026-06-19 12:49:07.467
cmqep6tai00q3jxp5tf5z03xa	cmqep6t7y00gjjxp59b9xkcrz	cmqep6t9500jdjxp5plj8wi0g	1	completed	2026-06-15 04:13:05.592	2026-06-19 12:47:05.522	2026-06-19 12:46:33.661	cmq0kyw85007kjx239k25z1ge	\N	เรื่องรูปร่างขาดความมั่นใจ	ไม่มี	internal	2026-06-19 12:50:50.955	2026-06-15 04:13:05.602	2026-06-19 12:50:50.957
cmqep6tai00q7jxp5zfws1ogk	cmqep6t7y00gkjxp5h4f0156z	cmqep6t9500jejxp5atgprn20	1	completed	2026-06-15 04:13:05.592	2026-06-19 12:47:04.022	2026-06-19 12:46:25.448	cmq0kyw85007kjx239k25z1ge	\N	อยากพยายามเรื่องการเรียนหนังสือ	เรียนหนังสือไม่ค่อยเข้าใจ	internal	2026-06-19 12:51:48.718	2026-06-15 04:13:05.602	2026-06-19 12:51:48.72
cmqep6tah00pgjxp5vpst4wb1	cmqep6t7y00gajxp56csicf0x	cmqep6t9400j4jxp52hwv21c8	2	completed	2026-06-19 12:54:34.484	2026-06-26 08:48:39.031	2026-06-26 08:48:35.524	cmq0kwit80066jx23pw930nx1	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:48:39.032
cmqep6tai00qjjxp5lrasw9rz	cmqep6t7y00gnjxp50tru9y0t	cmqep6t9500jhjxp5ee6zin61	1	completed	2026-06-15 04:13:05.592	2026-06-19 12:53:35.34	2026-06-19 12:52:57.708	cmq0kwit80066jx23pw930nx1	\N	ทางบ้านไม่ค่อยดูแลลและะชอบมองว่าลูกเป็นตัวปัญหา	เพื่อนที่ครบอยู่คอนข้างมีปัญหา	internal	2026-06-19 12:56:49.076	2026-06-15 04:13:05.602	2026-06-19 12:56:49.077
cmqep6tah00pijxp5zldp0o2u	cmqep6t7y00gbjxp5vsmxgz5z	cmqep6t9400j5jxp51vflwpcv	1	completed	2026-06-15 04:13:05.592	2026-06-19 12:54:58.23	2026-06-19 12:54:50.132	cmq0khs5m000wjx23jyhqhgkv	\N	ขาดความมั่นใจ	กังวลเรื่องรูปร่างตัวเอง	internal	2026-06-19 12:57:32.678	2026-06-15 04:13:05.602	2026-06-19 12:57:32.679
cmqf02tx9006djxop42fvws8c	cmqf02twi005vjxoph6si1y7m	cmqf02twx0064jxops0zutopk	1	completed	2026-06-15 09:17:55.579	2026-06-19 12:54:19.372	2026-06-19 12:54:15.914	cmq0kyw85007kjx239k25z1ge	\N	ไม่มีความมั่นใจ	มีความกังวลเรื่องค่าครองชีพ	internal	2026-06-19 12:58:43.434	2026-06-15 09:17:55.581	2026-06-19 12:58:43.435
cmqep6tah00pljxp54oayeo39	cmqep6t7y00gcjxp545zm4dej	cmqep6t9400j6jxp54seruv6b	1	completed	2026-06-15 04:13:05.592	2026-06-19 12:58:48.876	2026-06-19 12:58:47.038	cmq0khs5m000wjx23jyhqhgkv	\N	เกิดความชอบในตัวเองมากขึ้น	ไม่มี	internal	2026-06-19 12:59:47.903	2026-06-15 04:13:05.602	2026-06-19 12:59:47.904
cmqep6tai00qfjxp57u3dmokc	cmqep6t7y00gmjxp5w0cyfz8a	cmqep6t9500jgjxp54oyob17b	1	completed	2026-06-15 04:13:05.592	2026-06-19 12:59:17.69	2026-06-19 12:59:15.621	cmq0kyw85007kjx239k25z1ge	\N	ไม่มั่นใจในตัวเองแต่มั่นใจในโลกออนไลน์	ปัญหาครอบครัว	internal	2026-06-19 13:01:19.764	2026-06-15 04:13:05.602	2026-06-19 13:01:19.765
cmqep6tah00pjjxp5hexoqq72	cmqep6t7y00gbjxp5vsmxgz5z	cmqep6t9400j5jxp51vflwpcv	2	completed	2026-06-19 12:54:58.236	2026-06-26 08:49:31.735	2026-06-26 08:49:27.059	cmq0kwit80066jx23pw930nx1	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:49:31.737
cmqep6tai00qojxp5y8dtu0b5	cmqep6t7y00gojxp5v1t19fiv	cmqep6t9500jijxp5fmhyucyx	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:01:17.992	2026-06-19 13:01:15.842	cmq0kyw85007kjx239k25z1ge	\N	ไม่มั่นในตัวเองอยากเข้าหาคนอื่นมากกว่าเดิม	เรียนไม่ค่อยเข้าใจ 	internal	2026-06-19 13:04:33.891	2026-06-15 04:13:05.602	2026-06-19 13:04:33.892
cmqep6tai00psjxp5teda891e	cmqep6t7y00gejxp5hwiyumv6	cmqep6t9400j8jxp57qqo0m42	2	completed	2026-06-19 13:03:31.564	2026-06-26 08:52:52.593	2026-06-26 08:52:50.245	cmq0kwit80066jx23pw930nx1	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:52:52.594
cmqep6tai00qsjxp509wnhjrm	cmqep6t7y00gpjxp5s7zduyel	cmqep6t9500jjjxp59xh7ckl7	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:04:08.43	2026-06-19 13:04:00.212	cmq0kyw85007kjx239k25z1ge	\N	ไม่มั่นใจในการวาดรูปและไม่ค่อยมั่นใจในตัวเอง	ปัญหาครอบครัว	internal	2026-06-19 13:06:19.937	2026-06-15 04:13:05.602	2026-06-19 13:06:19.938
cmqf02tx9006hjxopae8zwuwx	cmqf02twi005wjxop1suc7kpd	cmqf02twx0065jxopks12xh9e	1	completed	2026-06-15 09:17:55.58	2026-06-19 13:01:54.605	2026-06-19 13:01:52.8	cmq0kwit80066jx23pw930nx1	\N	ยังค้นพบตัวเองไม่ได้	เป็นคนลิ้นไก่สั้นพูดไม่ชัด	external	2026-06-19 13:06:50.799	2026-06-15 09:17:55.581	2026-06-19 13:06:50.8
cmr254jpo00hxjxct3nx78v56	cmr254jj6001pjxct30c1mgbd	cmr254jms009mjxct99hi26u9	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6taj00s5jxp5ieg0s142	cmqep6t7y00h4jxp5jet4udax	cmqep6t9500jyjxp5l5okhfmh	2	completed	2026-06-19 13:13:33.49	2026-06-26 08:54:58.097	2026-06-26 08:54:56.736	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:54:58.098
cmqep6tai00r9jxp52ywbd3w3	cmqep6t7y00gvjxp59jqt3gqm	cmqep6t9500jpjxp5enw820v2	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:09:09.52	2026-06-19 13:09:07.637	cmq0khs5m000wjx23jyhqhgkv	\N	ขาดความมั่นใจในตัวเอง	ไม่มี	internal	2026-06-19 13:09:55.225	2026-06-15 04:13:05.602	2026-06-19 13:09:55.226
cmqep6taj00ssjxp5knzlg5ay	cmqep6t7y00hcjxp5o0okg8br	cmqep6t9500k6jxp57h4lamza	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:09:32.417	2026-06-19 13:09:30.236	cmq0kyw85007kjx239k25z1ge	\N	ไม่มั่นใจในการวาดรูปและการเรียน	มีปัญหาด้านการเงิน	internal	2026-06-19 13:10:32.329	2026-06-15 04:13:05.602	2026-06-19 13:10:32.329
cmr254jpo00hyjxct8vnh9gyc	cmr254jj6001pjxct30c1mgbd	cmr254jms009mjxct99hi26u9	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6tak00tcjxp5s4je3gyp	cmqep6t7y00hjjxp5xa6i02q3	cmqep6t9500kdjxp5zbtb2lnz	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:09:15.574	2026-06-19 13:09:13.027	cmq0kyw85007kjx239k25z1ge	\N	ไม่มั่นใจในตัวเอง	ไม่ค่อยเข้าสังคม	external	2026-06-19 13:11:42.625	2026-06-15 04:13:05.602	2026-06-19 13:11:42.626
cmqep6taj00szjxp5gnxnr18i	cmqep6t7y00hejxp5jx21o02o	cmqep6t9500k8jxp5f61o1mj3	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:09:41.692	2026-06-19 13:09:36.3	cmq0kwit80066jx23pw930nx1	\N	ไม่มั่นใจในตัวเอง	ไม่สมหวังกับความรัก	internal	2026-06-19 13:11:52.551	2026-06-15 04:13:05.602	2026-06-19 13:11:52.552
cmqep6tak00t9jxp5925pd5yg	cmqep6t7y00hijxp5mgitskzp	cmqep6t9500kcjxp5ckg6g2ce	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:11:20.591	2026-06-19 13:11:19.399	cmq0khs5m000wjx23jyhqhgkv	\N	รู้สึกมีค่าในตัวเอง	ไม่มี	internal	2026-06-19 13:12:01.862	2026-06-15 04:13:05.602	2026-06-19 13:12:01.863
cmqep6taj00s4jxp5cqd3j9df	cmqep6t7y00h4jxp5jet4udax	cmqep6t9500jyjxp5l5okhfmh	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:13:33.485	2026-06-19 13:13:32.002	cmq0kyw85007kjx239k25z1ge	\N	ไม่มั่นใจในการเรียน	เรียนไม่ค่อยเข้าใจ	internal	2026-06-19 13:15:21.773	2026-06-15 04:13:05.602	2026-06-19 13:15:21.774
cmqep6taj00rkjxp5bp36b887	cmqep6t7y00gzjxp5ymu2sdwq	cmqep6t9500jtjxp5auvusch8	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:16:57.871	2026-06-19 13:16:55.888	cmq0khs5m000wjx23jyhqhgkv	\N	ขาดความมั่นใจในตัวเอง	ไม่มี	internal	2026-06-19 13:17:20.76	2026-06-15 04:13:05.602	2026-06-19 13:17:20.761
cmqep6taj00s0jxp5h5bwajyo	cmqep6t7y00h3jxp5nsmq0bu1	cmqep6t9500jxjxp5c9llkurt	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:16:09.024	2026-06-19 13:16:07.725	cmq0kyw85007kjx239k25z1ge	\N	ไม่มั่นใจด้านการเรียนและการใช้ชีวิต	ปัญหาด้านครอบครัว	internal	2026-06-19 13:17:37.017	2026-06-15 04:13:05.602	2026-06-19 13:17:37.018
cmqep6taj00t3jxp5349w8cxc	cmqep6t7y00hgjxp51uc3pwty	cmqep6t9500kajxp58wj2pelo	2	completed	2026-06-19 13:13:41.864	2026-06-26 08:56:06.047	2026-06-26 08:56:04.515	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:56:06.048
cmqep6taj00sejxp5xa5bit93	cmqep6t7y00h7jxp5aomv3xif	cmqep6t9500k1jxp5ntanhqsd	2	completed	2026-06-19 13:14:33.519	2026-06-26 09:00:12.52	2026-06-26 09:00:11.273	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:00:12.521
cmqep6tag00mfjxp5x7xu61is	cmqep6t7x00fejxp5o7dl7di4	cmqep6t9400i8jxp575ybjipq	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:23:48.452	2026-06-19 13:23:46.272	cmq0khs5m000wjx23jyhqhgkv	\N	ขาดความมั่นใจ	ไม่มี	internal	2026-06-19 13:25:07.018	2026-06-15 04:13:05.602	2026-06-19 13:25:07.019
cmqep6tag00nujxp5o54ztmua	cmqep6t7x00ftjxp5qcd2510h	cmqep6t9400injxp5fr38gk7o	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:24:10.16	2026-06-19 13:24:08.292	cmq0khs5m000wjx23jyhqhgkv	\N	มีความตั้งใจในการทำอะไรสักอย่าง	ไม่มี	internal	2026-06-19 13:25:47.926	2026-06-15 04:13:05.602	2026-06-19 13:25:47.927
cmqep6tag00n6jxp53ced8pkg	cmqep6t7x00fljxp5cyty19cb	cmqep6t9400ifjxp53w1mo3fo	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:26:11.974	2026-06-19 13:26:10.835	cmq0khs5m000wjx23jyhqhgkv	\N	ขาดความมั่นใจในตัวเอง	ไม่มี	internal	2026-06-19 13:27:23.841	2026-06-15 04:13:05.602	2026-06-19 13:27:23.842
cmqep6tag00mqjxp5f9vuhif8	cmqep6t7x00fhjxp5fpnrj4l7	cmqep6t9400ibjxp5g6u6nf0y	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:26:17.384	2026-06-19 13:26:16.068	cmq0kyw85007kjx239k25z1ge	\N	ไม่มั่นใจในการเรียน	เรียนไม่ค่อยเข้าใจ	internal	2026-06-19 13:27:42.966	2026-06-15 04:13:05.602	2026-06-19 13:27:42.967
cmqep6tah00opjxp5r154rrkv	cmqep6t7x00g2jxp55u0n4faa	cmqep6t9400iwjxp5r5qe1j3u	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:27:01.434	2026-06-19 13:27:00.062	cmq0kwit80066jx23pw930nx1	\N	ยังไม่มั่นใจในการเรียน	ยังไม่มั่นใจในการเรียนมากพอ	external	2026-06-19 13:29:05.865	2026-06-15 04:13:05.602	2026-06-19 13:29:05.866
cmqep6tah00ojjxp5sze7k8vi	cmqep6t7x00g0jxp5x3rr3z29	cmqep6t9400iujxp5aln74t2r	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:28:58.353	2026-06-19 13:28:57.087	cmq0kyw85007kjx239k25z1ge	\N	ไม่มีความมั่นใจในการวาดรูปการรำและเต้น	ด้านการเงิน	internal	2026-06-19 13:29:42.948	2026-06-15 04:13:05.602	2026-06-19 13:29:42.949
cmqep6taj00s1jxp5ddbwgbnp	cmqep6t7y00h3jxp5nsmq0bu1	cmqep6t9500jxjxp5c9llkurt	2	completed	2026-06-19 13:16:09.028	2026-06-26 09:04:08.568	2026-06-26 09:03:38.619	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:04:08.569
cmqep6tak00t6jxp5dubgtvok	cmqep6t7y00hhjxp595rvk6sq	cmqep6t9500kbjxp5qesv8hdv	2	completed	2026-06-19 13:17:55.712	2026-06-26 09:06:16.385	2026-06-26 09:05:43.973	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:06:16.386
cmqep6tag00mjjxp5vhojhp11	cmqep6t7x00ffjxp5qxsn29jv	cmqep6t9400i9jxp5v1vpi65s	2	completed	2026-06-19 13:31:11.898	2026-06-26 09:45:04.326	2026-06-26 09:45:02.882	cmq0kwit80066jx23pw930nx1	เสริมสร้างพลังใจ	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:45:04.327
cmqep6tag00mujxp5c1ni7f1w	cmqep6t7x00fijxp5jyyrjuz8	cmqep6t9400icjxp563x2ubdm	2	completed	2026-06-19 13:31:32.879	2026-06-26 09:46:42.882	2026-06-26 09:46:41.212	cmq0kwit80066jx23pw930nx1	เห็นคุณค่าในตัวเอง	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:46:42.883
cmqep6tag00njjxp503nen2o3	cmqep6t7x00fqjxp5np9idghm	cmqep6t9400ikjxp5hxoelt9l	2	completed	2026-06-19 13:34:41.886	2026-06-26 09:49:30.525	2026-06-26 09:49:28.752	cmq0kwit80066jx23pw930nx1	ฝึกความใจเย็นให้มากขึ้น	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:49:30.526
cmqep6tag00mnjxp59hl9tbmt	cmqep6t7x00fgjxp5q4q2sqhp	cmqep6t9400iajxp5szt1pb8v	2	completed	2026-06-19 13:34:30.729	2026-06-26 09:51:42.975	2026-06-26 09:51:41.552	cmq0kwit80066jx23pw930nx1	ขาดความมั่นใจ	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:51:42.976
cmqep6tah00oqjxp50jjkbmzs	cmqep6t7x00g2jxp55u0n4faa	cmqep6t9400iwjxp5r5qe1j3u	2	completed	2026-06-19 13:27:01.437	2026-06-26 09:55:48.482	2026-06-26 09:55:47.349	cmq0kwit80066jx23pw930nx1	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:55:48.482
cmqep6tag00nyjxp50u57ywab	cmqep6t7x00fujxp5lzrwcrc9	cmqep6t9400iojxp535rm9rat	2	completed	2026-06-19 13:29:24.704	2026-06-26 09:57:30.651	2026-06-26 09:57:29.512	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:57:30.652
cmqep6tah00okjxp5gw39fbrt	cmqep6t7x00g0jxp5x3rr3z29	cmqep6t9400iujxp5aln74t2r	2	completed	2026-06-19 13:28:58.357	2026-06-26 09:56:51.994	2026-06-26 09:56:43.53	cmq0kwit80066jx23pw930nx1	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:56:51.995
cmqep6tag00mtjxp5psg80trx	cmqep6t7x00fijxp5jyyrjuz8	cmqep6t9400icjxp563x2ubdm	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:31:32.873	2026-06-19 13:31:31.706	cmq0kwit80066jx23pw930nx1	\N	ยังไม่มั่นใจในการทำงาน	ด้านการเงินกับการให้ความสำคัญในโซเซียล	external	2026-06-19 13:35:34.996	2026-06-15 04:13:05.602	2026-06-19 13:35:34.997
cmqep6tag00mmjxp5osl2gpuy	cmqep6t7x00fgjxp5q4q2sqhp	cmqep6t9400iajxp5szt1pb8v	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:34:30.724	2026-06-19 13:34:29.551	cmq0khs5m000wjx23jyhqhgkv	\N	ไม่มั่นใจในตัวเอง ขาดจุดเด่นของตัวเอง ตั้งเป้าหมายเกินไว	ไม่มี	internal	2026-06-19 13:37:14.535	2026-06-15 04:13:05.602	2026-06-19 13:37:14.536
cmr254jpo00hzjxct01c818va	cmr254jj6001pjxct30c1mgbd	cmr254jms009mjxct99hi26u9	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpo00i0jxctcut8z9k4	cmr254jj6001qjxct1t13zel2	cmr254jmt009njxctkuatett5	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpo00i1jxctooujpo4m	cmr254jj6001qjxct1t13zel2	cmr254jmt009njxctkuatett5	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6tah00oyjxp5hrce1ci3	cmqep6t7y00g5jxp53scmw13t	cmqep6t9400izjxp5kkrzband	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:39:09.416	2026-06-19 13:39:07.991	cmq0khs5m000wjx23jyhqhgkv	\N	ขาดความมั่นใจ รู้สึกไร้ค่า	ไม่มี	internal	2026-06-19 13:40:09.604	2026-06-15 04:13:05.602	2026-06-19 13:40:09.605
cmqep6tah00o0jxp5xsrc3nkd	cmqep6t7x00fvjxp5jwtduygo	cmqep6t9400ipjxp5mi3lxvqs	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:38:30.2	2026-06-19 13:38:14.639	cmq0kwit80066jx23pw930nx1	\N	ขาดความมั่นใจในตนเอง	ให้ความใส่ใจในรูปลักษณ์ภายนอก	external	2026-06-19 13:43:25.054	2026-06-15 04:13:05.602	2026-06-19 13:43:25.055
cmqep6tag00mxjxp5kyg8s55h	cmqep6t7x00fjjxp51to2rjq7	cmqep6t9400idjxp53hqq2voi	1	completed	2026-06-15 04:13:05.592	2026-06-19 13:39:32.354	2026-06-19 13:39:30.851	cmq0kyw85007kjx239k25z1ge	\N	รู้สึกไม่มั่นใจไม่ศัทราในตัวเอง	ให้ความสนใจกับกิจกรรมรอบข้างมากเกินไป	internal	2026-06-19 13:45:08.863	2026-06-15 04:13:05.602	2026-06-19 13:45:08.863
cmqo3trxl00sejxf05ku3qi98	cmqo3trrx00cmjxf0hkga2z6b	cmqo3trv500kjjxf01sygcmgy	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxl00sfjxf0dc1wallf	cmqo3trrx00cmjxf0hkga2z6b	cmqo3trv500kjjxf01sygcmgy	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxl00sgjxf0h70tcz8t	cmqo3trrx00cmjxf0hkga2z6b	cmqo3trv500kjjxf01sygcmgy	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxl00shjxf01cx8u277	cmqo3trrx00cojxf0b62gt7kx	cmqo3trv600kljxf03smm20jx	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxl00sijxf09l513ewc	cmqo3trrx00cojxf0b62gt7kx	cmqo3trv600kljxf03smm20jx	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxl00sjjxf0u4oj9wn9	cmqo3trrx00cojxf0b62gt7kx	cmqo3trv600kljxf03smm20jx	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxl00skjxf0k89h0c6m	cmqo3trrx00cpjxf09jq5zwly	cmqo3trv600kmjxf035maaeis	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxl00sljxf0q4w3udr7	cmqo3trrx00cpjxf09jq5zwly	cmqo3trv600kmjxf035maaeis	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxl00smjxf0uig8gsdf	cmqo3trrx00cpjxf09jq5zwly	cmqo3trv600kmjxf035maaeis	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00snjxf0czueb5lq	cmqo3trrx00cqjxf07w79kjv8	cmqo3trv600knjxf0xtm1bkla	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00sojxf00upm77yn	cmqo3trrx00cqjxf07w79kjv8	cmqo3trv600knjxf0xtm1bkla	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00spjxf0lvnjwcc4	cmqo3trrx00cqjxf07w79kjv8	cmqo3trv600knjxf0xtm1bkla	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00sqjxf0estkhg99	cmqo3trrx00csjxf0a9nxqmj4	cmqo3trv600kpjxf0i689ores	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00srjxf05mpu537j	cmqo3trrx00csjxf0a9nxqmj4	cmqo3trv600kpjxf0i689ores	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00ssjxf0g9p7cfq6	cmqo3trrx00csjxf0a9nxqmj4	cmqo3trv600kpjxf0i689ores	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00stjxf0042cly06	cmqo3trrx00cujxf0pl8ls09k	cmqo3trv600krjxf0q0wef31p	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00sujxf0ka2uh8g8	cmqo3trrx00cujxf0pl8ls09k	cmqo3trv600krjxf0q0wef31p	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00svjxf0z0uotcpy	cmqo3trrx00cujxf0pl8ls09k	cmqo3trv600krjxf0q0wef31p	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00swjxf03g4tzkmu	cmqo3trrx00cwjxf063cnpksu	cmqo3trv600ktjxf0v81bo6td	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00sxjxf0iy9uxomu	cmqo3trrx00cwjxf063cnpksu	cmqo3trv600ktjxf0v81bo6td	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00syjxf0ys9idwjl	cmqo3trrx00cwjxf063cnpksu	cmqo3trv600ktjxf0v81bo6td	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00szjxf0y8y70m2j	cmqo3trrx00cyjxf0cbuftbkp	cmqo3trv600kvjxf0jv2x1fho	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00t0jxf0uiitrgds	cmqo3trrx00cyjxf0cbuftbkp	cmqo3trv600kvjxf0jv2x1fho	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00t1jxf0urz1fmxu	cmqo3trrx00cyjxf0cbuftbkp	cmqo3trv600kvjxf0jv2x1fho	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00t2jxf0bh870x2p	cmqo3trrx00d0jxf02n42ut8g	cmqo3trv600kxjxf0h76s2nu3	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00t3jxf0pqlthyx5	cmqo3trrx00d0jxf02n42ut8g	cmqo3trv600kxjxf0h76s2nu3	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00t4jxf0zthu58e3	cmqo3trrx00d0jxf02n42ut8g	cmqo3trv600kxjxf0h76s2nu3	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00t5jxf0uwzslvin	cmqo3trrx00d5jxf0koyl25j4	cmqo3trv600l2jxf04xkb3m6u	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00t6jxf0ndehx3ap	cmqo3trrx00d5jxf0koyl25j4	cmqo3trv600l2jxf04xkb3m6u	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00t7jxf0h83o2ciu	cmqo3trrx00d5jxf0koyl25j4	cmqo3trv600l2jxf04xkb3m6u	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00t8jxf0sn57vcrz	cmqo3trrx00ddjxf06e6ec32j	cmqo3trv600lajxf0sufip4zy	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00t9jxf0e47k1h1n	cmqo3trrx00ddjxf06e6ec32j	cmqo3trv600lajxf0sufip4zy	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00tajxf00pgdpx0o	cmqo3trrx00ddjxf06e6ec32j	cmqo3trv600lajxf0sufip4zy	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00tbjxf0duflv4ri	cmqo3trrx00dgjxf070co0vw0	cmqo3trv600ldjxf02y1nrxk9	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00tcjxf0v8b68ipa	cmqo3trrx00dgjxf070co0vw0	cmqo3trv600ldjxf02y1nrxk9	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00tdjxf0li94rkkb	cmqo3trrx00dgjxf070co0vw0	cmqo3trv600ldjxf02y1nrxk9	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00tejxf0gdomzm3x	cmqo3trrx00dkjxf0qnhcwi7m	cmqo3trv600lhjxf0x42adw7s	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00tfjxf0sivugbob	cmqo3trrx00dkjxf0qnhcwi7m	cmqo3trv600lhjxf0x42adw7s	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00tgjxf071npzcn3	cmqo3trrx00dkjxf0qnhcwi7m	cmqo3trv600lhjxf0x42adw7s	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00thjxf0t8lrzoz1	cmqo3trrx00dojxf01csh8119	cmqo3trv600lljxf084u1og1r	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00tijxf0averd7fo	cmqo3trrx00dojxf01csh8119	cmqo3trv600lljxf084u1og1r	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00tjjxf07n0709ue	cmqo3trrx00dojxf01csh8119	cmqo3trv600lljxf084u1og1r	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00tkjxf0p3e1tok6	cmqo3trry00dujxf0vvbiy52a	cmqo3trv700lrjxf03xrpoofg	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00tljxf03bqh24yq	cmqo3trry00dujxf0vvbiy52a	cmqo3trv700lrjxf03xrpoofg	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00tmjxf0f5mhlami	cmqo3trry00dujxf0vvbiy52a	cmqo3trv700lrjxf03xrpoofg	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00tnjxf0mmig1c91	cmqo3trry00dujxf0vvbiy52a	cmqo3trv700lrjxf03xrpoofg	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00tojxf06dllneum	cmqo3trry00dvjxf08cenbaap	cmqo3trv700lsjxf0frv6o0vg	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00tpjxf04l02240x	cmqo3trry00dvjxf08cenbaap	cmqo3trv700lsjxf0frv6o0vg	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00tqjxf01apqr9ii	cmqo3trry00dvjxf08cenbaap	cmqo3trv700lsjxf0frv6o0vg	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00trjxf0vs8ksapf	cmqo3trry00dyjxf0prhrj4ee	cmqo3trv700lvjxf0uihv5cj9	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00tsjxf07rp5f2x1	cmqo3trry00dyjxf0prhrj4ee	cmqo3trv700lvjxf0uihv5cj9	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00ttjxf0bgrji5o2	cmqo3trry00dyjxf0prhrj4ee	cmqo3trv700lvjxf0uihv5cj9	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00tujxf01gmtxjnx	cmqo3trry00dyjxf0prhrj4ee	cmqo3trv700lvjxf0uihv5cj9	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00tvjxf087fbi62h	cmqo3trry00e0jxf0hsz5wdjk	cmqo3trv700lxjxf0jnewql21	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00twjxf0x05sd6oi	cmqo3trry00e0jxf0hsz5wdjk	cmqo3trv700lxjxf0jnewql21	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00txjxf0qhhbuu7f	cmqo3trry00e0jxf0hsz5wdjk	cmqo3trv700lxjxf0jnewql21	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00tyjxf0rh58ckmz	cmqo3trry00e0jxf0hsz5wdjk	cmqo3trv700lxjxf0jnewql21	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00tzjxf015tr1pv5	cmqo3trry00e3jxf0nwvzis1r	cmqo3trv700m0jxf01tldr9yo	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00u0jxf09a7dcnep	cmqo3trry00e3jxf0nwvzis1r	cmqo3trv700m0jxf01tldr9yo	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00u1jxf0915kztzi	cmqo3trry00e3jxf0nwvzis1r	cmqo3trv700m0jxf01tldr9yo	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00u2jxf0wg1d0wxb	cmqo3trry00e6jxf0b2xz7tjf	cmqo3trv700m3jxf0gw0vtlqa	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00u3jxf0c6mnnmkd	cmqo3trry00e6jxf0b2xz7tjf	cmqo3trv700m3jxf0gw0vtlqa	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00u4jxf0x38o7upv	cmqo3trry00e6jxf0b2xz7tjf	cmqo3trv700m3jxf0gw0vtlqa	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00u5jxf0yimb7i0t	cmqo3trry00e7jxf099u1i7bw	cmqo3trv700m4jxf09iklpakr	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00u6jxf02kpt3hkc	cmqo3trry00e7jxf099u1i7bw	cmqo3trv700m4jxf09iklpakr	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00u7jxf0x7xeim4a	cmqo3trry00e7jxf099u1i7bw	cmqo3trv700m4jxf09iklpakr	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00u8jxf0274ft4zz	cmqo3trry00e9jxf00sk8s4um	cmqo3trv700m6jxf0w9qd9yrg	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00u9jxf0m5lrm48x	cmqo3trry00e9jxf00sk8s4um	cmqo3trv700m6jxf0w9qd9yrg	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00uajxf0ev9b27g3	cmqo3trry00e9jxf00sk8s4um	cmqo3trv700m6jxf0w9qd9yrg	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00ubjxf0aemyr7ou	cmqo3trry00e9jxf00sk8s4um	cmqo3trv700m6jxf0w9qd9yrg	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00ucjxf026hdrtd9	cmqo3trry00ebjxf01zvrx7o7	cmqo3trv700m8jxf0l2detfc2	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00udjxf0esjpajeu	cmqo3trry00ebjxf01zvrx7o7	cmqo3trv700m8jxf0l2detfc2	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00uejxf06p8iakay	cmqo3trry00ebjxf01zvrx7o7	cmqo3trv700m8jxf0l2detfc2	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00ufjxf03u0kjrut	cmqo3trry00ebjxf01zvrx7o7	cmqo3trv700m8jxf0l2detfc2	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00ugjxf0is8l5a59	cmqo3trry00ecjxf0tqh1zbcq	cmqo3trv700m9jxf0o1mkm455	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00uhjxf020a16kex	cmqo3trry00ecjxf0tqh1zbcq	cmqo3trv700m9jxf0o1mkm455	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00uijxf0o50uau0n	cmqo3trry00ecjxf0tqh1zbcq	cmqo3trv700m9jxf0o1mkm455	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxm00ujjxf0dw9kkyvm	cmqo3trry00edjxf0y4sszbb3	cmqo3trv700majxf0plbqmevs	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00ukjxf00u3px6cr	cmqo3trry00edjxf0y4sszbb3	cmqo3trv700majxf0plbqmevs	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00uljxf0e3t77ph3	cmqo3trry00edjxf0y4sszbb3	cmqo3trv700majxf0plbqmevs	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00umjxf04op4aozb	cmqo3trry00enjxf0py52o7zw	cmqo3trv700mkjxf0swpo0kz3	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00unjxf0cfysg09x	cmqo3trry00enjxf0py52o7zw	cmqo3trv700mkjxf0swpo0kz3	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00uojxf0aizcf8c3	cmqo3trry00enjxf0py52o7zw	cmqo3trv700mkjxf0swpo0kz3	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00upjxf0qa6ma2d3	cmqo3trry00eojxf0zd1iyhx1	cmqo3trv700mljxf0bdaap8d1	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00uqjxf0jvfhq72g	cmqo3trry00eojxf0zd1iyhx1	cmqo3trv700mljxf0bdaap8d1	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00urjxf04btrofeo	cmqo3trry00eojxf0zd1iyhx1	cmqo3trv700mljxf0bdaap8d1	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00usjxf07u56e8xz	cmqo3trry00epjxf0h7rp4ikb	cmqo3trv700mmjxf01bhj6sr1	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00utjxf0bb16np19	cmqo3trry00epjxf0h7rp4ikb	cmqo3trv700mmjxf01bhj6sr1	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00uujxf0c0xo7uu1	cmqo3trry00epjxf0h7rp4ikb	cmqo3trv700mmjxf01bhj6sr1	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00uvjxf0t3znu7av	cmqo3trry00epjxf0h7rp4ikb	cmqo3trv700mmjxf01bhj6sr1	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00uwjxf02a9s9kfs	cmqo3trry00erjxf0tapbsk8t	cmqo3trv700mojxf0zv0wlw4y	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00uxjxf0p4jqx7iv	cmqo3trry00erjxf0tapbsk8t	cmqo3trv700mojxf0zv0wlw4y	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00uyjxf06qf1rfxx	cmqo3trry00erjxf0tapbsk8t	cmqo3trv700mojxf0zv0wlw4y	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00uzjxf0iznse570	cmqo3trry00esjxf0bm0tc1il	cmqo3trv700mpjxf00rpsaifj	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00v0jxf0635c2sol	cmqo3trry00esjxf0bm0tc1il	cmqo3trv700mpjxf00rpsaifj	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00v1jxf07g303eer	cmqo3trry00esjxf0bm0tc1il	cmqo3trv700mpjxf00rpsaifj	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00v2jxf0o45m9bif	cmqo3trry00etjxf0x1kawj88	cmqo3trv700mqjxf0hr7id754	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00v3jxf0xygotpj3	cmqo3trry00etjxf0x1kawj88	cmqo3trv700mqjxf0hr7id754	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00v4jxf0hs06gs5a	cmqo3trry00etjxf0x1kawj88	cmqo3trv700mqjxf0hr7id754	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00v5jxf0vjyvswi7	cmqo3trry00evjxf06x88zpy5	cmqo3trv700msjxf0rnqlt180	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00v6jxf07jkpgso3	cmqo3trry00evjxf06x88zpy5	cmqo3trv700msjxf0rnqlt180	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00v7jxf00rbm8yxo	cmqo3trry00evjxf06x88zpy5	cmqo3trv700msjxf0rnqlt180	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00v8jxf0fokywbv8	cmqo3trry00ewjxf0toodswrr	cmqo3trv700mtjxf0ve3g0cwk	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00v9jxf0atp27cwq	cmqo3trry00ewjxf0toodswrr	cmqo3trv700mtjxf0ve3g0cwk	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00vajxf0nxltu1x4	cmqo3trry00ewjxf0toodswrr	cmqo3trv700mtjxf0ve3g0cwk	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00vbjxf0534l0c2g	cmqo3trry00f0jxf020ixwdwi	cmqo3trv700mxjxf07vwd9n9b	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00vcjxf0wz8hd6h6	cmqo3trry00f0jxf020ixwdwi	cmqo3trv700mxjxf07vwd9n9b	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00vdjxf0dn2nkn7c	cmqo3trry00f0jxf020ixwdwi	cmqo3trv700mxjxf07vwd9n9b	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00vejxf0yx44jgz6	cmqo3trry00f0jxf020ixwdwi	cmqo3trv700mxjxf07vwd9n9b	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00vfjxf02bfmbnla	cmqo3trry00f0jxf020ixwdwi	cmqo3trv700mxjxf07vwd9n9b	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00vgjxf0ea32cwy4	cmqo3trry00f4jxf086ittq3f	cmqo3trv800n1jxf0kz4h5ro5	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00vhjxf0856dak1s	cmqo3trry00f4jxf086ittq3f	cmqo3trv800n1jxf0kz4h5ro5	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00vijxf0qrfdg2kd	cmqo3trry00f4jxf086ittq3f	cmqo3trv800n1jxf0kz4h5ro5	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00vjjxf0nqqxpye3	cmqo3trry00f6jxf0xhnsex81	cmqo3trv800n3jxf0foxp2rad	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00vkjxf0fp5xojkl	cmqo3trry00f6jxf0xhnsex81	cmqo3trv800n3jxf0foxp2rad	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00vljxf0fr01a4x8	cmqo3trry00f6jxf0xhnsex81	cmqo3trv800n3jxf0foxp2rad	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00vmjxf0q1q3wycf	cmqo3trry00f9jxf0t1etwy68	cmqo3trv800n6jxf02kbqhg6f	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00vnjxf00d7do0y4	cmqo3trry00f9jxf0t1etwy68	cmqo3trv800n6jxf02kbqhg6f	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00vojxf0oq17tzcp	cmqo3trry00f9jxf0t1etwy68	cmqo3trv800n6jxf02kbqhg6f	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00vpjxf0uo9aufyr	cmqo3trry00fajxf07zgohl3s	cmqo3trv800n7jxf0y1ec9plh	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00vqjxf0ehqguz9p	cmqo3trry00fajxf07zgohl3s	cmqo3trv800n7jxf0y1ec9plh	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00vrjxf0wl2ysc0x	cmqo3trry00fajxf07zgohl3s	cmqo3trv800n7jxf0y1ec9plh	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00vsjxf0zztusvf7	cmqo3trry00fbjxf05gxm8phc	cmqo3trv800n8jxf0iesm71xx	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00vtjxf0n07p9mti	cmqo3trry00fbjxf05gxm8phc	cmqo3trv800n8jxf0iesm71xx	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00vujxf0ylkya8a7	cmqo3trry00fbjxf05gxm8phc	cmqo3trv800n8jxf0iesm71xx	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00vvjxf0jz2tuqco	cmqo3trry00fejxf00abhefcg	cmqo3trv800nbjxf0583jodx9	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00vwjxf0bciy0hmf	cmqo3trry00fejxf00abhefcg	cmqo3trv800nbjxf0583jodx9	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00vxjxf0findhnlc	cmqo3trry00fejxf00abhefcg	cmqo3trv800nbjxf0583jodx9	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00vyjxf0l1vx88tn	cmqo3trry00fejxf00abhefcg	cmqo3trv800nbjxf0583jodx9	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00vzjxf0onzbbt5p	cmqo3trrz00g9jxf09fpmqbg0	cmqo3trv900o6jxf0079j9m8h	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00w0jxf0v3swd5xt	cmqo3trrz00g9jxf09fpmqbg0	cmqo3trv900o6jxf0079j9m8h	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00w1jxf0ym2hg36z	cmqo3trrz00g9jxf09fpmqbg0	cmqo3trv900o6jxf0079j9m8h	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00w2jxf0w1ccghb5	cmqo3trrz00ggjxf0t6hdtuoc	cmqo3trv900odjxf0uc8bj68r	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00w3jxf0mf3yoq8j	cmqo3trrz00ggjxf0t6hdtuoc	cmqo3trv900odjxf0uc8bj68r	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00w4jxf0gmdmp99q	cmqo3trrz00ggjxf0t6hdtuoc	cmqo3trv900odjxf0uc8bj68r	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00w5jxf0i6nhsck9	cmqo3trrz00gmjxf0b1mr40o3	cmqo3trv900ojjxf03eckf2sy	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00w6jxf0je3hf8g7	cmqo3trrz00gmjxf0b1mr40o3	cmqo3trv900ojjxf03eckf2sy	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00w7jxf0bgwh5qfz	cmqo3trrz00gmjxf0b1mr40o3	cmqo3trv900ojjxf03eckf2sy	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00w8jxf09jcru60v	cmqo3trrz00gojxf057482z7q	cmqo3trv900oljxf0y2d8kira	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00w9jxf0oxxzb9nt	cmqo3trrz00gojxf057482z7q	cmqo3trv900oljxf0y2d8kira	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00wajxf0ndt6a631	cmqo3trrz00gojxf057482z7q	cmqo3trv900oljxf0y2d8kira	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00wbjxf0141co8m9	cmqo3trrz00gtjxf09h5slaxo	cmqo3trv900oqjxf00qum5gbo	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00wcjxf03g3x8b97	cmqo3trrz00gtjxf09h5slaxo	cmqo3trv900oqjxf00qum5gbo	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00wdjxf03r7n4380	cmqo3trrz00gtjxf09h5slaxo	cmqo3trv900oqjxf00qum5gbo	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00wejxf0itn69hke	cmqo3trrz00gtjxf09h5slaxo	cmqo3trv900oqjxf00qum5gbo	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00wfjxf0oavm5evn	cmqo3trrz00h0jxf0pm6awfjg	cmqo3trv900oxjxf0fevlg44q	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00wgjxf0s3muw8ml	cmqo3trrz00h0jxf0pm6awfjg	cmqo3trv900oxjxf0fevlg44q	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00whjxf0wyyp4png	cmqo3trrz00h0jxf0pm6awfjg	cmqo3trv900oxjxf0fevlg44q	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00wijxf0pat6sjoi	cmqo3trrz00h1jxf0qrydpsgd	cmqo3trva00oyjxf0effo4rc8	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxn00wjjxf0wgcm61mp	cmqo3trrz00h1jxf0qrydpsgd	cmqo3trva00oyjxf0effo4rc8	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00wkjxf06mul0djh	cmqo3trrz00h1jxf0qrydpsgd	cmqo3trva00oyjxf0effo4rc8	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00wljxf05n51aq2t	cmqo3trrz00h6jxf052sls66w	cmqo3trva00p3jxf0awrdmpl1	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00wmjxf05byc67hs	cmqo3trrz00h6jxf052sls66w	cmqo3trva00p3jxf0awrdmpl1	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00wnjxf0kyvin2hx	cmqo3trrz00h6jxf052sls66w	cmqo3trva00p3jxf0awrdmpl1	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00wojxf0gwmklm0e	cmqo3trrz00h7jxf0phmz4mih	cmqo3trva00p4jxf0drhyulcn	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00wpjxf0udnhy1ui	cmqo3trrz00h7jxf0phmz4mih	cmqo3trva00p4jxf0drhyulcn	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00wqjxf06bps5xrg	cmqo3trrz00h7jxf0phmz4mih	cmqo3trva00p4jxf0drhyulcn	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00wrjxf0qoz0ogtx	cmqo3trrz00hajxf05t8nln3k	cmqo3trva00p7jxf0x2w924l9	1	in_progress	2026-06-21 18:12:47.137	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00wsjxf0sb0juzee	cmqo3trrz00hajxf05t8nln3k	cmqo3trva00p7jxf0x2w924l9	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00wtjxf0c9tpims1	cmqo3trrz00hajxf05t8nln3k	cmqo3trva00p7jxf0x2w924l9	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00wujxf0eks0zodb	cmqo3trrz00hdjxf05e3o2pl2	cmqo3trva00pajxf01x1uixul	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00wvjxf094b3v5st	cmqo3trrz00hdjxf05e3o2pl2	cmqo3trva00pajxf01x1uixul	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00wwjxf0qwt2ct2k	cmqo3trrz00hdjxf05e3o2pl2	cmqo3trva00pajxf01x1uixul	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00wxjxf0kb6b2xjc	cmqo3trrz00hhjxf0ib8t6qp9	cmqo3trva00pejxf06r7ny2r6	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00wyjxf0t5k9kc1s	cmqo3trrz00hhjxf0ib8t6qp9	cmqo3trva00pejxf06r7ny2r6	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00wzjxf0j9y7xb4a	cmqo3trrz00hhjxf0ib8t6qp9	cmqo3trva00pejxf06r7ny2r6	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00x0jxf02ytcrz6u	cmqo3trrz00hijxf0ui710mby	cmqo3trva00pfjxf04iwa0qzj	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00x1jxf0jezr3n18	cmqo3trrz00hijxf0ui710mby	cmqo3trva00pfjxf04iwa0qzj	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00x2jxf01exitdbx	cmqo3trrz00hijxf0ui710mby	cmqo3trva00pfjxf04iwa0qzj	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00x3jxf02d24sgza	cmqo3trrz00hmjxf04tywy4vr	cmqo3trva00pjjxf0yjj7nzbu	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00x4jxf0cekt9hya	cmqo3trrz00hmjxf04tywy4vr	cmqo3trva00pjjxf0yjj7nzbu	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00x5jxf0o8r3055o	cmqo3trrz00hmjxf04tywy4vr	cmqo3trva00pjjxf0yjj7nzbu	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00x6jxf0z1ernvfy	cmqo3trrz00hnjxf0n6h6e20p	cmqo3trva00pkjxf0rc9m2xac	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00x7jxf0mij58ddq	cmqo3trrz00hnjxf0n6h6e20p	cmqo3trva00pkjxf0rc9m2xac	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00x8jxf0tgtljrxn	cmqo3trrz00hnjxf0n6h6e20p	cmqo3trva00pkjxf0rc9m2xac	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00x9jxf0m1cqrb8y	cmqo3trrz00hnjxf0n6h6e20p	cmqo3trva00pkjxf0rc9m2xac	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00xajxf0fir0golp	cmqo3trrz00hojxf0u0h2h52t	cmqo3trva00pljxf06ch6sa31	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00xbjxf0bj8k5qpt	cmqo3trrz00hojxf0u0h2h52t	cmqo3trva00pljxf06ch6sa31	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00xcjxf0boveobxs	cmqo3trrz00hojxf0u0h2h52t	cmqo3trva00pljxf06ch6sa31	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00xdjxf02bfvwga6	cmqo3trrz00hpjxf0e0guc52t	cmqo3trva00pmjxf0b1eoqrc2	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00xejxf0p3wfa40f	cmqo3trrz00hpjxf0e0guc52t	cmqo3trva00pmjxf0b1eoqrc2	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00xfjxf0vpwyzzkc	cmqo3trrz00hpjxf0e0guc52t	cmqo3trva00pmjxf0b1eoqrc2	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00xgjxf0nq5u3bxi	cmqo3trs000hsjxf03i0g0wzd	cmqo3trva00ppjxf00tvxkoy7	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00xhjxf0e8cvyd1t	cmqo3trs000hsjxf03i0g0wzd	cmqo3trva00ppjxf00tvxkoy7	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00xijxf0mgzs7jow	cmqo3trs000hsjxf03i0g0wzd	cmqo3trva00ppjxf00tvxkoy7	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00xjjxf01oo7pjf9	cmqo3trs000htjxf0mugg0128	cmqo3trva00pqjxf0my7qbkcc	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00xkjxf0i93ljbz6	cmqo3trs000htjxf0mugg0128	cmqo3trva00pqjxf0my7qbkcc	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00xljxf0oo6z5abn	cmqo3trs000htjxf0mugg0128	cmqo3trva00pqjxf0my7qbkcc	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00xmjxf05novrpma	cmqo3trs000i1jxf0xnbsk42d	cmqo3trvb00pyjxf0tjysqurt	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00xnjxf0czy0vtxq	cmqo3trs000i1jxf0xnbsk42d	cmqo3trvb00pyjxf0tjysqurt	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00xojxf0i18jb45v	cmqo3trs000i1jxf0xnbsk42d	cmqo3trvb00pyjxf0tjysqurt	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00xpjxf02mh1tsub	cmqo3trs000i3jxf0nwase7y3	cmqo3trvb00q0jxf0uln86xk3	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00xqjxf0yl3k6vkm	cmqo3trs000i3jxf0nwase7y3	cmqo3trvb00q0jxf0uln86xk3	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00xrjxf05u88d6rb	cmqo3trs000i3jxf0nwase7y3	cmqo3trvb00q0jxf0uln86xk3	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00xsjxf0nmzm0qlx	cmqo3trs000i3jxf0nwase7y3	cmqo3trvb00q0jxf0uln86xk3	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00xtjxf0qncvcbon	cmqo3trs000i3jxf0nwase7y3	cmqo3trvb00q0jxf0uln86xk3	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00xujxf0i9udx7wa	cmqo3trs000i8jxf0lj5i6ck7	cmqo3trvb00q5jxf0g31yoduw	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00xvjxf0s7sgs2p1	cmqo3trs000i8jxf0lj5i6ck7	cmqo3trvb00q5jxf0g31yoduw	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00xwjxf03b5i9coz	cmqo3trs000i8jxf0lj5i6ck7	cmqo3trvb00q5jxf0g31yoduw	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00xxjxf07dj34j47	cmqo3trs000iajxf0mybsp82d	cmqo3trvb00q7jxf0cofdde9z	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00xyjxf03gpw4csu	cmqo3trs000iajxf0mybsp82d	cmqo3trvb00q7jxf0cofdde9z	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00xzjxf0bs7j5vnx	cmqo3trs000iajxf0mybsp82d	cmqo3trvb00q7jxf0cofdde9z	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00y0jxf0eqqjypw0	cmqo3trs000iajxf0mybsp82d	cmqo3trvb00q7jxf0cofdde9z	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00y1jxf0d91msznb	cmqo3trs000ibjxf03zq7wprq	cmqo3trvb00q8jxf0j03amc6m	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00y2jxf0sgi3ff37	cmqo3trs000ibjxf03zq7wprq	cmqo3trvb00q8jxf0j03amc6m	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00y3jxf0c16ec6li	cmqo3trs000ibjxf03zq7wprq	cmqo3trvb00q8jxf0j03amc6m	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00y4jxf01vi6cnzt	cmqo3trs000idjxf0n2k1bnwt	cmqo3trvb00qajxf00d7rlhdv	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00y5jxf0fscxyyrq	cmqo3trs000idjxf0n2k1bnwt	cmqo3trvb00qajxf00d7rlhdv	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00y6jxf03aua3hic	cmqo3trs000idjxf0n2k1bnwt	cmqo3trvb00qajxf00d7rlhdv	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00y7jxf0i1kua2a4	cmqo3trs000idjxf0n2k1bnwt	cmqo3trvb00qajxf00d7rlhdv	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00y8jxf0xiupney7	cmqo3trs000iijxf0t31s6fmx	cmqo3trvb00qfjxf0qduzyswj	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00y9jxf05fnm1aws	cmqo3trs000iijxf0t31s6fmx	cmqo3trvb00qfjxf0qduzyswj	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00yajxf056gr57om	cmqo3trs000iijxf0t31s6fmx	cmqo3trvb00qfjxf0qduzyswj	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00ybjxf040y65iys	cmqo3trs000ikjxf0c804u77b	cmqo3trvb00qhjxf0l1bpbdcu	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00ycjxf06e95si21	cmqo3trs000ikjxf0c804u77b	cmqo3trvb00qhjxf0l1bpbdcu	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00ydjxf0k125yog5	cmqo3trs000ikjxf0c804u77b	cmqo3trvb00qhjxf0l1bpbdcu	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00yejxf0d3ge6lyk	cmqo3trs000irjxf0lf2fit85	cmqo3trvb00qojxf0vufw9exy	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00yfjxf03pvmtn8w	cmqo3trs000irjxf0lf2fit85	cmqo3trvb00qojxf0vufw9exy	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00ygjxf08a54tlsy	cmqo3trs000irjxf0lf2fit85	cmqo3trvb00qojxf0vufw9exy	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00yhjxf00q37yo9i	cmqo3trs000ivjxf052cpo9aj	cmqo3trvb00qsjxf03in3vx3q	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00yijxf03oktpjpj	cmqo3trs000ivjxf052cpo9aj	cmqo3trvb00qsjxf03in3vx3q	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00yjjxf0gvb4sq5d	cmqo3trs000ivjxf052cpo9aj	cmqo3trvb00qsjxf03in3vx3q	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00ykjxf086ew4pmg	cmqo3trs000iwjxf0hwtqsr99	cmqo3trvb00qtjxf05a652ck1	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00yljxf0upsnijlg	cmqo3trs000iwjxf0hwtqsr99	cmqo3trvb00qtjxf05a652ck1	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxo00ymjxf0xubtmxfs	cmqo3trs000iwjxf0hwtqsr99	cmqo3trvb00qtjxf05a652ck1	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00ynjxf062mwu3hz	cmqo3trs000iwjxf0hwtqsr99	cmqo3trvb00qtjxf05a652ck1	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00yojxf0tcgkf9tb	cmqo3trs000ixjxf0hpq061q5	cmqo3trvb00qujxf0wgn6nk7s	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00ypjxf0t64hsi8f	cmqo3trs000ixjxf0hpq061q5	cmqo3trvb00qujxf0wgn6nk7s	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00yqjxf069tijxyq	cmqo3trs000ixjxf0hpq061q5	cmqo3trvb00qujxf0wgn6nk7s	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00yrjxf0bcp0og5d	cmqo3trs000iyjxf0oqdyax91	cmqo3trvb00qvjxf0flt8t5rb	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00ysjxf03jc3833b	cmqo3trs000iyjxf0oqdyax91	cmqo3trvb00qvjxf0flt8t5rb	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00ytjxf0euerap3c	cmqo3trs000iyjxf0oqdyax91	cmqo3trvb00qvjxf0flt8t5rb	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00yujxf0bnq47m04	cmqo3trs000j2jxf0tinhhty6	cmqo3trvc00qzjxf0ar7hg0do	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00yvjxf0sqq94940	cmqo3trs000j2jxf0tinhhty6	cmqo3trvc00qzjxf0ar7hg0do	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00ywjxf0y6pc7x9s	cmqo3trs000j2jxf0tinhhty6	cmqo3trvc00qzjxf0ar7hg0do	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00yxjxf0z6k5ny8w	cmqo3trs000jdjxf0tbqqkbsy	cmqo3trvc00rajxf0uulqihp0	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00yyjxf0cccc3dms	cmqo3trs000jdjxf0tbqqkbsy	cmqo3trvc00rajxf0uulqihp0	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00yzjxf0jibeo0pa	cmqo3trs000jdjxf0tbqqkbsy	cmqo3trvc00rajxf0uulqihp0	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00z0jxf0yx69t1ua	cmqo3trs000jejxf0lmmwphze	cmqo3trvc00rbjxf0r1tyb85q	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00z1jxf0hd7tjn8p	cmqo3trs000jejxf0lmmwphze	cmqo3trvc00rbjxf0r1tyb85q	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00z2jxf0tu7wkcah	cmqo3trs000jejxf0lmmwphze	cmqo3trvc00rbjxf0r1tyb85q	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00z3jxf0h1pw0urz	cmqo3trs000jjjxf0kjfj4ptb	cmqo3trvc00rgjxf0vdhs9mnt	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00z4jxf0gsq83t8a	cmqo3trs000jjjxf0kjfj4ptb	cmqo3trvc00rgjxf0vdhs9mnt	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00z5jxf05c2t2qn2	cmqo3trs000jjjxf0kjfj4ptb	cmqo3trvc00rgjxf0vdhs9mnt	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00z6jxf0851lyjmu	cmqo3trs000jkjxf04p8v0p1e	cmqo3trvc00rhjxf0lnv348rw	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00z7jxf06wu7gq7f	cmqo3trs000jkjxf04p8v0p1e	cmqo3trvc00rhjxf0lnv348rw	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00z8jxf0qdquuu2l	cmqo3trs000jkjxf04p8v0p1e	cmqo3trvc00rhjxf0lnv348rw	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00z9jxf0t95l6thm	cmqo3trs000jljxf0n1whl2b0	cmqo3trvc00rijxf0hythxyvs	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00zajxf0d7hdb91k	cmqo3trs000jljxf0n1whl2b0	cmqo3trvc00rijxf0hythxyvs	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00zbjxf0fx9i09ua	cmqo3trs000jljxf0n1whl2b0	cmqo3trvc00rijxf0hythxyvs	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00zcjxf0klhhjr4n	cmqo3trs100jmjxf0bk391c8p	cmqo3trvc00rjjxf0xuuhyikq	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00zdjxf0wnlvscsm	cmqo3trs100jmjxf0bk391c8p	cmqo3trvc00rjjxf0xuuhyikq	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00zejxf0so5qkc48	cmqo3trs100jmjxf0bk391c8p	cmqo3trvc00rjjxf0xuuhyikq	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00zfjxf0n9vxt9hx	cmqo3trs100jnjxf04bo0b6mo	cmqo3trvc00rkjxf0uqaxq7hf	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00zgjxf0w3pkf9f9	cmqo3trs100jnjxf04bo0b6mo	cmqo3trvc00rkjxf0uqaxq7hf	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00zhjxf0n7yqg8r3	cmqo3trs100jnjxf04bo0b6mo	cmqo3trvc00rkjxf0uqaxq7hf	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00zijxf0gkqq7pmb	cmqo3trs100jojxf0nzvb6y5x	cmqo3trvc00rljxf0mo8rfo71	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00zjjxf073lm518x	cmqo3trs100jojxf0nzvb6y5x	cmqo3trvc00rljxf0mo8rfo71	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00zkjxf0jmzbs4lb	cmqo3trs100jojxf0nzvb6y5x	cmqo3trvc00rljxf0mo8rfo71	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00zljxf0tq6klbbc	cmqo3trs100jpjxf0oc730zbi	cmqo3trvc00rmjxf0ircw7sa6	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00zmjxf0gpzlpt2h	cmqo3trs100jpjxf0oc730zbi	cmqo3trvc00rmjxf0ircw7sa6	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00znjxf0ols5gzwp	cmqo3trs100jpjxf0oc730zbi	cmqo3trvc00rmjxf0ircw7sa6	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00zojxf0pmx5o16d	cmqo3trs100jrjxf07xr2bi8g	cmqo3trvc00rojxf0639g2tru	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00zpjxf0pq7yntsp	cmqo3trs100jrjxf07xr2bi8g	cmqo3trvc00rojxf0639g2tru	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00zqjxf0xqywlyik	cmqo3trs100jrjxf07xr2bi8g	cmqo3trvc00rojxf0639g2tru	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00zrjxf071co0vpu	cmqo3trs100jsjxf0i1fvu5ef	cmqo3trvc00rpjxf087d47m57	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00zsjxf0raplot2u	cmqo3trs100jsjxf0i1fvu5ef	cmqo3trvc00rpjxf087d47m57	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00ztjxf0vpptcjb5	cmqo3trs100jsjxf0i1fvu5ef	cmqo3trvc00rpjxf087d47m57	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00zujxf0uzu8prmz	cmqo3trs100jwjxf0t2475383	cmqo3trvd00rtjxf0y3v333zc	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00zvjxf02e1jyhdd	cmqo3trs100jwjxf0t2475383	cmqo3trvd00rtjxf0y3v333zc	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00zwjxf000aogxjq	cmqo3trs100jwjxf0t2475383	cmqo3trvd00rtjxf0y3v333zc	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00zxjxf0gf6z5pn4	cmqo3trs100k0jxf0s2cnypqs	cmqo3trvd00rxjxf08q087ej3	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00zyjxf0lhl2y1vg	cmqo3trs100k0jxf0s2cnypqs	cmqo3trvd00rxjxf08q087ej3	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp00zzjxf0ln6v2wf2	cmqo3trs100k0jxf0s2cnypqs	cmqo3trvd00rxjxf08q087ej3	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp0100jxf0o6lthw5f	cmqo3trs100k1jxf08dm66p9q	cmqo3trvd00ryjxf031gnetr9	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp0101jxf00e368994	cmqo3trs100k1jxf08dm66p9q	cmqo3trvd00ryjxf031gnetr9	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp0102jxf0rcul110w	cmqo3trs100k1jxf08dm66p9q	cmqo3trvd00ryjxf031gnetr9	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp0103jxf03wy4awhw	cmqo3trs100k2jxf0cm47oiks	cmqo3trvd00rzjxf0skessz1r	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp0104jxf0zk2atj4f	cmqo3trs100k2jxf0cm47oiks	cmqo3trvd00rzjxf0skessz1r	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp0105jxf0pxhi7bd1	cmqo3trs100k2jxf0cm47oiks	cmqo3trvd00rzjxf0skessz1r	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp0106jxf0ij0mztde	cmqo3trs100k3jxf0lbg6txs7	cmqo3trvd00s0jxf08f87a8gp	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp0107jxf0okqoocj5	cmqo3trs100k3jxf0lbg6txs7	cmqo3trvd00s0jxf08f87a8gp	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp0108jxf0osk9icvm	cmqo3trs100k3jxf0lbg6txs7	cmqo3trvd00s0jxf08f87a8gp	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp0109jxf055tt2q4r	cmqo3trs100k5jxf0ebzyyxab	cmqo3trvd00s2jxf0ibaouk9t	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp010ajxf0q64c3mvo	cmqo3trs100k5jxf0ebzyyxab	cmqo3trvd00s2jxf0ibaouk9t	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp010bjxf0gk8axj6t	cmqo3trs100k5jxf0ebzyyxab	cmqo3trvd00s2jxf0ibaouk9t	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp010cjxf0zhtemo4k	cmqo3trs100k5jxf0ebzyyxab	cmqo3trvd00s2jxf0ibaouk9t	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp010djxf0x0rr7pom	cmqo3trs100k5jxf0ebzyyxab	cmqo3trvd00s2jxf0ibaouk9t	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp010ejxf0nhgatt1j	cmqo3trs100k6jxf097odkcaq	cmqo3trvd00s3jxf02zl5viqs	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp010fjxf0kdnc5ibd	cmqo3trs100k6jxf097odkcaq	cmqo3trvd00s3jxf02zl5viqs	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp010gjxf0xdxtu24g	cmqo3trs100k6jxf097odkcaq	cmqo3trvd00s3jxf02zl5viqs	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp010hjxf0qdy6qhid	cmqo3trs100k6jxf097odkcaq	cmqo3trvd00s3jxf02zl5viqs	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp010ijxf0wf66hmfq	cmqo3trs100k6jxf097odkcaq	cmqo3trvd00s3jxf02zl5viqs	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp010jjxf02dm9k8u6	cmqo3trs100k8jxf096uofmtk	cmqo3trvd00s5jxf0kudcs2sc	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp010kjxf0mpsl2efe	cmqo3trs100k8jxf096uofmtk	cmqo3trvd00s5jxf0kudcs2sc	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp010ljxf0qrvln06s	cmqo3trs100k8jxf096uofmtk	cmqo3trvd00s5jxf0kudcs2sc	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp010mjxf0brz094a7	cmqo3trs100k8jxf096uofmtk	cmqo3trvd00s5jxf0kudcs2sc	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp010njxf06j8pbil5	cmqo3trs100k9jxf0zd5abti7	cmqo3trvd00s6jxf0w2he50gu	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp010ojxf0yrxl4v48	cmqo3trs100k9jxf0zd5abti7	cmqo3trvd00s6jxf0w2he50gu	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp010pjxf0d5jweqlr	cmqo3trs100k9jxf0zd5abti7	cmqo3trvd00s6jxf0w2he50gu	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp010qjxf01iowvepy	cmqo3trs100k9jxf0zd5abti7	cmqo3trvd00s6jxf0w2he50gu	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxp010rjxf0wdfmh2f1	cmqo3trs100k9jxf0zd5abti7	cmqo3trvd00s6jxf0w2he50gu	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxq010sjxf06pmzpobu	cmqo3trs100kajxf0afxapwkn	cmqo3trvd00s7jxf0shq459ix	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxq010tjxf0kiucjxmb	cmqo3trs100kajxf0afxapwkn	cmqo3trvd00s7jxf0shq459ix	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxq010ujxf0p86qek3k	cmqo3trs100kajxf0afxapwkn	cmqo3trvd00s7jxf0shq459ix	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxq010vjxf0a6ifn25n	cmqo3trs100kajxf0afxapwkn	cmqo3trvd00s7jxf0shq459ix	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxq010wjxf0rdsq7kso	cmqo3trs100kbjxf00at60v0s	cmqo3trvd00s8jxf035qn65ux	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxq010xjxf0etv5rj18	cmqo3trs100kbjxf00at60v0s	cmqo3trvd00s8jxf035qn65ux	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxq010yjxf0kfl4lziu	cmqo3trs100kbjxf00at60v0s	cmqo3trvd00s8jxf035qn65ux	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxq010zjxf05mm6zc6g	cmqo3trs100kbjxf00at60v0s	cmqo3trvd00s8jxf035qn65ux	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxq0110jxf04nxmz3o7	cmqo3trs100kbjxf00at60v0s	cmqo3trvd00s8jxf035qn65ux	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxq0111jxf0krf70wdj	cmqo3trs100kcjxf03d64gxgg	cmqo3trvd00s9jxf0e38s3ncd	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxq0112jxf0tvkaypj7	cmqo3trs100kcjxf03d64gxgg	cmqo3trvd00s9jxf0e38s3ncd	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxq0113jxf0ddhh8cbk	cmqo3trs100kcjxf03d64gxgg	cmqo3trvd00s9jxf0e38s3ncd	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxq0114jxf05pvevdfw	cmqo3trs100kcjxf03d64gxgg	cmqo3trvd00s9jxf0e38s3ncd	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxq0115jxf0z6kze4ct	cmqo3trs100kcjxf03d64gxgg	cmqo3trvd00s9jxf0e38s3ncd	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxq0116jxf0cx31y4n1	cmqo3trs100kdjxf0so7lged7	cmqo3trvd00sajxf0nanf1r1r	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxq0117jxf059bwxmtv	cmqo3trs100kdjxf0so7lged7	cmqo3trvd00sajxf0nanf1r1r	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxq0118jxf0asyx2p17	cmqo3trs100kdjxf0so7lged7	cmqo3trvd00sajxf0nanf1r1r	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxq0119jxf0gvkdtrt4	cmqo3trs100kdjxf0so7lged7	cmqo3trvd00sajxf0nanf1r1r	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxq011ajxf0ewlt1bpq	cmqo3trs100kejxf06v05c5fm	cmqo3trvd00sbjxf06iqhr5p8	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxq011bjxf0y32lz1s6	cmqo3trs100kejxf06v05c5fm	cmqo3trvd00sbjxf06iqhr5p8	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxq011cjxf0453ywp9d	cmqo3trs100kejxf06v05c5fm	cmqo3trvd00sbjxf06iqhr5p8	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxq011djxf0h1h5q5l8	cmqo3trs100kejxf06v05c5fm	cmqo3trvd00sbjxf06iqhr5p8	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxq011ejxf0ryyuei06	cmqo3trs100kfjxf0m4itmu0z	cmqo3trvd00scjxf0nsu8ajyv	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxq011fjxf0x1g2wyme	cmqo3trs100kfjxf0m4itmu0z	cmqo3trvd00scjxf0nsu8ajyv	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxq011gjxf079ddxqad	cmqo3trs100kfjxf0m4itmu0z	cmqo3trvd00scjxf0nsu8ajyv	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxq011hjxf0iwnz7qa0	cmqo3trs100kfjxf0m4itmu0z	cmqo3trvd00scjxf0nsu8ajyv	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxq011ijxf0ef6zpwcj	cmqo3trs100kgjxf0sd21964h	cmqo3trvd00sdjxf0bn0dim07	1	in_progress	2026-06-21 18:12:47.138	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxq011jjxf00gg98tnp	cmqo3trs100kgjxf0sd21964h	cmqo3trvd00sdjxf0bn0dim07	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxq011kjxf0qskqdlze	cmqo3trs100kgjxf0sd21964h	cmqo3trvd00sdjxf0bn0dim07	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqo3trxq011ljxf0xjxnfykt	cmqo3trs100kgjxf0sd21964h	cmqo3trvd00sdjxf0bn0dim07	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-21 18:12:47.143	2026-06-21 18:12:47.143
cmqep6taj00smjxp5fepno62h	cmqep6t7y00hajxp53xjfiwp0	cmqep6t9500k4jxp58jv5ogik	2	completed	2026-06-19 13:12:21.433	2026-06-26 08:54:20.38	2026-06-26 08:54:18.178	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:54:20.381
cmqf02txa006ujxop9or9yvby	cmqf02twi005zjxop5kafgs6v	cmqf02twx0068jxopyix3b9jl	2	in_progress	2026-06-26 08:55:23.677	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 09:17:55.581	2026-06-26 08:55:23.678
cmr254jpo00i2jxctw2smzq2s	cmr254jj6001qjxct1t13zel2	cmr254jmt009njxctkuatett5	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6tag00mcjxp5n05ybmqc	cmqep6t7x00fdjxp5phrwrenn	cmqep6t9300i7jxp5czcjfas0	2	completed	2026-06-26 09:19:22.463	2026-06-26 09:22:52.316	2026-06-26 09:22:50.71	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:22:52.317
cmqep6tai00q8jxp5j3sw5p0h	cmqep6t7y00gkjxp5h4f0156z	cmqep6t9500jejxp5atgprn20	2	completed	2026-06-19 12:47:04.026	2026-06-26 08:56:03.235	2026-06-26 08:55:53.846	cmq0kwit80066jx23pw930nx1	เด็กค้นหาคุณค่าในตัวเองท้างด้านบวกมากขึ้น	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:56:03.236
cmqep6taj00sbjxp59d9tfy00	cmqep6t7y00h6jxp5lq2ohp8z	cmqep6t9500k0jxp51dcqlx2y	2	completed	2026-06-26 08:57:23.821	2026-06-26 08:59:12.135	2026-06-26 08:59:04.393	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 08:59:12.136
cmqep6tai00qgjxp5cq4musn4	cmqep6t7y00gmjxp5w0cyfz8a	cmqep6t9500jgjxp54oyob17b	2	completed	2026-06-19 12:59:17.693	2026-06-26 09:01:07.11	2026-06-26 09:01:05.32	cmq0kwit80066jx23pw930nx1	มีความคิดบวก เห็นคุณค่า	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:01:07.111
cmqf02tx9006ijxop21fes6vb	cmqf02twi005wjxop1suc7kpd	cmqf02twx0065jxopks12xh9e	2	completed	2026-06-19 13:01:54.611	2026-06-26 09:04:30.866	2026-06-26 09:04:24.179	cmq0kwit80066jx23pw930nx1	ไม่เห็นคุณค่าในตัวเองและไม่มีพลังใจนัดหมายเสริมพลังใจ	\N	\N	\N	\N	2026-06-15 09:17:55.581	2026-06-26 09:04:30.867
cmqep6tai00qtjxp5y1ykevay	cmqep6t7y00gpjxp5s7zduyel	cmqep6t9500jjjxp59xh7ckl7	2	completed	2026-06-19 13:04:08.435	2026-06-26 09:04:31.962	2026-06-26 09:04:30.596	cmq0kwit80066jx23pw930nx1	มองโลกในแง่บวก เห็นคุณค่าในตัวเอง มีพลังใจ	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:04:31.963
cmqf02txa0072jxopltnwnhhu	cmqf02twi0061jxopfw2ixih5	cmqf02twx006ajxop3fgj1itn	2	completed	2026-06-26 09:01:24.257	2026-06-26 09:05:46.853	2026-06-26 09:04:18.379	cmq0kyw85007kjx239k25z1ge	มีคุณค่าของตัวเองมากขึ้น	\N	\N	\N	\N	2026-06-15 09:17:55.581	2026-06-26 09:05:46.854
cmqep6tae00knjxp55547qqfn	cmqep6t7x00etjxp5oklc37y3	cmqep6t9300hnjxp5ojniwclr	5	completed	2026-06-26 09:26:13.778	2026-07-03 09:35:46.622	2026-07-03 09:35:42.556	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:35:46.623
cmqep6taj00spjxp52tkl75k5	cmqep6t7y00hbjxp5na2uvdzn	cmqep6t9500k5jxp5jdi00gvp	2	completed	2026-06-26 09:02:57.01	2026-06-26 09:06:06.425	2026-06-26 09:05:28.034	cmq0khs5m000wjx23jyhqhgkv	เพิ่มความตั้งใจในสิ่งที่อยากทำให้สำเร็จ	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:06:06.426
cmqep6tai00rdjxp5i0oqdhai	cmqep6t7y00gwjxp50vs32gfn	cmqep6t9500jqjxp55fr44i9j	2	completed	2026-06-19 13:19:06.472	2026-06-26 09:08:20.027	2026-06-26 09:07:36.797	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:08:20.027
cmqep6tae00kljxp5bna5lssm	cmqep6t7x00etjxp5oklc37y3	cmqep6t9300hnjxp5ojniwclr	1	completed	2026-06-15 04:13:05.592	2026-06-26 09:13:23.967	2026-06-26 09:13:22.612	cmq0kyw85007kjx239k25z1ge	\N	ไม่มีความมั่นใจเวลาพูด	ด้านการเรียน	internal	2026-06-26 09:14:25.397	2026-06-15 04:13:05.602	2026-06-26 09:14:25.398
cmqep6taf00lyjxp5a8sswzzg	cmqep6t7x00f7jxp5l3oii2qb	cmqep6t9300i1jxp596rewf7k	5	completed	2026-06-26 09:23:28.359	2026-07-03 09:38:33.235	2026-07-03 09:38:31.931	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:38:33.236
cmqep6tae00l8jxp5b07r9x0d	cmqep6t7x00f0jxp5gvfwi04n	cmqep6t9300hujxp557oed88p	2	completed	2026-06-26 09:13:10.964	2026-06-26 09:17:59.452	2026-06-26 09:16:12.805	cmq0kyw85007kjx239k25z1ge	ต้องการพัฒนาเรื่องการเรียน	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:17:59.453
cmqf02tx9006fjxopodj5wt87	cmqf02twi005vjxoph6si1y7m	cmqf02twx0064jxops0zutopk	3	completed	2026-06-26 08:59:59.2	2026-07-03 09:50:30.687	2026-07-03 09:50:29.209	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 09:17:55.581	2026-07-03 09:50:30.688
cmqep6tag00mbjxp5thy3ikfq	cmqep6t7x00fdjxp5phrwrenn	cmqep6t9300i7jxp5czcjfas0	1	completed	2026-06-15 04:13:05.592	2026-06-26 09:19:22.456	2026-06-26 09:19:16.042	cmq0khs5m000wjx23jyhqhgkv	\N	ขาดความมั่นใจในตัวเอง	ไม่มี	internal	2026-06-26 09:20:19.996	2026-06-15 04:13:05.602	2026-06-26 09:20:19.997
cmqep6taf00lejxp5jgsi4pad	cmqep6t7x00f2jxp5sh03nooy	cmqep6t9300hwjxp5k2345ah9	2	completed	2026-06-26 09:17:46.974	2026-06-26 09:22:05.825	2026-06-26 09:22:04.881	cmq0kyw85007kjx239k25z1ge	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:22:05.826
cmqep6taf00lljxp542gk4j6j	cmqep6t7x00f4jxp5ifdridnj	cmqep6t9300hyjxp5dd1qz18y	1	completed	2026-06-15 04:13:05.592	2026-06-26 09:25:52.451	2026-06-26 09:25:43.97	cmq0kyw85007kjx239k25z1ge	\N	ไม่มั่นใจในศักยภาพของตัวเอง	ปัญหาด้านครอบครัว	internal	2026-06-26 09:26:18.05	2026-06-15 04:13:05.602	2026-06-26 09:26:18.05
cmqep6tae00krjxp5vypyf6yf	cmqep6t7x00evjxp5vhoesa20	cmqep6t9300hpjxp5m0ic3656	1	completed	2026-06-15 04:13:05.592	2026-06-26 09:25:25.573	2026-06-26 09:25:16.35	cmq0khs5m000wjx23jyhqhgkv	\N	ขาดความมั่นใจในตัวเอง	ไม่มี	internal	2026-06-26 09:26:39.348	2026-06-15 04:13:05.602	2026-06-26 09:26:39.349
cmqep6taf00m3jxp5qzt1lfcc	cmqep6t7x00f9jxp5wi3o0rdy	cmqep6t9300i3jxp5puoo5th4	2	completed	2026-06-26 09:24:56.056	2026-06-26 09:27:31.473	2026-06-26 09:27:29.642	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:27:31.474
cmqep6taf00lsjxp57evc17m2	cmqep6t7x00f6jxp5ryay9b35	cmqep6t9300i0jxp58q6bdjuy	1	completed	2026-06-15 04:13:05.592	2026-06-26 09:29:47.66	2026-06-26 09:29:44.687	cmq0kyw85007kjx239k25z1ge	\N	ไม่มั่นใจในรูปร่างของตัวเอง	ปัญหาด้ายครอบครัว	internal	2026-06-26 09:31:05.06	2026-06-15 04:13:05.602	2026-06-26 09:31:05.061
cmqep6tae00kjjxp5vi4bc7k3	cmqep6t7x00esjxp5cbdmqqex	cmqep6t9300hmjxp57kf2hh40	2	completed	2026-06-26 09:30:19.432	2026-06-26 09:31:36.614	2026-06-26 09:31:34.421	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:31:36.615
cmqep6tae00l2jxp5j96lsa0u	cmqep6t7x00eyjxp55zwq78jl	cmqep6t9300hsjxp5mqoxbs0l	2	completed	2026-06-26 09:30:50.847	2026-06-26 09:32:55.291	2026-06-26 09:32:52.99	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:32:55.292
cmqep6taf00m9jxp57z2zn6f0	cmqep6t7x00fcjxp5slrtarvk	cmqep6t9300i6jxp5titg9cgh	2	completed	2026-06-26 09:32:33.688	2026-06-26 09:33:35.09	2026-06-26 09:33:28.025	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:33:35.09
cmqep6taf00ltjxp51jfefb7g	cmqep6t7x00f6jxp5ryay9b35	cmqep6t9300i0jxp58q6bdjuy	2	completed	2026-06-26 09:29:47.665	2026-06-26 09:35:07.281	2026-06-26 09:32:12.312	cmq0kyw85007kjx239k25z1ge	เห็นคุณค่าในตัวเองมากขึ้น	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:35:07.283
cmqep6taf00m6jxp5las1v0s5	cmqep6t7x00fbjxp5c1fz5ppe	cmqep6t9300i5jxp543jcx65k	2	completed	2026-06-26 09:34:11.734	2026-06-26 09:36:12.313	2026-06-26 09:36:08.027	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:36:12.314
cmqep6tah00oajxp5198ghjny	cmqep6t7x00fyjxp5gd0tiz6q	cmqep6t9400isjxp5q3gysgu2	2	completed	2026-06-19 13:39:16.127	2026-06-26 09:35:21.302	2026-06-26 09:35:20.159	cmq0kwit80066jx23pw930nx1	เห็นคุณค่าในตัวเอง	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:35:21.303
cmr254jpo00i3jxcterqw1ike	cmr254jj6001rjxctwo94bb0e	cmr254jmt009ojxctx9sifif9	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpo00i4jxctmvvt41kk	cmr254jj6001rjxctwo94bb0e	cmr254jmt009ojxctx9sifif9	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6tag00myjxp5c2o430fo	cmqep6t7x00fjjxp51to2rjq7	cmqep6t9400idjxp53hqq2voi	2	completed	2026-06-19 13:39:32.357	2026-06-26 09:39:02.793	2026-06-26 09:39:01.513	cmq0kwit80066jx23pw930nx1	เสริมกำลังให้เห็นคุณค่าในตัวเองโดยเริ่มจากคุณค่าเล็กๆ	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:39:02.794
cmr254jpo00i5jxct25fiqbkh	cmr254jj6001rjxctwo94bb0e	cmr254jmt009ojxctx9sifif9	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6tad00kgjxp5qt9lei1v	cmqep6t7x00erjxp54fnk3xqy	cmqep6t9300hljxp5tig3rlk1	2	completed	2026-06-26 09:37:46.742	2026-06-26 09:41:04.486	2026-06-26 09:41:03.029	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:41:04.487
cmr254jpp00i6jxct1llhlsi8	cmr254jj6001sjxctbrd5u4o4	cmr254jmt009pjxcttz5swkwp	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00i7jxctq059pv3u	cmr254jj6001sjxctbrd5u4o4	cmr254jmt009pjxcttz5swkwp	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00i8jxct7u3r6r1c	cmr254jj6001sjxctbrd5u4o4	cmr254jmt009pjxcttz5swkwp	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00i9jxct2ppzfyn5	cmr254jj6001tjxct70n7ucdd	cmr254jmt009qjxctdzu33z7h	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00iajxctymy01443	cmr254jj6001tjxct70n7ucdd	cmr254jmt009qjxctdzu33z7h	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00ibjxctg6zojncd	cmr254jj6001tjxct70n7ucdd	cmr254jmt009qjxctdzu33z7h	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00icjxctpg5dm0mr	cmr254jj6001ujxctg4rj6nid	cmr254jmt009rjxctwvz10alt	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00idjxctda3val4l	cmr254jj6001ujxctg4rj6nid	cmr254jmt009rjxctwvz10alt	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00iejxctdhy08pv3	cmr254jj6001ujxctg4rj6nid	cmr254jmt009rjxctwvz10alt	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00ifjxct3v9va24t	cmr254jj6001vjxctb0xb16xc	cmr254jmt009sjxctcrwx5g39	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00igjxcta2qrlejb	cmr254jj6001vjxctb0xb16xc	cmr254jmt009sjxctcrwx5g39	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00ihjxctlw5a7bzo	cmr254jj6001vjxctb0xb16xc	cmr254jmt009sjxctcrwx5g39	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00iijxctj4815lf8	cmr254jj6001wjxctpjg6xpx8	cmr254jmt009tjxct0jrx2brb	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00ijjxctuxvcb97s	cmr254jj6001wjxctpjg6xpx8	cmr254jmt009tjxct0jrx2brb	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00ikjxct4zolzqka	cmr254jj6001wjxctpjg6xpx8	cmr254jmt009tjxct0jrx2brb	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00iljxctb0yjfzrn	cmr254jj6001xjxctxl5hi4td	cmr254jmt009ujxctaheswmws	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00imjxct69u9kz5b	cmr254jj6001xjxctxl5hi4td	cmr254jmt009ujxctaheswmws	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00injxct05i5z5xp	cmr254jj6001xjxctxl5hi4td	cmr254jmt009ujxctaheswmws	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00iojxct31ibys0a	cmr254jj6001yjxctpb8vh5gl	cmr254jmt009vjxct8ef9246q	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00ipjxct9cie4hlu	cmr254jj6001yjxctpb8vh5gl	cmr254jmt009vjxct8ef9246q	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00iqjxctr4t2zs2c	cmr254jj6001yjxctpb8vh5gl	cmr254jmt009vjxct8ef9246q	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00irjxctfwb0nhxw	cmr254jj6001zjxcty6l1f2m2	cmr254jmt009wjxctjz6kds6l	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00isjxcti2gdvh6q	cmr254jj6001zjxcty6l1f2m2	cmr254jmt009wjxctjz6kds6l	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00itjxctfb7llz0o	cmr254jj6001zjxcty6l1f2m2	cmr254jmt009wjxctjz6kds6l	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00iujxct942vsf3t	cmr254jj60020jxctuhdrxbok	cmr254jmt009xjxctmqpw5w52	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00ivjxctgx7lmp82	cmr254jj60020jxctuhdrxbok	cmr254jmt009xjxctmqpw5w52	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00iwjxctmwsogocf	cmr254jj60020jxctuhdrxbok	cmr254jmt009xjxctmqpw5w52	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00ixjxct2vh40wwv	cmr254jj60021jxct8e2jqy0p	cmr254jmt009yjxct0mxolg4s	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00iyjxct9x179ieh	cmr254jj60021jxct8e2jqy0p	cmr254jmt009yjxct0mxolg4s	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00izjxct9r2m068u	cmr254jj60021jxct8e2jqy0p	cmr254jmt009yjxct0mxolg4s	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00j0jxctdpxuumr4	cmr254jj60022jxctn4iispfx	cmr254jmt009zjxctvk0zsx7m	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00j1jxctzjpvz6uq	cmr254jj60022jxctn4iispfx	cmr254jmt009zjxctvk0zsx7m	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00j2jxct03w2ois3	cmr254jj60022jxctn4iispfx	cmr254jmt009zjxctvk0zsx7m	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00j3jxct8je5zj4y	cmr254jj60023jxctwd7irxur	cmr254jmt00a0jxctfj09azgd	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00j4jxctxq4uwp4v	cmr254jj60023jxctwd7irxur	cmr254jmt00a0jxctfj09azgd	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00j5jxctq16hz1c3	cmr254jj60023jxctwd7irxur	cmr254jmt00a0jxctfj09azgd	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00j6jxctwybiugr9	cmr254jj60024jxct0np4tbk8	cmr254jmt00a1jxctt2rlnjq0	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00j7jxctalnxbodb	cmr254jj60024jxct0np4tbk8	cmr254jmt00a1jxctt2rlnjq0	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00j8jxctpl4kbenx	cmr254jj60024jxct0np4tbk8	cmr254jmt00a1jxctt2rlnjq0	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00j9jxcthuj5wyd5	cmr254jj60025jxct741n3p4j	cmr254jmt00a2jxct3hh7wi53	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00jajxcthnf4lj5h	cmr254jj60025jxct741n3p4j	cmr254jmt00a2jxct3hh7wi53	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00jbjxctig9dw2jc	cmr254jj60025jxct741n3p4j	cmr254jmt00a2jxct3hh7wi53	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00jcjxctsd3dvhi3	cmr254jj60026jxctqe54xgl5	cmr254jmt00a3jxctopm1x5vv	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00jdjxctn1fepl63	cmr254jj60026jxctqe54xgl5	cmr254jmt00a3jxctopm1x5vv	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00jejxctq23ymt2v	cmr254jj60026jxctqe54xgl5	cmr254jmt00a3jxctopm1x5vv	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00jfjxctefhab50s	cmr254jj60027jxct36hjoqdt	cmr254jmt00a4jxctlm17vquv	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00jgjxctwnwbekry	cmr254jj60027jxct36hjoqdt	cmr254jmt00a4jxctlm17vquv	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00jhjxctt9ovtams	cmr254jj60027jxct36hjoqdt	cmr254jmt00a4jxctlm17vquv	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6tah00o1jxp5dfoplbbl	cmqep6t7x00fvjxp5jwtduygo	cmqep6t9400ipjxp5mi3lxvqs	2	completed	2026-06-19 13:38:30.204	2026-06-26 09:38:52.503	2026-06-26 09:38:50.85	cmq0kwit80066jx23pw930nx1	นัดหมายเรื่องการปฏิบัติตัวในโรงเรียนและนอกโรงเรียน	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:38:52.503
cmr254jpp00jijxct0e3nqydb	cmr254jj60028jxcty4paqbmo	cmr254jmt00a5jxctxing5e1t	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00jjjxcth2rbacy4	cmr254jj60028jxcty4paqbmo	cmr254jmt00a5jxctxing5e1t	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00jkjxct8d57rozo	cmr254jj60028jxcty4paqbmo	cmr254jmt00a5jxctxing5e1t	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00jljxctzwaqbzwh	cmr254jj60029jxct05or0ma1	cmr254jmt00a6jxct0w05vpy6	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00jmjxctep17ooom	cmr254jj60029jxct05or0ma1	cmr254jmt00a6jxct0w05vpy6	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00jnjxcttlfflr66	cmr254jj60029jxct05or0ma1	cmr254jmt00a6jxct0w05vpy6	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00jojxctd2li9qed	cmr254jj6002ajxct2ybkqca0	cmr254jmt00a7jxcti4rc9aha	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00jpjxctg7ncs0ce	cmr254jj6002ajxct2ybkqca0	cmr254jmt00a7jxcti4rc9aha	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00jqjxct5813jh55	cmr254jj6002ajxct2ybkqca0	cmr254jmt00a7jxcti4rc9aha	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00jrjxctfaclmjb9	cmr254jj6002bjxctnbqb8fw7	cmr254jmt00a8jxctr2bhz0sg	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00jsjxcth9he3f04	cmr254jj6002bjxctnbqb8fw7	cmr254jmt00a8jxctr2bhz0sg	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00jtjxctneix955i	cmr254jj6002bjxctnbqb8fw7	cmr254jmt00a8jxctr2bhz0sg	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00jujxctezq8kgwy	cmr254jj6002cjxctg6t5rr8z	cmr254jmt00a9jxctulvf0alf	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00jvjxctw1jszff0	cmr254jj6002cjxctg6t5rr8z	cmr254jmt00a9jxctulvf0alf	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00jwjxct4uef6uoq	cmr254jj6002cjxctg6t5rr8z	cmr254jmt00a9jxctulvf0alf	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00jxjxctskr34tta	cmr254jj6002djxctpng681vy	cmr254jmt00aajxctwjtcifb5	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00jyjxct381iq4hr	cmr254jj6002djxctpng681vy	cmr254jmt00aajxctwjtcifb5	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00jzjxct4195584x	cmr254jj6002djxctpng681vy	cmr254jmt00aajxctwjtcifb5	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00k0jxctors2nqll	cmr254jj7002ejxctdh6ru24c	cmr254jmt00abjxctt00w8et8	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00k1jxctzeia8iqd	cmr254jj7002ejxctdh6ru24c	cmr254jmt00abjxctt00w8et8	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00k2jxct9ai4ts20	cmr254jj7002ejxctdh6ru24c	cmr254jmt00abjxctt00w8et8	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00k3jxctxi2bbwqj	cmr254jj7002fjxct0wnn4y6u	cmr254jmt00acjxctg815i8ah	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00k4jxctpyg4zhf2	cmr254jj7002fjxct0wnn4y6u	cmr254jmt00acjxctg815i8ah	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00k5jxctdzkwuadx	cmr254jj7002fjxct0wnn4y6u	cmr254jmt00acjxctg815i8ah	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00k6jxctw37vw3so	cmr254jj7002gjxct30bu8lbq	cmr254jmt00adjxct7cwvd6r4	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00k7jxct7khdju05	cmr254jj7002gjxct30bu8lbq	cmr254jmt00adjxct7cwvd6r4	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00k8jxct1s69xy5i	cmr254jj7002gjxct30bu8lbq	cmr254jmt00adjxct7cwvd6r4	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00k9jxctm0ktluso	cmr254jj7002hjxctj2eqtt02	cmr254jmt00aejxctr8eoeoqh	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00kajxct9x4kd9mu	cmr254jj7002hjxctj2eqtt02	cmr254jmt00aejxctr8eoeoqh	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00kbjxctmwbvk72h	cmr254jj7002hjxctj2eqtt02	cmr254jmt00aejxctr8eoeoqh	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00kcjxct3pe9vb31	cmr254jj7002ijxctpfcaqnao	cmr254jmu00afjxct0igrn0oz	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00kdjxctns9i6gvz	cmr254jj7002ijxctpfcaqnao	cmr254jmu00afjxct0igrn0oz	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00kejxctbobjhd8q	cmr254jj7002ijxctpfcaqnao	cmr254jmu00afjxct0igrn0oz	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00kfjxctx44hy1zo	cmr254jj7002jjxctlupbi8w4	cmr254jmu00agjxcteo9mmf5w	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpp00kgjxctv6ko778i	cmr254jj7002jjxctlupbi8w4	cmr254jmu00agjxcteo9mmf5w	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00khjxctrsk29sv8	cmr254jj7002jjxctlupbi8w4	cmr254jmu00agjxcteo9mmf5w	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00kijxct886snsfo	cmr254jj7002kjxctnzyfru1y	cmr254jmu00ahjxct5cvgm0ut	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00kjjxctkxgzj18a	cmr254jj7002kjxctnzyfru1y	cmr254jmu00ahjxct5cvgm0ut	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00kkjxct9oy7i7ke	cmr254jj7002kjxctnzyfru1y	cmr254jmu00ahjxct5cvgm0ut	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00kljxctrvy6cknx	cmr254jj7002ljxct56w0r9pl	cmr254jmu00aijxct2ijc6utz	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00kmjxctqgscm5cp	cmr254jj7002ljxct56w0r9pl	cmr254jmu00aijxct2ijc6utz	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00knjxctfl16mvff	cmr254jj7002ljxct56w0r9pl	cmr254jmu00aijxct2ijc6utz	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00kojxctwy1jli3s	cmr254jj7002mjxctz289p462	cmr254jmu00ajjxct1y56rsvo	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00kpjxct7vxc7uwm	cmr254jj7002mjxctz289p462	cmr254jmu00ajjxct1y56rsvo	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00kqjxct6tdurwy6	cmr254jj7002mjxctz289p462	cmr254jmu00ajjxct1y56rsvo	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00krjxctzvquqb0x	cmr254jj7002njxctw03m3kv0	cmr254jmu00akjxct1xyx0qcn	1	in_progress	2026-07-01 13:57:55.769	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00ksjxct5br60po3	cmr254jj7002njxctw03m3kv0	cmr254jmu00akjxct1xyx0qcn	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00ktjxctxw8aaytq	cmr254jj7002njxctw03m3kv0	cmr254jmu00akjxct1xyx0qcn	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00kujxctfuxjs26g	cmr254jj7002ojxct7oqv16mz	cmr254jmu00aljxctbh82ouk1	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00kvjxctsacyl4bc	cmr254jj7002ojxct7oqv16mz	cmr254jmu00aljxctbh82ouk1	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00kwjxctc645n5b9	cmr254jj7002ojxct7oqv16mz	cmr254jmu00aljxctbh82ouk1	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00kxjxctp2wypemt	cmr254jj7002pjxctyevwpk8i	cmr254jmu00amjxct3jn0clek	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00kyjxct896tbmse	cmr254jj7002pjxctyevwpk8i	cmr254jmu00amjxct3jn0clek	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00kzjxctst0gb270	cmr254jj7002pjxctyevwpk8i	cmr254jmu00amjxct3jn0clek	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6tah00ofjxp58keolg9h	cmqep6t7x00fzjxp54fjcjtah	cmqep6t9400itjxp58wqnqblq	2	completed	2026-06-19 13:38:36.059	2026-06-26 09:36:54.71	2026-06-26 09:36:36.968	cmq0kwit80066jx23pw930nx1	เห็นคุณค่าในตัวเอง มองโลกในแง่ดี	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:36:54.711
cmr254jpq00l0jxctmv87q42j	cmr254jj7002qjxctxjyisl8l	cmr254jmu00anjxctgi7jx7fl	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6tag00najxp5pa0647l0	cmqep6t7x00fnjxp5bqhzrp6l	cmqep6t9400ihjxp5z57lkkn2	2	completed	2026-06-19 13:44:10.623	2026-06-26 09:41:03.03	2026-06-26 09:40:49.251	cmq0kwit80066jx23pw930nx1	มีความมุ่งมั่นเวลาทำอะไร มีพลังใจ	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:41:03.03
cmr254jpq00l1jxctavb3lhyp	cmr254jj7002qjxctxjyisl8l	cmr254jmu00anjxctgi7jx7fl	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6tah00ozjxp5xbuex5h1	cmqep6t7y00g5jxp53scmw13t	cmqep6t9400izjxp5kkrzband	2	completed	2026-06-19 13:39:09.42	2026-06-26 09:42:05.42	2026-06-26 09:42:03.631	cmq0kwit80066jx23pw930nx1	ทบทวนคุณค่าของตัวเองด้านบวกเพื่อเสริมกำลังใจ	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:42:05.421
cmqep6tag00nqjxp5v71nwxj5	cmqep6t7x00fsjxp5s3lf3hkn	cmqep6t9400imjxp523k3l27b	2	completed	2026-06-19 13:44:10.717	2026-06-26 09:42:26.944	2026-06-26 09:42:08.627	cmq0kwit80066jx23pw930nx1	ฝึกความใจเย็น เสริมสร้างพลังใจ	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:42:26.945
cmqep6tah00o6jxp5yx9g0xv0	cmqep6t7x00fwjxp5he7659eh	cmqep6t9400iqjxp5ray5vlwm	2	completed	2026-06-19 13:31:24.245	2026-06-26 09:44:24.42	2026-06-26 09:44:23.158	cmq0kwit80066jx23pw930nx1	ฝึกมีความใจเย็นมากขึ้น ค้นหาคุณค่าในตัวเอง	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:44:24.42
cmr254jpq00l2jxct8rdryzw7	cmr254jj7002qjxctxjyisl8l	cmr254jmu00anjxctgi7jx7fl	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00l3jxctdhgoq4eq	cmr254jj7002rjxctanv8gs8c	cmr254jmu00aojxct96s3nctx	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6taf00lqjxp53hm8u98g	cmqep6t7x00f5jxp5kn6gv1ni	cmqep6t9300hzjxp5z36ifwwm	2	completed	2026-06-26 09:42:27.917	2026-06-26 09:46:27.356	2026-06-26 09:45:57.751	cmq0kyw85007kjx239k25z1ge	เห็นคุณค่าในตัวเองมากพอ	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:46:27.357
cmqep6tae00kojxp5rruxzuod	cmqep6t7x00eujxp5wceys9yo	cmqep6t9300hojxp5466nswgb	1	completed	2026-06-15 04:13:05.592	2026-06-26 09:45:12.688	2026-06-26 09:45:09.402	cmq0kyw85007kjx239k25z1ge	\N	ไม่มั่นใจในรูปร่างของตัวเอง	ปัญหาด้านครอบครัว	internal	2026-06-26 09:47:55.128	2026-06-15 04:13:05.602	2026-06-26 09:47:55.129
cmqep6tag00nfjxp5lqmchcea	cmqep6t7x00fpjxp5afe8hyp4	cmqep6t9400ijjxp59w5gpf1i	2	completed	2026-06-19 13:33:47.151	2026-06-26 09:48:04.961	2026-06-26 09:47:45.075	cmq0kwit80066jx23pw930nx1	มองโลกในแง่ดี มีความมั่นใจ	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:48:04.961
cmqep6tag00n4jxp5jd0wajfn	cmqep6t7x00fkjxp5dokcsihq	cmqep6t9400iejxp54gkhmb1r	3	in_progress	2026-06-26 09:49:01.257	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:49:01.258
cmr254jpq00l4jxctafhs6afk	cmr254jj7002rjxctanv8gs8c	cmr254jmu00aojxct96s3nctx	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00l5jxct8zvaz9i4	cmr254jj7002rjxctanv8gs8c	cmr254jmu00aojxct96s3nctx	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00l6jxctvijqfax3	cmr254jj7002sjxctktxnj5fz	cmr254jmu00apjxct3sqn1bhr	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6tae00kpjxp5plx2tggc	cmqep6t7x00eujxp5wceys9yo	cmqep6t9300hojxp5466nswgb	2	completed	2026-06-26 09:45:12.695	2026-06-26 09:50:52.061	2026-06-26 09:49:34.203	cmq0kyw85007kjx239k25z1ge	มีความมั่นใจและเห็นคุณค่าของตัวเองมากขึ้น	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:50:52.062
cmr254jpq00l7jxctiimng8a8	cmr254jj7002sjxctktxnj5fz	cmr254jmu00apjxct3sqn1bhr	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6tag00mgjxp5x2a4woek	cmqep6t7x00fejxp5o7dl7di4	cmqep6t9400i8jxp575ybjipq	2	completed	2026-06-19 13:23:48.458	2026-06-26 09:52:55.372	2026-06-26 09:52:53.92	cmq0kwit80066jx23pw930nx1	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:52:55.373
cmr254jpq00l8jxctj5lg4ibx	cmr254jj7002sjxctktxnj5fz	cmr254jmu00apjxct3sqn1bhr	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6taf00m0jxp5h51gbmg2	cmqep6t7x00f8jxp55qj3x2vc	cmqep6t9300i2jxp5qo3m1pbo	2	completed	2026-06-26 09:49:50.922	2026-06-26 09:53:25.161	2026-06-26 09:52:32.618	cmq0kyw85007kjx239k25z1ge	เห็นคุณค่าในตัวเองสูง	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:53:25.162
cmr254jpq00l9jxctc9g4g1w0	cmr254jj7002tjxctms5epztx	cmr254jmu00aqjxctpjpmssrg	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00lajxcte2rbv3p7	cmr254jj7002tjxctms5epztx	cmr254jmu00aqjxctpjpmssrg	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6taf00ljjxp5kxia7ix5	cmqep6t7x00f3jxp5synf5gsg	cmqep6t9300hxjxp5p4kf2gyr	2	completed	2026-06-26 09:53:44.28	2026-06-26 09:55:26.062	2026-06-26 09:55:24.247	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:55:26.063
cmr254jpq00lbjxctk9zo3ya5	cmr254jj7002tjxctms5epztx	cmr254jmu00aqjxctpjpmssrg	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6tah00otjxp5nwykt18t	cmqep6t7y00g3jxp5y3q080vj	cmqep6t9400ixjxp5vstdjxdp	2	completed	2026-06-19 13:29:31.395	2026-06-26 09:56:18	2026-06-26 09:56:16.973	cmq0kwit80066jx23pw930nx1	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:56:18.001
cmr254jpq00lcjxctysjnimda	cmr254jj7002ujxct3xaeidb6	cmr254jmu00arjxctur6gcwzl	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6tag00nnjxp5bcu5m5pt	cmqep6t7x00frjxp5y0vdu581	cmqep6t9400iljxp56hadyq5z	2	completed	2026-06-19 13:27:32.309	2026-06-26 09:57:10.918	2026-06-26 09:55:59.459	cmq0kyw85007kjx239k25z1ge	มีความมั่นใจในตัวเองสูง	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:57:10.919
cmqep6tag00n7jxp5vo5e30br	cmqep6t7x00fljxp5cyty19cb	cmqep6t9400ifjxp53w1mo3fo	2	completed	2026-06-19 13:26:11.979	2026-06-26 09:58:04.979	2026-06-26 09:57:26.853	cmq0kyw85007kjx239k25z1ge	ไม่กล้าพูดไม่มั่นใจในตัวเอง	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-06-26 09:58:04.98
cmr254jpq00ldjxctf4237qts	cmr254jj7002ujxct3xaeidb6	cmr254jmu00arjxctur6gcwzl	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00lejxct1m9criab	cmr254jj7002ujxct3xaeidb6	cmr254jmu00arjxctur6gcwzl	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00lfjxct5nlutnkj	cmr254jj7002vjxctop3e7v09	cmr254jmu00asjxct954uz7vx	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00lgjxctl6k79ni0	cmr254jj7002vjxctop3e7v09	cmr254jmu00asjxct954uz7vx	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00lhjxctcxfg35wm	cmr254jj7002vjxctop3e7v09	cmr254jmu00asjxct954uz7vx	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00lijxct5ltcrnc7	cmr254jj7002wjxctfyr3g1vg	cmr254jmu00atjxctapewqvj3	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00ljjxctfto9tx5r	cmr254jj7002wjxctfyr3g1vg	cmr254jmu00atjxctapewqvj3	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00lkjxctvtl5v3v2	cmr254jj7002wjxctfyr3g1vg	cmr254jmu00atjxctapewqvj3	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00lljxct2rsgk0l3	cmr254jj7002xjxctn1uw6a80	cmr254jmu00aujxctskst0rqz	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00lmjxctwu1pm4ic	cmr254jj7002xjxctn1uw6a80	cmr254jmu00aujxctskst0rqz	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00lnjxctaoo3jzcy	cmr254jj7002xjxctn1uw6a80	cmr254jmu00aujxctskst0rqz	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00lojxct7dsb6uss	cmr254jj7002yjxct9nv0lmyk	cmr254jmu00avjxctbgmbqz4r	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00lpjxctzsg4npov	cmr254jj7002yjxct9nv0lmyk	cmr254jmu00avjxctbgmbqz4r	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00lqjxctfgjkhgxz	cmr254jj7002yjxct9nv0lmyk	cmr254jmu00avjxctbgmbqz4r	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00lrjxct7orpgqk0	cmr254jj7002zjxctn6jn7zey	cmr254jmu00awjxctl5k6961l	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00lsjxcthziftsnm	cmr254jj7002zjxctn6jn7zey	cmr254jmu00awjxctl5k6961l	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00ltjxctil1o6qg2	cmr254jj7002zjxctn6jn7zey	cmr254jmu00awjxctl5k6961l	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00lujxct53gki1kr	cmr254jj70030jxct40ofpuia	cmr254jmu00axjxct8vrmutun	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00lvjxctvhxpln5d	cmr254jj70030jxct40ofpuia	cmr254jmu00axjxct8vrmutun	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00lwjxct6eoo98u8	cmr254jj70030jxct40ofpuia	cmr254jmu00axjxct8vrmutun	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00lxjxctgy9qrlv3	cmr254jj70031jxctez0qlkln	cmr254jmu00ayjxctutiirkum	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00lyjxct6mvcxa95	cmr254jj70031jxctez0qlkln	cmr254jmu00ayjxctutiirkum	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00lzjxcttwg16284	cmr254jj70031jxctez0qlkln	cmr254jmu00ayjxctutiirkum	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00m0jxcta0eju652	cmr254jj70032jxctatwgtpr0	cmr254jmu00azjxct14k25r7r	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00m1jxct026pg2lb	cmr254jj70032jxctatwgtpr0	cmr254jmu00azjxct14k25r7r	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00m2jxct82lbse0w	cmr254jj70032jxctatwgtpr0	cmr254jmu00azjxct14k25r7r	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00m3jxctbuixksml	cmr254jj70033jxctclizgpto	cmr254jmu00b0jxctueed0vg9	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00m4jxcta0kjy4ip	cmr254jj70033jxctclizgpto	cmr254jmu00b0jxctueed0vg9	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00m5jxct3eaucqrs	cmr254jj70033jxctclizgpto	cmr254jmu00b0jxctueed0vg9	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00m6jxcteuyr34ol	cmr254jj70034jxct7ndptjf1	cmr254jmu00b1jxctg33gk5nj	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00m7jxctso5lz8j1	cmr254jj70034jxct7ndptjf1	cmr254jmu00b1jxctg33gk5nj	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00m8jxctxny4j48c	cmr254jj70034jxct7ndptjf1	cmr254jmu00b1jxctg33gk5nj	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00m9jxctqpxakr7m	cmr254jj70035jxctoqk9yw3k	cmr254jmu00b2jxcti5ctv35b	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00majxctmezd1lpc	cmr254jj70035jxctoqk9yw3k	cmr254jmu00b2jxcti5ctv35b	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00mbjxctmtxzpb8e	cmr254jj70035jxctoqk9yw3k	cmr254jmu00b2jxcti5ctv35b	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00mcjxctkziyrp77	cmr254jj70036jxctjseudr3n	cmr254jmu00b3jxctm2xkmv69	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00mdjxcthjykduob	cmr254jj70036jxctjseudr3n	cmr254jmu00b3jxctm2xkmv69	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00mejxct09bf2b64	cmr254jj70036jxctjseudr3n	cmr254jmu00b3jxctm2xkmv69	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00mfjxct6y2fjuhk	cmr254jj70037jxctlgbgsobx	cmr254jmu00b4jxctgrbjwuml	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00mgjxctftdo309o	cmr254jj70037jxctlgbgsobx	cmr254jmu00b4jxctgrbjwuml	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00mhjxctlqufe5xl	cmr254jj70037jxctlgbgsobx	cmr254jmu00b4jxctgrbjwuml	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00mijxct11ldlku4	cmr254jj70038jxctjbykzfgb	cmr254jmu00b5jxctrw6bbswq	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00mjjxctxpwo7td7	cmr254jj70038jxctjbykzfgb	cmr254jmu00b5jxctrw6bbswq	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00mkjxctd097pn9t	cmr254jj70038jxctjbykzfgb	cmr254jmu00b5jxctrw6bbswq	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00mljxcty367k2r9	cmr254jj70039jxctczd3obvs	cmr254jmu00b6jxctcu1od8qb	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00mmjxcthjzlk26a	cmr254jj70039jxctczd3obvs	cmr254jmu00b6jxctcu1od8qb	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00mnjxct73jpmb6t	cmr254jj70039jxctczd3obvs	cmr254jmu00b6jxctcu1od8qb	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00mojxctclcylkwa	cmr254jj7003ajxct6d05b5cf	cmr254jmu00b7jxctvmabnkzv	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00mpjxct6xcnfq20	cmr254jj7003ajxct6d05b5cf	cmr254jmu00b7jxctvmabnkzv	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00mqjxctad03izvf	cmr254jj7003ajxct6d05b5cf	cmr254jmu00b7jxctvmabnkzv	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00mrjxctwzrhcdu1	cmr254jj7003bjxctsyxzrora	cmr254jmu00b8jxct0z307ray	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00msjxctyaqm3yx9	cmr254jj7003bjxctsyxzrora	cmr254jmu00b8jxct0z307ray	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00mtjxctmoddfqpj	cmr254jj7003bjxctsyxzrora	cmr254jmu00b8jxct0z307ray	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00mujxcts0kg4q7l	cmr254jj7003cjxctipojt240	cmr254jmu00b9jxcta9k8dc7e	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpq00mvjxctb9ueuutm	cmr254jj7003cjxctipojt240	cmr254jmu00b9jxcta9k8dc7e	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00mwjxcte7ir1cc9	cmr254jj7003cjxctipojt240	cmr254jmu00b9jxcta9k8dc7e	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00mxjxct4ablnzbm	cmr254jj7003djxctqlqpcyzc	cmr254jmu00bajxct86dktnl7	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00myjxct1gxqv261	cmr254jj7003djxctqlqpcyzc	cmr254jmu00bajxct86dktnl7	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00mzjxctu0h8h5ap	cmr254jj7003djxctqlqpcyzc	cmr254jmu00bajxct86dktnl7	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00n0jxctp91b5p3r	cmr254jj7003ejxctr1w3ozma	cmr254jmu00bbjxctukmp812t	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00n1jxcthfyfggct	cmr254jj7003ejxctr1w3ozma	cmr254jmu00bbjxctukmp812t	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00n2jxct7zcdnptm	cmr254jj7003ejxctr1w3ozma	cmr254jmu00bbjxctukmp812t	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00n3jxcteadx94bu	cmr254jj7003fjxctxc8ffa6t	cmr254jmu00bcjxctnm344cgt	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00n4jxctdj0rjix1	cmr254jj7003fjxctxc8ffa6t	cmr254jmu00bcjxctnm344cgt	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00n5jxctmst8mlbk	cmr254jj7003fjxctxc8ffa6t	cmr254jmu00bcjxctnm344cgt	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00n6jxct1pgujv7d	cmr254jj7003gjxctomi8egy6	cmr254jmu00bdjxctcsro24xe	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00n7jxctirlh4sn2	cmr254jj7003gjxctomi8egy6	cmr254jmu00bdjxctcsro24xe	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00n8jxctucagot7v	cmr254jj7003gjxctomi8egy6	cmr254jmu00bdjxctcsro24xe	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00n9jxct9n0qkh76	cmr254jj7003hjxct5gqfx5lx	cmr254jmv00bejxctfcsx5r19	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00najxct8enyboc4	cmr254jj7003hjxct5gqfx5lx	cmr254jmv00bejxctfcsx5r19	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00nbjxct8ms5m3q7	cmr254jj7003hjxct5gqfx5lx	cmr254jmv00bejxctfcsx5r19	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00ncjxct1ftqa1ur	cmr254jj7003ijxctjbh9avxi	cmr254jmv00bfjxctbcra3ahb	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00ndjxct1zswrj4c	cmr254jj7003ijxctjbh9avxi	cmr254jmv00bfjxctbcra3ahb	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00nejxctrxz1sj2k	cmr254jj7003ijxctjbh9avxi	cmr254jmv00bfjxctbcra3ahb	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00nfjxctrv92p7yg	cmr254jj8003jjxctz8xdvrl3	cmr254jmv00bgjxctzumco5qw	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00ngjxctohkbgunc	cmr254jj8003jjxctz8xdvrl3	cmr254jmv00bgjxctzumco5qw	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00nhjxctks723z2t	cmr254jj8003jjxctz8xdvrl3	cmr254jmv00bgjxctzumco5qw	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00nijxctlg2s3mhw	cmr254jj8003kjxctrdrhhw0v	cmr254jmv00bhjxcte7rc63ei	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00njjxct27dx2nqb	cmr254jj8003kjxctrdrhhw0v	cmr254jmv00bhjxcte7rc63ei	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00nkjxctg5tf67wg	cmr254jj8003kjxctrdrhhw0v	cmr254jmv00bhjxcte7rc63ei	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00nljxctnwszz18a	cmr254jj8003ljxctn2m88vr9	cmr254jmv00bijxctd0x96qt0	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00nmjxctkenbv2es	cmr254jj8003ljxctn2m88vr9	cmr254jmv00bijxctd0x96qt0	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00nnjxct065rrpig	cmr254jj8003ljxctn2m88vr9	cmr254jmv00bijxctd0x96qt0	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00nojxct4p4db8zj	cmr254jj8003mjxctjqsm5fml	cmr254jmv00bjjxct58emkweb	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00npjxctqekbs54i	cmr254jj8003mjxctjqsm5fml	cmr254jmv00bjjxct58emkweb	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00nqjxctxd9bouhg	cmr254jj8003mjxctjqsm5fml	cmr254jmv00bjjxct58emkweb	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00nrjxctq3u4x9ex	cmr254jj8003njxct1yfejuff	cmr254jmv00bkjxct1a6f2pp3	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00nsjxct4lee9fj8	cmr254jj8003njxct1yfejuff	cmr254jmv00bkjxct1a6f2pp3	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00ntjxctjjwvyj63	cmr254jj8003njxct1yfejuff	cmr254jmv00bkjxct1a6f2pp3	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00nujxct69egogdg	cmr254jj8003ojxctgovae9fb	cmr254jmv00bljxctxnvqvf49	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00nvjxcteftgj4s0	cmr254jj8003ojxctgovae9fb	cmr254jmv00bljxctxnvqvf49	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00nwjxct5xyuxg74	cmr254jj8003ojxctgovae9fb	cmr254jmv00bljxctxnvqvf49	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00nxjxctgavr4bth	cmr254jj8003pjxct8rwa06d9	cmr254jmv00bmjxctzks1kltl	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00nyjxctej0xyrl1	cmr254jj8003pjxct8rwa06d9	cmr254jmv00bmjxctzks1kltl	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00nzjxctw6qgijgt	cmr254jj8003pjxct8rwa06d9	cmr254jmv00bmjxctzks1kltl	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00o0jxctxr0febgu	cmr254jj8003qjxctfrbnb19r	cmr254jmv00bnjxct48dar3ea	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00o1jxctlwkmgqmm	cmr254jj8003qjxctfrbnb19r	cmr254jmv00bnjxct48dar3ea	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00o2jxcthm60n2d9	cmr254jj8003qjxctfrbnb19r	cmr254jmv00bnjxct48dar3ea	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00o3jxctob1mmu8t	cmr254jj8003rjxctxia500wk	cmr254jmv00bojxct91gzs8lo	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00o4jxct2bfewr8t	cmr254jj8003rjxctxia500wk	cmr254jmv00bojxct91gzs8lo	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00o5jxct4bps2cyi	cmr254jj8003rjxctxia500wk	cmr254jmv00bojxct91gzs8lo	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00o6jxctdaujvil6	cmr254jj8003sjxctz75d4m0f	cmr254jmv00bpjxcto1wdnwpa	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00o7jxct1qrhvqxy	cmr254jj8003sjxctz75d4m0f	cmr254jmv00bpjxcto1wdnwpa	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00o8jxctm0nmr2n2	cmr254jj8003sjxctz75d4m0f	cmr254jmv00bpjxcto1wdnwpa	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00o9jxctqil0efll	cmr254jj8003tjxctpex96m2r	cmr254jmv00bqjxcta881eagb	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00oajxctvrld8una	cmr254jj8003tjxctpex96m2r	cmr254jmv00bqjxcta881eagb	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00objxctq1ga1r06	cmr254jj8003tjxctpex96m2r	cmr254jmv00bqjxcta881eagb	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00ocjxctil8hj8c8	cmr254jj8003ujxctotiq1zwy	cmr254jmv00brjxctiwhoko9s	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00odjxctwkq2wafr	cmr254jj8003ujxctotiq1zwy	cmr254jmv00brjxctiwhoko9s	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00oejxctax8g06au	cmr254jj8003ujxctotiq1zwy	cmr254jmv00brjxctiwhoko9s	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00ofjxct7uqtabor	cmr254jj8003vjxctkj6m9wt8	cmr254jmv00bsjxct9ungalmy	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00ogjxctikk8cdsq	cmr254jj8003vjxctkj6m9wt8	cmr254jmv00bsjxct9ungalmy	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00ohjxctw2dujl7j	cmr254jj8003vjxctkj6m9wt8	cmr254jmv00bsjxct9ungalmy	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00oijxct4hw598de	cmr254jj8003wjxct4scxdfcj	cmr254jmv00btjxcts4336i7s	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00ojjxctcfa7qx2p	cmr254jj8003wjxct4scxdfcj	cmr254jmv00btjxcts4336i7s	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00okjxctbull2w4h	cmr254jj8003wjxct4scxdfcj	cmr254jmv00btjxcts4336i7s	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00oljxctq7q52kx4	cmr254jj8003xjxct0kzvzjli	cmr254jmv00bujxct7wgapql8	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00omjxcth58ofj11	cmr254jj8003xjxct0kzvzjli	cmr254jmv00bujxct7wgapql8	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00onjxct6irjdn5l	cmr254jj8003xjxct0kzvzjli	cmr254jmv00bujxct7wgapql8	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00oojxct7j7g5j3l	cmr254jj8003yjxctgb8nm2ik	cmr254jmv00bvjxctnab2sqoc	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00opjxctnsihza7a	cmr254jj8003yjxctgb8nm2ik	cmr254jmv00bvjxctnab2sqoc	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00oqjxctkfflqalz	cmr254jj8003yjxctgb8nm2ik	cmr254jmv00bvjxctnab2sqoc	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00orjxctjmwy1qtg	cmr254jj8003zjxctgslefl05	cmr254jmv00bwjxctyce1zrjn	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00osjxct8lxgds1l	cmr254jj8003zjxctgslefl05	cmr254jmv00bwjxctyce1zrjn	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00otjxcty60blvku	cmr254jj8003zjxctgslefl05	cmr254jmv00bwjxctyce1zrjn	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00oujxcti0proajx	cmr254jj80040jxct7z0rgqa7	cmr254jmv00bxjxct7j06cw9o	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00ovjxctp0eb2vbb	cmr254jj80040jxct7z0rgqa7	cmr254jmv00bxjxct7j06cw9o	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00owjxct5jkpe5yb	cmr254jj80040jxct7z0rgqa7	cmr254jmv00bxjxct7j06cw9o	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00oxjxct1z0w2rze	cmr254jj80041jxctmnla9ma7	cmr254jmv00byjxctk8m7rut2	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00oyjxctd1zgyp2w	cmr254jj80041jxctmnla9ma7	cmr254jmv00byjxctk8m7rut2	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00ozjxctsg49d3qg	cmr254jj80041jxctmnla9ma7	cmr254jmv00byjxctk8m7rut2	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00p0jxctgdu5djrn	cmr254jj80042jxcttwpznq8q	cmr254jmv00bzjxctoh9wxmxb	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00p1jxctylofude3	cmr254jj80042jxcttwpznq8q	cmr254jmv00bzjxctoh9wxmxb	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00p2jxctu7q2g511	cmr254jj80042jxcttwpznq8q	cmr254jmv00bzjxctoh9wxmxb	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00p3jxctzk6hrfbg	cmr254jj80043jxctb9ly8dom	cmr254jmv00c0jxctp8msfvba	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00p4jxctx29mse0c	cmr254jj80043jxctb9ly8dom	cmr254jmv00c0jxctp8msfvba	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpr00p5jxct5sf4tzb0	cmr254jj80043jxctb9ly8dom	cmr254jmv00c0jxctp8msfvba	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00p6jxctyxzcqrl6	cmr254jj80044jxct1earz6e1	cmr254jmv00c1jxct7hnw3ed5	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00p7jxctsmsduwbx	cmr254jj80044jxct1earz6e1	cmr254jmv00c1jxct7hnw3ed5	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00p8jxctgfuw5ais	cmr254jj80044jxct1earz6e1	cmr254jmv00c1jxct7hnw3ed5	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00p9jxct2ctjsft5	cmr254jj80045jxctego6v6ne	cmr254jmv00c2jxctzirneyz0	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00pajxct328dm7kc	cmr254jj80045jxctego6v6ne	cmr254jmv00c2jxctzirneyz0	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00pbjxct6p3f1ppy	cmr254jj80045jxctego6v6ne	cmr254jmv00c2jxctzirneyz0	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00pcjxctakiumnnu	cmr254jj80046jxct3s834408	cmr254jmv00c3jxcthbhc09fb	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00pdjxct4v8x926t	cmr254jj80046jxct3s834408	cmr254jmv00c3jxcthbhc09fb	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00pejxctle2jsxom	cmr254jj80046jxct3s834408	cmr254jmv00c3jxcthbhc09fb	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00pfjxctpxkh13py	cmr254jj80047jxct6iaq1r3y	cmr254jmv00c4jxctrek5dvpa	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00pgjxctrm92v2n3	cmr254jj80047jxct6iaq1r3y	cmr254jmv00c4jxctrek5dvpa	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00phjxctgf8cnkz4	cmr254jj80047jxct6iaq1r3y	cmr254jmv00c4jxctrek5dvpa	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00pijxcte1639zc3	cmr254jj80048jxctsdu3uoop	cmr254jmv00c5jxctwv4yq6eq	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00pjjxctpm1649ix	cmr254jj80048jxctsdu3uoop	cmr254jmv00c5jxctwv4yq6eq	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00pkjxct58kh62xx	cmr254jj80048jxctsdu3uoop	cmr254jmv00c5jxctwv4yq6eq	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00pljxctqcuctq8e	cmr254jj80049jxct1rj1qewz	cmr254jmv00c6jxctzsrwge53	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00pmjxctf37net5x	cmr254jj80049jxct1rj1qewz	cmr254jmv00c6jxctzsrwge53	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00pnjxctnw4zpgw1	cmr254jj80049jxct1rj1qewz	cmr254jmv00c6jxctzsrwge53	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00pojxct6ahnalp7	cmr254jj8004ajxct2i9jrhd6	cmr254jmw00c7jxctkg8oe3c7	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00ppjxctz6y0dvm4	cmr254jj8004ajxct2i9jrhd6	cmr254jmw00c7jxctkg8oe3c7	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00pqjxctbg9wu4vg	cmr254jj8004ajxct2i9jrhd6	cmr254jmw00c7jxctkg8oe3c7	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00prjxctv5nf3khc	cmr254jj8004ajxct2i9jrhd6	cmr254jmw00c7jxctkg8oe3c7	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00psjxctpo9vvbd1	cmr254jj8004bjxct6ztt3jio	cmr254jmw00c8jxctozy7ktyx	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00ptjxctc368i5hl	cmr254jj8004bjxct6ztt3jio	cmr254jmw00c8jxctozy7ktyx	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00pujxctrjxlvu5o	cmr254jj8004bjxct6ztt3jio	cmr254jmw00c8jxctozy7ktyx	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00pvjxctl3tgzyt3	cmr254jj8004cjxctzsdr2b2b	cmr254jmw00c9jxct8or7wr1f	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00pwjxct4onp9sqz	cmr254jj8004cjxctzsdr2b2b	cmr254jmw00c9jxct8or7wr1f	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00pxjxctjpg2pyvh	cmr254jj8004cjxctzsdr2b2b	cmr254jmw00c9jxct8or7wr1f	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00pyjxctriyxdtpw	cmr254jj8004djxctu66tc348	cmr254jmw00cajxct1z5cxpvr	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00pzjxctn70wi288	cmr254jj8004djxctu66tc348	cmr254jmw00cajxct1z5cxpvr	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00q0jxctehlinwec	cmr254jj8004djxctu66tc348	cmr254jmw00cajxct1z5cxpvr	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00q1jxctd3xjx5vx	cmr254jj8004ejxctcbrfp50r	cmr254jmw00cbjxct3rs40m08	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00q2jxct3jz55pbu	cmr254jj8004ejxctcbrfp50r	cmr254jmw00cbjxct3rs40m08	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00q3jxcti2aawktv	cmr254jj8004ejxctcbrfp50r	cmr254jmw00cbjxct3rs40m08	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00q4jxcteawup907	cmr254jj8004fjxctz1wc7cwl	cmr254jmw00ccjxcth01nhr8m	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00q5jxct9ydpjjwx	cmr254jj8004fjxctz1wc7cwl	cmr254jmw00ccjxcth01nhr8m	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00q6jxct6h5wh0e9	cmr254jj8004fjxctz1wc7cwl	cmr254jmw00ccjxcth01nhr8m	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00q7jxct2qw9dj61	cmr254jj8004gjxct2tnvqv4u	cmr254jmw00cdjxctev88gw05	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00q8jxctpnsc5ajt	cmr254jj8004gjxct2tnvqv4u	cmr254jmw00cdjxctev88gw05	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00q9jxctn8nlta66	cmr254jj8004gjxct2tnvqv4u	cmr254jmw00cdjxctev88gw05	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00qajxctzbagystn	cmr254jj8004hjxctedpu9yzb	cmr254jmw00cejxctl7zg2sa2	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00qbjxctyx4b0ybz	cmr254jj8004hjxctedpu9yzb	cmr254jmw00cejxctl7zg2sa2	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00qcjxct8ijimb4t	cmr254jj8004hjxctedpu9yzb	cmr254jmw00cejxctl7zg2sa2	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00qdjxctmll3jdfz	cmr254jj8004ijxct6cd2ylyk	cmr254jmw00cfjxctt22w00qi	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00qejxctp4zit1ra	cmr254jj8004ijxct6cd2ylyk	cmr254jmw00cfjxctt22w00qi	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00qfjxcttmkzjxzt	cmr254jj8004ijxct6cd2ylyk	cmr254jmw00cfjxctt22w00qi	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00qgjxctaetym0ae	cmr254jj8004jjxctmjhvdgji	cmr254jmw00cgjxcty9a4ju5n	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00qhjxctq91jydsi	cmr254jj8004jjxctmjhvdgji	cmr254jmw00cgjxcty9a4ju5n	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00qijxctd2jbmfcj	cmr254jj8004jjxctmjhvdgji	cmr254jmw00cgjxcty9a4ju5n	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00qjjxctsnne8uu2	cmr254jj8004kjxctcm1579ne	cmr254jmw00chjxct04acld9i	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00qkjxctjwxo0jr9	cmr254jj8004kjxctcm1579ne	cmr254jmw00chjxct04acld9i	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00qljxctn8de2ke9	cmr254jj8004kjxctcm1579ne	cmr254jmw00chjxct04acld9i	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00qmjxctk0jwtx6u	cmr254jj8004ljxct0nm1kdag	cmr254jmw00cijxctek03d14j	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00qnjxctn5fijapf	cmr254jj8004ljxct0nm1kdag	cmr254jmw00cijxctek03d14j	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00qojxctdr42trya	cmr254jj8004ljxct0nm1kdag	cmr254jmw00cijxctek03d14j	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00qpjxctej2a5wwo	cmr254jj8004mjxct60avukf8	cmr254jmw00cjjxctwqsgpuxz	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00qqjxctkdnn6qvi	cmr254jj8004mjxct60avukf8	cmr254jmw00cjjxctwqsgpuxz	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00qrjxctvzb5auul	cmr254jj8004mjxct60avukf8	cmr254jmw00cjjxctwqsgpuxz	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00qsjxctl9kfnf51	cmr254jj8004njxctb05soxf1	cmr254jmw00ckjxct2cxumm6h	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00qtjxct0adbuoyl	cmr254jj8004njxctb05soxf1	cmr254jmw00ckjxct2cxumm6h	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00qujxctwtnvf078	cmr254jj8004njxctb05soxf1	cmr254jmw00ckjxct2cxumm6h	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00qvjxcts75e8s2i	cmr254jj8004ojxctr9eyx073	cmr254jmw00cljxctuf2rl77x	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00qwjxctmy6x3o5f	cmr254jj8004ojxctr9eyx073	cmr254jmw00cljxctuf2rl77x	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00qxjxctcrikq063	cmr254jj8004ojxctr9eyx073	cmr254jmw00cljxctuf2rl77x	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00qyjxctx7pln8c3	cmr254jj9004pjxcts1r3ba26	cmr254jmw00cmjxct31u7a3a4	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00qzjxctpqds3qbj	cmr254jj9004pjxcts1r3ba26	cmr254jmw00cmjxct31u7a3a4	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00r0jxctc0q904tb	cmr254jj9004pjxcts1r3ba26	cmr254jmw00cmjxct31u7a3a4	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00r1jxct57dx6rkb	cmr254jj9004pjxcts1r3ba26	cmr254jmw00cmjxct31u7a3a4	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00r2jxctmd2vrafp	cmr254jj9004qjxctccn4l6d0	cmr254jmw00cnjxctrv2k2lzg	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00r3jxctvr20kiap	cmr254jj9004qjxctccn4l6d0	cmr254jmw00cnjxctrv2k2lzg	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00r4jxctw825ybsu	cmr254jj9004qjxctccn4l6d0	cmr254jmw00cnjxctrv2k2lzg	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00r5jxctutejdfkd	cmr254jj9004rjxctv7g9cke4	cmr254jmw00cojxct96t43f1i	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00r6jxctxjw44dgb	cmr254jj9004rjxctv7g9cke4	cmr254jmw00cojxct96t43f1i	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00r7jxctwjm2ewx1	cmr254jj9004rjxctv7g9cke4	cmr254jmw00cojxct96t43f1i	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00r8jxct7vk66a0d	cmr254jj9004sjxct5yjazz84	cmr254jmw00cpjxctb0thuo0z	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00r9jxctwipfpjlf	cmr254jj9004sjxct5yjazz84	cmr254jmw00cpjxctb0thuo0z	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00rajxct74xdo1n2	cmr254jj9004sjxct5yjazz84	cmr254jmw00cpjxctb0thuo0z	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00rbjxctrgnvpqfs	cmr254jj9004ujxctlqakkxx1	cmr254jmw00crjxctyaud849b	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00rcjxctb53e1k9p	cmr254jj9004ujxctlqakkxx1	cmr254jmw00crjxctyaud849b	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00rdjxctzafnalae	cmr254jj9004ujxctlqakkxx1	cmr254jmw00crjxctyaud849b	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jps00rejxctlerehby3	cmr254jj9004vjxctele0ln6q	cmr254jmw00csjxctst2qxsgq	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00rfjxctv4jo7cs3	cmr254jj9004vjxctele0ln6q	cmr254jmw00csjxctst2qxsgq	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00rgjxct64tlzgkm	cmr254jj9004vjxctele0ln6q	cmr254jmw00csjxctst2qxsgq	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00rhjxctnoplx5gu	cmr254jj9004wjxct9wavr8x8	cmr254jmw00ctjxctdfbkchrg	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00rijxct6u9lgbt6	cmr254jj9004wjxct9wavr8x8	cmr254jmw00ctjxctdfbkchrg	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00rjjxctav1j9kmy	cmr254jj9004wjxct9wavr8x8	cmr254jmw00ctjxctdfbkchrg	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00rkjxctqlj8lcgw	cmr254jj9004xjxctf82maoas	cmr254jmw00cujxctrklck0xu	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00rljxctt4b8ew1s	cmr254jj9004xjxctf82maoas	cmr254jmw00cujxctrklck0xu	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00rmjxctnwm9kh6a	cmr254jj9004xjxctf82maoas	cmr254jmw00cujxctrklck0xu	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00rnjxctjdvwpgoj	cmr254jj9004yjxctkqrsx4z0	cmr254jmw00cvjxctud5f16bm	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00rojxctzmytyht0	cmr254jj9004yjxctkqrsx4z0	cmr254jmw00cvjxctud5f16bm	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00rpjxctdq66l2pn	cmr254jj9004yjxctkqrsx4z0	cmr254jmw00cvjxctud5f16bm	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00rqjxct5dmdffgv	cmr254jj9004zjxct8y1cnv8l	cmr254jmw00cwjxctdc3vvt6u	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00rrjxctiudlroje	cmr254jj9004zjxct8y1cnv8l	cmr254jmw00cwjxctdc3vvt6u	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00rsjxctemodezp5	cmr254jj9004zjxct8y1cnv8l	cmr254jmw00cwjxctdc3vvt6u	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00rtjxct1komxj2l	cmr254jj90050jxctgh6bhswf	cmr254jmw00cxjxcthz2y565d	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00rujxctz2dqg3wp	cmr254jj90050jxctgh6bhswf	cmr254jmw00cxjxcthz2y565d	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00rvjxct4zf2ltaw	cmr254jj90050jxctgh6bhswf	cmr254jmw00cxjxcthz2y565d	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00rwjxctk60v3h0j	cmr254jj90052jxct91t14y6y	cmr254jmx00czjxctmxgyhvyv	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00rxjxctc24gky4v	cmr254jj90052jxct91t14y6y	cmr254jmx00czjxctmxgyhvyv	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00ryjxcttjy7bsq1	cmr254jj90052jxct91t14y6y	cmr254jmx00czjxctmxgyhvyv	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00rzjxct3pui3pp8	cmr254jj90053jxcterfpk1zl	cmr254jmx00d0jxctqp2csy2x	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00s0jxctnmqa07ch	cmr254jj90053jxcterfpk1zl	cmr254jmx00d0jxctqp2csy2x	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00s1jxct49q3bdau	cmr254jj90053jxcterfpk1zl	cmr254jmx00d0jxctqp2csy2x	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00s2jxcthzzz37tb	cmr254jj90053jxcterfpk1zl	cmr254jmx00d0jxctqp2csy2x	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00s3jxctter0kvg1	cmr254jj90053jxcterfpk1zl	cmr254jmx00d0jxctqp2csy2x	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00s4jxctg83zbjlb	cmr254jj90054jxcte8fdkrui	cmr254jmx00d1jxctodltnfzf	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00s5jxctj0c0f13z	cmr254jj90054jxcte8fdkrui	cmr254jmx00d1jxctodltnfzf	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00s6jxct4zev3vjn	cmr254jj90054jxcte8fdkrui	cmr254jmx00d1jxctodltnfzf	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00s7jxctzylltk16	cmr254jj90055jxct502vj8jp	cmr254jmx00d2jxct9ov4x39l	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00s8jxct9ui26h9t	cmr254jj90055jxct502vj8jp	cmr254jmx00d2jxct9ov4x39l	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00s9jxctcfrdksnt	cmr254jj90055jxct502vj8jp	cmr254jmx00d2jxct9ov4x39l	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00sajxctdwne0zlx	cmr254jj90055jxct502vj8jp	cmr254jmx00d2jxct9ov4x39l	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00sbjxctnul8anfy	cmr254jj90056jxct8zyd72or	cmr254jmx00d3jxctw15wmoxt	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00scjxctfp3ge7li	cmr254jj90056jxct8zyd72or	cmr254jmx00d3jxctw15wmoxt	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00sdjxct29amfvmr	cmr254jj90056jxct8zyd72or	cmr254jmx00d3jxctw15wmoxt	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00sejxcttrw6en6g	cmr254jj90056jxct8zyd72or	cmr254jmx00d3jxctw15wmoxt	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00sfjxctp5hfd3b4	cmr254jj90057jxctwje3v43w	cmr254jmx00d4jxctn47xqmia	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00sgjxcthq160gds	cmr254jj90057jxctwje3v43w	cmr254jmx00d4jxctn47xqmia	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00shjxct2dhkrl2d	cmr254jj90057jxctwje3v43w	cmr254jmx00d4jxctn47xqmia	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00sijxctyl4e3sm5	cmr254jj90057jxctwje3v43w	cmr254jmx00d4jxctn47xqmia	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00sjjxctysiy4ftx	cmr254jj90058jxctbkeet4dr	cmr254jmx00d5jxctrsaq1qg8	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00skjxctkpp5r786	cmr254jj90058jxctbkeet4dr	cmr254jmx00d5jxctrsaq1qg8	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00sljxctb1s32ibr	cmr254jj90058jxctbkeet4dr	cmr254jmx00d5jxctrsaq1qg8	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00smjxctbij57bwq	cmr254jj90058jxctbkeet4dr	cmr254jmx00d5jxctrsaq1qg8	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00snjxctrrrin9rd	cmr254jj90059jxctbt29cczv	cmr254jmx00d6jxctq1s3mygh	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00sojxct5q801qqb	cmr254jj90059jxctbt29cczv	cmr254jmx00d6jxctq1s3mygh	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00spjxctysdzta5j	cmr254jj90059jxctbt29cczv	cmr254jmx00d6jxctq1s3mygh	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00sqjxct3d9fnw8b	cmr254jj90059jxctbt29cczv	cmr254jmx00d6jxctq1s3mygh	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00srjxctrw8f63g7	cmr254jj9005ajxctt7n7gdhw	cmr254jmx00d7jxctx6bevfl7	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00ssjxctgtp2gz29	cmr254jj9005ajxctt7n7gdhw	cmr254jmx00d7jxctx6bevfl7	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00stjxctw0i6k9gr	cmr254jj9005ajxctt7n7gdhw	cmr254jmx00d7jxctx6bevfl7	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00sujxct6d7s2pw8	cmr254jj9005ajxctt7n7gdhw	cmr254jmx00d7jxctx6bevfl7	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00svjxctaemf0xxv	cmr254jj9005bjxctzjtz49w2	cmr254jmx00d8jxctsnfv6rxn	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00swjxctul53unb0	cmr254jj9005bjxctzjtz49w2	cmr254jmx00d8jxctsnfv6rxn	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00sxjxct5rd1j3o1	cmr254jj9005bjxctzjtz49w2	cmr254jmx00d8jxctsnfv6rxn	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00syjxctd9slfhop	cmr254jj9005bjxctzjtz49w2	cmr254jmx00d8jxctsnfv6rxn	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00szjxctzecdhoeo	cmr254jj9005cjxctxj2sae3q	cmr254jmx00d9jxct7mj7p38c	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00t0jxct0ws98fcm	cmr254jj9005cjxctxj2sae3q	cmr254jmx00d9jxct7mj7p38c	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00t1jxctwbp7bg6i	cmr254jj9005cjxctxj2sae3q	cmr254jmx00d9jxct7mj7p38c	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00t2jxctn75p69qe	cmr254jj9005cjxctxj2sae3q	cmr254jmx00d9jxct7mj7p38c	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00t3jxctqdklfjvf	cmr254jj9005djxctrkqpkwer	cmr254jmx00dajxctr14qhlpf	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00t4jxct7yup0i9q	cmr254jj9005djxctrkqpkwer	cmr254jmx00dajxctr14qhlpf	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00t5jxctkbsno6vv	cmr254jj9005djxctrkqpkwer	cmr254jmx00dajxctr14qhlpf	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00t6jxct2ox6gb40	cmr254jj9005djxctrkqpkwer	cmr254jmx00dajxctr14qhlpf	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00t7jxctzxhdrewi	cmr254jj9005ejxct3dshgd2q	cmr254jmx00dbjxct6franhlk	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00t8jxcteewzw2fz	cmr254jj9005ejxct3dshgd2q	cmr254jmx00dbjxct6franhlk	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00t9jxctwdem7vie	cmr254jj9005ejxct3dshgd2q	cmr254jmx00dbjxct6franhlk	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00tajxctenjuipru	cmr254jj9005ejxct3dshgd2q	cmr254jmx00dbjxct6franhlk	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00tbjxcty3xwkczi	cmr254jj9005fjxctayssosxa	cmr254jmx00dcjxcthcwfuw2m	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00tcjxctcgpznnjk	cmr254jj9005fjxctayssosxa	cmr254jmx00dcjxcthcwfuw2m	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00tdjxctzd9mfr89	cmr254jj9005fjxctayssosxa	cmr254jmx00dcjxcthcwfuw2m	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00tejxctf2s7kkca	cmr254jj9005fjxctayssosxa	cmr254jmx00dcjxcthcwfuw2m	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00tfjxctk1ihmo29	cmr254jj9005gjxctn1kvfmin	cmr254jmx00ddjxctq8rv7mkm	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00tgjxctdd4ctk5u	cmr254jj9005gjxctn1kvfmin	cmr254jmx00ddjxctq8rv7mkm	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00thjxct5091jk26	cmr254jj9005gjxctn1kvfmin	cmr254jmx00ddjxctq8rv7mkm	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00tijxctux22g0fu	cmr254jj9005gjxctn1kvfmin	cmr254jmx00ddjxctq8rv7mkm	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00tjjxctl4pjarzc	cmr254jj9005hjxctyx0mufj6	cmr254jmx00dejxctsvdfwvkv	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00tkjxcttdcdus7l	cmr254jj9005hjxctyx0mufj6	cmr254jmx00dejxctsvdfwvkv	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00tljxctp9cwuw2o	cmr254jj9005hjxctyx0mufj6	cmr254jmx00dejxctsvdfwvkv	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00tmjxctzdrfoyno	cmr254jj9005hjxctyx0mufj6	cmr254jmx00dejxctsvdfwvkv	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00tnjxct3ssqo51p	cmr254jj9005ijxctepqqasb1	cmr254jmx00dfjxctowmj8iu2	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpt00tojxctn70ebvy2	cmr254jj9005ijxctepqqasb1	cmr254jmx00dfjxctowmj8iu2	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00tpjxcthylxrolp	cmr254jj9005ijxctepqqasb1	cmr254jmx00dfjxctowmj8iu2	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00tqjxctb9hrjwqo	cmr254jj9005ijxctepqqasb1	cmr254jmx00dfjxctowmj8iu2	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00trjxct81vstikq	cmr254jj9005jjxct0e2lioa5	cmr254jmx00dgjxctdnhr9dcz	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00tsjxcteh41pwyv	cmr254jj9005jjxct0e2lioa5	cmr254jmx00dgjxctdnhr9dcz	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00ttjxct61ve1cig	cmr254jj9005jjxct0e2lioa5	cmr254jmx00dgjxctdnhr9dcz	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00tujxctrxc5hnmo	cmr254jj9005jjxct0e2lioa5	cmr254jmx00dgjxctdnhr9dcz	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00tvjxctsd8kdevr	cmr254jj9005jjxct0e2lioa5	cmr254jmx00dgjxctdnhr9dcz	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00twjxct6csud0rs	cmr254jj9005kjxctdbv3cldg	cmr254jmx00dhjxctp6sw28os	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00txjxctu11lcpp4	cmr254jj9005kjxctdbv3cldg	cmr254jmx00dhjxctp6sw28os	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00tyjxctzg0ra9cc	cmr254jj9005kjxctdbv3cldg	cmr254jmx00dhjxctp6sw28os	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00tzjxctm0umfj0z	cmr254jj9005kjxctdbv3cldg	cmr254jmx00dhjxctp6sw28os	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00u0jxct5omt04xn	cmr254jj9005ljxctslhf9zow	cmr254jmx00dijxctykajbam9	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00u1jxctr8zmfcv9	cmr254jj9005ljxctslhf9zow	cmr254jmx00dijxctykajbam9	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00u2jxctzb2a40u3	cmr254jj9005ljxctslhf9zow	cmr254jmx00dijxctykajbam9	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00u3jxcti89rsjeb	cmr254jj9005ljxctslhf9zow	cmr254jmx00dijxctykajbam9	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00u4jxct4goto3jj	cmr254jj9005mjxcteseajcaz	cmr254jmx00djjxctlxzx80sk	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00u5jxct532m3ua4	cmr254jj9005mjxcteseajcaz	cmr254jmx00djjxctlxzx80sk	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00u6jxctypla9ayz	cmr254jj9005mjxcteseajcaz	cmr254jmx00djjxctlxzx80sk	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00u7jxct3dnmk92i	cmr254jj9005mjxcteseajcaz	cmr254jmx00djjxctlxzx80sk	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00u8jxcthtspgwfm	cmr254jj9005njxct0ltbxrfq	cmr254jmx00dkjxctae07bxuw	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00u9jxctqogbb8vf	cmr254jj9005njxct0ltbxrfq	cmr254jmx00dkjxctae07bxuw	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00uajxct3yqysnsn	cmr254jj9005njxct0ltbxrfq	cmr254jmx00dkjxctae07bxuw	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00ubjxctv0n4bal1	cmr254jj9005njxct0ltbxrfq	cmr254jmx00dkjxctae07bxuw	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00ucjxct7ogtn74q	cmr254jj9005ojxctk6aeclko	cmr254jmx00dljxctjp050apn	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00udjxctg3l5d8vw	cmr254jj9005ojxctk6aeclko	cmr254jmx00dljxctjp050apn	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00uejxctho621c9s	cmr254jj9005ojxctk6aeclko	cmr254jmx00dljxctjp050apn	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00ufjxctek5i0hph	cmr254jj9005ojxctk6aeclko	cmr254jmx00dljxctjp050apn	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00ugjxctonwhvwx1	cmr254jj9005pjxctteobosx4	cmr254jmx00dmjxctgz1afg19	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00uhjxcth4j628oa	cmr254jj9005pjxctteobosx4	cmr254jmx00dmjxctgz1afg19	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00uijxctshbw347y	cmr254jj9005pjxctteobosx4	cmr254jmx00dmjxctgz1afg19	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00ujjxctrd94hsiz	cmr254jj9005pjxctteobosx4	cmr254jmx00dmjxctgz1afg19	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00ukjxctgso5tvw2	cmr254jj9005qjxctyhfgshq4	cmr254jmx00dnjxcttjbaa0q6	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00uljxcttfwx5tn6	cmr254jj9005qjxctyhfgshq4	cmr254jmx00dnjxcttjbaa0q6	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00umjxctc9ifbn5g	cmr254jj9005qjxctyhfgshq4	cmr254jmx00dnjxcttjbaa0q6	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00unjxctxxp8astz	cmr254jj9005qjxctyhfgshq4	cmr254jmx00dnjxcttjbaa0q6	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00uojxctwvvojnsk	cmr254jj9005rjxctiueb7u5g	cmr254jmx00dojxct8gezcb48	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00upjxctcpladc42	cmr254jj9005rjxctiueb7u5g	cmr254jmx00dojxct8gezcb48	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00uqjxctu0rp20t9	cmr254jj9005rjxctiueb7u5g	cmr254jmx00dojxct8gezcb48	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00urjxctbhaji1wu	cmr254jj9005sjxcthtvtizdq	cmr254jmx00dpjxctjfo8vwjt	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00usjxct4f3bsewh	cmr254jj9005sjxcthtvtizdq	cmr254jmx00dpjxctjfo8vwjt	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00utjxctlts5mvj1	cmr254jj9005sjxcthtvtizdq	cmr254jmx00dpjxctjfo8vwjt	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00uujxctz8qzf0gs	cmr254jj9005tjxctxewv1rya	cmr254jmx00dqjxctyltjpl4h	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00uvjxctlqaxbkq9	cmr254jj9005tjxctxewv1rya	cmr254jmx00dqjxctyltjpl4h	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00uwjxctmf6ejg61	cmr254jj9005tjxctxewv1rya	cmr254jmx00dqjxctyltjpl4h	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00uxjxct5eto3wda	cmr254jj9005tjxctxewv1rya	cmr254jmx00dqjxctyltjpl4h	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00uyjxctzenzxxsp	cmr254jj9005ujxct1acqdna9	cmr254jmx00drjxctptfxfwdw	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00uzjxct0wzxdwzh	cmr254jj9005ujxct1acqdna9	cmr254jmx00drjxctptfxfwdw	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00v0jxctckvzaw0x	cmr254jj9005ujxct1acqdna9	cmr254jmx00drjxctptfxfwdw	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00v1jxctb1yx2jpk	cmr254jj9005ujxct1acqdna9	cmr254jmx00drjxctptfxfwdw	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00v2jxctojh8spug	cmr254jja005vjxct70xecv9o	cmr254jmy00dsjxctqpqjfr5r	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00v3jxctzso1ngs2	cmr254jja005vjxct70xecv9o	cmr254jmy00dsjxctqpqjfr5r	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00v4jxct85ss07zs	cmr254jja005vjxct70xecv9o	cmr254jmy00dsjxctqpqjfr5r	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00v5jxct1r7vaply	cmr254jja005vjxct70xecv9o	cmr254jmy00dsjxctqpqjfr5r	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00v6jxcto80ws90k	cmr254jja005wjxctiumw4gx6	cmr254jmy00dtjxctthrma71h	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00v7jxctoulv37ta	cmr254jja005wjxctiumw4gx6	cmr254jmy00dtjxctthrma71h	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00v8jxctjpvdlh0i	cmr254jja005wjxctiumw4gx6	cmr254jmy00dtjxctthrma71h	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00v9jxct1n2k707b	cmr254jja005wjxctiumw4gx6	cmr254jmy00dtjxctthrma71h	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00vajxctjtpy1pqr	cmr254jja005xjxct5pstbp3w	cmr254jmy00dujxct66ajlpct	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00vbjxctgu6p719c	cmr254jja005xjxct5pstbp3w	cmr254jmy00dujxct66ajlpct	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00vcjxct1jk42hja	cmr254jja005xjxct5pstbp3w	cmr254jmy00dujxct66ajlpct	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00vdjxctuc6l0j9w	cmr254jja005xjxct5pstbp3w	cmr254jmy00dujxct66ajlpct	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00vejxctzi0cyxcz	cmr254jja005yjxct6tr26hcf	cmr254jmy00dvjxctk8a6h0l1	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00vfjxct2r21023f	cmr254jja005yjxct6tr26hcf	cmr254jmy00dvjxctk8a6h0l1	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00vgjxctsn1um5zs	cmr254jja005yjxct6tr26hcf	cmr254jmy00dvjxctk8a6h0l1	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00vhjxct5zldd26f	cmr254jja005yjxct6tr26hcf	cmr254jmy00dvjxctk8a6h0l1	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00vijxctspis2ung	cmr254jja005zjxcth6i2sorj	cmr254jmy00dwjxctzavdcvb4	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00vjjxct7dcrixh8	cmr254jja005zjxcth6i2sorj	cmr254jmy00dwjxctzavdcvb4	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00vkjxctapa6sfg2	cmr254jja005zjxcth6i2sorj	cmr254jmy00dwjxctzavdcvb4	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00vljxct27yeii2p	cmr254jja005zjxcth6i2sorj	cmr254jmy00dwjxctzavdcvb4	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00vmjxcts5jeobrm	cmr254jja0060jxct05820s3l	cmr254jmy00dxjxctk4yoe40u	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00vnjxct6rtars4s	cmr254jja0060jxct05820s3l	cmr254jmy00dxjxctk4yoe40u	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00vojxct49725w96	cmr254jja0060jxct05820s3l	cmr254jmy00dxjxctk4yoe40u	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00vpjxctn511d2u7	cmr254jja0060jxct05820s3l	cmr254jmy00dxjxctk4yoe40u	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00vqjxct6pa8vkw1	cmr254jja0061jxctqoe104vj	cmr254jmy00dyjxctdbamg9kv	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00vrjxctu4yxbh72	cmr254jja0061jxctqoe104vj	cmr254jmy00dyjxctdbamg9kv	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00vsjxctt42k4e59	cmr254jja0061jxctqoe104vj	cmr254jmy00dyjxctdbamg9kv	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00vtjxct4k8bq793	cmr254jja0061jxctqoe104vj	cmr254jmy00dyjxctdbamg9kv	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00vujxctkkk1fxjt	cmr254jja0062jxct35ydfwe7	cmr254jmy00dzjxctx3c6i28h	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00vvjxctoqfxwzvi	cmr254jja0062jxct35ydfwe7	cmr254jmy00dzjxctx3c6i28h	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpu00vwjxctyj7wgy8x	cmr254jja0062jxct35ydfwe7	cmr254jmy00dzjxctx3c6i28h	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00vxjxctijcdc7ot	cmr254jja0062jxct35ydfwe7	cmr254jmy00dzjxctx3c6i28h	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00vyjxctxkllhbrv	cmr254jja0063jxctu1a6nkb5	cmr254jmy00e0jxct2afx3j4y	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00vzjxctwrny28d5	cmr254jja0063jxctu1a6nkb5	cmr254jmy00e0jxct2afx3j4y	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00w0jxctrfflkd3x	cmr254jja0063jxctu1a6nkb5	cmr254jmy00e0jxct2afx3j4y	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00w1jxctqr14rx9m	cmr254jja0063jxctu1a6nkb5	cmr254jmy00e0jxct2afx3j4y	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00w2jxct97dh587l	cmr254jja0064jxctfu6t21ls	cmr254jmy00e1jxct7aqj3xvv	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00w3jxct15tuplna	cmr254jja0064jxctfu6t21ls	cmr254jmy00e1jxct7aqj3xvv	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00w4jxct3dpbhs1l	cmr254jja0064jxctfu6t21ls	cmr254jmy00e1jxct7aqj3xvv	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00w5jxct0jiud419	cmr254jja0064jxctfu6t21ls	cmr254jmy00e1jxct7aqj3xvv	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00w6jxct2k1chjw2	cmr254jja0065jxct0sakw43p	cmr254jmy00e2jxctphz9yvyx	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00w7jxctrd3r9s65	cmr254jja0065jxct0sakw43p	cmr254jmy00e2jxctphz9yvyx	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00w8jxct4rnvyd9c	cmr254jja0065jxct0sakw43p	cmr254jmy00e2jxctphz9yvyx	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00w9jxctq0daqk63	cmr254jja0065jxct0sakw43p	cmr254jmy00e2jxctphz9yvyx	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00wajxctm9knr6eb	cmr254jja0066jxct15e4wlkc	cmr254jmy00e3jxct2f7jdq59	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00wbjxctcbblgp29	cmr254jja0066jxct15e4wlkc	cmr254jmy00e3jxct2f7jdq59	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00wcjxcts6ae87v6	cmr254jja0066jxct15e4wlkc	cmr254jmy00e3jxct2f7jdq59	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00wdjxctbj4wwwv2	cmr254jja0066jxct15e4wlkc	cmr254jmy00e3jxct2f7jdq59	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00wejxct68i09vai	cmr254jja0067jxctalxehres	cmr254jmy00e4jxctksps0p91	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00wfjxct293trnr9	cmr254jja0067jxctalxehres	cmr254jmy00e4jxctksps0p91	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00wgjxctjj7crldc	cmr254jja0067jxctalxehres	cmr254jmy00e4jxctksps0p91	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00whjxctgfup0jr5	cmr254jja0067jxctalxehres	cmr254jmy00e4jxctksps0p91	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00wijxctx0d9ucsq	cmr254jja0068jxctentnbggv	cmr254jmy00e5jxctoo3nvp2d	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00wjjxctnxnga9s4	cmr254jja0068jxctentnbggv	cmr254jmy00e5jxctoo3nvp2d	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00wkjxctdmlciiju	cmr254jja0068jxctentnbggv	cmr254jmy00e5jxctoo3nvp2d	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00wljxctbb5iaio7	cmr254jja0068jxctentnbggv	cmr254jmy00e5jxctoo3nvp2d	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00wmjxct08ztexg4	cmr254jja0069jxctwhb7t2vp	cmr254jmy00e6jxct8p8yp7ak	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00wnjxct68f9twmm	cmr254jja0069jxctwhb7t2vp	cmr254jmy00e6jxct8p8yp7ak	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00wojxcthr3a9l31	cmr254jja0069jxctwhb7t2vp	cmr254jmy00e6jxct8p8yp7ak	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00wpjxctcshxtsdq	cmr254jja0069jxctwhb7t2vp	cmr254jmy00e6jxct8p8yp7ak	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00wqjxctrrixu44b	cmr254jja006ajxctab9fzoa0	cmr254jmy00e7jxctwhk32vp8	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00wrjxct48egge4d	cmr254jja006ajxctab9fzoa0	cmr254jmy00e7jxctwhk32vp8	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00wsjxctqm38nqt2	cmr254jja006ajxctab9fzoa0	cmr254jmy00e7jxctwhk32vp8	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00wtjxctqh3lb9mh	cmr254jja006ajxctab9fzoa0	cmr254jmy00e7jxctwhk32vp8	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00wujxctqzzmsc74	cmr254jja006bjxctyhssqqft	cmr254jmy00e8jxct7n59bd7q	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00wvjxctk74hbm22	cmr254jja006bjxctyhssqqft	cmr254jmy00e8jxct7n59bd7q	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00wwjxctj17fqlfo	cmr254jja006bjxctyhssqqft	cmr254jmy00e8jxct7n59bd7q	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00wxjxct9eji8pi5	cmr254jja006bjxctyhssqqft	cmr254jmy00e8jxct7n59bd7q	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00wyjxcti4kms0bw	cmr254jja006cjxct8tc2ylem	cmr254jmy00e9jxctg55hv80z	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00wzjxctdusp8h0y	cmr254jja006cjxct8tc2ylem	cmr254jmy00e9jxctg55hv80z	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00x0jxctbzdaocy0	cmr254jja006cjxct8tc2ylem	cmr254jmy00e9jxctg55hv80z	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00x1jxctffoaac2q	cmr254jja006cjxct8tc2ylem	cmr254jmy00e9jxctg55hv80z	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00x2jxctz5koks8g	cmr254jja006djxctcmhnrqvc	cmr254jmy00eajxct1r531hpa	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00x3jxctbgt7hbz8	cmr254jja006djxctcmhnrqvc	cmr254jmy00eajxct1r531hpa	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00x4jxcti0uqmaxb	cmr254jja006djxctcmhnrqvc	cmr254jmy00eajxct1r531hpa	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00x5jxctyvf4t8gs	cmr254jja006djxctcmhnrqvc	cmr254jmy00eajxct1r531hpa	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00x6jxctrh20vixx	cmr254jja006ejxct0pf26040	cmr254jmy00ebjxct2zqbawg9	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00x7jxctmwc0r9ej	cmr254jja006ejxct0pf26040	cmr254jmy00ebjxct2zqbawg9	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00x8jxctwn6xe67q	cmr254jja006ejxct0pf26040	cmr254jmy00ebjxct2zqbawg9	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00x9jxcttugzpz5m	cmr254jja006ejxct0pf26040	cmr254jmy00ebjxct2zqbawg9	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00xajxctxiqwjate	cmr254jja006fjxctsrpkyaz5	cmr254jmy00ecjxct2qkup8jm	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00xbjxctgwhpktit	cmr254jja006fjxctsrpkyaz5	cmr254jmy00ecjxct2qkup8jm	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00xcjxctz1aa27ox	cmr254jja006fjxctsrpkyaz5	cmr254jmy00ecjxct2qkup8jm	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00xdjxctwjzdxszk	cmr254jja006fjxctsrpkyaz5	cmr254jmy00ecjxct2qkup8jm	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00xejxctzavvwzms	cmr254jja006gjxcth7ncanj6	cmr254jmy00edjxct4f0u53o2	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00xfjxctxvdndzpd	cmr254jja006gjxcth7ncanj6	cmr254jmy00edjxct4f0u53o2	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00xgjxctonx1iq77	cmr254jja006gjxcth7ncanj6	cmr254jmy00edjxct4f0u53o2	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00xhjxctvhgzvczp	cmr254jja006gjxcth7ncanj6	cmr254jmy00edjxct4f0u53o2	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00xijxctxb9mysed	cmr254jja006hjxctyy6usdck	cmr254jmy00eejxct30rx5bik	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00xjjxct1byqypv5	cmr254jja006hjxctyy6usdck	cmr254jmy00eejxct30rx5bik	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00xkjxctu2u2q0tn	cmr254jja006hjxctyy6usdck	cmr254jmy00eejxct30rx5bik	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00xljxct1rqvuwzz	cmr254jja006hjxctyy6usdck	cmr254jmy00eejxct30rx5bik	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00xmjxctw7d8wevo	cmr254jja006ijxct2hnajz42	cmr254jmy00efjxct6vpte65c	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00xnjxctewea759w	cmr254jja006ijxct2hnajz42	cmr254jmy00efjxct6vpte65c	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00xojxcty0rtlu9e	cmr254jja006ijxct2hnajz42	cmr254jmy00efjxct6vpte65c	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00xpjxctleaifsku	cmr254jja006ijxct2hnajz42	cmr254jmy00efjxct6vpte65c	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00xqjxctkce3cq0f	cmr254jja006jjxctjbrpodxx	cmr254jmy00egjxct84wdxvz3	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00xrjxctj33csilw	cmr254jja006jjxctjbrpodxx	cmr254jmy00egjxct84wdxvz3	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00xsjxct9mnnhmdz	cmr254jja006jjxctjbrpodxx	cmr254jmy00egjxct84wdxvz3	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00xtjxcth11yl3cy	cmr254jja006jjxctjbrpodxx	cmr254jmy00egjxct84wdxvz3	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00xujxctuupcrtx9	cmr254jja006jjxctjbrpodxx	cmr254jmy00egjxct84wdxvz3	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00xvjxcthp4lup4g	cmr254jja006kjxct32hn1kjl	cmr254jmy00ehjxct4y6a8c06	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00xwjxct4xz04eeg	cmr254jja006kjxct32hn1kjl	cmr254jmy00ehjxct4y6a8c06	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00xxjxctrmgkqhu6	cmr254jja006kjxct32hn1kjl	cmr254jmy00ehjxct4y6a8c06	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00xyjxct2pk9edcy	cmr254jja006kjxct32hn1kjl	cmr254jmy00ehjxct4y6a8c06	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00xzjxct3pv8zjnd	cmr254jja006kjxct32hn1kjl	cmr254jmy00ehjxct4y6a8c06	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00y0jxctzrkziazh	cmr254jja006ljxctm2g689nn	cmr254jmy00eijxctnvyjqxsf	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00y1jxctxn97fqj7	cmr254jja006ljxctm2g689nn	cmr254jmy00eijxctnvyjqxsf	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00y2jxctia9hpcrr	cmr254jja006ljxctm2g689nn	cmr254jmy00eijxctnvyjqxsf	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00y3jxctpdrgqiuz	cmr254jja006ljxctm2g689nn	cmr254jmy00eijxctnvyjqxsf	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00y4jxct992rv0wp	cmr254jja006ljxctm2g689nn	cmr254jmy00eijxctnvyjqxsf	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00y5jxct4f5z8mou	cmr254jja006mjxctisfb5pzj	cmr254jmy00ejjxctughimc7k	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00y6jxcthkeusu23	cmr254jja006mjxctisfb5pzj	cmr254jmy00ejjxctughimc7k	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00y7jxctj7if1wj0	cmr254jja006mjxctisfb5pzj	cmr254jmy00ejjxctughimc7k	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00y8jxctizht1dkw	cmr254jja006mjxctisfb5pzj	cmr254jmy00ejjxctughimc7k	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpv00y9jxct06p63de9	cmr254jja006mjxctisfb5pzj	cmr254jmy00ejjxctughimc7k	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00yajxcterjtq4sn	cmr254jja006njxctwnviiryh	cmr254jmz00ekjxctiyw7os0f	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00ybjxctc9h9kkzd	cmr254jja006njxctwnviiryh	cmr254jmz00ekjxctiyw7os0f	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00ycjxctxoqa0gs6	cmr254jja006njxctwnviiryh	cmr254jmz00ekjxctiyw7os0f	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00ydjxct5bt43cum	cmr254jja006njxctwnviiryh	cmr254jmz00ekjxctiyw7os0f	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00yejxcttop5e5bl	cmr254jja006njxctwnviiryh	cmr254jmz00ekjxctiyw7os0f	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00yfjxct9ip0ia9x	cmr254jja006ojxct0sxd72c6	cmr254jmz00eljxctt40tp8n4	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00ygjxcty8ksynnl	cmr254jja006ojxct0sxd72c6	cmr254jmz00eljxctt40tp8n4	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00yhjxctrtupoiy2	cmr254jja006ojxct0sxd72c6	cmr254jmz00eljxctt40tp8n4	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00yijxctqjxfxvjd	cmr254jja006ojxct0sxd72c6	cmr254jmz00eljxctt40tp8n4	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00yjjxct1npwf4eq	cmr254jja006ojxct0sxd72c6	cmr254jmz00eljxctt40tp8n4	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00ykjxct5yp442o4	cmr254jja006pjxctdqrlwhdt	cmr254jmz00emjxctl0whe209	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00yljxct6riwl9zd	cmr254jja006pjxctdqrlwhdt	cmr254jmz00emjxctl0whe209	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00ymjxctrevlawm1	cmr254jja006pjxctdqrlwhdt	cmr254jmz00emjxctl0whe209	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00ynjxctzr3vk59q	cmr254jja006pjxctdqrlwhdt	cmr254jmz00emjxctl0whe209	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00yojxct4i0m06l5	cmr254jja006pjxctdqrlwhdt	cmr254jmz00emjxctl0whe209	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00ypjxct5mdkkj3u	cmr254jja006qjxctsx693uf5	cmr254jmz00enjxctlxym678o	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00yqjxctkdpo7jms	cmr254jja006qjxctsx693uf5	cmr254jmz00enjxctlxym678o	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00yrjxcta8vkuoho	cmr254jja006qjxctsx693uf5	cmr254jmz00enjxctlxym678o	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00ysjxct15dcdtzq	cmr254jja006qjxctsx693uf5	cmr254jmz00enjxctlxym678o	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00ytjxctr5c1zv81	cmr254jja006qjxctsx693uf5	cmr254jmz00enjxctlxym678o	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00yujxct8ur1y6j7	cmr254jja006rjxcty8rk0tit	cmr254jmz00eojxcte6ki0dta	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00yvjxctl3ia362k	cmr254jja006rjxcty8rk0tit	cmr254jmz00eojxcte6ki0dta	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00ywjxctd5j0xjp0	cmr254jja006rjxcty8rk0tit	cmr254jmz00eojxcte6ki0dta	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00yxjxct6h9t1epo	cmr254jja006rjxcty8rk0tit	cmr254jmz00eojxcte6ki0dta	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00yyjxct94h4ax5i	cmr254jja006rjxcty8rk0tit	cmr254jmz00eojxcte6ki0dta	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00yzjxcth2sm03pu	cmr254jja006sjxcth7kvuqn4	cmr254jmz00epjxcto4fixcff	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00z0jxctjmuk2pn5	cmr254jja006sjxcth7kvuqn4	cmr254jmz00epjxcto4fixcff	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00z1jxctgwh0mrjw	cmr254jja006sjxcth7kvuqn4	cmr254jmz00epjxcto4fixcff	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00z2jxctquy3ff3v	cmr254jja006sjxcth7kvuqn4	cmr254jmz00epjxcto4fixcff	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00z3jxctnyp2rvtd	cmr254jja006sjxcth7kvuqn4	cmr254jmz00epjxcto4fixcff	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00z4jxctgca8vs01	cmr254jja006tjxct50nal3zr	cmr254jmz00eqjxctbwpkwet9	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00z5jxctufuhg0ln	cmr254jja006tjxct50nal3zr	cmr254jmz00eqjxctbwpkwet9	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00z6jxctqmdqkzhv	cmr254jja006tjxct50nal3zr	cmr254jmz00eqjxctbwpkwet9	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00z7jxctrvduidav	cmr254jja006tjxct50nal3zr	cmr254jmz00eqjxctbwpkwet9	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00z8jxct3jm33vfr	cmr254jja006tjxct50nal3zr	cmr254jmz00eqjxctbwpkwet9	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00z9jxctp4iru4oj	cmr254jja006ujxct5n3k0suz	cmr254jmz00erjxctbf0uanpt	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00zajxctspd5bjd5	cmr254jja006ujxct5n3k0suz	cmr254jmz00erjxctbf0uanpt	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00zbjxctdfnr4mhc	cmr254jja006ujxct5n3k0suz	cmr254jmz00erjxctbf0uanpt	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00zcjxctf24ym1p3	cmr254jja006ujxct5n3k0suz	cmr254jmz00erjxctbf0uanpt	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00zdjxctn99m7456	cmr254jja006ujxct5n3k0suz	cmr254jmz00erjxctbf0uanpt	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00zejxcte04afkxs	cmr254jja006vjxctym6hgo8f	cmr254jmz00esjxctwpzomzgd	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00zfjxctsh705g05	cmr254jja006vjxctym6hgo8f	cmr254jmz00esjxctwpzomzgd	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00zgjxctq96khi6p	cmr254jja006vjxctym6hgo8f	cmr254jmz00esjxctwpzomzgd	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00zhjxct8m50eauu	cmr254jja006vjxctym6hgo8f	cmr254jmz00esjxctwpzomzgd	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00zijxctxksseaeh	cmr254jja006vjxctym6hgo8f	cmr254jmz00esjxctwpzomzgd	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00zjjxct8dur9o26	cmr254jja006wjxctjae4lmci	cmr254jmz00etjxctiq30vbtb	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00zkjxcter8jn3e3	cmr254jja006wjxctjae4lmci	cmr254jmz00etjxctiq30vbtb	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00zljxctt6v52ton	cmr254jja006wjxctjae4lmci	cmr254jmz00etjxctiq30vbtb	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00zmjxct9i73klx0	cmr254jja006wjxctjae4lmci	cmr254jmz00etjxctiq30vbtb	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00znjxctgotb7eml	cmr254jja006wjxctjae4lmci	cmr254jmz00etjxctiq30vbtb	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00zojxcte7wwtudn	cmr254jja006xjxctrvbog7ot	cmr254jmz00eujxcto4n7ckhs	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00zpjxct7h1lcrzi	cmr254jja006xjxctrvbog7ot	cmr254jmz00eujxcto4n7ckhs	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00zqjxctkzs5x5xk	cmr254jja006xjxctrvbog7ot	cmr254jmz00eujxcto4n7ckhs	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00zrjxctzs727plu	cmr254jja006xjxctrvbog7ot	cmr254jmz00eujxcto4n7ckhs	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00zsjxctau729e1u	cmr254jjb006yjxcttsje3ebg	cmr254jmz00evjxct1do1n0u8	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00ztjxctr00xr3d8	cmr254jjb006yjxcttsje3ebg	cmr254jmz00evjxct1do1n0u8	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00zujxct6vcf3pkh	cmr254jjb006yjxcttsje3ebg	cmr254jmz00evjxct1do1n0u8	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00zvjxcta211m7hu	cmr254jjb006yjxcttsje3ebg	cmr254jmz00evjxct1do1n0u8	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00zwjxctl1l0hsbp	cmr254jjb006zjxctj6g8mblk	cmr254jmz00ewjxctzbc73ne1	1	in_progress	2026-07-01 13:57:55.77	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00zxjxctjhzzr6c2	cmr254jjb006zjxctj6g8mblk	cmr254jmz00ewjxctzbc73ne1	2	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00zyjxctgirsws2k	cmr254jjb006zjxctj6g8mblk	cmr254jmz00ewjxctzbc73ne1	3	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw00zzjxctwce1q734	cmr254jjb006zjxctj6g8mblk	cmr254jmz00ewjxctzbc73ne1	4	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmr254jpw0100jxctdihezugr	cmr254jjb006zjxctj6g8mblk	cmr254jmz00ewjxctzbc73ne1	5	locked	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-07-01 13:57:55.783	2026-07-01 13:57:55.783
cmqep6tak00tbjxp5pr69czif	cmqep6t7y00hijxp5mgitskzp	cmqep6t9500kcjxp5ckg6g2ce	5	completed	2026-06-26 08:52:01.779	2026-07-03 09:26:10.975	2026-07-03 09:26:04.215	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:26:10.976
cmqep6tai00pwjxp5375oozbj	cmqep6t7y00gfjxp567zr1gct	cmqep6t9400j9jxp5qsnw08cm	5	completed	2026-06-26 08:52:20.682	2026-07-03 09:26:40.583	2026-07-03 09:26:27.059	cmq0kyw85007kjx239k25z1ge	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:26:40.584
cmqep6taj00s9jxp5bnhzmr9q	cmqep6t7y00h5jxp53x65440u	cmqep6t9500jzjxp5mvj6bhcg	5	completed	2026-06-26 08:59:36.673	2026-07-03 09:26:42.364	2026-07-03 09:26:40.421	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:26:42.365
cmqep6taj00rzjxp5ityje44g	cmqep6t7y00h2jxp5gb0okmzi	cmqep6t9500jwjxp5qugh2ett	5	completed	2026-06-26 08:53:23.548	2026-07-03 09:27:26.158	2026-07-03 09:27:24	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:27:26.159
cmqep6tai00r8jxp5dec6e0np	cmqep6t7y00gtjxp5zntc9qfk	cmqep6t9500jnjxp5yvcdf15m	5	completed	2026-06-26 08:45:12.264	2026-07-03 09:27:47.382	2026-07-03 09:27:37.578	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:27:47.383
cmqep6tai00r1jxp5yhr1zfi5	cmqep6t7y00grjxp5xaus94pp	cmqep6t9500jljxp5kexpgbim	5	completed	2026-06-26 08:47:07.069	2026-07-03 09:27:54.072	2026-07-03 09:27:41.538	cmq0kyw85007kjx239k25z1ge	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:27:54.073
cmqep6taj00sujxp5r6d0ibx1	cmqep6t7y00hcjxp5o0okg8br	cmqep6t9500k6jxp57h4lamza	5	completed	2026-06-26 08:47:40.414	2026-07-03 09:28:08.575	2026-07-03 09:28:05.493	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:28:08.576
cmqep6taj00t1jxp5905k7z9f	cmqep6t7y00hejxp5jx21o02o	cmqep6t9500k8jxp5f61o1mj3	5	completed	2026-06-26 08:50:58.036	2026-07-03 09:28:46.579	2026-07-03 09:28:38.609	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:28:46.58
cmqep6tak00thjxp578p80x21	cmqep6t7y00hkjxp50bymz2pu	cmqep6t9600kejxp53go2qb09	5	completed	2026-06-26 09:01:14.611	2026-07-03 09:28:55.218	2026-07-03 09:28:48.949	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:28:55.219
cmqep6taj00s6jxp50sckpr5x	cmqep6t7y00h4jxp5jet4udax	cmqep6t9500jyjxp5l5okhfmh	5	completed	2026-06-26 08:54:58.102	2026-07-03 09:29:33.177	2026-07-03 09:29:31.855	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:29:33.178
cmqep6tai00rbjxp5e4y0iv2n	cmqep6t7y00gvjxp59jqt3gqm	cmqep6t9500jpjxp5enw820v2	5	completed	2026-06-26 08:46:48.318	2026-07-03 09:31:24.545	2026-07-03 09:31:21.147	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:31:24.546
cmqep6taj00scjxp5b9obj5gb	cmqep6t7y00h6jxp5lq2ohp8z	cmqep6t9500k0jxp51dcqlx2y	5	completed	2026-06-26 08:59:12.139	2026-07-03 09:31:44.067	2026-07-03 09:31:42.595	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:31:44.068
cmqep6tai00q2jxp5cetek9dm	cmqep6t7y00ghjxp58tgg12zq	cmqep6t9500jbjxp5vxqfjko9	5	completed	2026-06-26 08:45:51.063	2026-07-03 09:32:14.357	2026-07-03 09:32:12.046	cmq0kyw85007kjx239k25z1ge	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:32:14.358
cmqep6tak00t4jxp54u256vum	cmqep6t7y00hgjxp51uc3pwty	cmqep6t9500kajxp58wj2pelo	5	completed	2026-06-26 08:56:06.051	2026-07-03 09:33:50.31	2026-07-03 09:33:49.124	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:33:50.311
cmqep6taf00lkjxp54s8m5lpa	cmqep6t7x00f3jxp5synf5gsg	cmqep6t9300hxjxp5p4kf2gyr	5	completed	2026-06-26 09:55:26.067	2026-07-03 09:34:44.324	2026-07-03 09:34:40.921	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:34:44.325
cmqep6tah00pkjxp5hh1kmg4e	cmqep6t7y00gbjxp5vsmxgz5z	cmqep6t9400j5jxp51vflwpcv	5	completed	2026-06-26 08:49:31.744	2026-07-03 09:35:10.309	2026-07-03 09:35:06.762	cmq0kyw85007kjx239k25z1ge	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:35:10.31
cmqep6tae00kqjxp5brhrwadq	cmqep6t7x00eujxp5wceys9yo	cmqep6t9300hojxp5466nswgb	5	completed	2026-06-26 09:50:52.064	2026-07-03 09:37:12.139	2026-07-03 09:37:09.899	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:37:12.14
cmqep6tae00lcjxp5ec3jc2zw	cmqep6t7x00f1jxp5twcea6w7	cmqep6t9300hvjxp5teazesc6	5	completed	2026-06-26 09:37:14.838	2026-07-03 09:37:17.16	2026-07-03 09:37:11.299	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:37:17.16
cmqep6tae00l9jxp59m4p4m2r	cmqep6t7x00f0jxp5gvfwi04n	cmqep6t9300hujxp557oed88p	5	completed	2026-06-26 09:17:59.457	2026-07-03 09:39:13.074	2026-07-03 09:39:06.903	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:39:13.074
cmqep6tae00l0jxp597apocg0	cmqep6t7x00exjxp5g48uiw9v	cmqep6t9300hrjxp5teg19y90	5	completed	2026-06-26 09:52:08.05	2026-07-03 09:39:50	2026-07-03 09:39:48.727	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:39:50.001
cmqep6tag00nojxp54qeklzd4	cmqep6t7x00frjxp5y0vdu581	cmqep6t9400iljxp56hadyq5z	5	completed	2026-06-26 09:57:10.921	2026-07-03 09:40:07.421	2026-07-03 09:40:05.499	cmq0kyw85007kjx239k25z1ge	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:40:07.422
cmqep6tae00l3jxp59jwixvk8	cmqep6t7x00eyjxp55zwq78jl	cmqep6t9300hsjxp5mqoxbs0l	5	completed	2026-06-26 09:32:55.295	2026-07-03 09:40:15.725	2026-07-03 09:40:14.379	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:40:15.726
cmqep6tah00oljxp5r8itap6y	cmqep6t7x00g0jxp5x3rr3z29	cmqep6t9400iujxp5aln74t2r	5	completed	2026-06-26 09:56:51.999	2026-07-03 09:41:34.538	2026-07-03 09:41:32.753	cmq0kyw85007kjx239k25z1ge	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:41:34.539
cmqep6tah00oxjxp527wpufzq	cmqep6t7y00g4jxp56txcwtrq	cmqep6t9400iyjxp5rtvgdkja	5	completed	2026-06-26 09:54:57.186	2026-07-03 09:43:26.474	2026-07-03 09:43:23.184	cmq0kyw85007kjx239k25z1ge	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:43:26.474
cmqep6tai00qrjxp579ubd8aj	cmqep6t7y00gojxp5v1t19fiv	cmqep6t9500jijxp5fmhyucyx	5	in_progress	2026-07-03 09:48:27.182	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:48:27.183
cmqep6tak00t8jxp54fokumvh	cmqep6t7y00hhjxp595rvk6sq	cmqep6t9500kbjxp5qesv8hdv	5	in_progress	2026-07-03 09:50:05.414	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:50:05.415
cmqf02tx9006gjxopt0bzqrku	cmqf02twi005vjxoph6si1y7m	cmqf02twx0064jxops0zutopk	5	in_progress	2026-07-03 09:50:30.691	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 09:17:55.581	2026-07-03 09:50:30.691
cmqep6taj00rfjxp556lbcksb	cmqep6t7y00gwjxp50vs32gfn	cmqep6t9500jqjxp55fr44i9j	4	in_progress	2026-07-03 09:50:32.035	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:50:32.036
cmqep6taj00rmjxp5vkofbybn	cmqep6t7y00gzjxp5ymu2sdwq	cmqep6t9500jtjxp5auvusch8	3	completed	2026-06-26 09:08:05.815	2026-07-03 09:52:18.276	2026-07-03 09:51:51.492	cmq0kyw85007kjx239k25z1ge	พูดคุยและให้กำลัง	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:52:18.277
cmqf02txa006jjxop2t5johuq	cmqf02twi005wjxop1suc7kpd	cmqf02twx0065jxopks12xh9e	3	completed	2026-06-26 09:04:30.87	2026-07-03 09:52:18.533	2026-07-03 09:52:13.887	cmq0khs5m000wjx23jyhqhgkv	\N	\N	\N	\N	\N	2026-06-15 09:17:55.581	2026-07-03 09:52:18.534
cmqep6taj00srjxp5tqiqtjgg	cmqep6t7y00hbjxp5na2uvdzn	cmqep6t9500k5jxp5jdi00gvp	5	in_progress	2026-07-03 09:56:00.8	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:56:00.8
cmqep6taj00sxjxp5ko4xmkbz	cmqep6t7y00hdjxp51yn11mxr	cmqep6t9500k7jxp51y56x4wo	3	completed	2026-06-26 09:02:37.197	2026-07-03 09:54:19.444	2026-07-03 09:52:11.049	cmq0kyw85007kjx239k25z1ge	เป็นกำลังให้ในการมาเรียน	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:54:19.445
cmqep6taj00sijxp5cpdan6yd	cmqep6t7y00h9jxp5ov6rpkzw	cmqep6t9500k3jxp52ot5274r	3	completed	2026-06-26 09:09:30.615	2026-07-03 09:55:02.59	2026-07-03 09:54:17.77	cmq0kyw85007kjx239k25z1ge	พูดคุยและปรับความคิด เสริมสร้างกำลังใจ	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:55:02.591
cmqep6taj00rujxp501ikz7ac	cmqep6t7y00h1jxp5kcbzvnst	cmqep6t9500jvjxp5bt8vbsww	3	completed	2026-06-26 09:12:26.901	2026-07-03 09:57:02.14	2026-07-03 09:56:25.054	cmq0kyw85007kjx239k25z1ge	พูดคุยและเสริมสร้างกำลังใจ	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:57:02.141
cmqep6tai00qljxp5ut870xat	cmqep6t7y00gnjxp50tru9y0t	cmqep6t9500jhjxp5ee6zin61	3	completed	2026-06-26 09:07:12.294	2026-07-03 09:59:35.495	2026-07-03 09:59:34.335	cmq0khs5m000wjx23jyhqhgkv	ปรับแนวคิดในสถานการณ์เป็นแบบที่เป็นด้านบวก ให้คำแนะนำโดยกระบวนการแซนวิซ	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 09:59:35.496
cmqep6tai00q5jxp52u66o161	cmqep6t7y00gjjxp59b9xkcrz	cmqep6t9500jdjxp5plj8wi0g	3	completed	2026-06-26 08:56:05.311	2026-07-03 10:01:31.372	2026-07-03 10:01:29.799	cmq0khs5m000wjx23jyhqhgkv	ให้ดูแลสุขภาพตัวเองมากขึ้น	\N	\N	\N	\N	2026-06-15 04:13:05.602	2026-07-03 10:01:31.373
\.


--
-- Data for Name: counseling_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.counseling_sessions (id, "studentId", "sessionNumber", "sessionDate", "counselorName", summary, "createdById", "createdAt", "updatedAt", "academicYearId") FROM stdin;
cmpav2c2u000fjxm5hod1snrg	cmpauvmyx0004jxm5zwck4o1s	1	2026-05-18 00:00:00	ไม่ได้เลือกโว้ย	ไปตายซะ ไอ้เวร !!!	cmp6j8ifp0002jxdffdiyvvw3	2026-05-18 07:06:47.334	2026-05-18 07:06:47.334	\N
cmpgszbga0009jx9d4dm4uhzv	cmpauvmyx0004jxm5zwck4o1s	2	2026-05-22 00:00:00	ไปตายซะ	ไอ้หนู ไอ้เวรรรรรร	cmp6j8ifp0002jxdffdiyvvw3	2026-05-22 10:55:04.379	2026-05-22 10:55:04.379	cmp6j4rh20002jxuik5drdqtt
cmpgtczyl0011jx9d0n86e2bx	cmp6jb4ux000kjxdfnh0bkm21	1	2026-05-22 00:00:00	คดสแว	วกวสสแวงกงงกงงกวปววกใก	cmp6j8ifp0002jxdffdiyvvw3	2026-05-22 11:05:42.669	2026-05-22 11:05:42.669	cmp6j4rh20002jxuik5drdqtt
\.


--
-- Data for Name: home_visit_photos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.home_visit_photos (id, "homeVisitId", "fileName", "fileUrl", "fileType", "fileSize", "uploadedAt", "idempotencyKey") FROM stdin;
cmpgt2kjf000djx9d3ir5h3n7	cmpgt2etp000bjx9df4aqnjjh	1000030960.jpg	/api/uploads/home-visits/cmpauvmyx0004jxm5zwck4o1s_visit_1779447456122.jpg	image/jpeg	259315	2026-05-22 10:57:36.124	\N
cmpnkws9n0007jx5q1q8ct8zg	cmpnkw8yf0005jx5qv3e1biam	NHFapp_logo.png	/api/uploads/home-visits/cmpauvmyx0004jxm5zwck4o1s_visit_1779857012506.png	image/png	21777	2026-05-27 04:43:32.508	\N
cmpnkx36a0009jx5q7gqx19en	cmpnkw8yf0005jx5qv3e1biam	burnout.png	/api/uploads/home-visits/cmpauvmyx0004jxm5zwck4o1s_visit_1779857026641.png	image/png	455235	2026-05-27 04:43:46.643	\N
\.


--
-- Data for Name: home_visits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.home_visits (id, "studentId", "visitNumber", "visitDate", description, "nextScheduledDate", "teacherName", "teacherRole", "createdById", "createdAt", "updatedAt", "academicYearId") FROM stdin;
cmpgt2etp000bjx9df4aqnjjh	cmpauvmyx0004jxm5zwck4o1s	1	2026-05-22 00:00:00	หนูควายยยยยยยยยย	2026-05-29 00:00:00	หนูทิน จะรวยแล้ว	ครูนางฟ้า	cmp6j8ifp0002jxdffdiyvvw3	2026-05-22 10:57:28.717	2026-05-22 10:57:28.717	cmp6j4rh20002jxuik5drdqtt
cmpnkw8yf0005jx5qv3e1biam	cmpauvmyx0004jxm5zwck4o1s	2	2026-05-27 00:00:00	บ้านบึ้มมมมมมมมมมมม	\N	หนูทิน จะรวยแล้ว	ครูนางฟ้า	cmp6j8ifp0002jxdffdiyvvw3	2026-05-27 04:43:07.479	2026-05-27 04:43:07.479	cmp6j4rh20002jxuik5drdqtt
\.


--
-- Data for Name: password_reset_token; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.password_reset_token (id, email, token, "expiresAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: phq_results; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phq_results (id, "studentId", "academicYearId", "importedById", "assessmentRound", q1, q2, q3, q4, q5, q6, q7, q8, q9, q9a, q9b, "totalScore", "riskLevel", "referredToHospital", "hospitalName", "createdAt") FROM stdin;
cmp6jb4v8000njxdfwyjjo1sz	cmp6jb4ux000jjxdf1gpsl39s	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	1	0	1	0	0	1	0	0	0	f	f	3	blue	f	\N	2026-05-15 06:26:37.796
cmp6jb4v8000ojxdf7u9738jx	cmp6jb4ux000kjxdfnh0bkm21	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	2	1	1	0	1	0	0	1	0	f	f	6	green	f	\N	2026-05-15 06:26:37.796
cmp6jb4v8000pjxdf02n9n7al	cmp6jb4ux000ljxdf32u2b13l	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	0	0	0	0	0	0	0	0	0	f	f	0	blue	f	\N	2026-05-15 06:26:37.796
cmp6jb4v8000qjxdfgf02117g	cmp6jb4ux000mjxdf5pxamnft	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	2	2	2	1	2	1	1	2	2	f	f	15	orange	f	\N	2026-05-15 06:26:37.796
cmpauvmz50005jxm5rgnfbphy	cmpauvmyx0004jxm5zwck4o1s	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	0	1	2	3	0	1	2	3	0	f	f	12	yellow	f	\N	2026-05-18 07:01:34.866
cmpjfwomt0027jx2mi41xo6dn	cmpjfwomm0023jx2mkak9orx7	cmp6j4rh20002jxuik5drdqtt	cmpjfu3b60016jx2mszo9avsp	1	0	1	1	1	0	0	1	0	0	t	f	4	red	f	\N	2026-05-24 07:12:25.013
cmpjfwomt0028jx2mc8hh6dsk	cmpjfwomm0024jx2msn5sgb52	cmp6j4rh20002jxuik5drdqtt	cmpjfu3b60016jx2mszo9avsp	1	1	1	0	1	0	0	1	0	0	f	f	4	blue	f	\N	2026-05-24 07:12:25.013
cmpjfwomt0029jx2mcob8ec5y	cmpjfwomm0025jx2mqp2sarfq	cmp6j4rh20002jxuik5drdqtt	cmpjfu3b60016jx2mszo9avsp	1	0	1	0	1	1	0	1	0	0	f	f	4	blue	f	\N	2026-05-24 07:12:25.013
cmpjfwomt002ajx2ml4olpqtd	cmpjfwomm0026jx2m2dnegu2z	cmp6j4rh20002jxuik5drdqtt	cmpjfu3b60016jx2mszo9avsp	1	1	1	1	1	0	1	1	0	0	f	f	6	green	f	\N	2026-05-24 07:12:25.013
cmprve8lv001sjx5qyklkol0k	cmprve8l5000xjx5q8yfs30hz	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	0	1	0	1	0	0	1	0	0	f	f	3	blue	f	\N	2026-05-30 04:48:07.699
cmprve8lv001tjx5qsk7gp8bh	cmprve8l5000yjx5qxjdz6rp8	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	1	1	0	1	1	1	1	0	0	f	f	6	green	f	\N	2026-05-30 04:48:07.699
cmprve8lv001ujx5qktpyxw9r	cmprve8l5000zjx5qnhtbywm5	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	0	2	1	1	3	0	3	2	3	t	t	15	red	f	\N	2026-05-30 04:48:07.699
cmprve8lv001vjx5qi5tqmg6p	cmprve8l50010jx5qlo0nyjtc	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	2	0	2	1	3	2	0	2	3	f	t	15	orange	f	\N	2026-05-30 04:48:07.699
cmprve8lv001wjx5qmywet7tj	cmprve8l50011jx5qhpm1dvmd	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	1	0	3	2	1	3	2	1	1	t	f	14	red	f	\N	2026-05-30 04:48:07.699
cmprve8lw001xjx5qrsnrzx1x	cmprve8l50012jx5qj6qlzxu9	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	0	3	1	2	3	1	0	3	2	f	f	15	orange	f	\N	2026-05-30 04:48:07.699
cmprve8lw001yjx5qvxwwhcyr	cmprve8l50013jx5q08thkxep	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	2	3	0	2	3	2	2	1	0	f	f	15	orange	f	\N	2026-05-30 04:48:07.699
cmprve8lw001zjx5qb3z7l75d	cmprve8l50014jx5qsq8okhxj	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	0	0	1	1	0	0	2	2	3	t	t	9	red	f	\N	2026-05-30 04:48:07.699
cmprve8lw0020jx5qojudcgar	cmprve8l50015jx5qtqhy3p8l	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	3	0	1	3	1	3	2	2	1	t	f	16	red	f	\N	2026-05-30 04:48:07.699
cmprve8lw0021jx5q61j5gsrh	cmprve8l50016jx5qimkh5tot	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	3	3	3	3	3	0	0	3	2	t	f	20	red	f	\N	2026-05-30 04:48:07.699
cmprve8lw0022jx5q17ojvv2g	cmprve8l50017jx5qc1g3ryzt	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	3	0	3	1	3	0	2	0	3	f	f	15	orange	f	\N	2026-05-30 04:48:07.699
cmprve8lw0023jx5q1rou1e2j	cmprve8l50018jx5q45abost6	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	3	1	3	1	3	0	0	3	3	f	f	17	orange	f	\N	2026-05-30 04:48:07.699
cmprve8lw0024jx5qor5979de	cmprve8l50019jx5qyzrvi13i	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	1	1	3	1	0	1	1	3	1	f	f	12	yellow	f	\N	2026-05-30 04:48:07.699
cmprve8lw0025jx5qjaoxyfxp	cmprve8l5001ajx5qewbyvflm	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	2	2	3	2	2	1	0	3	0	f	f	15	orange	f	\N	2026-05-30 04:48:07.699
cmprve8lw0026jx5q4v0ioe5z	cmprve8l5001bjx5qvwvekbo3	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	1	0	1	3	3	3	1	0	1	f	t	13	yellow	f	\N	2026-05-30 04:48:07.699
cmprve8lw0027jx5q18bf5xl8	cmprve8l5001cjx5qpmcf03xl	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	2	2	2	0	3	1	0	3	2	f	f	15	orange	f	\N	2026-05-30 04:48:07.699
cmprve8lw0029jx5ql8ykr8pd	cmprve8l5001ejx5qyacdv8ge	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	2	0	0	2	1	1	2	2	2	f	f	12	yellow	f	\N	2026-05-30 04:48:07.699
cmprve8lw002ajx5qtjgwem32	cmprve8l5001fjx5qwrwbswpu	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	0	0	1	0	3	2	3	3	2	f	f	14	yellow	f	\N	2026-05-30 04:48:07.699
cmprve8lw002bjx5qcy63me5z	cmprve8l5001gjx5qqjjvx9qi	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	1	0	3	2	3	0	2	2	3	f	t	16	orange	f	\N	2026-05-30 04:48:07.699
cmprve8lw002cjx5qutnavt4a	cmprve8l5001hjx5qbvppe3pc	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	0	3	0	2	1	1	3	2	1	f	f	13	yellow	f	\N	2026-05-30 04:48:07.699
cmprve8lw002djx5q3sq3nnvx	cmprve8l5001ijx5q2rbnbp6b	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	3	0	0	3	2	2	1	0	1	t	t	12	red	f	\N	2026-05-30 04:48:07.699
cmprve8lw002ejx5qjdoa7scn	cmprve8l5001jjx5qp7ocohgz	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	3	0	3	0	3	0	1	2	2	f	t	14	yellow	f	\N	2026-05-30 04:48:07.699
cmprve8lw002fjx5qk5yjz3mt	cmprve8l5001kjx5qops1z6t7	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	0	1	0	2	3	3	1	3	0	t	t	13	red	f	\N	2026-05-30 04:48:07.699
cmprve8lw002gjx5qio594g89	cmprve8l5001ljx5q0277mh23	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	2	2	0	0	1	0	1	1	0	f	f	7	green	f	\N	2026-05-30 04:48:07.699
cmprve8lw002hjx5q3cidqmox	cmprve8l5001mjx5qqybqucjk	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	0	1	3	0	3	1	3	3	1	f	f	15	orange	f	\N	2026-05-30 04:48:07.699
cmprve8lw002ijx5qgmmb9pq0	cmprve8l5001njx5qjladhnpl	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	1	2	0	1	3	0	2	2	3	f	f	14	yellow	f	\N	2026-05-30 04:48:07.699
cmprve8lw002jjx5qkqf1n4bi	cmprve8l5001ojx5q9dn40x1c	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	2	1	0	3	2	2	0	3	2	f	t	15	orange	f	\N	2026-05-30 04:48:07.699
cmprve8lw002kjx5qxq1ws06u	cmprve8l5001pjx5qzq4cy4y9	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	1	2	1	1	1	1	3	1	1	f	t	12	yellow	f	\N	2026-05-30 04:48:07.699
cmprve8lw002ljx5q13giaep5	cmprve8l5001qjx5qp9884e4i	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	3	0	1	2	0	0	1	1	0	t	t	8	red	f	\N	2026-05-30 04:48:07.699
cmprve8lw002mjx5qv7gja9cy	cmprve8l5001rjx5q3rtia0n1	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	3	3	2	2	2	3	1	0	2	t	f	18	red	f	\N	2026-05-30 04:48:07.699
cmpvn6ti6002yjxjcnxte9wjs	cmpvn6thw002kjxjc9nodq7ko	cmp6j4rh20002jxuik5drdqtt	cmpmdmbqv000kjxgmprk5t2o6	1	0	0	1	0	0	0	0	0	0	f	f	1	blue	f	\N	2026-06-01 20:09:29.311
cmpvn6ti6002zjxjcicffquf1	cmpvn6thw002ljxjch14i18id	cmp6j4rh20002jxuik5drdqtt	cmpmdmbqv000kjxgmprk5t2o6	1	1	0	0	0	1	0	1	0	0	f	f	3	blue	f	\N	2026-06-01 20:09:29.311
cmpvn6ti60030jxjc87yjxgqx	cmpvn6thw002mjxjc949hkrkq	cmp6j4rh20002jxuik5drdqtt	cmpmdmbqv000kjxgmprk5t2o6	1	0	1	0	0	0	0	1	0	0	f	f	2	blue	f	\N	2026-06-01 20:09:29.311
cmpvn6ti60031jxjcnkgbehbu	cmpvn6thw002njxjc3ne9m690	cmp6j4rh20002jxuik5drdqtt	cmpmdmbqv000kjxgmprk5t2o6	1	1	1	1	1	1	0	1	0	0	f	f	6	green	f	\N	2026-06-01 20:09:29.311
cmpvn6ti60032jxjc0ft8evyd	cmpvn6thw002ojxjci1w6vzmy	cmp6j4rh20002jxuik5drdqtt	cmpmdmbqv000kjxgmprk5t2o6	1	2	2	1	1	1	1	1	0	0	f	f	9	green	f	\N	2026-06-01 20:09:29.311
cmpvn6ti60033jxjc96zmm4j2	cmpvn6thw002pjxjcpvv8b9pu	cmp6j4rh20002jxuik5drdqtt	cmpmdmbqv000kjxgmprk5t2o6	1	3	3	2	2	2	1	1	1	0	f	f	15	orange	f	\N	2026-06-01 20:09:29.311
cmpvn6ti60034jxjcp3pxz447	cmpvn6thw002qjxjc4l7qikrp	cmp6j4rh20002jxuik5drdqtt	cmpmdmbqv000kjxgmprk5t2o6	1	0	0	0	0	0	0	0	0	0	t	f	0	red	f	\N	2026-06-01 20:09:29.311
cmpvn6ti70035jxjce67o4ssh	cmpvn6thw002rjxjcyujulgg9	cmp6j4rh20002jxuik5drdqtt	cmpmdmbqv000kjxgmprk5t2o6	1	0	0	1	0	0	0	0	0	0	f	f	1	blue	f	\N	2026-06-01 20:09:29.311
cmpvn6ti70036jxjcgnd4oks5	cmpvn6thw002sjxjcddl37umd	cmp6j4rh20002jxuik5drdqtt	cmpmdmbqv000kjxgmprk5t2o6	1	1	0	0	0	1	0	1	0	0	f	f	3	blue	f	\N	2026-06-01 20:09:29.311
cmpvn6ti70037jxjcb1ujrzzf	cmpvn6thx002tjxjck9twdrt3	cmp6j4rh20002jxuik5drdqtt	cmpmdmbqv000kjxgmprk5t2o6	1	1	1	1	1	1	0	1	0	0	f	f	6	green	f	\N	2026-06-01 20:09:29.311
cmpvn6ti70038jxjciazd9fky	cmpvn6thx002ujxjc5a4bxgmx	cmp6j4rh20002jxuik5drdqtt	cmpmdmbqv000kjxgmprk5t2o6	1	2	2	1	1	1	1	1	0	0	f	f	9	green	f	\N	2026-06-01 20:09:29.311
cmpvn6ti70039jxjcqu708176	cmpvn6thx002vjxjca96funyx	cmp6j4rh20002jxuik5drdqtt	cmpmdmbqv000kjxgmprk5t2o6	1	3	3	2	2	2	1	1	1	0	f	f	15	orange	f	\N	2026-06-01 20:09:29.311
cmpvn6ti7003ajxjcme5huedc	cmpvn6thx002wjxjca9hb7g61	cmp6j4rh20002jxuik5drdqtt	cmpmdmbqv000kjxgmprk5t2o6	1	0	0	0	0	0	0	0	0	0	f	t	0	blue	f	\N	2026-06-01 20:09:29.311
cmpvn6ti7003bjxjc4tyjq3hy	cmpvn6thx002xjxjcxmgelrm4	cmp6j4rh20002jxuik5drdqtt	cmpmdmbqv000kjxgmprk5t2o6	1	1	0	0	0	1	0	0	0	0	f	f	2	blue	f	\N	2026-06-01 20:09:29.311
cmqalpiam003ujxp5npq54s70	cmqalpi960012jxp5rhx9ouoz	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	2	2	2	3	1	0	0	f	f	12	yellow	f	\N	2026-06-12 07:24:34.65
cmqalpiam003vjxp57o098r5p	cmqalpi960013jxp5wuog0od9	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	0	3	1	1	0	1	1	0	f	f	8	green	f	\N	2026-06-12 07:24:34.65
cmqalpiam003wjxp51a4ruaqh	cmqalpi960014jxp5tl5up5la	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	0	1	1	1	1	0	1	0	f	f	5	green	f	\N	2026-06-12 07:24:34.65
cmqalpiam003xjxp5112lq1ag	cmqalpi960015jxp5nwmfy5v6	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	1	1	1	1	1	0	f	f	8	green	f	\N	2026-06-12 07:24:34.65
cmqalpiam003yjxp5jbogpimw	cmqalpi960016jxp5cra084p3	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	0	0	1	1	0	1	0	f	f	5	green	f	\N	2026-06-12 07:24:34.65
cmqalpiam003zjxp51r2sl929	cmqalpi960017jxp50ebbggjc	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	1	1	3	2	3	1	f	f	14	yellow	f	\N	2026-06-12 07:24:34.65
cmqalpiam0040jxp52m7gpz3y	cmqalpi960018jxp5s4s050rb	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	0	1	0	0	1	0	0	0	f	f	3	blue	f	\N	2026-06-12 07:24:34.65
cmqalpiam0041jxp57hbxth85	cmqalpi960019jxp5ohtf7mj8	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	0	0	0	0	1	0	0	0	f	f	2	blue	f	\N	2026-06-12 07:24:34.65
cmqalpiam0042jxp5wovp55io	cmqalpi96001ajxp5uqzy8g52	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	2	2	1	2	1	0	2	0	f	f	11	yellow	f	\N	2026-06-12 07:24:34.65
cmqalpiam0043jxp5ymbn724y	cmqalpi96001bjxp51pogwo5i	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	0	1	0	1	1	1	0	0	f	f	4	blue	f	\N	2026-06-12 07:24:34.65
cmqalpiam0044jxp5xh6s3kj4	cmqalpi96001cjxp5trw9j8uz	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	0	1	0	1	1	1	0	0	f	f	5	green	f	\N	2026-06-12 07:24:34.65
cmqalpiam0045jxp52ztqcz08	cmqalpi96001djxp5bi4muyu5	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	0	1	2	1	2	0	2	1	t	f	10	red	f	\N	2026-06-12 07:24:34.65
cmqalpiam0046jxp5lemylaz7	cmqalpi96001ejxp5tx4hlxw5	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	0	1	1	0	1	0	0	0	f	f	4	blue	f	\N	2026-06-12 07:24:34.65
cmqalpiam0047jxp52gyzo52i	cmqalpi96001fjxp5lo3nxy35	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	1	1	1	0	1	0	0	0	f	f	4	blue	f	\N	2026-06-12 07:24:34.65
cmqalpiam0048jxp5j4jhr774	cmqalpi96001gjxp54ob73o79	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	3	0	3	1	2	2	1	1	1	f	f	14	yellow	f	\N	2026-06-12 07:24:34.65
cmqalpiam0049jxp5222k74tx	cmqalpi96001hjxp5d80gmqv6	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	0	1	0	1	1	0	1	0	f	f	5	green	f	\N	2026-06-12 07:24:34.65
cmqalpiam004ajxp51zvhqkmp	cmqalpi96001ijxp509o2ix3a	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	0	0	1	0	1	1	0	f	f	5	green	f	\N	2026-06-12 07:24:34.65
cmqalpiam004bjxp5mnlz6yx5	cmqalpi96001jjxp55llfe3nd	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	2	3	2	1	3	3	3	2	3	t	f	22	red	f	\N	2026-06-12 07:24:34.65
cmqalpiam004cjxp531zu2nlg	cmqalpi96001kjxp5tzyt114n	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	3	1	1	3	3	1	0	1	1	f	f	14	yellow	f	\N	2026-06-12 07:24:34.65
cmqalpian004djxp5gz7v0lt8	cmqalpi96001ljxp5lana3l03	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	3	2	1	1	1	3	1	2	1	f	f	15	orange	f	\N	2026-06-12 07:24:34.65
cmqalpian004ejxp511wcwaq7	cmqalpi96001mjxp5o6bktrmr	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	3	1	1	1	0	0	0	f	f	8	green	f	\N	2026-06-12 07:24:34.65
cmqalpian004fjxp5hx2oefbf	cmqalpi96001njxp5l2jh7n98	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	0	0	1	0	0	0	f	f	4	blue	f	\N	2026-06-12 07:24:34.65
cmqalpian004gjxp5s31fkbsf	cmqalpi96001ojxp57y0rd6s1	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	2	2	3	1	3	3	3	1	3	f	f	21	red	f	\N	2026-06-12 07:24:34.65
cmqalpian004hjxp5b5a7k1w3	cmqalpi96001pjxp5l0fi6jmt	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	3	1	3	3	3	1	1	3	0	f	f	18	orange	f	\N	2026-06-12 07:24:34.65
cmqalpian004ijxp5mlxqv566	cmqalpi96001qjxp528roaybt	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	2	1	2	1	1	2	1	t	t	12	red	f	\N	2026-06-12 07:24:34.65
cmqalpian004jjxp5505zeaon	cmqalpi96001rjxp588l8e3vd	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	1	1	0	1	1	1	0	0	f	f	5	green	f	\N	2026-06-12 07:24:34.65
cmqalpian004kjxp5aogjkn88	cmqalpi96001sjxp5vwnpfxot	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	0	1	2	1	2	0	f	f	9	green	f	\N	2026-06-12 07:24:34.65
cmqalpian004ljxp59c7tejh4	cmqalpi96001tjxp5fdpniekj	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	2	1	2	2	1	0	f	f	11	yellow	f	\N	2026-06-12 07:24:34.65
cmqalpian004mjxp5hiw9mn6x	cmqalpi96001ujxp5tu4c79kh	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	3	1	3	3	3	1	3	f	f	19	orange	f	\N	2026-06-12 07:24:34.65
cmqalpian004njxp57fc45mr1	cmqalpi97001vjxp5sdz06dbq	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	0	1	1	2	1	0	f	f	8	green	f	\N	2026-06-12 07:24:34.65
cmqalpian004ojxp5k7p6z47m	cmqalpi97001wjxp5xshf4tfm	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	0	0	0	1	1	0	f	f	5	green	f	\N	2026-06-12 07:24:34.65
cmqalpian004pjxp5934wheos	cmqalpi97001xjxp5j5wfn9ue	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	1	1	1	2	2	0	f	f	10	yellow	f	\N	2026-06-12 07:24:34.65
cmqalpian004qjxp5c2kv1zag	cmqalpi97001yjxp51saawq2l	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	0	1	0	1	1	0	2	0	f	f	6	green	f	\N	2026-06-12 07:24:34.65
cmqalpian004rjxp5b5hv7yyj	cmqalpi97001zjxp5qg7w9o1c	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	0	2	1	0	1	0	f	f	7	green	f	\N	2026-06-12 07:24:34.65
cmqalpian004sjxp5a9xuzxzn	cmqalpi970020jxp550e0ubo0	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	3	1	3	1	3	1	1	1	0	t	f	14	red	f	\N	2026-06-12 07:24:34.65
cmqalpian004tjxp5cpi62j7b	cmqalpi970021jxp56ic9dy79	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	0	1	0	0	1	0	1	0	f	f	3	blue	f	\N	2026-06-12 07:24:34.65
cmqalpian004ujxp5qf1h0wn0	cmqalpi970022jxp5miadisl2	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	1	1	2	1	1	0	f	f	9	green	f	\N	2026-06-12 07:24:34.65
cmqalpian004vjxp5a9omuzmp	cmqalpi970023jxp5fpz8b79i	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	0	1	0	1	1	1	0	0	t	t	5	red	f	\N	2026-06-12 07:24:34.65
cmqalpian004wjxp5jal8n4zr	cmqalpi970024jxp54fdsncne	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	2	1	3	2	2	3	1	1	0	f	f	15	orange	f	\N	2026-06-12 07:24:34.65
cmqalpian004xjxp5p0aoty6o	cmqalpi970025jxp5qkdn2a9m	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	0	1	0	0	1	0	f	f	5	green	f	\N	2026-06-12 07:24:34.65
cmqalpian004yjxp5lz4646e1	cmqalpi970026jxp588tncp69	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	3	3	1	2	1	1	1	1	t	f	14	red	f	\N	2026-06-12 07:24:34.65
cmqalpian004zjxp5lsaqfqk6	cmqalpi970027jxp5le03ql4h	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	0	0	1	1	0	0	0	f	f	4	blue	f	\N	2026-06-12 07:24:34.65
cmqalpian0050jxp5zsytjac3	cmqalpi970028jxp5qipn2get	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	0	0	0	0	1	0	0	0	f	f	2	blue	f	\N	2026-06-12 07:24:34.65
cmqalpian0051jxp50smslat2	cmqalpi970029jxp5r8fs4om9	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	0	1	1	1	1	0	1	0	f	f	5	green	f	\N	2026-06-12 07:24:34.65
cmqalpian0052jxp5pi1f2zu7	cmqalpi97002ajxp55fljalc9	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	3	1	1	0	1	2	1	1	0	f	f	10	yellow	f	\N	2026-06-12 07:24:34.65
cmqalpian0053jxp5802c2znx	cmqalpi97002bjxp5rl1agw32	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	3	1	3	2	0	0	1	0	1	t	f	11	red	f	\N	2026-06-12 07:24:34.65
cmqalpian0054jxp5qw1tp6gy	cmqalpi97002cjxp5z3aptjb3	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	2	3	2	1	2	3	2	1	1	t	t	17	red	f	\N	2026-06-12 07:24:34.65
cmqalpian0055jxp5v0oansfe	cmqalpi97002djxp56b8fbyjn	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	0	0	1	1	1	0	f	f	6	green	f	\N	2026-06-12 07:24:34.65
cmqalpian0056jxp5r9ybf8os	cmqalpi97002ejxp5rxc3b0a5	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	0	0	0	1	0	0	0	0	f	f	1	blue	f	\N	2026-06-12 07:24:34.65
cmqalpiao0057jxp5cfo5flhp	cmqalpi97002fjxp5l0e2p6zj	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	1	1	0	0	1	0	0	0	f	f	3	blue	f	\N	2026-06-12 07:24:34.65
cmqalpiao0058jxp5bind7wot	cmqalpi97002gjxp537vrw7ny	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	1	0	0	1	0	1	0	0	f	f	3	blue	f	\N	2026-06-12 07:24:34.65
cmqalpiao0059jxp504iv8faw	cmqalpi97002hjxp5m0gkg78j	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	1	1	0	1	0	0	0	0	f	f	3	blue	f	\N	2026-06-12 07:24:34.65
cmqalpiao005ajxp5zxrry8ix	cmqalpi97002ijxp5xf6xzhce	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	0	1	1	0	1	0	f	f	6	green	f	\N	2026-06-12 07:24:34.65
cmqalpiao005bjxp52c9chcnc	cmqalpi97002jjxp5lvxpic0x	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	2	3	1	2	1	1	2	1	t	t	14	red	f	\N	2026-06-12 07:24:34.65
cmqalpiao005cjxp5qph8q0wh	cmqalpi97002kjxp5soq40s2v	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	0	0	0	1	1	1	1	0	f	f	5	green	f	\N	2026-06-12 07:24:34.65
cmqalpiao005djxp5wzrfbgnd	cmqalpi97002ljxp5hhwzyzws	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	0	1	1	3	2	1	1	1	t	t	11	red	f	\N	2026-06-12 07:24:34.65
cmqalpiao005ejxp5sz1e80ev	cmqalpi97002mjxp5omcyzqus	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	0	0	3	1	1	1	f	f	9	green	f	\N	2026-06-12 07:24:34.65
cmqalpiao005fjxp5jcilvf3t	cmqalpi97002njxp581o7fm27	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	0	0	0	1	0	2	1	3	t	t	8	red	f	\N	2026-06-12 07:24:34.65
cmqalpiao005gjxp5vwrlk2xr	cmqalpi97002ojxp5z2jqvz3k	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	3	0	1	1	0	0	0	f	f	7	green	f	\N	2026-06-12 07:24:34.65
cmqalpiao005hjxp50adev3a8	cmqalpi97002pjxp5i6820dlh	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	0	2	1	1	2	1	f	f	10	yellow	f	\N	2026-06-12 07:24:34.65
cmqalpiao005ijxp58o1zxfoa	cmqalpi97002qjxp5cjavuhl8	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	2	1	1	3	3	1	1	0	t	f	13	red	f	\N	2026-06-12 07:24:34.65
cmqalpiao005jjxp5ksdvf6ff	cmqalpi97002rjxp5oe53oyfe	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	3	1	1	1	1	2	3	1	0	f	f	13	yellow	f	\N	2026-06-12 07:24:34.65
cmqalpiao005kjxp59h52pxpr	cmqalpi97002sjxp51p4tohag	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	0	1	3	1	0	1	f	f	9	green	f	\N	2026-06-12 07:24:34.65
cmqalpiao005ljxp5lpeau6s7	cmqalpi97002tjxp5ot7zb1bq	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	0	1	1	0	1	0	1	f	f	6	green	f	\N	2026-06-12 07:24:34.65
cmqalpiao005mjxp5dnfg54ew	cmqalpi97002ujxp5rvgdha4h	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	0	1	0	1	1	1	0	0	f	f	4	blue	f	\N	2026-06-12 07:24:34.65
cmqalpiao005njxp5bhfeh2gv	cmqalpi97002vjxp592oanqth	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	0	0	0	1	1	0	1	0	f	f	4	blue	f	\N	2026-06-12 07:24:34.65
cmqalpiao005ojxp5qyrboba4	cmqalpi97002wjxp5yfhgkmvu	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	0	1	2	3	0	0	1	2	f	f	10	yellow	f	\N	2026-06-12 07:24:34.65
cmqalpiao005pjxp5kpxd8gjk	cmqalpi97002xjxp5egkpnxmv	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	0	1	1	0	1	1	1	0	f	f	6	green	f	\N	2026-06-12 07:24:34.65
cmqalpiao005qjxp5dazelets	cmqalpi97002yjxp5kwr61ko6	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	1	1	2	1	1	1	f	t	10	red	f	\N	2026-06-12 07:24:34.65
cmqalpiao005rjxp55o95znp0	cmqalpi97002zjxp5i817qxzx	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	2	1	2	0	3	2	1	1	1	t	f	13	red	f	\N	2026-06-12 07:24:34.65
cmqalpiao005sjxp5rulk7n5y	cmqalpi970030jxp5glg0t3do	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	0	0	1	0	2	1	0	f	f	6	green	f	\N	2026-06-12 07:24:34.65
cmqalpiao005tjxp5qnk4oazd	cmqalpi970031jxp598n1gxtn	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	2	1	1	1	2	1	1	0	0	f	f	9	green	f	\N	2026-06-12 07:24:34.65
cmqalpiao005ujxp5tte5vgaq	cmqalpi970032jxp5p7sear8o	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	1	1	2	1	1	1	t	f	10	red	f	\N	2026-06-12 07:24:34.65
cmqalpiao005vjxp5n2hgv98t	cmqalpi970033jxp5s0tln28x	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	0	0	0	1	0	0	1	0	f	f	2	blue	f	\N	2026-06-12 07:24:34.65
cmqalpiao005wjxp5j2t1rj0j	cmqalpi970034jxp51mt5i7yj	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	3	1	1	1	3	2	3	1	0	f	f	15	orange	f	\N	2026-06-12 07:24:34.65
cmqalpiao005xjxp5wyj4bllb	cmqalpi970035jxp568lschn3	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	0	0	3	3	1	0	0	t	f	9	red	f	\N	2026-06-12 07:24:34.65
cmqalpiao005yjxp5gn43y8xs	cmqalpi970036jxp5nqcpucqm	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	2	2	1	1	1	0	3	3	t	t	14	red	f	\N	2026-06-12 07:24:34.65
cmqalpiao005zjxp5korr084z	cmqalpi970037jxp5tv1t3skz	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	3	1	0	3	0	1	f	f	11	yellow	f	\N	2026-06-12 07:24:34.65
cmqalpiap0060jxp5792o4veb	cmqalpi970038jxp54ol4raxk	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	0	1	0	2	3	0	0	0	f	f	6	green	f	\N	2026-06-12 07:24:34.65
cmqalpiap0061jxp5lpxrltwn	cmqalpi980039jxp5m07n54q4	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	2	1	1	1	0	3	2	t	f	12	red	f	\N	2026-06-12 07:24:34.65
cmqalpiap0062jxp5pabemo09	cmqalpi98003ajxp50mzuheex	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	1	1	1	1	1	1	1	0	f	f	7	green	f	\N	2026-06-12 07:24:34.65
cmqalpiap0063jxp52wwbs86z	cmqalpi98003bjxp5juah0t8r	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	2	0	1	2	1	0	0	f	f	8	green	f	\N	2026-06-12 07:24:34.65
cmqalpiap0064jxp54a4qcjxz	cmqalpi98003cjxp5qjgexcqv	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	2	0	1	1	1	0	0	f	f	7	green	f	\N	2026-06-12 07:24:34.65
cmqalpiap0065jxp5kuerrh50	cmqalpi98003djxp5q66ktksr	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	0	1	0	0	1	0	0	0	f	f	3	blue	f	\N	2026-06-12 07:24:34.65
cmqalpiap0066jxp5vk0svgk7	cmqalpi98003ejxp51tbimguj	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	2	1	1	0	3	2	1	1	1	t	f	12	red	f	\N	2026-06-12 07:24:34.65
cmqalpiap0067jxp50yrk8vvq	cmqalpi98003fjxp5cttap7kg	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	2	3	2	3	2	0	0	0	f	f	13	yellow	f	\N	2026-06-12 07:24:34.65
cmqalpiap0068jxp5qi1gn70f	cmqalpi98003gjxp557e7wlie	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	2	3	1	1	3	1	2	2	1	f	f	16	orange	f	\N	2026-06-12 07:24:34.65
cmqalpiap0069jxp5smss5gd6	cmqalpi98003hjxp5lfvhux50	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	1	1	1	1	0	0	f	f	7	green	f	\N	2026-06-12 07:24:34.65
cmqalpiap006ajxp58to58goj	cmqalpi98003ijxp5k1uwndsd	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	0	1	1	2	1	3	3	t	t	13	red	f	\N	2026-06-12 07:24:34.65
cmqalpiap006bjxp5zrg5vm61	cmqalpi98003jjxp5zbw16fo4	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	0	1	0	0	1	0	0	1	f	f	4	blue	f	\N	2026-06-12 07:24:34.65
cmqalpiap006cjxp5vb2j986z	cmqalpi98003kjxp5xicb7mfw	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	0	0	1	1	2	1	0	f	f	7	green	f	\N	2026-06-12 07:24:34.65
cmqalpiap006djxp5xpi9sy25	cmqalpi98003ljxp5s5sb19tr	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	1	1	1	1	1	0	f	f	8	green	f	\N	2026-06-12 07:24:34.65
cmqalpiap006ejxp5ik2avft6	cmqalpi98003mjxp5wd31a19h	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	0	0	1	3	2	2	f	f	11	yellow	f	\N	2026-06-12 07:24:34.65
cmqalpiap006fjxp5yha0vscy	cmqalpi98003njxp5d5xli0u8	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	2	1	3	2	3	1	1	1	0	f	f	14	yellow	f	\N	2026-06-12 07:24:34.65
cmqalpiap006gjxp51g05bzms	cmqalpi98003ojxp50yew7145	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	1	1	0	1	1	0	0	0	f	f	4	blue	f	\N	2026-06-12 07:24:34.65
cmqalpiap006hjxp5dbk9jxqw	cmqalpi98003pjxp5wlyaqmir	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	0	3	1	1	0	0	1	f	f	8	green	f	\N	2026-06-12 07:24:34.65
cmqalpiap006ijxp5j5xkrsld	cmqalpi98003qjxp5u7nbs1ow	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	2	3	3	3	2	2	1	0	f	f	17	orange	f	\N	2026-06-12 07:24:34.65
cmqalpiap006jjxp5unyi6g23	cmqalpi98003rjxp5ba48e688	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	3	3	1	1	1	1	0	t	f	12	red	f	\N	2026-06-12 07:24:34.65
cmqalpiap006kjxp5dmvq7qj7	cmqalpi98003sjxp5mamtm52a	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	0	1	0	0	0	1	0	f	f	4	blue	f	\N	2026-06-12 07:24:34.65
cmqalpiap006ljxp53beojhnj	cmqalpi98003tjxp5mlq4tasj	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	0	3	1	1	1	1	1	1	f	f	9	green	f	\N	2026-06-12 07:24:34.65
cmqcf7l4300dljxp5nlmr0p94	cmqcf7l3t00djjxp5hga3flde	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	0	1	0	0	1	0	1	1	1	f	f	5	green	f	\N	2026-06-13 13:58:13.155
cmqcf7l4300dmjxp59dznc6ta	cmqcf7l3t00dkjxp5b81qqau5	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	0	1	0	1	1	0	0	1	f	f	5	green	f	\N	2026-06-13 13:58:13.155
cmqep6t9300hljxp5tig3rlk1	cmqep6t7x00erjxp54fnk3xqy	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	1	1	1	1	1	0	0	f	f	7	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9300hmjxp57kf2hh40	cmqep6t7x00esjxp5cbdmqqex	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	0	1	1	1	1	1	1	0	0	f	f	6	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9300hnjxp5ojniwclr	cmqep6t7x00etjxp5oklc37y3	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	0	1	1	1	1	0	1	0	0	f	f	5	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9300hojxp5466nswgb	cmqep6t7x00eujxp5wceys9yo	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	0	2	1	0	0	1	0	0	f	f	5	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9300hpjxp5m0ic3656	cmqep6t7x00evjxp5vhoesa20	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	1	0	1	1	1	0	0	f	f	6	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9300hqjxp5w9e5hxew	cmqep6t7x00ewjxp58q8ujqlw	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	2	1	2	1	1	2	0	f	f	11	yellow	f	\N	2026-06-15 04:13:05.557
cmqep6t9300hrjxp5teg19y90	cmqep6t7x00exjxp5g48uiw9v	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	1	1	1	1	1	0	0	f	f	7	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9300hsjxp5mqoxbs0l	cmqep6t7x00eyjxp55zwq78jl	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	0	0	0	1	1	1	1	1	0	f	f	5	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9300htjxp5xv8jqt3o	cmqep6t7x00ezjxp5vlltxpho	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	1	1	0	1	1	0	1	f	f	7	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9300hujxp557oed88p	cmqep6t7x00f0jxp5gvfwi04n	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	0	1	1	0	1	1	0	1	0	f	f	5	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9300hvjxp5teazesc6	cmqep6t7x00f1jxp5twcea6w7	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	1	2	1	1	1	1	0	f	f	9	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9300hwjxp5k2345ah9	cmqep6t7x00f2jxp5sh03nooy	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	2	2	3	3	2	2	1	1	2	f	f	18	orange	f	\N	2026-06-15 04:13:05.557
cmqep6t9300hxjxp5p4kf2gyr	cmqep6t7x00f3jxp5synf5gsg	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	0	0	1	1	1	0	0	f	f	5	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9300hyjxp5dd1qz18y	cmqep6t7x00f4jxp5ifdridnj	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	2	1	3	1	2	1	1	0	1	f	f	12	yellow	f	\N	2026-06-15 04:13:05.557
cmqep6t9300hzjxp5z36ifwwm	cmqep6t7x00f5jxp5kn6gv1ni	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	2	1	0	0	2	0	0	f	f	7	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9300i0jxp58q6bdjuy	cmqep6t7x00f6jxp5ryay9b35	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	2	1	2	1	2	1	0	1	f	f	11	yellow	f	\N	2026-06-15 04:13:05.557
cmqep6t9300i1jxp596rewf7k	cmqep6t7x00f7jxp5l3oii2qb	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	0	0	1	1	1	1	1	f	f	7	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9300i2jxp5qo3m1pbo	cmqep6t7x00f8jxp55qj3x2vc	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	0	1	0	1	1	1	0	f	f	6	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9300i3jxp5puoo5th4	cmqep6t7x00f9jxp5wi3o0rdy	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	0	1	1	1	0	1	1	0	0	f	f	5	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9300i4jxp5qgsqj4cs	cmqep6t7x00fajxp59dpeqyun	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	1	0	1	0	0	0	0	f	f	4	blue	f	\N	2026-06-15 04:13:05.557
cmqep6t9300i5jxp543jcx65k	cmqep6t7x00fbjxp5c1fz5ppe	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	3	1	0	1	0	0	0	0	f	f	6	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9300i6jxp5titg9cgh	cmqep6t7x00fcjxp5slrtarvk	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	0	1	1	0	1	2	1	0	0	f	f	6	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9300i7jxp5czcjfas0	cmqep6t7x00fdjxp5phrwrenn	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	2	1	1	2	1	1	0	1	1	f	f	10	yellow	f	\N	2026-06-15 04:13:05.557
cmqep6t9400i8jxp575ybjipq	cmqep6t7x00fejxp5o7dl7di4	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	2	1	1	0	1	0	1	0	f	f	7	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9400i9jxp5v1vpi65s	cmqep6t7x00ffjxp5qxsn29jv	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	1	2	1	2	1	2	0	f	f	11	yellow	f	\N	2026-06-15 04:13:05.557
cmqep6t9400iajxp5szt1pb8v	cmqep6t7x00fgjxp5q4q2sqhp	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	2	0	3	1	1	1	1	0	f	f	10	yellow	f	\N	2026-06-15 04:13:05.557
cmqep6t9400ibjxp5g6u6nf0y	cmqep6t7x00fhjxp5fpnrj4l7	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	0	1	2	0	2	0	0	f	f	7	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9400icjxp563x2ubdm	cmqep6t7x00fijxp5jyyrjuz8	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	1	1	2	3	3	1	1	f	f	14	yellow	f	\N	2026-06-15 04:13:05.557
cmqep6t9400idjxp53hqq2voi	cmqep6t7x00fjjxp51to2rjq7	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	2	1	1	0	3	3	2	3	1	f	f	16	orange	f	\N	2026-06-15 04:13:05.557
cmqep6t9400iejxp54gkhmb1r	cmqep6t7x00fkjxp5dokcsihq	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	0	1	2	1	3	2	3	f	f	14	yellow	f	\N	2026-06-15 04:13:05.557
cmqep6t9400ifjxp53w1mo3fo	cmqep6t7x00fljxp5cyty19cb	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	2	1	1	0	1	1	1	1	1	f	f	9	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9400igjxp59oezn31z	cmqep6t7x00fmjxp5sc7vd876	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	1	0	0	0	0	0	0	f	f	3	blue	f	\N	2026-06-15 04:13:05.557
cmqep6t9400ihjxp5z57lkkn2	cmqep6t7x00fnjxp5bqhzrp6l	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	3	1	1	2	2	2	3	2	2	f	f	18	orange	f	\N	2026-06-15 04:13:05.557
cmqep6t9400iijxp5mlaav2n5	cmqep6t7x00fojxp52gwrmqld	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	0	0	1	0	0	0	0	0	0	f	f	1	blue	f	\N	2026-06-15 04:13:05.557
cmqep6t9400ijjxp59w5gpf1i	cmqep6t7x00fpjxp5afe8hyp4	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	2	3	0	1	3	2	1	1	f	f	14	yellow	f	\N	2026-06-15 04:13:05.557
cmqep6t9400ikjxp5hxoelt9l	cmqep6t7x00fqjxp5np9idghm	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	2	3	1	2	1	0	2	0	f	f	12	yellow	f	\N	2026-06-15 04:13:05.557
cmqep6t9400iljxp56hadyq5z	cmqep6t7x00frjxp5y0vdu581	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	2	1	0	1	0	0	0	0	f	f	5	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9400imjxp523k3l27b	cmqep6t7x00fsjxp5s3lf3hkn	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	2	3	2	1	3	1	3	1	0	f	f	16	orange	f	\N	2026-06-15 04:13:05.557
cmqep6t9400injxp5fr38gk7o	cmqep6t7x00ftjxp5qcd2510h	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	0	0	1	0	1	1	3	0	0	f	f	6	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9400iojxp535rm9rat	cmqep6t7x00fujxp5lzrwcrc9	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	1	1	0	1	0	0	0	f	f	5	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9400ipjxp5mi3lxvqs	cmqep6t7x00fvjxp5jwtduygo	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	3	1	2	1	2	3	1	2	3	f	f	18	orange	f	\N	2026-06-15 04:13:05.557
cmqep6t9400iqjxp5ray5vlwm	cmqep6t7x00fwjxp5he7659eh	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	2	1	2	2	3	1	0	f	f	13	yellow	f	\N	2026-06-15 04:13:05.557
cmqep6t9400irjxp5sljdpq11	cmqep6t7x00fxjxp5n1r9qyq3	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	2	2	1	2	3	3	2	3	3	f	f	21	red	f	\N	2026-06-15 04:13:05.557
cmqep6t9400isjxp5q3gysgu2	cmqep6t7x00fyjxp5gd0tiz6q	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	3	2	1	1	1	1	2	3	3	f	f	17	orange	f	\N	2026-06-15 04:13:05.557
cmqep6t9400itjxp58wqnqblq	cmqep6t7x00fzjxp54fjcjtah	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	3	2	3	3	1	3	1	1	2	f	f	19	orange	f	\N	2026-06-15 04:13:05.557
cmqep6t9400iujxp5aln74t2r	cmqep6t7x00g0jxp5x3rr3z29	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	2	2	1	0	1	0	0	f	f	8	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9400ivjxp5t3h4go5l	cmqep6t7x00g1jxp5xksr1is3	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	1	1	1	1	1	0	0	f	f	7	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9400iwjxp5r5qe1j3u	cmqep6t7x00g2jxp55u0n4faa	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	0	0	0	1	0	1	1	f	f	5	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9400ixjxp5vstdjxdp	cmqep6t7y00g3jxp5y3q080vj	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	1	3	1	1	1	0	0	f	f	9	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9400iyjxp5rtvgdkja	cmqep6t7y00g4jxp56txcwtrq	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	1	0	1	0	1	0	0	f	f	5	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9400izjxp5kkrzband	cmqep6t7y00g5jxp53scmw13t	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	2	3	3	3	1	2	1	2	1	f	f	18	orange	f	\N	2026-06-15 04:13:05.557
cmqep6t9400j0jxp5yejmpcsg	cmqep6t7y00g6jxp5voah6fkg	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	2	1	1	1	1	1	1	0	f	f	9	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9400j1jxp5niy42x68	cmqep6t7y00g7jxp5dadbmh4c	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	1	0	1	0	1	0	0	f	f	5	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9400j2jxp58h2t12fu	cmqep6t7y00g8jxp5e5io1j25	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	1	1	2	0	2	0	0	f	f	8	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9400j3jxp5vvixk3ea	cmqep6t7y00g9jxp5yihqococ	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	0	1	1	0	1	0	1	0	f	f	5	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9400j4jxp52hwv21c8	cmqep6t7y00gajxp56csicf0x	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	0	1	1	1	3	1	1	0	0	f	f	8	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9400j5jxp51vflwpcv	cmqep6t7y00gbjxp5vsmxgz5z	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	0	1	1	0	2	0	1	0	1	f	f	6	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9400j6jxp54seruv6b	cmqep6t7y00gcjxp545zm4dej	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	1	0	1	1	1	0	0	f	f	6	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9400j7jxp5zb2zuhrm	cmqep6t7y00gdjxp59lrmb5t2	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	0	1	0	1	0	1	0	f	f	5	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9400j8jxp57qqo0m42	cmqep6t7y00gejxp5hwiyumv6	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	1	0	3	1	1	0	0	f	f	8	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9400j9jxp5qsnw08cm	cmqep6t7y00gfjxp567zr1gct	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	0	0	1	0	3	0	1	2	0	f	f	7	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9400jajxp57smqjf8x	cmqep6t7y00ggjxp5lamjmi4s	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	2	2	1	0	1	1	0	0	0	f	f	7	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9500jbjxp5vxqfjko9	cmqep6t7y00ghjxp58tgg12zq	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	0	2	2	0	1	1	1	0	0	f	f	7	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9500jcjxp5bcghc5xw	cmqep6t7y00gijxp5hs7idnt2	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	2	1	2	3	2	3	3	3	2	f	f	21	red	f	\N	2026-06-15 04:13:05.557
cmqep6t9500jdjxp5plj8wi0g	cmqep6t7y00gjjxp59b9xkcrz	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	2	1	1	2	2	2	1	1	2	f	f	14	yellow	f	\N	2026-06-15 04:13:05.557
cmqep6t9500jejxp5atgprn20	cmqep6t7y00gkjxp5h4f0156z	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	2	1	3	1	1	0	0	f	f	10	yellow	f	\N	2026-06-15 04:13:05.557
cmqep6t9500jfjxp5vl7ugm1d	cmqep6t7y00gljxp5et9f6y0c	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	1	1	3	1	0	1	1	f	f	10	yellow	f	\N	2026-06-15 04:13:05.557
cmqep6t9500jgjxp54oyob17b	cmqep6t7y00gmjxp5w0cyfz8a	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	2	2	2	0	1	1	1	0	1	f	f	10	yellow	f	\N	2026-06-15 04:13:05.557
cmqep6t9500jhjxp5ee6zin61	cmqep6t7y00gnjxp50tru9y0t	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	3	2	3	1	2	3	1	1	3	f	f	19	orange	f	\N	2026-06-15 04:13:05.557
cmqep6t9500jijxp5fmhyucyx	cmqep6t7y00gojxp5v1t19fiv	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	2	3	3	1	1	1	0	f	f	13	yellow	f	\N	2026-06-15 04:13:05.557
cmqep6t9500jjjxp59xh7ckl7	cmqep6t7y00gpjxp5s7zduyel	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	2	1	2	1	1	2	1	2	f	f	13	yellow	f	\N	2026-06-15 04:13:05.557
cmqep6t9500jkjxp51baz0r1h	cmqep6t7y00gqjxp5i3yv7iln	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	1	0	2	0	1	2	0	f	f	8	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9500jljxp5kexpgbim	cmqep6t7y00grjxp5xaus94pp	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	1	1	1	1	0	1	1	f	f	8	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9500jmjxp5bsu40yub	cmqep6t7y00gsjxp5mtilww6e	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	1	0	3	3	3	2	0	f	f	14	yellow	f	\N	2026-06-15 04:13:05.557
cmqep6t9500jnjxp5yvcdf15m	cmqep6t7y00gtjxp5zntc9qfk	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	0	2	2	0	2	0	0	0	0	f	f	6	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9500jojxp5iov27q07	cmqep6t7y00gujxp58nym0q6l	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	0	0	1	0	1	0	1	1	0	f	f	4	blue	f	\N	2026-06-15 04:13:05.557
cmqep6t9500jpjxp5enw820v2	cmqep6t7y00gvjxp59jqt3gqm	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	2	2	1	0	0	0	0	0	f	f	6	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9500jqjxp55fr44i9j	cmqep6t7y00gwjxp50vs32gfn	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	0	2	3	1	2	1	3	0	3	f	f	15	orange	f	\N	2026-06-15 04:13:05.557
cmqep6t9500jrjxp5tlctw22f	cmqep6t7y00gxjxp5o36ncraj	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	0	0	1	0	0	0	1	0	0	f	f	2	blue	f	\N	2026-06-15 04:13:05.557
cmqep6t9500jsjxp5ef2erjmm	cmqep6t7y00gyjxp50orak3f8	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	0	0	2	0	1	1	1	0	0	f	f	5	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9500jtjxp5auvusch8	cmqep6t7y00gzjxp5ymu2sdwq	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	3	3	3	1	1	1	3	3	1	f	f	19	orange	f	\N	2026-06-15 04:13:05.557
cmqep6t9500jujxp5pardkvru	cmqep6t7y00h0jxp5b6k9d2ql	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	2	1	1	1	0	1	0	0	f	f	7	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9500jvjxp5bt8vbsww	cmqep6t7y00h1jxp5kcbzvnst	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	2	3	1	1	3	2	1	1	f	f	15	orange	f	\N	2026-06-15 04:13:05.557
cmqep6t9500jwjxp5qugh2ett	cmqep6t7y00h2jxp5gb0okmzi	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	0	0	1	1	1	1	1	0	0	f	f	5	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9500jxjxp5c9llkurt	cmqep6t7y00h3jxp5nsmq0bu1	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	2	1	2	1	0	0	2	f	f	10	yellow	f	\N	2026-06-15 04:13:05.557
cmqep6t9500jyjxp5l5okhfmh	cmqep6t7y00h4jxp5jet4udax	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	0	0	1	1	1	2	0	0	f	f	6	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9500jzjxp5mvj6bhcg	cmqep6t7y00h5jxp53x65440u	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	1	0	2	1	1	0	0	f	f	7	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9500k0jxp51dcqlx2y	cmqep6t7y00h6jxp5lq2ohp8z	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	1	0	1	0	1	0	0	f	f	5	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9500k1jxp5ntanhqsd	cmqep6t7y00h7jxp5aomv3xif	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	0	1	1	0	0	2	1	0	f	f	6	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9500k2jxp5l4m3ry0s	cmqep6t7y00h8jxp5zbds7y6i	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	0	0	1	1	1	0	1	0	0	f	f	4	blue	f	\N	2026-06-15 04:13:05.557
cmqep6t9500k3jxp52ot5274r	cmqep6t7y00h9jxp5ov6rpkzw	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	2	2	2	3	0	1	3	f	f	15	orange	f	\N	2026-06-15 04:13:05.557
cmqep6t9500k4jxp58jv5ogik	cmqep6t7y00hajxp53xjfiwp0	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	1	1	1	1	1	1	1	f	f	9	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9500k5jxp5jdi00gvp	cmqep6t7y00hbjxp5na2uvdzn	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	0	2	2	1	1	0	2	2	0	f	f	10	yellow	f	\N	2026-06-15 04:13:05.557
cmqep6t9500k6jxp57h4lamza	cmqep6t7y00hcjxp5o0okg8br	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	0	0	2	1	2	1	1	f	f	9	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9500k7jxp51y56x4wo	cmqep6t7y00hdjxp51yn11mxr	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	2	1	0	1	1	1	1	2	1	f	f	10	yellow	f	\N	2026-06-15 04:13:05.557
cmqep6t9500k8jxp5f61o1mj3	cmqep6t7y00hejxp5jx21o02o	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	1	0	1	1	1	2	0	f	f	8	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9500k9jxp5uhnpsge0	cmqep6t7y00hfjxp5s0yrlw9n	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	0	0	1	0	1	0	1	0	0	f	f	3	blue	f	\N	2026-06-15 04:13:05.557
cmqep6t9500kajxp58wj2pelo	cmqep6t7y00hgjxp51uc3pwty	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	2	1	0	2	2	0	0	1	0	f	f	8	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9500kbjxp5qesv8hdv	cmqep6t7y00hhjxp595rvk6sq	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	1	2	2	2	1	1	2	f	f	13	yellow	f	\N	2026-06-15 04:13:05.557
cmqep6t9500kcjxp5ckg6g2ce	cmqep6t7y00hijxp5mgitskzp	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	0	1	1	1	1	1	1	0	f	f	7	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9500kdjxp5zbtb2lnz	cmqep6t7y00hjjxp5xa6i02q3	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	1	1	1	0	1	1	1	f	f	8	green	f	\N	2026-06-15 04:13:05.557
cmqep6t9600kejxp53go2qb09	cmqep6t7y00hkjxp50bymz2pu	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	2	0	1	1	1	1	1	f	f	9	green	f	\N	2026-06-15 04:13:05.557
cmqexoddo00uqjxp599ehqyun	cmqexodd500twjxp5ozjix5p3	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	0	1	1	0	1	0	f	f	6	green	f	\N	2026-06-15 08:10:41.724
cmqexoddo00urjxp5c9wrx98d	cmqexodd500txjxp59nr26qu8	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	2	1	2	2	3	1	2	1	f	t	15	red	f	\N	2026-06-15 08:10:41.724
cmqexoddo00usjxp5906upa9o	cmqexodd500tyjxp5spf0vt4l	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	0	1	0	1	1	1	1	3	t	f	9	red	f	\N	2026-06-15 08:10:41.724
cmqexoddo00utjxp5c7c4todp	cmqexodd500tzjxp5ey8cx4bn	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	3	3	0	1	3	1	0	0	f	f	12	yellow	f	\N	2026-06-15 08:10:41.724
cmqexoddo00uujxp5syfjs2rq	cmqexodd500u0jxp5cnf5d5h9	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	0	2	1	0	1	2	t	f	9	red	f	\N	2026-06-15 08:10:41.724
cmqexoddo00uvjxp59yjwxcvw	cmqexodd500u1jxp5fygnoo9b	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	1	1	1	1	1	0	f	f	8	green	f	\N	2026-06-15 08:10:41.724
cmqexoddo00uwjxp5y14j6083	cmqexodd500u2jxp5vou9mtno	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	0	1	0	1	0	0	f	f	5	green	f	\N	2026-06-15 08:10:41.724
cmqexoddo00uxjxp53u0glqzh	cmqexodd500u3jxp5o7xdka1n	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	3	1	1	1	1	1	0	f	f	10	yellow	f	\N	2026-06-15 08:10:41.724
cmqexoddo00uyjxp5pewiq24u	cmqexodd600u4jxp5hx4r479y	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	3	1	1	1	1	1	0	f	f	10	yellow	f	\N	2026-06-15 08:10:41.724
cmqexoddo00uzjxp509rdw4i4	cmqexodd600u5jxp5ysyqeaup	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	0	0	1	1	1	1	0	f	f	6	green	f	\N	2026-06-15 08:10:41.724
cmqexoddo00v0jxp5o7ebxj77	cmqexodd600u6jxp59vhjqfw0	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	0	0	0	1	0	0	0	0	f	f	1	blue	f	\N	2026-06-15 08:10:41.724
cmqexoddo00v1jxp504h3mxsl	cmqexodd600u7jxp5jyyu6ovh	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	1	0	0	0	0	0	0	0	f	f	1	blue	f	\N	2026-06-15 08:10:41.724
cmqexoddo00v2jxp5r6x0wpff	cmqexodd600u8jxp5tc7jlxnf	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	0	0	0	1	0	0	f	f	4	blue	f	\N	2026-06-15 08:10:41.724
cmqexoddo00v3jxp5qml3h8jb	cmqexodd600u9jxp5gg5gxyhi	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	3	0	1	1	1	1	1	1	f	f	10	yellow	f	\N	2026-06-15 08:10:41.724
cmqexoddo00v4jxp59ckxnj2b	cmqexodd600uajxp5lqdb8aor	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	1	1	0	0	1	1	0	1	t	f	5	red	f	\N	2026-06-15 08:10:41.724
cmqexoddo00v5jxp5tdqrt3e5	cmqexodd600ubjxp5392pe7yt	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	0	3	1	1	3	1	3	0	f	f	13	yellow	f	\N	2026-06-15 08:10:41.724
cmqexoddo00v6jxp59uf3fi3d	cmqexodd600ucjxp5yylkny0y	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	3	1	2	3	3	3	1	1	3	t	t	20	red	f	\N	2026-06-15 08:10:41.724
cmqexoddo00v7jxp5c96d7j25	cmqexodd600udjxp5yyr5mjxs	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	3	3	2	2	3	3	3	1	1	t	t	21	red	f	\N	2026-06-15 08:10:41.724
cmqexoddo00v8jxp5085i81o3	cmqexodd600uejxp5pmwcsj0o	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	3	1	1	0	1	1	0	0	0	f	f	7	green	f	\N	2026-06-15 08:10:41.724
cmqexoddo00v9jxp5tlwy5kka	cmqexodd600ufjxp5lg8ivxwe	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	2	1	2	1	1	1	0	f	f	10	yellow	f	\N	2026-06-15 08:10:41.724
cmqexoddo00vajxp5nqsk3mei	cmqexodd600ugjxp53cp800t1	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	3	1	1	3	1	1	1	1	0	f	f	12	yellow	f	\N	2026-06-15 08:10:41.724
cmqexoddo00vbjxp597bp1148	cmqexodd600uhjxp5exu9cft6	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	3	1	0	1	1	3	1	0	0	f	f	10	yellow	f	\N	2026-06-15 08:10:41.724
cmqexoddo00vcjxp5w8xm1re2	cmqexodd600uijxp5pim3mba1	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	2	1	2	1	1	1	0	f	f	10	yellow	f	\N	2026-06-15 08:10:41.724
cmqexoddo00vdjxp5nadj3dk1	cmqexodd600ujjxp55j4o61zk	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	3	0	1	1	0	1	0	f	f	8	green	f	\N	2026-06-15 08:10:41.724
cmqexoddo00vejxp5307tv1nb	cmqexodd600ukjxp5yi3vryh4	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	3	1	3	3	1	1	1	t	f	15	red	f	\N	2026-06-15 08:10:41.724
cmqexoddo00vfjxp5issr57oo	cmqexodd600uljxp5g5aiustd	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	0	0	1	0	0	0	f	f	4	blue	f	\N	2026-06-15 08:10:41.724
cmqexoddo00vgjxp5ogrl99lm	cmqexodd600umjxp5dlcm8f78	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	3	1	0	1	1	3	0	0	f	f	10	yellow	f	\N	2026-06-15 08:10:41.724
cmqexoddo00vhjxp51mz1iqts	cmqexodd600unjxp54ae6qmd2	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	3	1	3	1	3	1	1	1	1	t	f	15	red	f	\N	2026-06-15 08:10:41.724
cmqexoddo00vijxp58wvle1w9	cmqexodd600uojxp55el16rgl	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	1	1	1	1	0	0	f	f	7	green	f	\N	2026-06-15 08:10:41.724
cmqexoddo00vjjxp5lymc6c7v	cmqexodd600upjxp5l09vyjzr	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	0	3	1	3	3	1	1	0	t	f	13	red	f	\N	2026-06-15 08:10:41.724
cmqf02twx0064jxops0zutopk	cmqf02twi005vjxoph6si1y7m	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	2	3	1	3	0	0	1	0	f	f	11	yellow	f	\N	2026-06-15 09:17:55.569
cmqf02twx0065jxopks12xh9e	cmqf02twi005wjxop1suc7kpd	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	2	2	2	1	0	2	0	0	f	f	10	yellow	f	\N	2026-06-15 09:17:55.569
cmqf02twx0066jxop7hee7txt	cmqf02twi005xjxop9todeqnc	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	1	1	1	1	0	0	0	f	f	6	green	f	\N	2026-06-15 09:17:55.569
cmqf02twx0067jxop3imvllx8	cmqf02twi005yjxopdari537w	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	2	2	2	3	3	3	1	f	f	18	orange	f	\N	2026-06-15 09:17:55.569
cmqf02twx0068jxopyix3b9jl	cmqf02twi005zjxop5kafgs6v	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	2	0	2	3	1	1	1	f	f	12	yellow	f	\N	2026-06-15 09:17:55.569
cmqf02twx0069jxopew6sr4k5	cmqf02twi0060jxopbq0u963r	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	2	0	2	2	1	1	1	f	f	11	yellow	f	\N	2026-06-15 09:17:55.569
cmqf02twx006ajxop3fgj1itn	cmqf02twi0061jxopfw2ixih5	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	1	0	2	2	1	1	1	f	f	10	yellow	f	\N	2026-06-15 09:17:55.569
cmqf02twx006bjxopdyn7ss4z	cmqf02twi0062jxop3z5jrxny	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	2	2	2	2	3	2	1	f	f	16	orange	f	\N	2026-06-15 09:17:55.569
cmqf02twx006cjxopbakfs0te	cmqf02twi0063jxopuqpquhah	cmp6j4rh20002jxuik5drdqtt	cmq0khs5m000wjx23jyhqhgkv	1	1	1	2	0	2	1	1	1	1	f	f	10	yellow	f	\N	2026-06-15 09:17:55.569
cmqgdyco0002ejxy9a6u4trlc	cmqgdycn8001djxy9h4tbxdxf	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	2	1	2	2	1	0	1	0	f	f	10	yellow	f	\N	2026-06-16 08:34:07.391
cmqgdyco0002fjxy99y54h81h	cmqgdycn8001ejxy9exoa7t0x	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	0	1	1	3	1	0	f	f	9	green	f	\N	2026-06-16 08:34:07.391
cmqgdyco0002gjxy97c0bugel	cmqgdycn8001fjxy9zly679kv	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	0	1	1	1	0	1	1	0	f	f	5	green	f	\N	2026-06-16 08:34:07.391
cmqgdyco0002hjxy96b90xtlz	cmqgdycn9001gjxy9v9cuoe6b	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	0	0	1	1	1	0	0	f	f	5	green	f	\N	2026-06-16 08:34:07.391
cmqgdyco0002ijxy9rx8sxq9z	cmqgdycn9001hjxy9i3kg026e	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	0	1	0	0	0	0	0	0	f	f	1	blue	f	\N	2026-06-16 08:34:07.391
cmqgdyco0002jjxy92kaoh3do	cmqgdycn9001ijxy9iunp2rcp	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	1	3	0	1	1	1	0	0	t	f	7	red	f	\N	2026-06-16 08:34:07.391
cmqgdyco0002kjxy9ezegozr0	cmqgdycn9001jjxy9tj4en4n8	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	2	1	1	1	1	1	1	0	f	t	9	red	f	\N	2026-06-16 08:34:07.391
cmqgdyco0002ljxy9963618gy	cmqgdycn9001kjxy99e4tek05	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	1	1	1	3	3	0	0	0	f	f	9	green	f	\N	2026-06-16 08:34:07.391
cmqgdyco0002mjxy9h1ek1rbq	cmqgdycn9001ljxy9jyeqjz4b	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	0	1	0	1	0	1	0	0	f	f	3	blue	f	\N	2026-06-16 08:34:07.391
cmqgdyco0002njxy9067tf3mt	cmqgdycn9001mjxy9ljnm3a73	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	0	1	2	0	1	0	f	f	7	green	f	\N	2026-06-16 08:34:07.391
cmqgdyco0002ojxy9j48rhu9c	cmqgdycn9001njxy9an6nlwry	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	0	1	0	0	0	0	0	0	f	f	1	blue	f	\N	2026-06-16 08:34:07.391
cmqgdyco0002pjxy9unla8xwt	cmqgdycn9001ojxy9g54zqow0	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	0	0	0	1	1	1	1	0	f	f	5	green	f	\N	2026-06-16 08:34:07.391
cmqgdyco0002qjxy9r85l0cuv	cmqgdycn9001pjxy9gc0vlc18	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	0	1	0	0	0	1	0	1	f	f	3	blue	f	\N	2026-06-16 08:34:07.391
cmqgdyco0002rjxy9ok1r299a	cmqgdycn9001qjxy9jz62rob0	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	1	1	1	1	0	1	1	0	f	f	6	green	f	\N	2026-06-16 08:34:07.391
cmqgdyco0002sjxy9iicluirx	cmqgdycn9001rjxy9ktr4obzg	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	1	2	0	1	1	1	1	1	f	f	8	green	f	\N	2026-06-16 08:34:07.391
cmqgdyco0002tjxy9hd3y4mhl	cmqgdycn9001sjxy9jz4l3nkr	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	3	0	0	0	0	1	0	0	f	f	5	green	f	\N	2026-06-16 08:34:07.391
cmqgdyco0002ujxy9o21kza3d	cmqgdycn9001tjxy9t6irqpz8	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	0	1	0	1	0	1	1	0	f	f	4	blue	f	\N	2026-06-16 08:34:07.391
cmqgdyco0002vjxy9h1h7lsxq	cmqgdycn9001ujxy9o88iutuy	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	0	1	1	0	0	0	0	0	f	f	2	blue	f	\N	2026-06-16 08:34:07.391
cmqgdyco0002wjxy9g4zlajyo	cmqgdycn9001vjxy9in1wwxmx	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	1	0	0	1	0	1	0	0	f	f	3	blue	f	\N	2026-06-16 08:34:07.391
cmqgdyco0002xjxy9wslbhgvz	cmqgdycn9001wjxy9kpqhu7ep	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	0	3	0	0	1	0	0	0	f	f	4	blue	f	\N	2026-06-16 08:34:07.391
cmqgdyco0002yjxy9h28dm4ps	cmqgdycn9001xjxy9wlw3n593	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	0	0	0	1	1	0	0	0	f	f	3	blue	f	\N	2026-06-16 08:34:07.391
cmqgdyco0002zjxy90krg8617	cmqgdycn9001yjxy9cp7ipqz9	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	1	1	1	1	0	1	t	f	8	red	f	\N	2026-06-16 08:34:07.391
cmqgdyco00030jxy9teaxzpfj	cmqgdycn9001zjxy9d4tpzbfh	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	1	1	1	1	2	1	0	0	f	f	7	green	f	\N	2026-06-16 08:34:07.391
cmqgdyco10031jxy92t5wch55	cmqgdycn90020jxy9ftwb5ojy	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	0	0	1	0	0	0	0	0	f	f	1	blue	f	\N	2026-06-16 08:34:07.391
cmqgdyco10032jxy9mt6fr3wg	cmqgdycn90021jxy9vmh2xgxi	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	0	1	0	1	1	0	0	0	f	f	4	blue	f	\N	2026-06-16 08:34:07.391
cmqgdyco10033jxy9d2f9n01k	cmqgdycn90022jxy97xb1hja1	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	0	1	1	1	0	0	0	0	f	f	4	blue	f	\N	2026-06-16 08:34:07.391
cmqgdyco10034jxy92bimj0kn	cmqgdycn90023jxy9l3qdzxdj	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	0	1	1	1	0	0	0	f	f	5	green	f	\N	2026-06-16 08:34:07.391
cmqgdyco10035jxy97m3byc1f	cmqgdycn90024jxy931kz4zq1	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	0	1	0	1	1	0	0	0	f	f	4	blue	f	\N	2026-06-16 08:34:07.391
cmqgdyco10036jxy9tbhzrxt7	cmqgdycn90025jxy94rcud4ci	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	0	0	0	1	0	1	0	0	f	f	2	blue	f	\N	2026-06-16 08:34:07.391
cmqgdyco10037jxy92f2vx90v	cmqgdycn90026jxy90k7aemar	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	0	1	1	1	1	0	1	0	0	f	f	5	green	f	\N	2026-06-16 08:34:07.391
cmqgdyco10038jxy9xbogk5nx	cmqgdycn90027jxy9acp4i59f	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	0	3	1	1	1	3	0	0	f	f	10	yellow	f	\N	2026-06-16 08:34:07.391
cmqgdyco10039jxy9uzqhgq3t	cmqgdycn90028jxy94fnhfaz0	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	3	3	3	3	1	1	2	f	f	18	orange	f	\N	2026-06-16 08:34:07.391
cmqgdyco1003ajxy9cchr8s7q	cmqgdycn90029jxy9eb9ejuhg	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	0	1	1	3	3	1	0	0	t	f	10	red	f	\N	2026-06-16 08:34:07.391
cmqgdyco1003bjxy9kjuu177b	cmqgdycn9002ajxy972fgvbbh	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	2	1	3	1	3	3	1	0	1	t	f	15	red	f	\N	2026-06-16 08:34:07.391
cmqgdyco1003cjxy9vamipzeq	cmqgdycn9002bjxy9nejfa9yv	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	1	1	2	1	2	1	t	f	11	red	f	\N	2026-06-16 08:34:07.391
cmqgdyco1003djxy9t00wlbxm	cmqgdycn9002cjxy9g2voe87k	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	3	1	0	1	1	1	1	t	f	10	red	f	\N	2026-06-16 08:34:07.391
cmqgdyco1003ejxy9vrzzycn8	cmqgdycn9002djxy94nsh9t22	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	1	1	3	1	1	2	t	t	12	red	f	\N	2026-06-16 08:34:07.391
cmqgem6a3001ajxxty5bb7q6o	cmqgem69r0010jxxt97z9hkxb	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	1	1	0	1	1	0	f	f	7	green	f	\N	2026-06-16 08:52:38.859
cmqgem6a3001bjxxtouyfylnx	cmqgem69r0011jxxtuazyo8z8	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	1	1	1	2	2	1	f	f	11	yellow	f	\N	2026-06-16 08:52:38.859
cmqgem6a3001cjxxtwnh9cj0i	cmqgem69r0012jxxtc7jpe7n4	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	1	1	2	2	2	0	f	f	11	yellow	f	\N	2026-06-16 08:52:38.859
cmqgem6a3001djxxt0pdkf5b7	cmqgem69r0013jxxt66actfu5	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	0	0	1	1	1	0	f	f	6	green	f	\N	2026-06-16 08:52:38.859
cmqgem6a3001ejxxttgu7rmvt	cmqgem69r0014jxxtf48r06rr	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	0	1	1	1	1	0	f	f	7	green	f	\N	2026-06-16 08:52:38.859
cmqgem6a3001fjxxt3rqpz4yd	cmqgem69r0015jxxtaduu4v33	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	2	1	1	1	1	1	1	0	f	f	9	green	f	\N	2026-06-16 08:52:38.859
cmqgem6a3001gjxxt29m9dntc	cmqgem69r0016jxxt04rvuch5	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	1	1	1	1	1	0	f	f	8	green	f	\N	2026-06-16 08:52:38.859
cmqgem6a3001hjxxt4x3kaovn	cmqgem69r0017jxxtki2eprim	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	1	1	1	1	1	0	f	f	8	green	f	\N	2026-06-16 08:52:38.859
cmqgem6a3001ijxxtnw7lkcno	cmqgem69s0018jxxtpuo45d2u	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	1	1	1	1	1	0	f	f	8	green	f	\N	2026-06-16 08:52:38.859
cmqgem6a3001jjxxtlhelaabe	cmqgem69s0019jxxt0vx6c2m4	cmp6j4rh20002jxuik5drdqtt	cmq0ke15g0007jx23k3ypiimb	1	1	1	1	1	1	1	1	1	0	f	f	8	green	f	\N	2026-06-16 08:52:38.859
cmprve8lw0028jx5qc76ny9dc	cmprve8l5001djx5q6y4qam8e	cmp6j4rh20002jxuik5drdqtt	cmp6j8ifp0002jxdffdiyvvw3	1	3	1	1	2	1	2	1	0	0	t	t	11	red	f	\N	2026-05-30 04:48:07.699
cmqo3trv500khjxf032xbex4i	cmqo3trrx00ckjxf0vx7oz13b	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	0	0	0	0	0	1	0	f	f	2	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv500kijxf0mao06170	cmqo3trrx00cljxf08shzfqtc	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	0	1	0	0	0	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv500kjjxf01sygcmgy	cmqo3trrx00cmjxf0hkga2z6b	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	1	0	1	1	1	0	f	f	7	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv600kkjxf0rp5jeoat	cmqo3trrx00cnjxf0ucejo8au	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	1	0	0	0	0	0	0	f	f	1	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv600kljxf03smm20jx	cmqo3trrx00cojxf0b62gt7kx	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	0	1	3	2	1	0	f	f	9	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv600kmjxf035maaeis	cmqo3trrx00cpjxf09jq5zwly	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	1	2	1	1	1	0	f	f	9	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv600knjxf0xtm1bkla	cmqo3trrx00cqjxf07w79kjv8	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	2	1	1	1	1	0	3	0	0	f	f	9	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv600kojxf0rutyvoz4	cmqo3trrx00crjxf010d5hn46	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	1	0	0	0	0	0	0	f	f	2	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv600kpjxf0i689ores	cmqo3trrx00csjxf0a9nxqmj4	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	1	1	1	0	1	1	0	f	f	6	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv600kqjxf0sxb76htn	cmqo3trrx00ctjxf0ghhxb3qw	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	0	0	0	1	0	0	0	f	f	1	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv600krjxf0q0wef31p	cmqo3trrx00cujxf0pl8ls09k	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	0	0	1	1	1	1	0	f	f	5	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv600ksjxf0317y0oqx	cmqo3trrx00cvjxf0qgnnuul3	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	2	1	1	1	2	2	1	1	1	t	f	12	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv600ktjxf0v81bo6td	cmqo3trrx00cwjxf063cnpksu	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	3	1	0	1	0	1	0	0	f	f	7	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv600kujxf091ddl1u2	cmqo3trrx00cxjxf0yso0kz4l	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	0	1	1	0	0	0	0	t	t	2	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv600kvjxf0jv2x1fho	cmqo3trrx00cyjxf0cbuftbkp	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	2	1	0	1	1	0	0	f	f	7	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv600kwjxf0eft8kf21	cmqo3trrx00czjxf0edfg8bq8	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	3	1	1	1	0	0	1	t	f	9	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv600kxjxf0h76s2nu3	cmqo3trrx00d0jxf02n42ut8g	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	1	0	1	1	1	0	0	f	f	5	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv600kyjxf0yab3mp21	cmqo3trrx00d1jxf01suy4i7i	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	0	1	1	3	0	1	t	f	8	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv600kzjxf0cofrj1yi	cmqo3trrx00d2jxf0j79zga8a	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	0	0	1	1	0	0	0	t	f	3	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv600l0jxf09ms5cusl	cmqo3trrx00d3jxf0bzc17mdo	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	1	1	0	0	0	0	f	t	4	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv600l1jxf0ph6ps183	cmqo3trrx00d4jxf07ites9wo	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	0	0	1	0	1	0	0	f	f	3	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv600l2jxf04xkb3m6u	cmqo3trrx00d5jxf0koyl25j4	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	1	1	1	0	0	0	f	f	6	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv600l3jxf0b17qkb4j	cmqo3trrx00d6jxf0lnowoxwa	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	1	1	0	1	0	1	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv600l4jxf0v71dv5om	cmqo3trrx00d7jxf0bwir8wrm	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	1	0	0	0	0	0	0	f	f	1	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv600l5jxf023vlhjy0	cmqo3trrx00d8jxf0rpnpe169	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	0	0	1	1	1	0	0	f	f	3	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv600l6jxf0s6aplbbx	cmqo3trrx00d9jxf0l2v7fbbn	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	0	0	0	1	0	0	f	f	3	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv600l7jxf0r21729hq	cmqo3trrx00dajxf0p6k2wvfz	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	2	0	0	0	0	1	t	f	6	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv600l8jxf0v9vhnnas	cmqo3trrx00dbjxf0ck4aadua	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	0	1	0	1	0	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv600l9jxf0cjyyj9wt	cmqo3trrx00dcjxf0041xwlnt	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	0	0	1	0	1	0	0	f	f	3	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv600lajxf0sufip4zy	cmqo3trrx00ddjxf06e6ec32j	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	3	0	1	0	0	0	0	f	f	6	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv600lbjxf0nv3ogjd6	cmqo3trrx00dejxf0006iinz4	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	0	1	1	1	1	0	1	t	f	6	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv600lcjxf0wuffesvr	cmqo3trrx00dfjxf020h9ywmf	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	2	1	3	1	1	0	1	t	f	11	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv600ldjxf02y1nrxk9	cmqo3trrx00dgjxf070co0vw0	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	2	1	1	0	1	1	1	0	0	f	f	7	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv600lejxf0ld14ld3l	cmqo3trrx00dhjxf0itgnwdn9	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	1	0	1	1	0	0	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv600lfjxf08ts8ocyq	cmqo3trrx00dijxf04fxwyfes	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	0	0	1	0	0	0	0	f	f	1	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv600lgjxf0up8vmvmk	cmqo3trrx00djjxf0m8hzognb	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	0	1	1	0	0	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv600lhjxf0x42adw7s	cmqo3trrx00dkjxf0qnhcwi7m	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	1	1	1	0	2	0	f	f	8	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv600lijxf0b36qldum	cmqo3trrx00dljxf03i5faqa1	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	0	1	1	0	0	0	0	f	f	3	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv600ljjxf0oxhegm79	cmqo3trrx00dmjxf04kxojlkl	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	1	0	0	0	1	0	0	f	f	2	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv600lkjxf0zcarz1n6	cmqo3trrx00dnjxf0z5o6lea5	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	3	1	2	3	1	3	3	1	t	f	18	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv600lljxf084u1og1r	cmqo3trrx00dojxf01csh8119	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	3	1	1	0	1	0	0	f	f	6	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv600lmjxf0jii14aif	cmqo3trrx00dpjxf0j3dbd902	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	1	0	0	0	1	0	1	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv600lnjxf0bzd2qpga	cmqo3trry00dqjxf07ap4wok0	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	0	0	1	0	0	1	0	f	f	3	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv600lojxf0br25fq1b	cmqo3trry00drjxf00mvoe6rz	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	1	0	0	0	0	0	0	f	f	1	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv700lpjxf0eij7j94o	cmqo3trry00dsjxf0ee4brpjh	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	2	1	1	0	0	0	t	t	7	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv700lqjxf07j3v1oh7	cmqo3trry00dtjxf0ctm12tv7	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	1	1	1	0	0	0	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv700lrjxf03xrpoofg	cmqo3trry00dujxf0vvbiy52a	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	1	1	1	3	1	0	f	f	10	yellow	f	\N	2026-06-21 18:12:47.051
cmqo3trv700lsjxf0frv6o0vg	cmqo3trry00dvjxf08cenbaap	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	0	1	1	1	0	0	f	f	6	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv700ltjxf0498s6k0n	cmqo3trry00dwjxf0zyktyu8c	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	0	0	1	1	1	0	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv700lujxf0opws6nbx	cmqo3trry00dxjxf054rmucid	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	0	0	1	1	1	0	1	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv700lvjxf0uihv5cj9	cmqo3trry00dyjxf0prhrj4ee	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	3	3	3	1	0	1	0	f	f	13	yellow	f	\N	2026-06-21 18:12:47.051
cmqo3trv700lwjxf0v1kpmpoz	cmqo3trry00dzjxf0avwlh2ob	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	2	1	1	1	1	3	1	1	2	t	f	13	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv700lxjxf0jnewql21	cmqo3trry00e0jxf0hsz5wdjk	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	0	3	1	1	3	1	f	f	12	yellow	f	\N	2026-06-21 18:12:47.051
cmqo3trv700lyjxf0ntfixuyx	cmqo3trry00e1jxf0zw5hipoe	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	1	0	1	0	1	1	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv700lzjxf0pcbpn3y9	cmqo3trry00e2jxf0gb1stue6	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	1	1	1	0	1	0	1	t	t	5	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv700m0jxf01tldr9yo	cmqo3trry00e3jxf0nwvzis1r	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	0	1	0	1	0	0	f	f	5	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv700m1jxf09bwg8oyv	cmqo3trry00e4jxf0gqszhsf9	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	0	0	1	0	0	0	0	f	f	1	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv700m2jxf037rxkewu	cmqo3trry00e5jxf03blxyoep	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	0	1	1	0	0	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv700m3jxf0gw0vtlqa	cmqo3trry00e6jxf0b2xz7tjf	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	0	1	0	3	0	0	f	f	7	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv700m4jxf09iklpakr	cmqo3trry00e7jxf099u1i7bw	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	0	1	1	0	0	0	f	f	5	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv700m5jxf0f7z0yts5	cmqo3trry00e8jxf02xkc81sh	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	1	0	0	0	1	0	0	f	f	2	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv700m6jxf0w9qd9yrg	cmqo3trry00e9jxf00sk8s4um	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	2	1	1	1	1	1	1	2	1	f	f	11	yellow	f	\N	2026-06-21 18:12:47.051
cmqo3trv700m7jxf0gjlqjs2w	cmqo3trry00eajxf08o399zhz	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	0	1	0	1	0	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv700m8jxf0l2detfc2	cmqo3trry00ebjxf01zvrx7o7	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	3	1	3	1	1	0	0	f	f	11	yellow	f	\N	2026-06-21 18:12:47.051
cmqo3trv700m9jxf0o1mkm455	cmqo3trry00ecjxf0tqh1zbcq	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	3	0	1	1	1	1	0	f	f	9	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv700majxf0plbqmevs	cmqo3trry00edjxf0y4sszbb3	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	0	1	1	0	1	0	f	f	6	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv700mbjxf0p321gj7h	cmqo3trry00eejxf0iq4el9xy	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	0	1	0	0	0	0	0	f	f	1	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv700mcjxf09kbz36l3	cmqo3trry00efjxf0yhwxeok3	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	0	0	0	0	0	0	0	f	f	1	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv700mdjxf0imjvv1ls	cmqo3trry00egjxf01dy434tu	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	0	0	1	0	0	1	0	f	f	2	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv700mejxf0zzxo1lgy	cmqo3trry00ehjxf0a4p2qq96	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	0	0	1	0	1	0	0	f	f	3	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv700mfjxf021b5bggd	cmqo3trry00eijxf01unwp8tn	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	1	0	1	1	0	0	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv700mgjxf0plka87t6	cmqo3trry00ejjxf0xokr3ofl	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	2	1	2	2	2	2	2	2	2	f	t	17	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv700mhjxf0360c0g25	cmqo3trry00ekjxf0t04fza87	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	2	2	3	2	1	1	1	t	f	14	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv700mijxf0uf59jctj	cmqo3trry00eljxf0ylnn2t8p	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	1	3	1	3	1	1	t	f	12	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv700mjjxf0vpp089uw	cmqo3trry00emjxf0pz6fb4an	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	0	1	0	0	0	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv700mkjxf0swpo0kz3	cmqo3trry00enjxf0py52o7zw	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	1	1	0	1	0	0	f	f	5	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv700mljxf0bdaap8d1	cmqo3trry00eojxf0zd1iyhx1	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	0	1	1	1	1	0	f	f	7	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv700mmjxf01bhj6sr1	cmqo3trry00epjxf0h7rp4ikb	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	3	1	1	1	2	1	2	0	f	f	12	yellow	f	\N	2026-06-21 18:12:47.051
cmqo3trv700mnjxf0mm2fdhv0	cmqo3trry00eqjxf0sy4o72o9	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	0	0	0	0	1	0	0	t	t	1	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv700mojxf0zv0wlw4y	cmqo3trry00erjxf0tapbsk8t	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	0	1	0	3	0	0	f	f	7	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv700mpjxf00rpsaifj	cmqo3trry00esjxf0bm0tc1il	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	0	1	0	1	0	0	f	f	5	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv700mqjxf0hr7id754	cmqo3trry00etjxf0x1kawj88	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	0	1	1	0	0	0	f	f	5	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv700mrjxf00ek8dli5	cmqo3trry00eujxf0qvrfyalr	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	1	0	1	0	1	0	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv700msjxf0rnqlt180	cmqo3trry00evjxf06x88zpy5	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	0	1	1	0	0	1	f	f	6	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv700mtjxf0ve3g0cwk	cmqo3trry00ewjxf0toodswrr	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	1	1	0	1	1	0	f	f	6	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv700mujxf032nlfblc	cmqo3trry00exjxf0u8qwfmo1	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	3	1	3	1	0	0	0	t	f	9	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv700mvjxf0ktzxjh86	cmqo3trry00eyjxf0d6nvg775	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	0	1	0	1	0	0	t	f	4	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv700mwjxf0svdvanxj	cmqo3trry00ezjxf0116tbiah	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	0	1	1	0	0	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv700mxjxf07vwd9n9b	cmqo3trry00f0jxf020ixwdwi	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	3	3	3	0	2	1	0	3	0	f	f	15	orange	f	\N	2026-06-21 18:12:47.051
cmqo3trv800myjxf0x5iys0mj	cmqo3trry00f1jxf005seeejt	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	0	0	1	0	0	0	0	f	f	2	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv800mzjxf0v3goohi6	cmqo3trry00f2jxf0cc2txd99	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	3	2	3	2	3	3	2	2	3	t	t	23	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv800n0jxf02nftjs70	cmqo3trry00f3jxf0dd448jgh	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	0	0	1	0	0	0	0	f	f	2	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv800n1jxf0kz4h5ro5	cmqo3trry00f4jxf086ittq3f	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	0	1	1	1	1	0	f	f	7	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv800n2jxf0jxbi9ysy	cmqo3trry00f5jxf0ahjt6456	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	3	3	3	2	3	1	3	t	f	20	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv800n3jxf0foxp2rad	cmqo3trry00f6jxf0xhnsex81	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	3	1	0	0	1	1	0	0	1	f	f	7	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv800n4jxf0smjz5w9q	cmqo3trry00f7jxf060hli21q	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	3	0	0	0	0	0	0	f	f	3	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv800n5jxf09za36hr9	cmqo3trry00f8jxf0aqolapwn	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	3	2	1	1	1	0	0	t	f	10	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv800n6jxf02kbqhg6f	cmqo3trry00f9jxf0t1etwy68	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	1	1	1	1	1	0	f	f	8	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv800n7jxf0y1ec9plh	cmqo3trry00fajxf07zgohl3s	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	0	1	1	1	1	1	f	f	8	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv800n8jxf0iesm71xx	cmqo3trry00fbjxf05gxm8phc	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	3	0	1	0	1	1	0	f	f	7	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv800n9jxf0u45njtt6	cmqo3trry00fcjxf0uv7bwi0f	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	0	0	1	0	1	0	0	f	f	2	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv800najxf0sk3vbs20	cmqo3trry00fdjxf0vyrpd9jw	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	1	0	1	0	0	0	0	f	f	2	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv800nbjxf0583jodx9	cmqo3trry00fejxf00abhefcg	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	2	1	1	1	2	1	0	1	1	f	f	10	yellow	f	\N	2026-06-21 18:12:47.051
cmqo3trv800ncjxf08l77pgoy	cmqo3trry00ffjxf0erpxtj15	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	0	0	0	1	0	0	0	f	f	2	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv800ndjxf0yqzvp9ud	cmqo3trry00fgjxf0ys6a7oaj	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	1	0	0	0	3	0	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv800nejxf0q8654cny	cmqo3trry00fhjxf0aurz1l17	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	3	0	1	0	1	2	0	1	t	f	9	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv800nfjxf0kekuopwt	cmqo3trry00fijxf0m7jewnty	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	0	0	0	0	1	0	0	f	f	1	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv800ngjxf0vbf0vywg	cmqo3trry00fjjxf058vqth05	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	3	3	1	3	1	1	1	1	t	t	15	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv800nhjxf0ckqs0pys	cmqo3trry00fkjxf0wq27hwn0	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	3	1	1	1	1	1	t	f	11	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv800nijxf0fdvahuyx	cmqo3trry00fljxf065c5m8rh	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	0	0	0	0	1	0	0	t	f	1	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv800njjxf0mkhhrg57	cmqo3trry00fmjxf0bc1vzbr9	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	1	0	1	1	0	0	0	t	t	4	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv800nkjxf0srpu0cq8	cmqo3trry00fnjxf0b023tzml	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	0	0	1	0	0	0	0	f	f	1	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv800nljxf0cnosa90w	cmqo3trry00fojxf03jg7nprj	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	1	0	1	0	0	0	0	f	f	3	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv800nmjxf0aj621afp	cmqo3trry00fpjxf0bir9c1c1	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	0	0	1	0	0	0	0	f	f	1	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv800nnjxf0n7mu1itv	cmqo3trry00fqjxf0m5i6wqym	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	0	0	0	0	0	0	0	f	f	1	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv800nojxf0l4ybc4o4	cmqo3trrz00frjxf0kbmqurgi	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	1	0	0	1	0	0	0	f	f	2	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv800npjxf0fwzm7pcz	cmqo3trrz00fsjxf0e31e36cq	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	0	0	0	0	2	0	0	f	t	2	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv800nqjxf0e318qvzz	cmqo3trrz00ftjxf0atwyzi53	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	0	1	1	0	1	0	0	t	f	3	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv800nrjxf0fvb5re3i	cmqo3trrz00fujxf0w2g6vu17	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	3	1	1	1	1	3	0	0	3	t	t	13	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv800nsjxf0lnkz8v7h	cmqo3trrz00fvjxf0ayg4ehyt	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	1	1	0	0	0	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv800ntjxf0e5d2occ5	cmqo3trrz00fwjxf0j3a6lvgl	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	0	0	0	0	1	0	0	f	f	1	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv800nujxf0z65xg7om	cmqo3trrz00fxjxf0oivwledo	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	0	1	0	0	0	0	f	f	3	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv800nvjxf0lh8wlusx	cmqo3trrz00fyjxf0malpalfg	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	1	1	0	1	0	0	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv800nwjxf0mvr6144x	cmqo3trrz00fzjxf073ylpnkm	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	1	0	1	0	0	0	1	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv800nxjxf0oltwkx3e	cmqo3trrz00g0jxf037y1iwx6	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	1	0	0	0	0	0	0	f	f	2	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv800nyjxf0fz3ym5yn	cmqo3trrz00g1jxf01dissupz	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	1	0	0	1	0	0	t	f	5	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv800nzjxf0552y1vqt	cmqo3trrz00g2jxf0aygn4y0o	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	0	0	0	0	0	0	0	f	f	1	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv800o0jxf0ngc9inml	cmqo3trrz00g3jxf0uqzalbg6	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	0	0	1	1	0	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv800o1jxf015hso4k8	cmqo3trrz00g4jxf0avq9xgzw	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	0	1	0	1	0	0	1	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv900o2jxf0t3qhuhqb	cmqo3trrz00g5jxf08254eigw	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	0	1	1	0	0	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv900o3jxf0afco1e4v	cmqo3trrz00g6jxf0b3hcn3eo	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	0	0	0	0	0	1	0	f	f	2	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv900o4jxf0xw8fipbz	cmqo3trrz00g7jxf0lnrv18gx	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	1	0	1	0	0	0	0	f	f	3	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv900o5jxf0svvz2l3h	cmqo3trrz00g8jxf0x3sthlu4	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	1	0	1	0	0	0	0	f	f	3	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv900o6jxf0079j9m8h	cmqo3trrz00g9jxf09fpmqbg0	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	0	1	1	0	0	0	f	f	5	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv900o7jxf05mn1wt9w	cmqo3trrz00gajxf0ed8vdnho	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	0	0	0	0	1	0	0	f	f	2	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv900o8jxf0s7b3fpyq	cmqo3trrz00gbjxf03t1f9dhz	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	0	1	0	0	0	0	f	f	3	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv900o9jxf0vs6x0cvb	cmqo3trrz00gcjxf0109hvi6b	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	0	0	0	0	0	0	f	f	2	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv900oajxf09227bi4l	cmqo3trrz00gdjxf0v9cmankg	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	0	0	0	1	0	0	0	f	f	1	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv900objxf06cz0pefe	cmqo3trrz00gejxf0gy4o0lhe	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	1	0	0	0	0	0	0	f	f	1	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv900ocjxf0gm0p1lgp	cmqo3trrz00gfjxf0rhomr06g	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	0	0	0	0	0	0	0	t	t	0	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv900odjxf0uc8bj68r	cmqo3trrz00ggjxf0t6hdtuoc	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	1	1	1	1	1	0	f	f	8	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv900oejxf0ljnl8o2k	cmqo3trrz00ghjxf0acgd18g0	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	0	0	0	0	0	0	0	f	f	1	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv900ofjxf06ix5oioh	cmqo3trrz00gijxf0d49ynohu	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	0	0	0	1	0	0	0	f	f	1	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv900ogjxf07n7d26b0	cmqo3trrz00gjjxf084lzjm41	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	0	0	0	0	3	0	0	f	f	3	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv900ohjxf08stj6zt9	cmqo3trrz00gkjxf0siyoz3hv	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	2	1	1	3	3	1	1	1	t	f	14	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv900oijxf0yz48mipu	cmqo3trrz00gljxf0giokh4dg	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	0	1	0	1	1	1	t	f	7	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv900ojjxf03eckf2sy	cmqo3trrz00gmjxf0b1mr40o3	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	0	1	1	1	1	0	f	f	6	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv900okjxf06pb2uorw	cmqo3trrz00gnjxf0xhoafl57	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	3	3	3	3	1	3	2	2	t	t	21	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv900oljxf0y2d8kira	cmqo3trrz00gojxf057482z7q	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	3	1	0	0	1	0	f	f	7	green	f	\N	2026-06-21 18:12:47.051
cmqo3trv900omjxf0v7awk3i7	cmqo3trrz00gpjxf0b1blugpc	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	0	0	1	0	1	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv900onjxf0k46u93tq	cmqo3trrz00gqjxf08plupf8x	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	2	2	2	1	1	2	1	1	1	t	t	13	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv900oojxf0lmw9bics	cmqo3trrz00grjxf0ucn9x9ib	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	0	0	1	0	0	0	0	f	f	2	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv900opjxf0nn33kceh	cmqo3trrz00gsjxf0k4eqemjh	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	1	0	1	1	0	0	0	f	f	3	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv900oqjxf00qum5gbo	cmqo3trrz00gtjxf09h5slaxo	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	3	1	1	3	3	1	1	0	f	f	14	yellow	f	\N	2026-06-21 18:12:47.051
cmqo3trv900orjxf0es4iqmzc	cmqo3trrz00gujxf0tbzg7uku	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	1	1	0	0	0	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv900osjxf0a1gbg3g5	cmqo3trrz00gvjxf0sj98j9yo	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	0	0	0	3	0	0	0	f	f	3	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv900otjxf0v7d543zu	cmqo3trrz00gwjxf0yuo0jfqf	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	1	1	0	0	0	0	0	f	f	3	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trv900oujxf0nnausaf7	cmqo3trrz00gxjxf07zx5n66d	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	1	0	1	1	0	0	0	t	t	3	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv900ovjxf0enqd8cy3	cmqo3trrz00gyjxf0wzfurkl8	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	0	1	1	0	0	2	t	f	6	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv900owjxf0t6ijejio	cmqo3trrz00gzjxf0qbu15z5k	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	3	2	2	1	1	2	1	2	3	t	t	17	red	f	\N	2026-06-21 18:12:47.051
cmqo3trv900oxjxf0fevlg44q	cmqo3trrz00h0jxf0pm6awfjg	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	1	1	1	0	1	0	0	f	f	5	green	f	\N	2026-06-21 18:12:47.051
cmqo3trva00oyjxf0effo4rc8	cmqo3trrz00h1jxf0qrydpsgd	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	3	1	0	1	1	0	f	f	9	green	f	\N	2026-06-21 18:12:47.051
cmqo3trva00ozjxf0xq0j7sbp	cmqo3trrz00h2jxf0ms9tlg8t	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	0	1	1	0	1	1	t	t	7	red	f	\N	2026-06-21 18:12:47.051
cmqo3trva00p0jxf0ijkh8s11	cmqo3trrz00h3jxf0y15w9r1h	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	0	0	1	0	1	0	0	f	f	2	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trva00p1jxf0zbzppop1	cmqo3trrz00h4jxf08xieam6q	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	2	3	3	1	1	2	3	1	f	t	17	red	f	\N	2026-06-21 18:12:47.051
cmqo3trva00p2jxf0adhreg5b	cmqo3trrz00h5jxf0go044det	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	1	0	0	0	1	0	0	f	f	3	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trva00p3jxf0awrdmpl1	cmqo3trrz00h6jxf052sls66w	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	3	1	0	1	0	0	0	f	f	6	green	f	\N	2026-06-21 18:12:47.051
cmqo3trva00p4jxf0drhyulcn	cmqo3trrz00h7jxf0phmz4mih	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	1	1	0	1	0	0	f	f	6	green	f	\N	2026-06-21 18:12:47.051
cmqo3trva00p5jxf0ip09cy8f	cmqo3trrz00h8jxf087ldrc29	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	3	3	1	0	3	3	3	3	3	t	f	22	red	f	\N	2026-06-21 18:12:47.051
cmqo3trva00p6jxf05av1md2o	cmqo3trrz00h9jxf04u385z9f	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	0	1	0	1	0	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trva00p7jxf0x2w924l9	cmqo3trrz00hajxf05t8nln3k	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	2	2	1	0	1	0	0	f	f	8	green	f	\N	2026-06-21 18:12:47.051
cmqo3trva00p8jxf0f7l85jn7	cmqo3trrz00hbjxf0voxqxf8y	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	0	1	1	0	1	1	t	f	7	red	f	\N	2026-06-21 18:12:47.051
cmqo3trva00p9jxf0i1riw5ij	cmqo3trrz00hcjxf0dh38xmsa	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	1	1	1	1	1	1	t	f	9	red	f	\N	2026-06-21 18:12:47.051
cmqo3trva00pajxf01x1uixul	cmqo3trrz00hdjxf05e3o2pl2	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	0	3	1	1	0	0	f	f	7	green	f	\N	2026-06-21 18:12:47.051
cmqo3trva00pbjxf022zvo5xf	cmqo3trrz00hejxf0amg32b9e	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	1	1	3	1	1	1	t	f	11	red	f	\N	2026-06-21 18:12:47.051
cmqo3trva00pcjxf0uolyj562	cmqo3trrz00hfjxf05wn4ufmb	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	0	0	0	1	0	0	0	f	f	1	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trva00pdjxf0g6ysi1n3	cmqo3trrz00hgjxf0obtg8071	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	1	0	1	1	0	0	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trva00pejxf06r7ny2r6	cmqo3trrz00hhjxf0ib8t6qp9	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	0	1	1	1	0	1	0	f	f	5	green	f	\N	2026-06-21 18:12:47.051
cmqo3trva00pfjxf04iwa0qzj	cmqo3trrz00hijxf0ui710mby	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	0	1	0	2	0	0	f	f	6	green	f	\N	2026-06-21 18:12:47.051
cmqo3trva00pgjxf0vpzgk5r4	cmqo3trrz00hjjxf0zv1eo0jl	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	0	1	0	1	0	0	f	t	4	red	f	\N	2026-06-21 18:12:47.051
cmqo3trva00phjxf0dgotjpcx	cmqo3trrz00hkjxf0bpnem85n	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	3	2	3	3	3	3	0	3	2	f	f	22	red	f	\N	2026-06-21 18:12:47.051
cmqo3trva00pijxf04m2cma25	cmqo3trrz00hljxf07u1tlme0	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	1	0	1	0	1	0	0	f	f	3	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trva00pjjxf0yjj7nzbu	cmqo3trrz00hmjxf04tywy4vr	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	1	1	1	1	1	1	0	f	f	7	green	f	\N	2026-06-21 18:12:47.051
cmqo3trva00pkjxf0rc9m2xac	cmqo3trrz00hnjxf0n6h6e20p	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	3	0	1	1	1	1	1	f	f	10	yellow	f	\N	2026-06-21 18:12:47.051
cmqo3trva00pljxf06ch6sa31	cmqo3trrz00hojxf0u0h2h52t	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	1	2	0	3	0	0	f	f	9	green	f	\N	2026-06-21 18:12:47.051
cmqo3trva00pmjxf0b1eoqrc2	cmqo3trrz00hpjxf0e0guc52t	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	1	3	0	0	0	0	f	f	7	green	f	\N	2026-06-21 18:12:47.051
cmqo3trva00pnjxf029wvbdn5	cmqo3trrz00hqjxf0hmac2rbs	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	0	0	0	0	0	0	0	f	f	1	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trva00pojxf0kveoniu1	cmqo3trrz00hrjxf00bgjhomy	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	1	1	0	1	1	0	f	t	6	red	f	\N	2026-06-21 18:12:47.051
cmqo3trva00ppjxf00tvxkoy7	cmqo3trs000hsjxf03i0g0wzd	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	1	1	1	0	1	0	0	f	f	5	green	f	\N	2026-06-21 18:12:47.051
cmqo3trva00pqjxf0my7qbkcc	cmqo3trs000htjxf0mugg0128	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	1	1	1	0	1	0	0	f	f	5	green	f	\N	2026-06-21 18:12:47.051
cmqo3trva00prjxf0ncnwuxsh	cmqo3trs000hujxf0plmf6a9q	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	1	0	0	0	0	0	0	f	f	2	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trva00psjxf0z52sej0u	cmqo3trs000hvjxf0hay1yd1b	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	0	0	0	0	1	0	0	f	f	2	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trva00ptjxf0jipz2roy	cmqo3trs000hwjxf0onvioxl9	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	0	1	1	0	0	0	t	f	4	red	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00pujxf0eabndqmz	cmqo3trs000hxjxf0ls5ywnyl	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	0	0	0	0	0	0	0	f	f	1	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00pvjxf0x3znvtlm	cmqo3trs000hyjxf0xlqjno2q	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	0	1	1	1	2	1	t	t	9	red	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00pwjxf0b0n1bovq	cmqo3trs000hzjxf0im9nokm9	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	0	1	0	0	0	0	t	t	3	red	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00pxjxf0ia8fxz1t	cmqo3trs000i0jxf0qsxdnqfp	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	3	1	1	1	1	1	0	t	t	10	red	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00pyjxf0tjysqurt	cmqo3trs000i1jxf0xnbsk42d	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	1	0	0	0	3	0	0	f	f	5	green	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00pzjxf01k8hdx0y	cmqo3trs000i2jxf0ccykf4ve	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	1	0	1	0	0	1	0	f	f	3	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00q0jxf0uln86xk3	cmqo3trs000i3jxf0nwase7y3	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	3	1	3	1	1	3	3	1	1	f	f	17	orange	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00q1jxf0edt8qrmr	cmqo3trs000i4jxf0p4x5qk8h	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	0	1	1	0	0	0	0	f	f	3	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00q2jxf0qlcz34l0	cmqo3trs000i5jxf0dp72j3pq	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	1	0	0	0	0	0	0	f	f	2	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00q3jxf0hpaix3f5	cmqo3trs000i6jxf07v5el932	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	2	1	1	2	1	1	2	t	f	12	red	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00q4jxf07hp80ndt	cmqo3trs000i7jxf0bpqoolun	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	0	1	1	1	0	0	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00q5jxf0g31yoduw	cmqo3trs000i8jxf0lj5i6ck7	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	1	1	0	1	0	0	f	f	6	green	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00q6jxf0y4mitj8x	cmqo3trs000i9jxf0jd834eom	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	0	0	1	1	1	0	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00q7jxf0cofdde9z	cmqo3trs000iajxf0mybsp82d	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	2	1	1	2	1	2	0	0	f	f	10	yellow	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00q8jxf0j03amc6m	cmqo3trs000ibjxf03zq7wprq	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	0	1	1	0	0	1	f	f	5	green	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00q9jxf0b5n7epg5	cmqo3trs000icjxf076t59xa6	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	0	0	0	0	1	0	0	f	t	2	red	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00qajxf00d7rlhdv	cmqo3trs000idjxf0n2k1bnwt	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	2	1	1	3	2	1	1	f	f	13	yellow	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00qbjxf0lgkbtpkr	cmqo3trs000iejxf0pg6s3ynp	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	0	0	0	0	0	0	f	f	2	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00qcjxf0na7xsdc7	cmqo3trs000ifjxf0ucuxayyy	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	0	0	1	1	0	0	0	f	f	3	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00qdjxf0p5vwwvpk	cmqo3trs000igjxf0j7kpknav	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	1	1	1	0	0	0	t	f	5	red	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00qejxf0nx47cmf3	cmqo3trs000ihjxf0mctf463b	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	0	0	0	0	0	0	0	f	f	0	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00qfjxf0qduzyswj	cmqo3trs000iijxf0t31s6fmx	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	1	1	1	1	0	0	f	f	7	green	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00qgjxf0v1e627wk	cmqo3trs000ijjxf09gsn00fb	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	0	1	0	0	0	0	f	f	3	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00qhjxf0l1bpbdcu	cmqo3trs000ikjxf0c804u77b	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	1	1	1	1	1	0	f	f	8	green	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00qijxf0nl5auick	cmqo3trs000iljxf073575yc4	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	0	1	1	0	0	0	0	f	f	3	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00qjjxf0qoq6r9l7	cmqo3trs000imjxf0ylxsla9o	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	1	0	0	0	0	0	0	f	f	2	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00qkjxf07vdji5pe	cmqo3trs000injxf0ndrfksli	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	1	0	0	0	2	0	0	f	f	3	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00qljxf0zlfmwmul	cmqo3trs000iojxf03imlic74	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	1	0	1	0	2	0	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00qmjxf0azmi4eug	cmqo3trs000ipjxf0sr9qnjle	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	3	1	3	3	3	3	3	1	3	f	f	23	red	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00qnjxf0t0qp1cjq	cmqo3trs000iqjxf0enzzfk5f	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	0	0	1	0	0	0	0	f	f	2	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00qojxf0vufw9exy	cmqo3trs000irjxf0lf2fit85	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	2	0	2	1	1	1	0	f	f	9	green	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00qpjxf07gz9zkr6	cmqo3trs000isjxf0pl8pp3o2	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	2	1	2	3	3	2	1	1	1	t	t	16	red	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00qqjxf04pa64k18	cmqo3trs000itjxf0sltvmwfn	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	2	1	2	1	3	3	1	2	1	t	t	16	red	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00qrjxf0k6d3a7rj	cmqo3trs000iujxf0onfybrs6	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	0	0	1	0	0	0	0	f	f	2	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00qsjxf03in3vx3q	cmqo3trs000ivjxf052cpo9aj	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	1	1	1	1	1	1	f	f	9	green	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00qtjxf05a652ck1	cmqo3trs000iwjxf0hwtqsr99	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	1	2	1	1	2	1	f	f	11	yellow	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00qujxf0wgn6nk7s	cmqo3trs000ixjxf0hpq061q5	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	1	1	0	1	0	0	f	f	5	green	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00qvjxf0flt8t5rb	cmqo3trs000iyjxf0oqdyax91	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	2	1	0	1	0	0	1	f	f	7	green	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00qwjxf0srd734z7	cmqo3trs000izjxf0j6uj6kux	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	2	2	1	1	2	3	1	1	1	t	f	14	red	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00qxjxf05ap0ba88	cmqo3trs000j0jxf0ot96m31s	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	3	0	0	0	0	0	0	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvb00qyjxf06le450jd	cmqo3trs000j1jxf03lktvuey	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	0	0	1	0	0	0	0	f	f	1	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvc00qzjxf0ar7hg0do	cmqo3trs000j2jxf0tinhhty6	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	1	1	2	1	0	1	f	f	9	green	f	\N	2026-06-21 18:12:47.051
cmqo3trvc00r0jxf09qz5bd89	cmqo3trs000j3jxf0sv5e3xv1	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	0	1	1	2	1	1	t	f	9	red	f	\N	2026-06-21 18:12:47.051
cmqo3trvc00r1jxf0thwnke2h	cmqo3trs000j4jxf0p4rubb8t	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	1	1	0	0	0	0	0	f	f	3	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvc00r2jxf0yxiaovfp	cmqo3trs000j5jxf09zar2gc1	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	3	0	1	1	1	1	1	t	f	10	red	f	\N	2026-06-21 18:12:47.051
cmqo3trvc00r3jxf04buswy5s	cmqo3trs000j6jxf0xczzqby1	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	0	1	0	0	1	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvc00r4jxf08iowmr12	cmqo3trs000j7jxf0jg8102o2	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	1	0	1	0	1	0	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvc00r5jxf0dpbtz49c	cmqo3trs000j8jxf0rz8hdwec	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	0	1	1	0	0	0	0	f	f	2	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvc00r6jxf0e4hudtfs	cmqo3trs000j9jxf06zkwvzd9	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	1	0	0	0	0	0	0	f	f	2	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvc00r7jxf027rkrg50	cmqo3trs000jajxf01z2bh5iu	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	0	1	1	1	0	0	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvc00r8jxf0m9bnokdu	cmqo3trs000jbjxf06ln3yal0	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	1	0	1	0	1	0	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvc00r9jxf08cxv5dn9	cmqo3trs000jcjxf0r10e4feu	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	1	1	1	1	1	0	f	t	8	red	f	\N	2026-06-21 18:12:47.051
cmqo3trvc00rajxf0uulqihp0	cmqo3trs000jdjxf0tbqqkbsy	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	1	1	1	1	1	0	0	f	f	6	green	f	\N	2026-06-21 18:12:47.051
cmqo3trvc00rbjxf0r1tyb85q	cmqo3trs000jejxf0lmmwphze	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	0	1	0	3	0	0	f	f	6	green	f	\N	2026-06-21 18:12:47.051
cmqo3trvc00rcjxf01e10z4d6	cmqo3trs000jfjxf0658qeity	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	1	0	1	1	0	0	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvc00rdjxf07kkhqdl4	cmqo3trs000jgjxf0vv2t2h95	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	1	1	0	1	0	0	0	f	f	4	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvc00rejxf0qzgwtd8w	cmqo3trs000jhjxf0t0pfqvi6	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	0	0	1	0	0	0	0	t	f	1	red	f	\N	2026-06-21 18:12:47.051
cmqo3trvc00rfjxf02cmv09no	cmqo3trs000jijxf0c2mgss0e	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	1	0	1	0	0	0	0	f	f	3	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvc00rgjxf0vdhs9mnt	cmqo3trs000jjjxf0kjfj4ptb	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	0	1	2	1	0	0	f	f	6	green	f	\N	2026-06-21 18:12:47.051
cmqo3trvc00rhjxf0lnv348rw	cmqo3trs000jkjxf04p8v0p1e	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	1	0	0	1	1	2	1	f	f	7	green	f	\N	2026-06-21 18:12:47.051
cmqo3trvc00rijxf0hythxyvs	cmqo3trs000jljxf0n1whl2b0	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	0	1	1	0	0	0	f	f	5	green	f	\N	2026-06-21 18:12:47.051
cmqo3trvc00rjjxf0xuuhyikq	cmqo3trs100jmjxf0bk391c8p	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	2	1	1	1	0	0	0	f	f	7	green	f	\N	2026-06-21 18:12:47.051
cmqo3trvc00rkjxf0uqaxq7hf	cmqo3trs100jnjxf04bo0b6mo	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	0	1	2	1	1	0	f	f	7	green	f	\N	2026-06-21 18:12:47.051
cmqo3trvc00rljxf0mo8rfo71	cmqo3trs100jojxf0nzvb6y5x	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	2	0	1	1	2	1	0	f	f	9	green	f	\N	2026-06-21 18:12:47.051
cmqo3trvc00rmjxf0ircw7sa6	cmqo3trs100jpjxf0oc730zbi	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	0	1	1	1	0	0	f	f	5	green	f	\N	2026-06-21 18:12:47.051
cmqo3trvc00rnjxf0blffkq88	cmqo3trs100jqjxf0sz4scm4n	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	1	0	0	0	0	0	0	f	f	1	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvc00rojxf0639g2tru	cmqo3trs100jrjxf07xr2bi8g	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	3	1	1	0	0	0	f	f	7	green	f	\N	2026-06-21 18:12:47.051
cmqo3trvc00rpjxf087d47m57	cmqo3trs100jsjxf0i1fvu5ef	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	1	0	1	1	1	1	0	f	f	6	green	f	\N	2026-06-21 18:12:47.051
cmqo3trvc00rqjxf0p1oaudin	cmqo3trs100jtjxf09x089c05	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	0	1	0	0	0	0	0	0	f	f	1	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvc00rrjxf06s19c4oq	cmqo3trs100jujxf0bczhn08e	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	1	0	1	0	0	0	0	f	f	3	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvd00rsjxf0f34lo826	cmqo3trs100jvjxf0sdr0cmus	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	1	0	0	1	0	0	0	0	f	f	2	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvd00rtjxf0y3v333zc	cmqo3trs100jwjxf0t2475383	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	1	1	0	2	0	0	f	f	7	green	f	\N	2026-06-21 18:12:47.051
cmqo3trvd00rujxf0wd6lh39v	cmqo3trs100jxjxf04s5qfo5x	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	0	0	1	0	0	0	0	t	f	2	red	f	\N	2026-06-21 18:12:47.051
cmqo3trvd00rvjxf0vb05uboa	cmqo3trs100jyjxf0qxkwq3vw	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	0	0	1	0	0	0	0	t	t	2	red	f	\N	2026-06-21 18:12:47.051
cmqo3trvd00rwjxf0t15m36my	cmqo3trs100jzjxf0k8chpi77	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	3	3	3	3	3	3	1	3	3	t	t	25	red	f	\N	2026-06-21 18:12:47.051
cmqo3trvd00rxjxf08q087ej3	cmqo3trs100k0jxf0s2cnypqs	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	1	0	1	0	1	0	0	f	f	5	green	f	\N	2026-06-21 18:12:47.051
cmqo3trvd00ryjxf031gnetr9	cmqo3trs100k1jxf08dm66p9q	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	0	0	1	0	1	1	0	f	f	5	green	f	\N	2026-06-21 18:12:47.051
cmqo3trvd00rzjxf0skessz1r	cmqo3trs100k2jxf0cm47oiks	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	3	0	1	1	1	0	0	f	f	8	green	f	\N	2026-06-21 18:12:47.051
cmqo3trvd00s0jxf08f87a8gp	cmqo3trs100k3jxf0lbg6txs7	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	0	2	1	0	1	0	1	0	0	f	f	5	green	f	\N	2026-06-21 18:12:47.051
cmqo3trvd00s1jxf0bwdwcj1l	cmqo3trs100k4jxf0cq5um2rb	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	0	0	0	1	0	0	0	0	f	f	2	blue	f	\N	2026-06-21 18:12:47.051
cmqo3trvd00s2jxf0ibaouk9t	cmqo3trs100k5jxf0ebzyyxab	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	3	1	3	1	3	0	3	1	0	f	f	15	orange	f	\N	2026-06-21 18:12:47.051
cmqo3trvd00s3jxf02zl5viqs	cmqo3trs100k6jxf097odkcaq	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	3	1	3	1	3	3	1	0	0	f	f	15	orange	f	\N	2026-06-21 18:12:47.051
cmqo3trvd00s4jxf001uodlqa	cmqo3trs100k7jxf0d2yw252j	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	2	1	1	3	1	3	1	1	1	f	t	14	red	f	\N	2026-06-21 18:12:47.051
cmqo3trvd00s5jxf0kudcs2sc	cmqo3trs100k8jxf096uofmtk	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	2	1	2	3	1	2	0	f	f	13	yellow	f	\N	2026-06-21 18:12:47.051
cmqo3trvd00s6jxf0w2he50gu	cmqo3trs100k9jxf0zd5abti7	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	3	1	0	0	3	3	1	3	1	f	f	15	orange	f	\N	2026-06-21 18:12:47.051
cmqo3trvd00s7jxf0shq459ix	cmqo3trs100kajxf0afxapwkn	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	3	2	1	1	1	1	0	f	f	11	yellow	f	\N	2026-06-21 18:12:47.051
cmqo3trvd00s8jxf035qn65ux	cmqo3trs100kbjxf00at60v0s	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	3	2	1	0	3	3	1	1	3	f	f	17	orange	f	\N	2026-06-21 18:12:47.051
cmqo3trvd00s9jxf0e38s3ncd	cmqo3trs100kcjxf03d64gxgg	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	3	3	1	0	1	3	1	1	3	f	f	16	orange	f	\N	2026-06-21 18:12:47.051
cmqo3trvd00sajxf0nanf1r1r	cmqo3trs100kdjxf0so7lged7	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	2	1	2	3	1	1	0	1	1	f	f	12	yellow	f	\N	2026-06-21 18:12:47.051
cmqo3trvd00sbjxf06iqhr5p8	cmqo3trs100kejxf06v05c5fm	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	2	1	1	1	1	1	1	f	f	10	yellow	f	\N	2026-06-21 18:12:47.051
cmqo3trvd00scjxf0nsu8ajyv	cmqo3trs100kfjxf0m4itmu0z	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	1	2	1	3	1	1	1	0	f	f	11	yellow	f	\N	2026-06-21 18:12:47.051
cmqo3trvd00sdjxf0bn0dim07	cmqo3trs100kgjxf0sd21964h	cmp6j4rh20002jxuik5drdqtt	cmq0kgjsg000njx23n27h0rcx	1	1	2	1	1	2	2	1	1	2	f	f	13	yellow	f	\N	2026-06-21 18:12:47.051
cmr254jms009fjxctm2uqzgyg	cmr254jj6001ijxct0thvp7fd	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	0	3	1	0	0	0	3	0	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jms009gjxct8vs5ndn6	cmr254jj6001jjxctvt06lll6	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	0	1	3	1	0	1	0	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jms009hjxctxqc1jcyl	cmr254jj6001kjxct1wt4ieey	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	0	0	1	1	0	1	0	f	f	5	green	f	\N	2026-07-01 13:57:55.679
cmr254jms009ijxctejyw577w	cmr254jj6001ljxct3dsq8br7	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	0	1	1	0	1	1	0	1	0	f	f	5	green	f	\N	2026-07-01 13:57:55.679
cmr254jms009jjxct23t8tn0b	cmr254jj6001mjxcttgoon3hz	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	0	1	1	0	1	1	1	0	0	f	f	5	green	f	\N	2026-07-01 13:57:55.679
cmr254jms009kjxctyq1lkvfe	cmr254jj6001njxctguuj6dv1	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	0	0	1	0	2	0	0	f	f	5	green	f	\N	2026-07-01 13:57:55.679
cmr254jms009ljxctgi2zbnzc	cmr254jj6001ojxct93uhsc2s	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	0	1	2	0	0	0	f	f	6	green	f	\N	2026-07-01 13:57:55.679
cmr254jms009mjxct99hi26u9	cmr254jj6001pjxct30c1mgbd	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	0	1	1	1	1	0	0	f	f	6	green	f	\N	2026-07-01 13:57:55.679
cmr254jmt009njxctkuatett5	cmr254jj6001qjxct1t13zel2	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	0	1	3	0	2	1	0	0	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jmt009ojxctx9sifif9	cmr254jj6001rjxctwo94bb0e	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	0	1	1	3	0	0	3	0	0	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jmt009pjxcttz5swkwp	cmr254jj6001sjxctbrd5u4o4	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	0	2	1	0	0	0	0	1	f	f	5	green	f	\N	2026-07-01 13:57:55.679
cmr254jmt009qjxctdzu33z7h	cmr254jj6001tjxct70n7ucdd	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	0	1	1	0	1	1	0	0	f	f	5	green	f	\N	2026-07-01 13:57:55.679
cmr254jmt009rjxctwvz10alt	cmr254jj6001ujxctg4rj6nid	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	0	0	0	1	3	0	0	0	f	f	5	green	f	\N	2026-07-01 13:57:55.679
cmr254jmt009sjxctcrwx5g39	cmr254jj6001vjxctb0xb16xc	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	0	1	1	0	0	0	f	f	5	green	f	\N	2026-07-01 13:57:55.679
cmr254jmt009tjxct0jrx2brb	cmr254jj6001wjxctpjg6xpx8	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	0	1	0	1	0	0	1	f	f	5	green	f	\N	2026-07-01 13:57:55.679
cmr254jmt009ujxctaheswmws	cmr254jj6001xjxctxl5hi4td	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	1	0	0	0	1	f	f	6	green	f	\N	2026-07-01 13:57:55.679
cmr254jmt009vjxct8ef9246q	cmr254jj6001yjxctpb8vh5gl	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	1	0	1	1	1	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jmt009wjxctjz6kds6l	cmr254jj6001zjxcty6l1f2m2	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	0	0	1	0	1	1	f	f	6	green	f	\N	2026-07-01 13:57:55.679
cmr254jmt009xjxctmqpw5w52	cmr254jj60020jxctuhdrxbok	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	2	1	1	2	0	1	1	0	f	f	9	green	f	\N	2026-07-01 13:57:55.679
cmr254jmt009yjxct0mxolg4s	cmr254jj60021jxct8e2jqy0p	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	0	0	1	1	0	1	1	0	1	f	f	5	green	f	\N	2026-07-01 13:57:55.679
cmr254jmt009zjxctvk0zsx7m	cmr254jj60022jxctn4iispfx	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	0	0	1	1	3	1	0	0	1	f	f	7	green	f	\N	2026-07-01 13:57:55.679
cmr254jmt00a0jxctfj09azgd	cmr254jj60023jxctwd7irxur	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	0	1	0	1	0	0	f	f	5	green	f	\N	2026-07-01 13:57:55.679
cmr254jmt00a1jxctt2rlnjq0	cmr254jj60024jxct0np4tbk8	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	0	1	1	1	0	1	f	f	7	green	f	\N	2026-07-01 13:57:55.679
cmr254jmt00a2jxct3hh7wi53	cmr254jj60025jxct741n3p4j	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	0	0	1	1	0	1	f	f	6	green	f	\N	2026-07-01 13:57:55.679
cmr254jmt00a3jxctopm1x5vv	cmr254jj60026jxctqe54xgl5	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	0	2	1	0	2	1	1	1	f	f	9	green	f	\N	2026-07-01 13:57:55.679
cmr254jmt00a4jxctlm17vquv	cmr254jj60027jxct36hjoqdt	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	1	1	1	1	0	0	1	0	f	f	7	green	f	\N	2026-07-01 13:57:55.679
cmr254jmt00a5jxctxing5e1t	cmr254jj60028jxcty4paqbmo	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	0	1	1	1	0	1	f	f	7	green	f	\N	2026-07-01 13:57:55.679
cmr254jmt00a6jxct0w05vpy6	cmr254jj60029jxct05or0ma1	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	1	0	2	1	1	0	1	0	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jmt00a7jxcti4rc9aha	cmr254jj6002ajxct2ybkqca0	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	1	1	0	1	1	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jmt00a8jxctr2bhz0sg	cmr254jj6002bjxctnbqb8fw7	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	0	1	1	1	1	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jmt00a9jxctulvf0alf	cmr254jj6002cjxctg6t5rr8z	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	1	0	1	1	1	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jmt00aajxctwjtcifb5	cmr254jj6002djxctpng681vy	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	0	1	1	1	1	1	1	0	f	f	7	green	f	\N	2026-07-01 13:57:55.679
cmr254jmt00abjxctt00w8et8	cmr254jj7002ejxctdh6ru24c	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	0	1	1	0	1	0	f	f	6	green	f	\N	2026-07-01 13:57:55.679
cmr254jmt00acjxctg815i8ah	cmr254jj7002fjxct0wnn4y6u	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	0	3	0	1	1	1	0	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jmt00adjxct7cwvd6r4	cmr254jj7002gjxct30bu8lbq	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	0	1	2	1	2	1	0	1	f	f	9	green	f	\N	2026-07-01 13:57:55.679
cmr254jmt00aejxctr8eoeoqh	cmr254jj7002hjxctj2eqtt02	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	0	0	1	0	1	3	0	0	0	f	f	5	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00afjxct0igrn0oz	cmr254jj7002ijxctpfcaqnao	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	0	0	1	1	0	1	2	1	1	f	f	7	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00agjxcteo9mmf5w	cmr254jj7002jjxctlupbi8w4	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	2	1	1	1	1	0	f	f	9	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00ahjxct5cvgm0ut	cmr254jj7002kjxctnzyfru1y	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	1	0	1	1	3	0	0	0	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00aijxct2ijc6utz	cmr254jj7002ljxct56w0r9pl	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	0	0	2	1	0	1	0	f	f	6	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00ajjxct1y56rsvo	cmr254jj7002mjxctz289p462	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	3	0	0	0	0	0	f	f	6	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00akjxct1xyx0qcn	cmr254jj7002njxctw03m3kv0	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	2	1	2	1	0	0	0	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00aljxctbh82ouk1	cmr254jj7002ojxct7oqv16mz	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	3	3	0	0	0	0	0	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00amjxct3jn0clek	cmr254jj7002pjxctyevwpk8i	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	1	1	1	0	0	f	f	7	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00anjxctgi7jx7fl	cmr254jj7002qjxctxjyisl8l	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	0	1	0	0	1	2	f	f	7	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00aojxct96s3nctx	cmr254jj7002rjxctanv8gs8c	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	1	1	0	3	0	0	1	0	f	f	9	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00apjxct3sqn1bhr	cmr254jj7002sjxctktxnj5fz	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	0	0	1	1	0	1	2	0	f	f	6	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00aqjxctpjpmssrg	cmr254jj7002tjxctms5epztx	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	0	0	1	1	1	1	0	1	0	f	f	5	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00arjxctur6gcwzl	cmr254jj7002ujxct3xaeidb6	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	2	0	1	3	0	0	0	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00asjxct954uz7vx	cmr254jj7002vjxctop3e7v09	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	2	2	1	0	1	0	f	f	9	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00atjxctapewqvj3	cmr254jj7002wjxctfyr3g1vg	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	0	2	1	0	0	f	f	7	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00aujxctskst0rqz	cmr254jj7002xjxctn1uw6a80	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	0	1	1	0	1	0	f	f	6	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00avjxctbgmbqz4r	cmr254jj7002yjxct9nv0lmyk	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	0	1	1	0	1	2	1	0	0	f	f	6	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00awjxctl5k6961l	cmr254jj7002zjxctn6jn7zey	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	0	0	0	1	1	1	1	0	1	f	f	5	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00axjxct8vrmutun	cmr254jj70030jxct40ofpuia	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	0	0	1	1	1	1	0	0	f	f	5	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00ayjxctutiirkum	cmr254jj70031jxctez0qlkln	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	0	0	2	1	0	1	0	f	f	6	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00azjxct14k25r7r	cmr254jj70032jxctatwgtpr0	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	2	0	1	0	0	0	0	f	f	5	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00b0jxctueed0vg9	cmr254jj70033jxctclizgpto	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	0	1	1	0	1	0	0	0	f	f	6	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00b1jxctg33gk5nj	cmr254jj70034jxct7ndptjf1	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	0	1	0	1	1	1	0	0	f	f	5	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00b2jxcti5ctv35b	cmr254jj70035jxctoqk9yw3k	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	0	1	1	0	0	0	f	f	5	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00b3jxctm2xkmv69	cmr254jj70036jxctjseudr3n	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	1	0	1	1	0	f	f	7	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00b4jxctgrbjwuml	cmr254jj70037jxctlgbgsobx	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	0	1	1	0	1	1	0	2	0	f	f	6	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00b5jxctrw6bbswq	cmr254jj70038jxctjbykzfgb	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	0	1	1	1	1	2	1	0	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00b6jxctcu1od8qb	cmr254jj70039jxctczd3obvs	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	2	0	1	3	0	1	1	0	f	f	9	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00b7jxctvmabnkzv	cmr254jj7003ajxct6d05b5cf	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	0	1	1	0	1	1	0	1	0	f	f	5	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00b8jxct0z307ray	cmr254jj7003bjxctsyxzrora	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	0	1	2	1	1	2	1	0	f	f	9	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00b9jxcta9k8dc7e	cmr254jj7003cjxctipojt240	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	1	1	0	1	0	f	f	7	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00bajxct86dktnl7	cmr254jj7003djxctqlqpcyzc	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	0	0	1	1	1	0	0	f	f	5	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00bbjxctukmp812t	cmr254jj7003ejxctr1w3ozma	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	0	1	1	0	1	0	f	f	6	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00bcjxctnm344cgt	cmr254jj7003fjxctxc8ffa6t	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	0	2	0	0	0	0	f	f	5	green	f	\N	2026-07-01 13:57:55.679
cmr254jmu00bdjxctcsro24xe	cmr254jj7003gjxctomi8egy6	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	0	1	2	2	0	0	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jmv00bejxctfcsx5r19	cmr254jj7003hjxct5gqfx5lx	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	1	1	0	0	0	f	f	6	green	f	\N	2026-07-01 13:57:55.679
cmr254jmv00bfjxctbcra3ahb	cmr254jj7003ijxctjbh9avxi	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	0	1	2	1	0	1	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jmv00bgjxctzumco5qw	cmr254jj8003jjxctz8xdvrl3	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	0	0	3	0	2	0	0	f	f	7	green	f	\N	2026-07-01 13:57:55.679
cmr254jmv00bhjxcte7rc63ei	cmr254jj8003kjxctrdrhhw0v	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	2	1	1	2	0	0	1	f	f	9	green	f	\N	2026-07-01 13:57:55.679
cmr254jmv00bijxctd0x96qt0	cmr254jj8003ljxctn2m88vr9	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	0	1	1	1	3	0	f	f	9	green	f	\N	2026-07-01 13:57:55.679
cmr254jmv00bjjxct58emkweb	cmr254jj8003mjxctjqsm5fml	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	2	0	0	1	0	1	0	0	f	f	5	green	f	\N	2026-07-01 13:57:55.679
cmr254jmv00bkjxct1a6f2pp3	cmr254jj8003njxct1yfejuff	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	0	1	1	1	0	1	f	f	7	green	f	\N	2026-07-01 13:57:55.679
cmr254jmv00bljxctxnvqvf49	cmr254jj8003ojxctgovae9fb	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	0	1	0	1	2	1	0	f	f	7	green	f	\N	2026-07-01 13:57:55.679
cmr254jmv00bmjxctzks1kltl	cmr254jj8003pjxct8rwa06d9	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	1	1	0	0	0	f	f	6	green	f	\N	2026-07-01 13:57:55.679
cmr254jmv00bnjxct48dar3ea	cmr254jj8003qjxctfrbnb19r	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	0	0	0	0	1	1	1	2	0	f	f	5	green	f	\N	2026-07-01 13:57:55.679
cmr254jmv00bojxct91gzs8lo	cmr254jj8003rjxctxia500wk	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	0	0	3	0	1	0	f	f	7	green	f	\N	2026-07-01 13:57:55.679
cmr254jmv00bpjxcto1wdnwpa	cmr254jj8003sjxctz75d4m0f	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	1	1	1	1	1	f	f	9	green	f	\N	2026-07-01 13:57:55.679
cmr254jmv00bqjxcta881eagb	cmr254jj8003tjxctpex96m2r	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	0	1	1	0	2	0	3	1	0	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jmv00brjxctiwhoko9s	cmr254jj8003ujxctotiq1zwy	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	1	0	1	0	0	f	f	6	green	f	\N	2026-07-01 13:57:55.679
cmr254jmv00bsjxct9ungalmy	cmr254jj8003vjxctkj6m9wt8	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	0	1	1	1	1	0	1	f	f	7	green	f	\N	2026-07-01 13:57:55.679
cmr254jmv00btjxcts4336i7s	cmr254jj8003wjxct4scxdfcj	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	0	0	1	0	3	1	0	f	f	7	green	f	\N	2026-07-01 13:57:55.679
cmr254jmv00bujxct7wgapql8	cmr254jj8003xjxct0kzvzjli	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	1	1	1	1	1	f	f	9	green	f	\N	2026-07-01 13:57:55.679
cmr254jmv00bvjxctnab2sqoc	cmr254jj8003yjxctgb8nm2ik	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	2	1	1	1	1	0	0	1	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jmv00bwjxctyce1zrjn	cmr254jj8003zjxctgslefl05	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	1	1	1	1	1	f	f	9	green	f	\N	2026-07-01 13:57:55.679
cmr254jmv00bxjxct7j06cw9o	cmr254jj80040jxct7z0rgqa7	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	3	1	1	1	0	0	f	f	9	green	f	\N	2026-07-01 13:57:55.679
cmr254jmv00byjxctk8m7rut2	cmr254jj80041jxctmnla9ma7	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	2	2	1	0	0	f	f	9	green	f	\N	2026-07-01 13:57:55.679
cmr254jmv00bzjxctoh9wxmxb	cmr254jj80042jxcttwpznq8q	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	1	1	1	1	0	1	0	0	f	f	7	green	f	\N	2026-07-01 13:57:55.679
cmr254jmv00c0jxctp8msfvba	cmr254jj80043jxctb9ly8dom	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	2	1	1	1	1	0	0	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jmv00c1jxct7hnw3ed5	cmr254jj80044jxct1earz6e1	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	0	0	1	3	1	0	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jmv00c2jxctzirneyz0	cmr254jj80045jxctego6v6ne	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	3	1	0	1	1	0	0	0	f	f	7	green	f	\N	2026-07-01 13:57:55.679
cmr254jmv00c3jxcthbhc09fb	cmr254jj80046jxct3s834408	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	2	2	1	0	0	0	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jmv00c4jxctrek5dvpa	cmr254jj80047jxct6iaq1r3y	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	0	0	0	1	3	0	0	1	f	f	6	green	f	\N	2026-07-01 13:57:55.679
cmr254jmv00c5jxctwv4yq6eq	cmr254jj80048jxctsdu3uoop	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	2	1	1	1	1	1	0	f	f	9	green	f	\N	2026-07-01 13:57:55.679
cmr254jmv00c6jxctzsrwge53	cmr254jj80049jxct1rj1qewz	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	3	0	1	1	0	0	0	f	f	7	green	f	\N	2026-07-01 13:57:55.679
cmr254jmw00c7jxctkg8oe3c7	cmr254jj8004ajxct2i9jrhd6	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	2	3	2	1	1	1	0	1	f	f	14	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmw00c8jxctozy7ktyx	cmr254jj8004bjxct6ztt3jio	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	0	0	1	1	2	1	1	1	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jmw00c9jxct8or7wr1f	cmr254jj8004cjxctzsdr2b2b	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	3	0	0	1	0	0	1	1	f	f	7	green	f	\N	2026-07-01 13:57:55.679
cmr254jmw00cajxct1z5cxpvr	cmr254jj8004djxctu66tc348	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	0	0	3	1	1	0	0	f	f	7	green	f	\N	2026-07-01 13:57:55.679
cmr254jmw00cbjxct3rs40m08	cmr254jj8004ejxctcbrfp50r	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	0	1	1	1	0	0	f	f	6	green	f	\N	2026-07-01 13:57:55.679
cmr254jmw00ccjxcth01nhr8m	cmr254jj8004fjxctz1wc7cwl	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	0	1	0	1	0	0	f	f	5	green	f	\N	2026-07-01 13:57:55.679
cmr254jmw00cdjxctev88gw05	cmr254jj8004gjxct2tnvqv4u	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	0	1	0	1	1	0	f	f	6	green	f	\N	2026-07-01 13:57:55.679
cmr254jmw00cejxctl7zg2sa2	cmr254jj8004hjxctedpu9yzb	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	1	2	0	0	0	f	f	7	green	f	\N	2026-07-01 13:57:55.679
cmr254jmw00cfjxctt22w00qi	cmr254jj8004ijxct6cd2ylyk	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	1	1	1	1	0	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jmw00cgjxcty9a4ju5n	cmr254jj8004jjxctmjhvdgji	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	0	1	1	1	1	1	1	0	f	f	7	green	f	\N	2026-07-01 13:57:55.679
cmr254jmw00chjxct04acld9i	cmr254jj8004kjxctcm1579ne	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	0	3	1	0	1	1	0	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jmw00cijxctek03d14j	cmr254jj8004ljxct0nm1kdag	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	0	1	1	1	2	1	f	f	9	green	f	\N	2026-07-01 13:57:55.679
cmr254jmw00cjjxctwqsgpuxz	cmr254jj8004mjxct60avukf8	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	0	3	1	0	1	1	0	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jmw00ckjxct2cxumm6h	cmr254jj8004njxctb05soxf1	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	0	3	1	0	1	1	0	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jmw00cljxctuf2rl77x	cmr254jj8004ojxctr9eyx073	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	0	3	1	0	1	1	0	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jmw00cmjxct31u7a3a4	cmr254jj9004pjxcts1r3ba26	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	1	1	0	1	1	1	1	1	f	f	10	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmw00cnjxctrv2k2lzg	cmr254jj9004qjxctccn4l6d0	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	1	1	0	1	0	1	0	0	f	f	6	green	f	\N	2026-07-01 13:57:55.679
cmr254jmw00cojxct96t43f1i	cmr254jj9004rjxctv7g9cke4	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	3	1	1	0	0	f	f	9	green	f	\N	2026-07-01 13:57:55.679
cmr254jmw00cpjxctb0thuo0z	cmr254jj9004sjxct5yjazz84	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	1	0	1	1	1	1	0	0	f	f	7	green	f	\N	2026-07-01 13:57:55.679
cmr254jmw00cqjxctr5adrskl	cmr254jj9004tjxctkbasrjun	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	0	0	0	0	0	0	f	f	3	blue	f	\N	2026-07-01 13:57:55.679
cmr254jmw00crjxctyaud849b	cmr254jj9004ujxctlqakkxx1	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	1	1	1	1	1	f	f	9	green	f	\N	2026-07-01 13:57:55.679
cmr254jmw00csjxctst2qxsgq	cmr254jj9004vjxctele0ln6q	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	1	0	0	0	0	f	f	5	green	f	\N	2026-07-01 13:57:55.679
cmr254jmw00ctjxctdfbkchrg	cmr254jj9004wjxct9wavr8x8	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	1	1	1	1	1	f	f	9	green	f	\N	2026-07-01 13:57:55.679
cmr254jmw00cujxctrklck0xu	cmr254jj9004xjxctf82maoas	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	1	1	1	1	0	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jmw00cvjxctud5f16bm	cmr254jj9004yjxctkqrsx4z0	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	1	1	1	1	0	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jmw00cwjxctdc3vvt6u	cmr254jj9004zjxct8y1cnv8l	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	0	1	1	1	1	0	f	f	7	green	f	\N	2026-07-01 13:57:55.679
cmr254jmw00cxjxcthz2y565d	cmr254jj90050jxctgh6bhswf	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	1	1	1	1	0	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jmw00cyjxctsd1z5ts8	cmr254jj90051jxcthq83q8vy	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	0	1	0	1	1	0	0	0	f	f	4	blue	f	\N	2026-07-01 13:57:55.679
cmr254jmx00czjxctmxgyhvyv	cmr254jj90052jxct91t14y6y	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	3	1	1	0	0	0	0	f	f	7	green	f	\N	2026-07-01 13:57:55.679
cmr254jmx00d0jxctqp2csy2x	cmr254jj90053jxcterfpk1zl	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	3	3	1	3	1	1	1	0	f	f	16	orange	f	\N	2026-07-01 13:57:55.679
cmr254jmx00d1jxctodltnfzf	cmr254jj90054jxcte8fdkrui	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	1	1	1	1	0	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jmx00d2jxct9ov4x39l	cmr254jj90055jxct502vj8jp	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	2	3	1	1	0	0	1	2	f	f	11	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmx00d3jxctw15wmoxt	cmr254jj90056jxct8zyd72or	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	1	3	1	1	1	1	0	0	f	f	10	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmx00d4jxctn47xqmia	cmr254jj90057jxctwje3v43w	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	1	2	1	0	2	1	0	2	f	f	11	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmx00d5jxctrsaq1qg8	cmr254jj90058jxctbkeet4dr	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	3	1	0	1	1	1	f	f	10	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmx00d6jxctq1s3mygh	cmr254jj90059jxctbt29cczv	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	2	1	1	2	2	1	1	3	f	f	14	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmx00d7jxctx6bevfl7	cmr254jj9005ajxctt7n7gdhw	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	0	1	1	1	3	3	1	f	f	12	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmx00d8jxctsnfv6rxn	cmr254jj9005bjxctzjtz49w2	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	3	2	1	3	1	f	f	14	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmx00d9jxct7mj7p38c	cmr254jj9005cjxctxj2sae3q	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	2	1	1	2	1	0	1	f	f	10	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmx00dajxctr14qhlpf	cmr254jj9005djxctrkqpkwer	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	1	1	2	1	3	1	0	3	f	f	14	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmx00dbjxct6franhlk	cmr254jj9005ejxct3dshgd2q	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	1	3	1	1	0	f	f	10	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmx00dcjxcthcwfuw2m	cmr254jj9005fjxctayssosxa	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	0	3	3	3	1	1	f	f	14	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmx00ddjxctq8rv7mkm	cmr254jj9005gjxctn1kvfmin	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	1	1	1	1	2	1	1	0	f	f	11	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmx00dejxctsvdfwvkv	cmr254jj9005hjxctyx0mufj6	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	3	1	3	1	1	f	f	13	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmx00dfjxctowmj8iu2	cmr254jj9005ijxctepqqasb1	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	2	1	2	3	0	1	f	f	12	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmx00dgjxctdnhr9dcz	cmr254jj9005jjxct0e2lioa5	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	1	2	1	3	3	1	1	2	f	f	17	orange	f	\N	2026-07-01 13:57:55.679
cmr254jmx00dhjxctp6sw28os	cmr254jj9005kjxctdbv3cldg	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	2	0	1	2	2	1	0	1	f	f	10	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmx00dijxctykajbam9	cmr254jj9005ljxctslhf9zow	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	1	1	1	1	2	0	1	1	f	f	11	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmx00djjxctlxzx80sk	cmr254jj9005mjxcteseajcaz	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	2	2	1	1	0	f	f	10	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmx00dkjxctae07bxuw	cmr254jj9005njxct0ltbxrfq	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	0	3	1	3	2	1	f	f	13	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmx00dljxctjp050apn	cmr254jj9005ojxctk6aeclko	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	2	1	1	2	1	1	1	0	f	f	12	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmx00dmjxctgz1afg19	cmr254jj9005pjxctteobosx4	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	3	1	2	3	1	0	0	f	f	12	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmx00dnjxcttjbaa0q6	cmr254jj9005qjxctyhfgshq4	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	1	1	1	2	2	1	0	0	f	f	10	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmx00dojxct8gezcb48	cmr254jj9005rjxctiueb7u5g	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	3	0	3	0	0	0	0	f	f	8	green	f	\N	2026-07-01 13:57:55.679
cmr254jmx00dpjxctjfo8vwjt	cmr254jj9005sjxcthtvtizdq	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	3	0	1	0	1	0	0	f	f	7	green	f	\N	2026-07-01 13:57:55.679
cmr254jmx00dqjxctyltjpl4h	cmr254jj9005tjxctxewv1rya	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	3	1	1	1	1	1	0	f	f	10	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmx00drjxctptfxfwdw	cmr254jj9005ujxct1acqdna9	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	2	1	2	1	1	1	0	f	f	10	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmy00dsjxctqpqjfr5r	cmr254jja005vjxct70xecv9o	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	1	1	0	1	1	1	1	1	f	f	10	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmy00dtjxctthrma71h	cmr254jja005wjxctiumw4gx6	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	1	2	1	0	3	0	1	0	f	f	11	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmy00dujxct66ajlpct	cmr254jja005xjxct5pstbp3w	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	2	1	2	3	1	2	0	f	f	13	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmy00dvjxctk8a6h0l1	cmr254jja005yjxct6tr26hcf	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	3	2	2	1	1	1	f	f	13	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmy00dwjxctzavdcvb4	cmr254jja005zjxcth6i2sorj	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	2	2	1	1	2	f	f	12	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmy00dxjxctk4yoe40u	cmr254jja0060jxct05820s3l	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	2	3	1	1	1	0	1	0	f	f	10	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmy00dyjxctdbamg9kv	cmr254jja0061jxctqoe104vj	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	3	1	1	1	2	3	0	2	f	f	14	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmy00dzjxctx3c6i28h	cmr254jja0062jxct35ydfwe7	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	0	0	3	1	3	1	1	0	1	f	f	10	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmy00e0jxct2afx3j4y	cmr254jja0063jxctu1a6nkb5	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	2	2	2	1	1	1	1	0	f	f	11	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmy00e1jxct7aqj3xvv	cmr254jja0064jxctfu6t21ls	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	2	1	2	2	1	0	1	f	f	11	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmy00e2jxctphz9yvyx	cmr254jja0065jxct0sakw43p	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	2	2	2	1	1	0	1	1	f	f	11	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmy00e3jxct2f7jdq59	cmr254jja0066jxct15e4wlkc	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	1	3	2	1	0	0	1	1	f	f	11	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmy00e4jxctksps0p91	cmr254jja0067jxctalxehres	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	3	3	1	3	1	0	0	0	f	f	12	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmy00e5jxctoo3nvp2d	cmr254jja0068jxctentnbggv	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	3	1	1	1	1	1	1	f	f	11	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmy00e6jxct8p8yp7ak	cmr254jja0069jxctwhb7t2vp	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	3	1	0	2	3	0	0	0	f	f	10	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmy00e7jxctwhk32vp8	cmr254jja006ajxctab9fzoa0	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	1	2	1	1	3	0	0	1	f	f	12	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmy00e8jxct7n59bd7q	cmr254jja006bjxctyhssqqft	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	1	2	2	2	1	1	1	0	f	f	12	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmy00e9jxctg55hv80z	cmr254jja006cjxct8tc2ylem	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	3	3	1	3	1	0	0	0	f	f	12	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmy00eajxct1r531hpa	cmr254jja006djxctcmhnrqvc	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	2	1	3	3	0	1	f	f	13	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmy00ebjxct2zqbawg9	cmr254jja006ejxct0pf26040	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	3	1	1	1	1	0	1	f	f	10	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmy00ecjxct2qkup8jm	cmr254jja006fjxctsrpkyaz5	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	3	3	1	1	1	1	f	f	13	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmy00edjxct4f0u53o2	cmr254jja006gjxcth7ncanj6	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	1	1	2	3	1	1	2	1	f	f	14	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmy00eejxct30rx5bik	cmr254jja006hjxctyy6usdck	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	3	0	1	2	1	0	1	f	f	10	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmy00efjxct6vpte65c	cmr254jja006ijxct2hnajz42	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	2	2	2	0	3	3	0	f	f	14	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmy00egjxct84wdxvz3	cmr254jja006jjxctjbrpodxx	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	0	3	1	3	3	2	1	2	f	f	18	orange	f	\N	2026-07-01 13:57:55.679
cmr254jmy00ehjxct4y6a8c06	cmr254jja006kjxct32hn1kjl	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	1	2	3	1	2	3	1	3	f	f	19	orange	f	\N	2026-07-01 13:57:55.679
cmr254jmy00eijxctnvyjqxsf	cmr254jja006ljxctm2g689nn	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	3	2	1	3	1	1	2	0	f	f	16	orange	f	\N	2026-07-01 13:57:55.679
cmr254jmy00ejjxctughimc7k	cmr254jja006mjxctisfb5pzj	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	2	3	1	1	3	2	3	3	f	f	19	orange	f	\N	2026-07-01 13:57:55.679
cmr254jmz00ekjxctiyw7os0f	cmr254jja006njxctwnviiryh	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	2	1	1	3	3	2	2	3	f	f	18	orange	f	\N	2026-07-01 13:57:55.679
cmr254jmz00eljxctt40tp8n4	cmr254jja006ojxct0sxd72c6	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	1	3	1	3	3	0	1	3	f	f	18	orange	f	\N	2026-07-01 13:57:55.679
cmr254jmz00emjxctl0whe209	cmr254jja006pjxctdqrlwhdt	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	1	2	1	3	3	0	1	3	f	f	17	orange	f	\N	2026-07-01 13:57:55.679
cmr254jmz00enjxctlxym678o	cmr254jja006qjxctsx693uf5	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	2	1	1	2	2	2	3	1	f	f	16	orange	f	\N	2026-07-01 13:57:55.679
cmr254jmz00eojxcte6ki0dta	cmr254jja006rjxcty8rk0tit	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	1	2	1	1	3	1	1	3	f	f	15	orange	f	\N	2026-07-01 13:57:55.679
cmr254jmz00epjxcto4fixcff	cmr254jja006sjxcth7kvuqn4	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	3	3	1	1	2	3	f	f	16	orange	f	\N	2026-07-01 13:57:55.679
cmr254jmz00eqjxctbwpkwet9	cmr254jja006tjxct50nal3zr	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	3	3	1	2	2	2	1	0	f	f	16	orange	f	\N	2026-07-01 13:57:55.679
cmr254jmz00erjxctbf0uanpt	cmr254jja006ujxct5n3k0suz	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	3	1	3	1	1	3	2	1	f	f	18	orange	f	\N	2026-07-01 13:57:55.679
cmr254jmz00esjxctwpzomzgd	cmr254jja006vjxctym6hgo8f	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	2	3	3	3	2	2	1	1	f	f	18	orange	f	\N	2026-07-01 13:57:55.679
cmr254jmz00etjxctiq30vbtb	cmr254jja006wjxctjae4lmci	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	1	3	1	3	1	1	3	0	f	f	16	orange	f	\N	2026-07-01 13:57:55.679
cmr254jmz00eujxcto4n7ckhs	cmr254jja006xjxctrvbog7ot	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	0	1	3	1	3	3	0	0	f	f	12	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmz00evjxct1do1n0u8	cmr254jjb006yjxcttsje3ebg	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	0	2	3	2	1	0	f	f	11	yellow	f	\N	2026-07-01 13:57:55.679
cmr254jmz00ewjxctzbc73ne1	cmr254jjb006zjxctj6g8mblk	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	2	3	3	1	3	0	1	f	f	15	orange	f	\N	2026-07-01 13:57:55.679
cmr254jmz00exjxct3z190mbf	cmr254jjb0070jxctxlyg0hih	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	0	1	1	0	1	0	1	1	0	f	t	5	red	f	\N	2026-07-01 13:57:55.679
cmr254jmz00eyjxctnxy47awn	cmr254jjb0071jxctd7ohammf	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	0	1	0	0	1	1	2	2	2	t	t	9	red	f	\N	2026-07-01 13:57:55.679
cmr254jmz00ezjxct8gxdy1k3	cmr254jjb0072jxct8zpc7k02	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	3	3	3	3	3	3	3	1	f	f	25	red	f	\N	2026-07-01 13:57:55.679
cmr254jmz00f0jxctn6o3v7p9	cmr254jjb0073jxcthzfo7nna	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	3	3	3	2	3	3	2	3	t	t	25	red	f	\N	2026-07-01 13:57:55.679
cmr254jmz00f1jxct7selw8rb	cmr254jjb0074jxctjjgyxu84	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	3	2	0	1	1	2	1	t	t	12	red	f	\N	2026-07-01 13:57:55.679
cmr254jmz00f2jxct1c7k6o9d	cmr254jjb0075jxctnwux8b0m	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	0	1	1	0	1	1	0	0	1	t	t	5	red	f	\N	2026-07-01 13:57:55.679
cmr254jmz00f3jxctncuvsopr	cmr254jjb0076jxctab730zh9	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	2	3	1	2	1	2	1	1	t	t	15	red	f	\N	2026-07-01 13:57:55.679
cmr254jmz00f4jxcts7bzwoy3	cmr254jjb0077jxctd0p8mqwn	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	0	1	3	2	3	0	1	2	1	f	t	13	red	f	\N	2026-07-01 13:57:55.679
cmr254jmz00f5jxctkh90g4vu	cmr254jjb0078jxct3onpnz0j	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	1	3	3	1	3	2	1	3	t	t	20	red	f	\N	2026-07-01 13:57:55.679
cmr254jmz00f6jxcte396x44y	cmr254jjb0079jxctsb3x0yyd	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	1	2	2	2	1	1	1	3	t	t	15	red	f	\N	2026-07-01 13:57:55.679
cmr254jmz00f7jxcteqmisbri	cmr254jjb007ajxctk1t57uam	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	2	3	2	2	1	3	2	3	t	t	21	red	f	\N	2026-07-01 13:57:55.679
cmr254jmz00f8jxctoen04a8r	cmr254jjb007bjxctps5wn0fy	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	0	0	1	3	1	0	1	t	t	8	red	f	\N	2026-07-01 13:57:55.679
cmr254jmz00f9jxct07wyuuw3	cmr254jjb007cjxctnrk94efh	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	0	1	0	1	1	1	0	3	t	t	8	red	f	\N	2026-07-01 13:57:55.679
cmr254jmz00fajxcth46mqcbl	cmr254jjb007djxct8738ahfu	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	3	3	3	3	1	1	3	t	t	19	red	f	\N	2026-07-01 13:57:55.679
cmr254jmz00fbjxctiw6xwuj4	cmr254jjb007ejxctj7qs658w	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	3	3	1	3	3	0	0	3	t	t	19	red	f	\N	2026-07-01 13:57:55.679
cmr254jn000fcjxcttahm0j21	cmr254jjb007fjxct0gm73973	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	2	1	0	0	1	0	0	3	t	t	10	red	f	\N	2026-07-01 13:57:55.679
cmr254jn000fdjxctbg6xyu49	cmr254jjb007gjxctsolxfm1x	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	3	3	2	3	3	1	3	3	t	t	24	red	f	\N	2026-07-01 13:57:55.679
cmr254jn000fejxct5rcd9vw6	cmr254jjb007hjxctbrvthkrs	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	0	0	0	1	3	1	1	3	t	t	12	red	f	\N	2026-07-01 13:57:55.679
cmr254jn000ffjxct2afsde3h	cmr254jjb007ijxcto4udvtd4	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	2	1	2	2	1	1	t	t	12	red	f	\N	2026-07-01 13:57:55.679
cmr254jn000fgjxct1exa90hl	cmr254jjb007jjxct7rfv97tf	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	2	2	1	2	3	0	1	t	t	13	red	f	\N	2026-07-01 13:57:55.679
cmr254jn000fhjxctl9eoy0u8	cmr254jjb007kjxctov5vt9p4	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	0	0	0	1	2	0	0	1	t	t	5	red	f	\N	2026-07-01 13:57:55.679
cmr254jn000fijxcti8cu4vt2	cmr254jjb007ljxcth2xmnajg	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	3	2	1	2	3	1	1	3	t	t	19	red	f	\N	2026-07-01 13:57:55.679
cmr254jn000fjjxctabbz6mfn	cmr254jjb007mjxct0mlc9xpz	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	3	3	2	3	1	3	3	1	f	t	21	red	f	\N	2026-07-01 13:57:55.679
cmr254jn000fkjxctxc2e3wru	cmr254jjb007njxctq0v70zao	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	0	1	1	1	1	1	0	0	f	t	6	red	f	\N	2026-07-01 13:57:55.679
cmr254jn000fljxct2nddxcpa	cmr254jjb007ojxctvqvbt60y	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	3	1	1	1	1	1	1	1	t	t	11	red	f	\N	2026-07-01 13:57:55.679
cmr254jn000fmjxctrltkylzr	cmr254jjb007pjxctsq9esh5l	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	0	2	1	0	1	3	0	1	t	t	9	red	f	\N	2026-07-01 13:57:55.679
cmr254jn000fnjxctzohgyjtd	cmr254jjb007qjxctgfnio1o6	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	0	1	2	1	2	1	3	1	t	t	12	red	f	\N	2026-07-01 13:57:55.679
cmr254jn000fojxct461d57gj	cmr254jjb007rjxctkoflpezu	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	1	0	1	3	1	1	1	3	t	f	14	red	f	\N	2026-07-01 13:57:55.679
cmr254jn000fpjxctr6pg6d26	cmr254jjb007sjxct2rppw13a	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	3	3	3	2	3	2	3	3	t	f	25	red	f	\N	2026-07-01 13:57:55.679
cmr254jn000fqjxctyosmrakl	cmr254jjb007tjxctofpwkugb	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	2	3	3	3	1	3	3	1	t	t	21	red	f	\N	2026-07-01 13:57:55.679
cmr254jn000frjxct8hgqzj1d	cmr254jjb007ujxctgyjiw6u1	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	2	1	1	1	1	1	1	t	t	10	red	f	\N	2026-07-01 13:57:55.679
cmr254jn000fsjxct5wdn2mnh	cmr254jjb007vjxctnj59chg2	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	0	1	1	2	1	2	3	0	3	t	t	13	red	f	\N	2026-07-01 13:57:55.679
cmr254jn000ftjxctn1pd17df	cmr254jjb007wjxctaitrqcxo	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	3	0	2	1	2	1	1	1	t	f	13	red	f	\N	2026-07-01 13:57:55.679
cmr254jn000fujxctwgc7w2lo	cmr254jjb007xjxctlylftu0k	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	3	3	3	0	1	t	f	14	red	f	\N	2026-07-01 13:57:55.679
cmr254jn000fvjxctmh6fbepf	cmr254jjb007yjxct45npw5si	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	0	0	0	0	0	0	t	f	3	red	f	\N	2026-07-01 13:57:55.679
cmr254jn000fwjxctjzdilhkg	cmr254jjb007zjxctzp7775xa	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	1	1	1	1	1	f	t	9	red	f	\N	2026-07-01 13:57:55.679
cmr254jn000fxjxct2bz1eyty	cmr254jjb0080jxct5110esg8	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	2	1	1	3	2	1	1	2	t	f	16	red	f	\N	2026-07-01 13:57:55.679
cmr254jn000fyjxctf6ycmpk7	cmr254jjb0081jxctkjjaa5rc	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	2	1	1	2	2	3	0	1	f	t	14	red	f	\N	2026-07-01 13:57:55.679
cmr254jn000fzjxctjwuujbx9	cmr254jjc0082jxct0l7q8r1n	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	2	0	1	3	2	3	3	1	t	f	16	red	f	\N	2026-07-01 13:57:55.679
cmr254jn000g0jxctnztdk1om	cmr254jjc0083jxctmb6u8izj	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	0	1	1	1	2	1	1	f	t	9	red	f	\N	2026-07-01 13:57:55.679
cmr254jn000g1jxct7nb3iqn0	cmr254jjc0084jxct5y958p7e	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	0	0	0	1	1	0	1	1	f	t	5	red	f	\N	2026-07-01 13:57:55.679
cmr254jn000g2jxctnvd0lyec	cmr254jjc0085jxctor1w3rae	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	2	0	3	2	1	0	2	f	t	12	red	f	\N	2026-07-01 13:57:55.679
cmr254jn000g3jxctjxlbopu3	cmr254jjc0086jxctwauc8kfx	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	0	0	1	1	0	1	1	f	t	6	red	f	\N	2026-07-01 13:57:55.679
cmr254jn100g4jxctlhegaurz	cmr254jjc0087jxctpuh1qo85	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	2	2	3	2	3	3	3	t	t	20	red	f	\N	2026-07-01 13:57:55.679
cmr254jn100g5jxct3fq2be30	cmr254jjc0088jxctqw69b6zt	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	1	3	3	3	2	2	3	3	t	t	22	red	f	\N	2026-07-01 13:57:55.679
cmr254jn100g6jxctem4grhjl	cmr254jjc0089jxct1qfno2jq	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	0	1	3	0	1	3	t	t	11	red	f	\N	2026-07-01 13:57:55.679
cmr254jn100g7jxcthqac9ry0	cmr254jjc008ajxctbodzdw0a	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	1	2	3	1	3	1	1	3	t	f	18	red	f	\N	2026-07-01 13:57:55.679
cmr254jn100g8jxct3ojdinkd	cmr254jjc008bjxctd3417f3c	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	1	0	3	3	3	1	1	3	t	t	18	red	f	\N	2026-07-01 13:57:55.679
cmr254jn100g9jxct7ahf5qxs	cmr254jjc008cjxctwy4crgs8	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	1	3	2	3	2	3	3	1	t	f	21	red	f	\N	2026-07-01 13:57:55.679
cmr254jn100gajxcthle9zvxy	cmr254jjc008djxcthbmjpwxd	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	2	2	3	3	2	2	3	1	f	f	20	red	f	\N	2026-07-01 13:57:55.679
cmr254jn100gbjxcto0dfyo92	cmr254jjc008ejxct2ijbq871	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	3	3	3	3	2	3	3	0	f	f	23	red	f	\N	2026-07-01 13:57:55.679
cmr254jn100gcjxctdyhufzow	cmr254jjc008fjxcty5eaj4xg	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	2	1	3	3	1	2	1	t	t	15	red	f	\N	2026-07-01 13:57:55.679
cmr254jn100gdjxctoz6j4wcz	cmr254jjc008gjxctj2zxrchv	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	0	1	3	1	1	1	1	t	t	10	red	f	\N	2026-07-01 13:57:55.679
cmr254jn100gejxctuvno38xu	cmr254jjc008hjxctzaizg30i	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	1	3	3	2	3	1	2	3	f	f	20	red	f	\N	2026-07-01 13:57:55.679
cmr254jn100gfjxctizi48hwv	cmr254jjc008ijxct6qorkwcl	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	2	3	3	2	3	3	3	2	t	t	22	red	f	\N	2026-07-01 13:57:55.679
cmr254jn100ggjxctk59l5qtp	cmr254jjc008jjxctit0vvtr9	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	1	3	1	2	2	1	2	1	t	t	15	red	f	\N	2026-07-01 13:57:55.679
cmr254jn100ghjxctk8uhnwtn	cmr254jjc008kjxct7wxe6h5h	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	0	1	0	0	0	1	1	1	t	f	5	red	f	\N	2026-07-01 13:57:55.679
cmr254jn100gijxctd9fc15of	cmr254jjc008ljxct81cn5vku	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	2	3	2	3	2	2	3	0	f	f	20	red	f	\N	2026-07-01 13:57:55.679
cmr254jn100gjjxct4xlo15cj	cmr254jjc008mjxctnfljt48y	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	1	2	1	0	3	2	2	3	t	t	16	red	f	\N	2026-07-01 13:57:55.679
cmr254jn100gkjxctsgawt6np	cmr254jjc008njxctq6ry4k4q	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	2	1	0	3	2	1	3	1	f	t	16	red	f	\N	2026-07-01 13:57:55.679
cmr254jn100gljxcts54rnjn8	cmr254jjc008ojxctiac8twqd	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	0	3	1	1	0	0	0	t	f	7	red	f	\N	2026-07-01 13:57:55.679
cmr254jn100gmjxct1rw2l4gl	cmr254jjc008pjxctym9rmi86	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	0	1	2	1	2	1	0	f	t	9	red	f	\N	2026-07-01 13:57:55.679
cmr254jn100gnjxctpcs4q1yf	cmr254jjc008qjxct86matvwn	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	2	1	1	0	1	1	0	f	t	8	red	f	\N	2026-07-01 13:57:55.679
cmr254jn100gojxctld0nrvjq	cmr254jjc008rjxct1hkdyxje	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	0	3	1	1	0	1	0	0	t	f	7	red	f	\N	2026-07-01 13:57:55.679
cmr254jn100gpjxct7vnrr7sa	cmr254jjc008sjxctnpmykhmb	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	1	1	0	1	1	0	0	1	f	t	7	red	f	\N	2026-07-01 13:57:55.679
cmr254jn100gqjxcteyw0u47u	cmr254jjc008tjxctr64ejdgk	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	2	3	1	1	0	1	1	f	t	11	red	f	\N	2026-07-01 13:57:55.679
cmr254jn100grjxctebxeri9v	cmr254jjc008ujxctrek1f9uu	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	3	3	3	1	1	1	1	t	f	15	red	f	\N	2026-07-01 13:57:55.679
cmr254jn100gsjxcttpsd48h7	cmr254jjc008vjxct5tl2gn1o	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	2	3	2	3	2	2	3	0	t	t	20	red	f	\N	2026-07-01 13:57:55.679
cmr254jn100gtjxct6q4d7pje	cmr254jjc008wjxct79sy0vsj	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	1	0	1	1	0	f	t	7	red	f	\N	2026-07-01 13:57:55.679
cmr254jn100gujxctr8yupk58	cmr254jjc008xjxctsq4d14hz	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	2	1	1	1	1	1	1	1	f	t	10	red	f	\N	2026-07-01 13:57:55.679
cmr254jn100gvjxctqsjkx5mz	cmr254jjc008yjxctu4g5esst	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	2	0	2	1	1	2	1	0	t	f	10	red	f	\N	2026-07-01 13:57:55.679
cmr254jn200gwjxctnywbecoz	cmr254jjc008zjxctqm693s18	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	1	3	1	1	1	1	1	0	t	f	11	red	f	\N	2026-07-01 13:57:55.679
cmr254jn200gxjxctmd3ugxr9	cmr254jjc0090jxctcvlxmcmk	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	1	1	1	2	3	3	1	1	t	t	16	red	f	\N	2026-07-01 13:57:55.679
cmr254jn200gyjxctsw197ol4	cmr254jjc0091jxctmn826440	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	1	3	1	1	2	1	1	1	t	f	13	red	f	\N	2026-07-01 13:57:55.679
cmr254jn200gzjxctjvcr4ok2	cmr254jjc0092jxctnqt53ghu	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	2	1	1	1	3	1	1	1	t	f	13	red	f	\N	2026-07-01 13:57:55.679
cmr254jn200h0jxctccy7s9qh	cmr254jjc0093jxctwrykzvkw	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	1	1	1	0	1	0	1	f	t	7	red	f	\N	2026-07-01 13:57:55.679
cmr254jn200h1jxctfdorpnsu	cmr254jjc0094jxcthlr57zdh	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	1	1	1	1	0	1	0	0	f	t	8	red	f	\N	2026-07-01 13:57:55.679
cmr254jn200h2jxcto959gxo3	cmr254jjd0095jxcthb3acy7x	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	2	2	1	1	3	1	2	3	t	t	17	red	f	\N	2026-07-01 13:57:55.679
cmr254jn200h3jxctx0xq318l	cmr254jjd0096jxct8eo8fuvo	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	1	1	2	3	3	3	1	1	t	f	18	red	f	\N	2026-07-01 13:57:55.679
cmr254jn200h4jxctmctsx27t	cmr254jjd0097jxct6lmnp6es	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	2	1	2	3	3	1	1	1	f	t	16	red	f	\N	2026-07-01 13:57:55.679
cmr254jn200h5jxct8d7p8t2l	cmr254jjd0098jxctdrh3tt60	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	1	2	1	2	1	1	2	2	f	t	14	red	f	\N	2026-07-01 13:57:55.679
cmr254jn200h6jxctlm5nf2tq	cmr254jjd0099jxctfz2b6suv	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	0	1	3	3	3	3	3	3	3	t	f	22	red	f	\N	2026-07-01 13:57:55.679
cmr254jn200h7jxctb39hthin	cmr254jjd009ajxctyl5irdqn	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	1	2	1	2	3	1	1	3	t	t	15	red	f	\N	2026-07-01 13:57:55.679
cmr254jn200h8jxctsj3bh0po	cmr254jjd009bjxct805du1q8	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	1	3	1	3	3	2	2	2	t	t	19	red	f	\N	2026-07-01 13:57:55.679
cmr254jn200h9jxctg5loelsc	cmr254jjd009cjxctfiibuqyf	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	1	2	2	1	2	1	1	0	0	t	t	10	red	f	\N	2026-07-01 13:57:55.679
cmr254jn200hajxct2sig8bje	cmr254jjd009djxcttfbwyhkz	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	3	3	1	1	3	3	1	3	1	f	t	19	red	f	\N	2026-07-01 13:57:55.679
cmr254jn200hbjxctxchkkew0	cmr254jjd009ejxct154gsjnu	cmp6j4rh20002jxuik5drdqtt	cmq0kfz02000ijx23kh3yrfbs	1	2	1	3	1	2	3	1	2	1	t	f	16	red	f	\N	2026-07-01 13:57:55.679
\.


--
-- Data for Name: school_admin_invites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.school_admin_invites (id, token, email, role, "usedAt", "expiresAt", "createdBy", "createdAt") FROM stdin;
cmp6j84d60001jxdf12asd1g1	ca867665c598ed2a37d0b1e2c5af94c97c53d8b82de5d8bd77646b5fa9004245	yingyot.j@thainhf.org	school_admin	2026-05-15 06:24:35.415	2026-05-22 06:24:17.177	cmp6j4rgk0000jxuitzv4y8us	2026-05-15 06:24:17.178
cmpjftk860015jx2m7m1tjct8	c0e6156865b6a1e807d3a1a79174e1775cc3cbc9a2492055d9fa970b3a1accd9	yingyot123@test.com	school_admin	2026-05-24 07:10:24.07	2026-05-31 07:09:59.333	cmp6j4rgk0000jxuitzv4y8us	2026-05-24 07:09:59.335
cmpkp75il002njx2mtqi5uh1n	c4b92f2f55673a71dcffa22e95204b051d23dc4c0f09edd12cc95a77c41087cc	naipaporn.v@gmail.com	school_admin	2026-05-25 04:21:31.815	2026-06-01 04:20:16.173	cmp6j4rgk0000jxuitzv4y8us	2026-05-25 04:20:16.174
cmpm5litg0006jxgml75eb1py	eb8c0a085d4445375e9aafae03ed03ef2220230a98a2ca97f649634e2e6b1fff	systemadmin@thainhf.org	system_admin	2026-05-26 04:47:33.258	2026-06-02 04:47:06.628	cmp6j4rgk0000jxuitzv4y8us	2026-05-26 04:47:06.629
cmpm7suu1000bjxgmd0vk2zyr	7df779b6e5ecdffd418a67cd7d061aa655ad469b6ffd36ed7c6ba863c1fb1759	dear-wanwisa@hotmail.com	school_admin	2026-05-26 08:31:41.054	2026-06-02 05:48:48.024	cmp6j4rgk0000jxuitzv4y8us	2026-05-26 05:48:48.025
cmpzr3nwn002kjxwnbniflzju	c5a3bb59f79f98797550508e130887c6a542ec571a2acb90bef49867390ef375	shreandlearn555@gmail.com	school_admin	2026-06-04 17:10:39.186	2026-06-11 17:10:05.255	cmp6j4rgk0000jxuitzv4y8us	2026-06-04 17:10:05.256
cmpzqv8ya002ejxwny7ewdbwy	b9880b483f4f293479c4e16dd0bd9581e98f734fb97ce85e9633a94b17bbb670	bombamadm@gmail.com	school_admin	2026-06-05 06:49:52.506	2026-06-11 17:03:32.625	cmp6j4rgk0000jxuitzv4y8us	2026-06-04 17:03:32.626
cmpzqwdqz002ijxwnkio3yfk5	8a87af5414e7c8ed6644e969327e5571913b1d151fba52f25e555fdaff1ff7f8	nurissawarid@gmail.com	school_admin	2026-06-05 06:49:57.846	2026-06-11 17:04:25.499	cmp6j4rgk0000jxuitzv4y8us	2026-06-04 17:04:25.499
cmpzqua9s002cjxwnoce2g3co	6d158aa19eec34c6b4855b11cdb7142775a91725924acc6351211bb3fb2bf8c1	benjaporn1863@gmail.com	school_admin	2026-06-05 06:51:28.372	2026-06-11 17:02:47.679	cmp6j4rgk0000jxuitzv4y8us	2026-06-04 17:02:47.68
cmpzqvpo9002gjxwn0cx0bbmy	48b790377f9181e2f4ed2a725fa442843802e99bf9365b235bfa1982604988bc	jaturan092@gmail.com	school_admin	2026-06-05 06:51:55.314	2026-06-11 17:03:54.296	cmp6j4rgk0000jxuitzv4y8us	2026-06-04 17:03:54.297
cmq0f9vpz003kjxwncedpxq4k	719ba780a891aa304bfd12627cc5dae10a72a88271fda7e35028dfd3524ce592	kkika052519@gmail.com	school_admin	2026-06-05 06:52:52.812	2026-06-12 04:26:46.102	cmp6j4rgk0000jxuitzv4y8us	2026-06-05 04:26:46.103
cmq9jt2q2000vjxh5q9yxsp53	88e7a1dc3a96dec28f6d417ed8bcc81de3898328653637efea11fca7d6e21ed8	saengauthai101035@gmail.com	school_admin	\N	2026-06-18 13:43:35.69	cmp6j4rgk0000jxuitzv4y8us	2026-06-11 13:43:35.69
cmqn92278005ojxf02o5kevsh	acbe9fe843c51aa443a499b3661aca2fc3e95fb22cab85f1c2f6d4ecea976b1a	phonthipphawann@gmail.com	school_admin	2026-06-21 03:53:09.066	2026-06-28 03:51:25.603	cmp6j4rgk0000jxuitzv4y8us	2026-06-21 03:51:25.605
cmqopkez4011zjxf0ftvld6ih	6fb66c69d1f51c47b1ab9bc1b8f4598c372ee09d6e8621e811f58dd1e9611524	kanokporn.ne@ku.th	school_admin	\N	2026-06-29 04:21:22	cmp6j4rgk0000jxuitzv4y8us	2026-06-22 04:21:22.001
cmqoplx9z0121jxf0decmj2ge	e640da1d5acfd12414c63422de18b415c3e641214b61dc5456bc37a70ff0fb7d	orapannow@gmail.com	school_admin	\N	2026-06-29 04:22:32.374	cmp6j4rgk0000jxuitzv4y8us	2026-06-22 04:22:32.375
cmqopnr5g0123jxf0z8c0pvnc	a05114a0ac0530f8e621d439dd83d5a75d25180ba2977d3cffb1a97752561849	chatree@swc.ac.th	school_admin	\N	2026-06-29 04:23:57.748	cmp6j4rgk0000jxuitzv4y8us	2026-06-22 04:23:57.749
cmqopogpb0125jxf0ze4f1zxx	8c7669a1525ec13e7d1a70c171be6b4218c61e49ff3fd4fba38f717289a07129	thaidramasuparas@gmail.com	school_admin	\N	2026-06-29 04:24:30.862	cmp6j4rgk0000jxuitzv4y8us	2026-06-22 04:24:30.863
cmqtlicb2000jjxu6sznzwiyh	4cdf1f6e61e9097128659442143073a31f6e08b12743fbf1e534904e21ba581a	admin@wbws.ac.th	school_admin	\N	2026-07-02 14:26:37.643	cmp6j4rgk0000jxuitzv4y8us	2026-06-25 14:26:37.646
cmqopmxxz00dbjxek4ht65iso	7c310fb812e2999eb169b48bf6464e1b32f5cd25b7c8a6cbeba8a3f0638232db	moytanatha12@gmail.com	school_admin	2026-06-22 05:54:42.733	2026-06-29 04:23:19.894	cmp6j4rgk0000jxuitzv4y8us	2026-06-22 04:23:19.895
cmqtlo2ek000cjxt6q2i087jw	804b75f78737dc31e0c93555691adc282241eaa408afd9930739fb73e4ff9de4	nungaromd@gmail.com	school_admin	\N	2026-07-02 14:31:04.748	cmp6j4rgk0000jxuitzv4y8us	2026-06-25 14:31:04.748
cmqtlpdnr000ejxt6ajj8qiyt	9024436db7e3a4af3ade050ede3c75dd51c0b2e5ea41116e0be57f68f9bc0512	pacharasiri176@gmail.com	school_admin	\N	2026-07-02 14:32:05.991	cmp6j4rgk0000jxuitzv4y8us	2026-06-25 14:32:05.992
cmqtlqtre000ljxu6om3qaw7b	29503b5ae7a9d41135ecd96286d3cc658396030325ea03b73f9987f5d52dfdbf	tonor1609@gmail.com	school_admin	\N	2026-07-02 14:33:13.513	cmp6j4rgk0000jxuitzv4y8us	2026-06-25 14:33:13.514
cmr4nbw6k010fjxctajlojh2j	0c25f757229b67d322dd6cf09ca1a83cb7ba39fe02291f633b2e084fe54af966	channapatios9@gmail.com	school_admin	2026-07-03 08:06:32.254	2026-07-10 08:03:03.979	cmp6j4rgk0000jxuitzv4y8us	2026-07-03 08:03:03.98
\.


--
-- Data for Name: school_class_terms; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.school_class_terms (id, "schoolClassId", "academicYearId", "expectedStudentCount", "createdAt", "updatedAt") FROM stdin;
clst_22d3f64fe431fc07cbeab2d9da046620	cmp6jamug000ejxdffnpliz33	cmp6j4rh20002jxuik5drdqtt	10	2026-05-22 16:49:48.736	2026-05-22 16:49:48.736
clst_53feb30bcb15bdef058e60ab137788c7	cmp6jamxm000gjxdf5naqar9q	cmp6j4rh20002jxuik5drdqtt	10	2026-05-22 16:49:48.736	2026-05-22 16:49:48.736
cmq0l0fc6008kjx23l0pezcly	cmq0l0fc1008ijx23gbgw78w7	cmp6j4rh20002jxuik5drdqtt	25	2026-06-05 07:07:22.663	2026-06-05 07:07:37.226
cmpjfvruh001fjx2mrq0mjfhc	cmpjfvrud001djx2mizt2xeie	cmp6j4rh20002jxuik5drdqtt	10	2026-05-24 07:11:42.522	2026-05-24 07:11:42.522
cmpjfvry5001kjx2mlfqtco0x	cmpjfvrxy001ijx2m73w9t57r	cmp6j4rh20002jxuik5drdqtt	10	2026-05-24 07:11:42.653	2026-05-24 07:11:42.653
cmpjfvs1a001pjx2ms3ljnl5l	cmpjfvs16001njx2mriabvex3	cmp6j4rh20002jxuik5drdqtt	10	2026-05-24 07:11:42.766	2026-05-24 07:11:42.766
cmpjfvs4e001ujx2mwj8194bc	cmpjfvs4a001sjx2mfuersbc4	cmp6j4rh20002jxuik5drdqtt	10	2026-05-24 07:11:42.878	2026-05-24 07:11:42.878
cmpjfvs7f001zjx2mkit16aws	cmpjfvs7b001xjx2mwmoqqwxs	cmp6j4rh20002jxuik5drdqtt	10	2026-05-24 07:11:42.987	2026-05-24 07:11:42.987
cmpnih2x20027jxgmfm857m55	cmpnih2wv0025jxgmrcw6clre	cmp6j4rh20002jxuik5drdqtt	20	2026-05-27 03:35:20.582	2026-05-27 03:35:20.582
cmpnig2p3001yjxgmaf38et17	cmpnig2ox001wjxgmevz48gjv	cmp6j4rh20002jxuik5drdqtt	19	2026-05-27 03:34:33.639	2026-06-15 09:57:51.177
cmpvlp1410028jxjci28x1tta	cmpvlp13p0026jxjcazgnov1t	cmp6j4rh20002jxuik5drdqtt	7	2026-06-01 19:27:39.745	2026-06-01 19:27:39.745
cmpvlp16v002djxjco1ke9e4d	cmpvlp15w002bjxjckkljmx48	cmp6j4rh20002jxuik5drdqtt	7	2026-06-01 19:27:39.848	2026-06-01 19:27:39.848
cmpyc6jup0011jxwnykfzzuy1	cmpyc6jum000zjxwnaz56ev50	cmp6j4rh20002jxuik5drdqtt	15	2026-06-03 17:24:39.554	2026-06-03 17:24:39.554
cmpyc6jxn0016jxwnktln6asz	cmpyc6jxi0014jxwnjy0yu86t	cmp6j4rh20002jxuik5drdqtt	15	2026-06-03 17:24:39.66	2026-06-03 17:24:39.66
cmq08soa40035jxwnxb24ckwn	cmq08so9z0033jxwnubf27yft	cmp6j4rh20002jxuik5drdqtt	40	2026-06-05 01:25:25.612	2026-06-05 01:25:25.612
cmq0kkhnt001kjx23w7zafk0h	cmq0kkhnq001ijx23q2jl1fgu	cmp6j4rh20002jxuik5drdqtt	34	2026-06-05 06:54:59.178	2026-06-05 06:54:59.178
cmq0kktel001pjx23wyqtxrpx	cmq0kkteh001njx23w3ickk28	cmp6j4rh20002jxuik5drdqtt	34	2026-06-05 06:55:14.397	2026-06-05 06:55:14.397
cmq0klddh0020jx2377r10kxi	cmq0kldda001yjx23kqne0b9y	cmp6j4rh20002jxuik5drdqtt	25	2026-06-05 06:55:40.277	2026-06-05 06:55:40.277
cmq0kldpy0025jx23ofrf892y	cmq0kldpt0023jx238w4zc8u9	cmp6j4rh20002jxuik5drdqtt	24	2026-06-05 06:55:40.726	2026-06-05 06:55:54.269
cmq0klxym002ijx239794zfuf	cmq0klxyi002gjx23xf9e2e7g	cmp6j4rh20002jxuik5drdqtt	33	2026-06-05 06:56:06.958	2026-06-05 06:56:06.958
cmq0klyix002njx23yoqopkv3	cmq0klyit002ljx23vucgubow	cmp6j4rh20002jxuik5drdqtt	34	2026-06-05 06:56:07.689	2026-06-05 06:56:17.676
cmq0kmgue003cjx233ri44h5p	cmq0kmgu9003ajx23l4ukli8q	cmp6j4rh20002jxuik5drdqtt	29	2026-06-05 06:56:31.431	2026-06-05 06:56:31.431
cmq0kmh3v003mjx23zb1l3h16	cmq0kmh3r003kjx23hj3nm4ra	cmp6j4rh20002jxuik5drdqtt	29	2026-06-05 06:56:31.772	2026-06-05 06:56:31.772
cmq0kmh84003rjx23bu5bz0w3	cmq0kmh80003pjx23fpxvrrlw	cmp6j4rh20002jxuik5drdqtt	29	2026-06-05 06:56:31.924	2026-06-05 06:56:31.924
cmq0kmgzz003hjx236wsy2csu	cmq0kmgzu003fjx23ni53wxb7	cmp6j4rh20002jxuik5drdqtt	34	2026-06-05 06:56:31.631	2026-06-05 06:56:51.733
cmq0kyjtd006ujx231hsqbaza	cmq0kyjt4006sjx23ovbzo4u5	cmp6j4rh20002jxuik5drdqtt	29	2026-06-05 07:05:55.153	2026-06-05 07:05:55.153
cmq0kyk5y0074jx238h3whp5j	cmq0kyk5v0072jx23457tkouc	cmp6j4rh20002jxuik5drdqtt	29	2026-06-05 07:05:55.606	2026-06-05 07:05:55.606
cmq0kyjwl006zjx23ic8ldk5i	cmq0kyjwf006xjx23xc3m9hml	cmp6j4rh20002jxuik5drdqtt	25	2026-06-05 07:05:55.27	2026-06-05 07:06:14.987
cmq0kyk9b0079jx23g9oq7vmr	cmq0kyk970077jx235vtyfe05	cmp6j4rh20002jxuik5drdqtt	27	2026-06-05 07:05:55.727	2026-06-05 07:06:18.384
cmq0l0fu3008pjx2342d60s1w	cmq0l0fty008njx230lba64wz	cmp6j4rh20002jxuik5drdqtt	26	2026-06-05 07:07:23.308	2026-06-05 07:07:23.308
cmq0l0ge9008ujx23tve223l0	cmq0l0ge6008sjx232akfpoc6	cmp6j4rh20002jxuik5drdqtt	22	2026-06-05 07:07:24.034	2026-06-05 07:07:39.511
cmq0l0gpi008zjx23akjxhkg2	cmq0l0gpf008xjx23kdz6e78d	cmp6j4rh20002jxuik5drdqtt	24	2026-06-05 07:07:24.438	2026-06-05 07:07:47.025
cmq0l2nhv00a6jx23xbnqqk2f	cmq0l2nhs00a4jx23515gqlk1	cmp6j4rh20002jxuik5drdqtt	30	2026-06-05 07:09:06.547	2026-06-05 07:09:06.547
cmq0l2nc700a1jx23f3rpy865	cmq0l2nc4009zjx23ibmvgl25	cmp6j4rh20002jxuik5drdqtt	27	2026-06-05 07:09:06.344	2026-06-05 07:09:12.422
cmq0l37jd00aejx23r9zgl1q0	cmq0l37j800acjx238q9wazht	cmp6j4rh20002jxuik5drdqtt	26	2026-06-05 07:09:32.521	2026-06-05 07:09:32.521
cmq0l37my00ajjx23voih5bgl	cmq0l37ms00ahjx23zxl8fwdl	cmp6j4rh20002jxuik5drdqtt	16	2026-06-05 07:09:32.65	2026-06-05 07:09:38.928
cmq0l3p9e00asjx2374p9da0e	cmq0l3p9b00aqjx23xkoqvbpn	cmp6j4rh20002jxuik5drdqtt	21	2026-06-05 07:09:55.49	2026-06-05 07:10:06.91
cmq0l3pdh00axjx23pyndg53b	cmq0l3pdb00avjx23ahywc7bg	cmp6j4rh20002jxuik5drdqtt	14	2026-06-05 07:09:55.637	2026-06-05 07:10:09.303
clst_a5829d0bd4fd82e10b58f718df27b895	cmp6jamr1000cjxdfp3zovs11	cmp6j4rh20002jxuik5drdqtt	15	2026-05-22 16:49:48.736	2026-06-10 11:37:10.716
cmqeogrec002njxopu3ucfzh4	cmqeogre6002ljxop1xyn75j3	cmp6j4rh20002jxuik5drdqtt	23	2026-06-15 03:52:50.1	2026-06-15 03:52:50.1
cmqeohj2z00eijxp5kia18qf0	cmqeohj2s00egjxp5s8vrneyv	cmp6j4rh20002jxuik5drdqtt	29	2026-06-15 03:53:25.98	2026-06-15 03:53:25.98
cmqeoifqe002sjxop2co4a57y	cmqeoifq7002qjxophqoao70n	cmp6j4rh20002jxuik5drdqtt	24	2026-06-15 03:54:08.294	2026-06-15 03:54:08.294
cmqeoj0uc00enjxp5fs0flxdl	cmqeoj0u800eljxp58lgsh7sb	cmp6j4rh20002jxuik5drdqtt	28	2026-06-15 03:54:35.652	2026-06-15 03:54:35.652
cmq0knhl60043jx23b7946522	cmq0knhl00041jx23fomw9ktn	cmp6j4rh20002jxuik5drdqtt	44	2026-06-05 06:57:19.05	2026-06-15 08:21:32.312
cmq0knhse0048jx2328euocgd	cmq0knhsb0046jx233rxr0sub	cmp6j4rh20002jxuik5drdqtt	43	2026-06-05 06:57:19.31	2026-06-15 08:21:35.676
cmqalbpa6000njxp5ixro0b2t	cmqalbp9w000ljxp5x762hqqn	cmp6j4rh20002jxuik5drdqtt	34	2026-06-12 07:13:50.526	2026-06-15 08:21:47.98
cmqalbpgm000sjxp5vfkoww5r	cmqalbpgf000qjxp5rfez5dd4	cmp6j4rh20002jxuik5drdqtt	37	2026-06-12 07:13:50.758	2026-06-15 08:21:52.91
cmqalbpl3000ojxop54mkbqyu	cmqalbpky000mjxopw9gwxokg	cmp6j4rh20002jxuik5drdqtt	36	2026-06-12 07:13:50.919	2026-06-15 08:21:54.75
cmqalc2re000xjxp55fcdblus	cmqalc2ra000vjxp5rw1vozj3	cmp6j4rh20002jxuik5drdqtt	33	2026-06-12 07:14:07.995	2026-06-15 08:22:03.182
cmqalc2vl000tjxopb5oqp69g	cmqalc2vg000rjxopstgevqgy	cmp6j4rh20002jxuik5drdqtt	41	2026-06-12 07:14:08.145	2026-06-15 08:22:14.149
cmqevw8lr0037jxopxmtrbu8t	cmqevw8li0035jxopwcvbsj6f	cmp6j4rh20002jxuik5drdqtt	35	2026-06-15 07:20:49.551	2026-06-15 08:22:25.837
cmqevw8ra00trjxp5itq5li93	cmqevw8r600tpjxp5tdq0itax	cmp6j4rh20002jxuik5drdqtt	33	2026-06-15 07:20:49.75	2026-06-15 08:22:29.51
cmqey1d11003fjxop37pg3dsw	cmqey1d0w003djxop6grz3x1q	cmp6j4rh20002jxuik5drdqtt	22	2026-06-15 08:20:47.797	2026-06-15 08:23:03.358
cmqey1d6q00xhjxp5ldofqw9b	cmqey1d6g00xfjxp59n9wnwrz	cmp6j4rh20002jxuik5drdqtt	36	2026-06-15 08:20:48.002	2026-06-15 08:23:09.207
cmqey3scj003tjxopgl7g0ga0	cmqey3scc003rjxopqg2ipvcc	cmp6j4rh20002jxuik5drdqtt	24	2026-06-15 08:22:40.964	2026-06-15 08:23:32.738
cmqey3sg900y4jxp5jmjxkomx	cmqey3sg300y2jxp50vijn668	cmp6j4rh20002jxuik5drdqtt	33	2026-06-15 08:22:41.097	2026-06-15 08:23:37.514
cmqezw8hp005rjxopk5i4cn87	cmqezw8hl005pjxopglxnvxdz	cmp6j4rh20002jxuik5drdqtt	7	2026-06-15 09:12:47.87	2026-06-15 09:12:47.87
clst_8a928d9a01597073e3b0cb668696a4dd	cmp6jamnw000ajxdf0km83u6b	cmp6j4rh20002jxuik5drdqtt	11	2026-05-22 16:49:48.736	2026-06-19 05:08:23.711
cmqnw7r8j008ajxf0wvjqka1j	cmqnw7r8e0088jxf0bavdii1g	cmp6j4rh20002jxuik5drdqtt	36	2026-06-21 14:39:42.499	2026-06-21 14:39:42.499
cmqnw85hj007sjxekws8lft05	cmqnw85hc007qjxek9a1yplc0	cmp6j4rh20002jxuik5drdqtt	38	2026-06-21 14:40:00.967	2026-06-21 14:40:00.967
cmqnw8iw4008fjxf0ch650wqs	cmqnw8iw0008djxf0viqczga3	cmp6j4rh20002jxuik5drdqtt	38	2026-06-21 14:40:18.341	2026-06-21 14:40:18.341
cmqnw8tmd007zjxek36edgss9	cmqnw8tm7007xjxekgkpm6uqn	cmp6j4rh20002jxuik5drdqtt	16	2026-06-21 14:40:32.245	2026-06-21 14:40:32.245
cmqnw9d050084jxekjjqxmyer	cmqnw9d010082jxeketm8e263	cmp6j4rh20002jxuik5drdqtt	33	2026-06-21 14:40:57.365	2026-06-21 14:40:57.365
cmqnw9l7d008ljxf0t9w6ma18	cmqnw9l78008jjxf084agn3p5	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:41:07.993	2026-06-21 14:41:07.993
cmqnw9t3k0089jxekxoic160k	cmqnw9t3g0087jxekquy639dy	cmp6j4rh20002jxuik5drdqtt	39	2026-06-21 14:41:18.224	2026-06-21 14:41:18.224
cmqnwa5fg008fjxek0t9esjmw	cmqnwa5fb008djxeksig21yn8	cmp6j4rh20002jxuik5drdqtt	42	2026-06-21 14:41:34.204	2026-06-21 14:41:34.204
cmqnwadk7008qjxf0fwswtgbp	cmqnwadk2008ojxf0aghk7ea4	cmp6j4rh20002jxuik5drdqtt	36	2026-06-21 14:41:44.743	2026-06-21 14:41:44.743
cmqnwal7r008vjxf0oiuiyxif	cmqnwal7m008tjxf0o4lifdmb	cmp6j4rh20002jxuik5drdqtt	19	2026-06-21 14:41:54.663	2026-06-21 14:41:54.663
cmqnwoilv008qjxekbyzp5hvg	cmqnwoilp008ojxek0snyjpmk	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:52:44.468	2026-06-21 14:52:44.468
cmqnwoipl0096jxf0tkt5121m	cmqnwoipf0094jxf06sivyg3r	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:52:44.601	2026-06-21 14:52:44.601
cmqnwoitc008vjxek0vm5r5de	cmqnwoit9008tjxekn95dw7ue	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:52:44.737	2026-06-21 14:52:44.737
cmqnwoiwp009bjxf0ouv6i0ay	cmqnwoiwk0099jxf0vxfkfixe	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:52:44.858	2026-06-21 14:52:44.858
cmqnwoj0a0090jxekw4b6cywb	cmqnwoj05008yjxekb2he5ifl	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:52:44.986	2026-06-21 14:52:44.986
cmqnwoj3i009gjxf0mvmewwr4	cmqnwoj3d009ejxf0i0gj9o3q	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:52:45.102	2026-06-21 14:52:45.102
cmqnwox770095jxeknfvz0lxy	cmqnwox710093jxekcvogml9t	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:53:03.379	2026-06-21 14:53:03.379
cmqnwoxau009ljxf0okb2x6y1	cmqnwoxam009jjxf0nqj68uma	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:53:03.51	2026-06-21 14:53:03.51
cmqnwoxe9009ajxek4b085txc	cmqnwoxe60098jxek8ycs0jag	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:53:03.633	2026-06-21 14:53:03.633
cmqnwoxhi009qjxf07qo3b5hr	cmqnwoxhd009ojxf0oz3or0yh	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:53:03.75	2026-06-21 14:53:03.75
cmqnwoxku009fjxekmkqq5516	cmqnwoxkr009djxekn0hb3vou	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:53:03.87	2026-06-21 14:53:03.87
cmqnwoxo7009vjxf0o68y8xhv	cmqnwoxo3009tjxf0t4255udt	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:53:03.991	2026-06-21 14:53:03.991
cmqnwp6lx00a0jxf0jb9k1ucy	cmqnwp6lt009yjxf0kcn9od5v	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:53:15.573	2026-06-21 14:53:15.573
cmqnwp6pb009mjxekz6wpiqt6	cmqnwp6p7009kjxekat80lqmt	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:53:15.695	2026-06-21 14:53:15.695
cmqnwp6sg00a5jxf0yedncaih	cmqnwp6sc00a3jxf0bq7dc3d1	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:53:15.809	2026-06-21 14:53:15.809
cmqnwp6vp009rjxek9rl15x41	cmqnwp6vl009pjxekby3gpsna	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:53:15.925	2026-06-21 14:53:15.925
cmqnwp6yq00aajxf0si2l4tqg	cmqnwp6ym00a8jxf02r0mvniv	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:53:16.035	2026-06-21 14:53:16.035
cmqnwp72b009wjxekmopass1g	cmqnwp726009ujxek0r2bxxhw	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:53:16.163	2026-06-21 14:53:16.163
cmprvdnu3000tjx5qabr0ke41	cmprvdntx000rjx5qqrr9jgc7	cmp6j4rh20002jxuik5drdqtt	30	2026-05-30 04:47:40.779	2026-06-19 05:10:18.546
cmqnvnepo006fjxf01mxr12nn	cmqnvnepk006djxf0skutte08	cmp6j4rh20002jxuik5drdqtt	33	2026-06-21 14:23:53.149	2026-06-21 14:23:53.149
cmqnvo1xp006kjxf0ej4j76av	cmqnvo1xk006ijxf0ybgmi4ra	cmp6j4rh20002jxuik5drdqtt	28	2026-06-21 14:24:23.245	2026-06-21 14:24:23.245
cmqnvofc6005zjxekpx87el5g	cmqnvofby005xjxekjgt7tnhb	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:24:40.615	2026-06-21 14:24:40.615
cmqnvowev006pjxf0uic7279a	cmqnvoweq006njxf0nvgu5ng2	cmp6j4rh20002jxuik5drdqtt	25	2026-06-21 14:25:02.743	2026-06-21 14:25:02.743
cmqnvpame0064jxeku8r0rz6l	cmqnvpam90062jxekynreyuq1	cmp6j4rh20002jxuik5drdqtt	29	2026-06-21 14:25:21.159	2026-06-21 14:25:21.159
cmqnvpqy9006ujxf02dnmq2i9	cmqnvpqy5006sjxf0ol0o7n7k	cmp6j4rh20002jxuik5drdqtt	18	2026-06-21 14:25:42.322	2026-06-21 14:25:42.322
cmqnvqkxi0069jxekgpj6idwl	cmqnvqkxd0067jxek37qhk7in	cmp6j4rh20002jxuik5drdqtt	30	2026-06-21 14:26:21.174	2026-06-21 14:26:21.174
cmqnvqvh2006zjxf0y8y3y7pj	cmqnvqvgt006xjxf0wxtww7sc	cmp6j4rh20002jxuik5drdqtt	31	2026-06-21 14:26:34.839	2026-06-21 14:26:34.839
cmqnvra0z006ejxek6q94n72i	cmqnvra0v006cjxekfgbcm76g	cmp6j4rh20002jxuik5drdqtt	33	2026-06-21 14:26:53.7	2026-06-21 14:26:53.7
cmqnvrils0074jxf0t34uvw86	cmqnvriln0072jxf05pup6bv6	cmp6j4rh20002jxuik5drdqtt	35	2026-06-21 14:27:04.816	2026-06-21 14:27:04.816
cmqnvrrwq006jjxekhb2nemk8	cmqnvrrwj006hjxek8maxws2a	cmp6j4rh20002jxuik5drdqtt	25	2026-06-21 14:27:16.874	2026-06-21 14:27:16.874
cmqnvs4jw0079jxf0d19c1oxq	cmqnvs4jn0077jxf0rrmlfc87	cmp6j4rh20002jxuik5drdqtt	16	2026-06-21 14:27:33.26	2026-06-21 14:27:33.26
cmqnvsxyr006ojxekdl2gab6m	cmqnvsxyn006mjxekiyv4cm0k	cmp6j4rh20002jxuik5drdqtt	37	2026-06-21 14:28:11.38	2026-06-21 14:28:11.38
cmqnvt8fz007ejxf0qpwanbzt	cmqnvt8fv007cjxf0c4gnnv04	cmp6j4rh20002jxuik5drdqtt	37	2026-06-21 14:28:24.96	2026-06-21 14:28:24.96
cmqnvtg25006tjxek5lbb9d82	cmqnvtg22006rjxek6e7f0m47	cmp6j4rh20002jxuik5drdqtt	28	2026-06-21 14:28:34.829	2026-06-21 14:28:34.829
cmqnvto65006yjxeki5x94lkw	cmqnvto60006wjxekbax3tzj4	cmp6j4rh20002jxuik5drdqtt	34	2026-06-21 14:28:45.341	2026-06-21 14:28:45.341
cmqnvu3sb007jjxf016af5dpu	cmqnvu3s6007hjxf0vqfsm9yl	cmp6j4rh20002jxuik5drdqtt	38	2026-06-21 14:29:05.58	2026-06-21 14:29:05.58
cmqnvudv30073jxek6vj56v2a	cmqnvudv00071jxekpfexpwpy	cmp6j4rh20002jxuik5drdqtt	20	2026-06-21 14:29:18.64	2026-06-21 14:29:18.64
cmqnvvkvz007ojxf0yumqp41n	cmqnvvkvt007mjxf0luyawl2v	cmp6j4rh20002jxuik5drdqtt	39	2026-06-21 14:30:14.399	2026-06-21 14:30:14.399
cmqnvw9sx0078jxekrn9zofff	cmqnvw9ss0076jxekzn227l5x	cmp6j4rh20002jxuik5drdqtt	37	2026-06-21 14:30:46.689	2026-06-21 14:30:46.689
cmqnvwmng007tjxf0ot7oo5c4	cmqnvwmnb007rjxf0pw1jsmg1	cmp6j4rh20002jxuik5drdqtt	36	2026-06-21 14:31:03.34	2026-06-21 14:31:03.34
cmqnvx3zn007djxek3xaswyot	cmqnvx3zg007bjxekmhq8jifa	cmp6j4rh20002jxuik5drdqtt	36	2026-06-21 14:31:25.811	2026-06-21 14:31:25.811
cmqnvxkly007yjxf023easm37	cmqnvxklu007wjxf0sbn1vley	cmp6j4rh20002jxuik5drdqtt	33	2026-06-21 14:31:47.35	2026-06-21 14:31:47.35
cmqnvy154007ijxekiiffxeuu	cmqnvy150007gjxekhho1nbq8	cmp6j4rh20002jxuik5drdqtt	12	2026-06-21 14:32:08.776	2026-06-21 14:32:08.776
cmqnw6u700085jxf0j6vj1dme	cmqnw6u6x0083jxf0r0a3qieq	cmp6j4rh20002jxuik5drdqtt	39	2026-06-21 14:38:59.677	2026-06-21 14:38:59.677
cmqnw7b08007njxekeutu8m6s	cmqnw7b03007ljxek3m5nekpj	cmp6j4rh20002jxuik5drdqtt	37	2026-06-21 14:39:21.465	2026-06-21 14:39:21.465
cmqnwph9r00afjxf0ikjbcqru	cmqnwph9n00adjxf093dv597d	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:53:29.391	2026-06-21 14:53:29.391
cmqnwphdh00a1jxekeaa47u51	cmqnwphdd009zjxeksqwmgc90	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:53:29.525	2026-06-21 14:53:29.525
cmqnwphie00akjxf09urzj2hi	cmqnwphia00aijxf0wbijyl1c	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:53:29.702	2026-06-21 14:53:29.702
cmqnwpho600a6jxeko5chy1k2	cmqnwpho200a4jxekze36lgk4	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:53:29.911	2026-06-21 14:53:29.911
cmqnwphxv00apjxf02ajxf0sk	cmqnwphxt00anjxf0qjrkzv42	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:53:30.26	2026-06-21 14:53:30.26
cmqnwpi1500abjxekf84arxc3	cmqnwpi1000a9jxekqz3s3yrx	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:53:30.377	2026-06-21 14:53:30.377
cmqnwppuv00aujxf0chpfhhr0	cmqnwppuq00asjxf0sl2km1r6	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:53:40.519	2026-06-21 14:53:40.519
cmqnwppya00agjxek6dow43l9	cmqnwppy400aejxekqwi1z9n0	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:53:40.642	2026-06-21 14:53:40.642
cmqnwpq1j00azjxf0nmqgh6a0	cmqnwpq1f00axjxf08t4pa264	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:53:40.759	2026-06-21 14:53:40.759
cmqnwpqes00b9jxf01gudhfys	cmqnwpqeo00b7jxf0k6qb7zib	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:53:41.236	2026-06-21 14:53:41.236
cmqnwpxs700avjxekwhzpjyxy	cmqnwpxs400atjxek4qb7dz56	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:53:50.791	2026-06-21 14:53:50.791
cmqnwpq4y00aljxek2srzmcmz	cmqnwpq4u00ajjxek5hy0qp3u	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:53:40.882	2026-06-21 14:53:40.882
cmqnwpqbq00aqjxek1axb6hzh	cmqnwpqbm00aojxeklh7dhmhh	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:53:41.127	2026-06-21 14:53:41.127
cmqnwpxvb00bjjxf0w558a4u2	cmqnwpxv700bhjxf04y3wcgtu	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:53:50.903	2026-06-21 14:53:50.903
cmqnwpq8900b4jxf0z8frlehd	cmqnwpq8400b2jxf06n1ds58k	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:53:41.001	2026-06-21 14:53:41.001
cmqnwpy1s00bojxf0dvt9illn	cmqnwpy1p00bmjxf0iuawuczn	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:53:51.137	2026-06-21 14:53:51.137
cmqnwpxoz00bejxf0f54lk6f3	cmqnwpxou00bcjxf0rbsiruq3	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:53:50.675	2026-06-21 14:53:50.675
cmqnwpxyk00b0jxekncdwnpu9	cmqnwpxyf00ayjxekdtt1yp6w	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:53:51.02	2026-06-21 14:53:51.02
cmqnwpy4u00b5jxekci1ahor0	cmqnwpy4q00b3jxekp19bibnt	cmp6j4rh20002jxuik5drdqtt	40	2026-06-21 14:53:51.246	2026-06-21 14:53:51.246
\.


--
-- Data for Name: school_classes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.school_classes (id, "schoolId", name, "createdAt", "expectedStudentCount") FROM stdin;
cmp6jamug000ejxdffnpliz33	cmp6j9hjm0005jxdfd9vm0g4e	ม.1/3	2026-05-15 06:26:14.44	10
cmp6jamxm000gjxdf5naqar9q	cmp6j9hjm0005jxdfd9vm0g4e	ม.1/4	2026-05-15 06:26:14.554	10
cmq0l3p9b00aqjx23xkoqvbpn	cmq0kjbpl0019jx236ppwjdv2	ม.6/1	2026-06-05 07:09:55.487	21
cmq0l3pdb00avjx23ahywc7bg	cmq0kjbpl0019jx236ppwjdv2	ม.6/2	2026-06-05 07:09:55.631	14
cmp6jamr1000cjxdfp3zovs11	cmp6j9hjm0005jxdfd9vm0g4e	ม.1/2	2026-05-15 06:26:14.317	15
cmqnvpqy5006sjxf0ol0o7n7k	cmqn96nzy005fjxekv4ihp11u	ม.6/6	2026-06-21 14:25:42.317	18
cmpjfvrud001djx2mizt2xeie	cmpjfvisu001bjx2mezlfvfdl	ม.3/1	2026-05-24 07:11:42.517	10
cmpjfvrxy001ijx2m73w9t57r	cmpjfvisu001bjx2mezlfvfdl	ม.3/2	2026-05-24 07:11:42.646	10
cmpjfvs16001njx2mriabvex3	cmpjfvisu001bjx2mezlfvfdl	ม.3/3	2026-05-24 07:11:42.762	10
cmpjfvs4a001sjx2mfuersbc4	cmpjfvisu001bjx2mezlfvfdl	ม.3/4	2026-05-24 07:11:42.875	10
cmpjfvs7b001xjx2mwmoqqwxs	cmpjfvisu001bjx2mezlfvfdl	ม.3/5	2026-05-24 07:11:42.983	10
cmpnih2wv0025jxgmrcw6clre	cmp6j9hjm0005jxdfd9vm0g4e	ม.3/2	2026-05-27 03:35:20.576	20
cmqevw8li0035jxopwcvbsj6f	cmq0khbql000ujx237a6k27or	4/1	2026-06-15 07:20:49.543	35
cmp6jamnw000ajxdf0km83u6b	cmp6j9hjm0005jxdfd9vm0g4e	ม.1/1	2026-05-15 06:26:14.204	11
cmpvlp13p0026jxjcazgnov1t	cmpmdqjp8000pjxgmt4j3159q	ม.2/1	2026-06-01 19:27:39.734	7
cmpvlp15w002bjxjckkljmx48	cmpmdqjp8000pjxgmt4j3159q	ม.2/2	2026-06-01 19:27:39.813	7
cmpyc6jum000zjxwnaz56ev50	cmpmdqjp8000pjxgmt4j3159q	ม.4/1	2026-06-03 17:24:39.55	15
cmpyc6jxi0014jxwnjy0yu86t	cmpmdqjp8000pjxgmt4j3159q	ม.4/2	2026-06-03 17:24:39.655	15
cmq08so9z0033jxwnubf27yft	cmpzr7zap002sjxwn1qukwz8i	ม.4/1	2026-06-05 01:25:25.607	40
cmq0kkhnq001ijx23q2jl1fgu	cmq0kga6m000ljx23ghh9yu87	ป.6/1	2026-06-05 06:54:59.174	34
cmq0kkteh001njx23w3ickk28	cmq0kga6m000ljx23ghh9yu87	ป.6/2	2026-06-05 06:55:14.393	34
cmq0kldda001yjx23kqne0b9y	cmq0kjbpl0019jx236ppwjdv2	ป.5/1	2026-06-05 06:55:40.271	25
cmq0kldpt0023jx238w4zc8u9	cmq0kjbpl0019jx236ppwjdv2	ป.5/2	2026-06-05 06:55:40.722	24
cmq0klxyi002gjx23xf9e2e7g	cmq0kjbpl0019jx236ppwjdv2	ป.6/1	2026-06-05 06:56:06.954	33
cmq0klyit002ljx23vucgubow	cmq0kjbpl0019jx236ppwjdv2	ป.6/2	2026-06-05 06:56:07.685	34
cmq0kmgu9003ajx23l4ukli8q	cmq0kjbpl0019jx236ppwjdv2	ม.1/1	2026-06-05 06:56:31.425	29
cmq0kmh3r003kjx23hj3nm4ra	cmq0kjbpl0019jx236ppwjdv2	ม.1/3	2026-06-05 06:56:31.768	29
cmq0kmh80003pjx23fpxvrrlw	cmq0kjbpl0019jx236ppwjdv2	ม.1/4	2026-06-05 06:56:31.921	29
cmq0kmgzu003fjx23ni53wxb7	cmq0kjbpl0019jx236ppwjdv2	ม.1/2	2026-06-05 06:56:31.626	34
cmq0kyjt4006sjx23ovbzo4u5	cmq0kjbpl0019jx236ppwjdv2	ม.2/1	2026-06-05 07:05:55.144	29
cmq0kyk5v0072jx23457tkouc	cmq0kjbpl0019jx236ppwjdv2	ม.2/3	2026-06-05 07:05:55.604	29
cmq0kyjwf006xjx23xc3m9hml	cmq0kjbpl0019jx236ppwjdv2	ม.2/2	2026-06-05 07:05:55.263	25
cmq0kyk970077jx235vtyfe05	cmq0kjbpl0019jx236ppwjdv2	ม.2/4	2026-06-05 07:05:55.723	27
cmq0l0fty008njx230lba64wz	cmq0kjbpl0019jx236ppwjdv2	ม.3/2	2026-06-05 07:07:23.303	26
cmq0l0fc1008ijx23gbgw78w7	cmq0kjbpl0019jx236ppwjdv2	ม.3/1	2026-06-05 07:07:22.657	25
cmq0l0ge6008sjx232akfpoc6	cmq0kjbpl0019jx236ppwjdv2	ม.3/3	2026-06-05 07:07:24.03	22
cmq0l0gpf008xjx23kdz6e78d	cmq0kjbpl0019jx236ppwjdv2	ม.3/4	2026-06-05 07:07:24.435	24
cmq0l2nhs00a4jx23515gqlk1	cmq0kjbpl0019jx236ppwjdv2	ม.4/2	2026-06-05 07:09:06.544	30
cmq0l2nc4009zjx23ibmvgl25	cmq0kjbpl0019jx236ppwjdv2	ม.4/1	2026-06-05 07:09:06.34	27
cmq0l37j800acjx238q9wazht	cmq0kjbpl0019jx236ppwjdv2	ม.5/1	2026-06-05 07:09:32.516	26
cmq0l37ms00ahjx23zxl8fwdl	cmq0kjbpl0019jx236ppwjdv2	ม.5/2	2026-06-05 07:09:32.645	16
cmqevw8r600tpjxp5tdq0itax	cmq0khbql000ujx237a6k27or	4/2	2026-06-15 07:20:49.746	33
cmqeogre6002ljxop1xyn75j3	cmq0kjrxw001ejx23detqolsk	ม.2/1	2026-06-15 03:52:50.095	23
cmqeohj2s00egjxp5s8vrneyv	cmq0kjrxw001ejx23detqolsk	ม.2/2	2026-06-15 03:53:25.972	29
cmqeoifq7002qjxophqoao70n	cmq0kjrxw001ejx23detqolsk	ม.3/3	2026-06-15 03:54:08.288	24
cmqeoj0u800eljxp58lgsh7sb	cmq0kjrxw001ejx23detqolsk	ม.3/4	2026-06-15 03:54:35.648	28
cmq0knhl00041jx23fomw9ktn	cmq0khbql000ujx237a6k27or	1/1	2026-06-05 06:57:19.044	44
cmq0knhsb0046jx233rxr0sub	cmq0khbql000ujx237a6k27or	1/2	2026-06-05 06:57:19.307	43
cmqalbp9w000ljxp5x762hqqn	cmq0khbql000ujx237a6k27or	2/1	2026-06-12 07:13:50.516	34
cmqalbpgf000qjxp5rfez5dd4	cmq0khbql000ujx237a6k27or	2/2	2026-06-12 07:13:50.752	37
cmqalbpky000mjxopw9gwxokg	cmq0khbql000ujx237a6k27or	2/3	2026-06-12 07:13:50.914	36
cmqalc2ra000vjxp5rw1vozj3	cmq0khbql000ujx237a6k27or	3/1	2026-06-12 07:14:07.99	33
cmqalc2vg000rjxopstgevqgy	cmq0khbql000ujx237a6k27or	3/2	2026-06-12 07:14:08.141	41
cmqey1d0w003djxop6grz3x1q	cmq0khbql000ujx237a6k27or	5/1	2026-06-15 08:20:47.792	22
cmqey1d6g00xfjxp59n9wnwrz	cmq0khbql000ujx237a6k27or	5/2	2026-06-15 08:20:47.993	36
cmqey3scc003rjxopqg2ipvcc	cmq0khbql000ujx237a6k27or	6/1	2026-06-15 08:22:40.957	24
cmqey3sg300y2jxp50vijn668	cmq0khbql000ujx237a6k27or	6/2	2026-06-15 08:22:41.092	33
cmqezw8hl005pjxopglxnvxdz	cmq0kjrxw001ejx23detqolsk	ม.2/3	2026-06-15 09:12:47.866	7
cmprvdntx000rjx5qqrr9jgc7	cmp6j9hjm0005jxdfd9vm0g4e	ม.3/5	2026-05-30 04:47:40.773	30
cmqnvnepk006djxf0skutte08	cmqn96nzy005fjxekv4ihp11u	ม.6/1	2026-06-21 14:23:53.144	33
cmpnig2ox001wjxgmevz48gjv	cmp6j9hjm0005jxdfd9vm0g4e	ม.3/1	2026-05-27 03:34:33.633	19
cmqnvo1xk006ijxf0ybgmi4ra	cmqn96nzy005fjxekv4ihp11u	ม.6/2	2026-06-21 14:24:23.241	28
cmqnvofby005xjxekjgt7tnhb	cmqn96nzy005fjxekv4ihp11u	ม.6/3	2026-06-21 14:24:40.606	40
cmqnvoweq006njxf0nvgu5ng2	cmqn96nzy005fjxekv4ihp11u	ม.6/4	2026-06-21 14:25:02.738	25
cmqnvqkxd0067jxek37qhk7in	cmqn96nzy005fjxekv4ihp11u	ม.5/1	2026-06-21 14:26:21.17	30
cmqnvpam90062jxekynreyuq1	cmqn96nzy005fjxekv4ihp11u	ม.6/5	2026-06-21 14:25:21.153	29
cmqnvqvgt006xjxf0wxtww7sc	cmqn96nzy005fjxekv4ihp11u	ม.5/2	2026-06-21 14:26:34.83	31
cmqnvra0v006cjxekfgbcm76g	cmqn96nzy005fjxekv4ihp11u	ม.5/3	2026-06-21 14:26:53.696	33
cmqnvriln0072jxf05pup6bv6	cmqn96nzy005fjxekv4ihp11u	ม.5/4	2026-06-21 14:27:04.811	35
cmqnvrrwj006hjxek8maxws2a	cmqn96nzy005fjxekv4ihp11u	ม.5/5	2026-06-21 14:27:16.867	25
cmqnvs4jn0077jxf0rrmlfc87	cmqn96nzy005fjxekv4ihp11u	ม.5/6	2026-06-21 14:27:33.252	16
cmqnvsxyn006mjxekiyv4cm0k	cmqn96nzy005fjxekv4ihp11u	ม.4/1	2026-06-21 14:28:11.376	37
cmqnvt8fv007cjxf0c4gnnv04	cmqn96nzy005fjxekv4ihp11u	ม.4/2	2026-06-21 14:28:24.955	37
cmqnvtg22006rjxek6e7f0m47	cmqn96nzy005fjxekv4ihp11u	ม.4/3	2026-06-21 14:28:34.826	28
cmqnvto60006wjxekbax3tzj4	cmqn96nzy005fjxekv4ihp11u	ม.4/4	2026-06-21 14:28:45.336	34
cmqnvxklu007wjxf0sbn1vley	cmqn96nzy005fjxekv4ihp11u	ม.3/5	2026-06-21 14:31:47.347	33
cmqnwoit9008tjxekn95dw7ue	cmq0kj2ej0018jx23hz3n6u59	ม.1/3	2026-06-21 14:52:44.733	40
cmqnwp6p7009kjxekat80lqmt	cmq0kj2ej0018jx23hz3n6u59	ม.3/2	2026-06-21 14:53:15.691	40
cmqnwpq8400b2jxf06n1ds58k	cmq0kj2ej0018jx23hz3n6u59	ม.5/5	2026-06-21 14:53:40.997	40
cmqnwpy1p00bmjxf0iuawuczn	cmq0kj2ej0018jx23hz3n6u59	ม.6/5	2026-06-21 14:53:51.134	40
cmqnvu3s6007hjxf0vqfsm9yl	cmqn96nzy005fjxekv4ihp11u	ม.4/5	2026-06-21 14:29:05.574	38
cmqnw8tm7007xjxekgkpm6uqn	cmqn96nzy005fjxekv4ihp11u	ม.2/6	2026-06-21 14:40:32.24	16
cmqnw9l78008jjxf084agn3p5	cmqn96nzy005fjxekv4ihp11u	ม.1/2	2026-06-21 14:41:07.988	40
cmqnwal7m008tjxf0o4lifdmb	cmqn96nzy005fjxekv4ihp11u	ม.1/6	2026-06-21 14:41:54.659	19
cmqnwoipf0094jxf06sivyg3r	cmq0kj2ej0018jx23hz3n6u59	ม.1/2	2026-06-21 14:52:44.595	40
cmqnwoiwk0099jxf0vxfkfixe	cmq0kj2ej0018jx23hz3n6u59	ม.1/4	2026-06-21 14:52:44.852	40
cmqnvudv00071jxekpfexpwpy	cmqn96nzy005fjxekv4ihp11u	ม.4/6	2026-06-21 14:29:18.637	20
cmqnvvkvt007mjxf0luyawl2v	cmqn96nzy005fjxekv4ihp11u	ม.3/1	2026-06-21 14:30:14.394	39
cmqnvw9ss0076jxekzn227l5x	cmqn96nzy005fjxekv4ihp11u	ม.3/2	2026-06-21 14:30:46.685	37
cmqnvwmnb007rjxf0pw1jsmg1	cmqn96nzy005fjxekv4ihp11u	ม.3/3	2026-06-21 14:31:03.336	36
cmqnvx3zg007bjxekmhq8jifa	cmqn96nzy005fjxekv4ihp11u	ม.3/4	2026-06-21 14:31:25.804	36
cmqnvy150007gjxekhho1nbq8	cmqn96nzy005fjxekv4ihp11u	ม.3/6	2026-06-21 14:32:08.772	12
cmqnw6u6x0083jxf0r0a3qieq	cmqn96nzy005fjxekv4ihp11u	ม.2/1	2026-06-21 14:38:59.673	39
cmqnw7b03007ljxek3m5nekpj	cmqn96nzy005fjxekv4ihp11u	ม.2/2	2026-06-21 14:39:21.459	37
cmqnw7r8e0088jxf0bavdii1g	cmqn96nzy005fjxekv4ihp11u	ม.2/3	2026-06-21 14:39:42.495	36
cmqnw8iw0008djxf0viqczga3	cmqn96nzy005fjxekv4ihp11u	ม.2/5	2026-06-21 14:40:18.336	38
cmqnw9d010082jxeketm8e263	cmqn96nzy005fjxekv4ihp11u	ม.1/1	2026-06-21 14:40:57.361	33
cmqnw9t3g0087jxekquy639dy	cmqn96nzy005fjxekv4ihp11u	ม.1/3	2026-06-21 14:41:18.22	39
cmqnwa5fb008djxeksig21yn8	cmqn96nzy005fjxekv4ihp11u	ม.1/4	2026-06-21 14:41:34.199	42
cmqnwadk2008ojxf0aghk7ea4	cmqn96nzy005fjxekv4ihp11u	ม.1/5	2026-06-21 14:41:44.738	36
cmqnwoj3d009ejxf0i0gj9o3q	cmq0kj2ej0018jx23hz3n6u59	ม.1/6	2026-06-21 14:52:45.097	40
cmqnwox710093jxekcvogml9t	cmq0kj2ej0018jx23hz3n6u59	ม.2/1	2026-06-21 14:53:03.373	40
cmqnwoxe60098jxek8ycs0jag	cmq0kj2ej0018jx23hz3n6u59	ม.2/3	2026-06-21 14:53:03.63	40
cmqnwoxo3009tjxf0t4255udt	cmq0kj2ej0018jx23hz3n6u59	ม.2/6	2026-06-21 14:53:03.987	40
cmqnwp6lt009yjxf0kcn9od5v	cmq0kj2ej0018jx23hz3n6u59	ม.3/1	2026-06-21 14:53:15.57	40
cmqnwph9n00adjxf093dv597d	cmq0kj2ej0018jx23hz3n6u59	ม.4/1	2026-06-21 14:53:29.388	40
cmqnwphia00aijxf0wbijyl1c	cmq0kj2ej0018jx23hz3n6u59	ม.4/3	2026-06-21 14:53:29.698	40
cmqnwphxt00anjxf0qjrkzv42	cmq0kj2ej0018jx23hz3n6u59	ม.4/5	2026-06-21 14:53:30.257	40
cmqnwppuq00asjxf0sl2km1r6	cmq0kj2ej0018jx23hz3n6u59	ม.5/1	2026-06-21 14:53:40.514	40
cmqnwppy400aejxekqwi1z9n0	cmq0kj2ej0018jx23hz3n6u59	ม.5/2	2026-06-21 14:53:40.636	40
cmqnwpq1f00axjxf08t4pa264	cmq0kj2ej0018jx23hz3n6u59	ม.5/3	2026-06-21 14:53:40.755	40
cmqnwpq4u00ajjxek5hy0qp3u	cmq0kj2ej0018jx23hz3n6u59	ม.5/4	2026-06-21 14:53:40.878	40
cmqnwpqbm00aojxeklh7dhmhh	cmq0kj2ej0018jx23hz3n6u59	ม.5/6	2026-06-21 14:53:41.122	40
cmqnwpqeo00b7jxf0k6qb7zib	cmq0kj2ej0018jx23hz3n6u59	ม.5/7	2026-06-21 14:53:41.232	40
cmqnwpxs400atjxek4qb7dz56	cmq0kj2ej0018jx23hz3n6u59	ม.6/2	2026-06-21 14:53:50.788	40
cmqnwpxv700bhjxf04y3wcgtu	cmq0kj2ej0018jx23hz3n6u59	ม.6/3	2026-06-21 14:53:50.899	40
cmqnw85hc007qjxek9a1yplc0	cmqn96nzy005fjxekv4ihp11u	ม.2/4	2026-06-21 14:40:00.961	38
cmqnwoilp008ojxek0snyjpmk	cmq0kj2ej0018jx23hz3n6u59	ม.1/1	2026-06-21 14:52:44.462	40
cmqnwoj05008yjxekb2he5ifl	cmq0kj2ej0018jx23hz3n6u59	ม.1/5	2026-06-21 14:52:44.982	40
cmqnwoxam009jjxf0nqj68uma	cmq0kj2ej0018jx23hz3n6u59	ม.2/2	2026-06-21 14:53:03.502	40
cmqnwoxhd009ojxf0oz3or0yh	cmq0kj2ej0018jx23hz3n6u59	ม.2/4	2026-06-21 14:53:03.746	40
cmqnwoxkr009djxekn0hb3vou	cmq0kj2ej0018jx23hz3n6u59	ม.2/5	2026-06-21 14:53:03.867	40
cmqnwp6sc00a3jxf0bq7dc3d1	cmq0kj2ej0018jx23hz3n6u59	ม.3/3	2026-06-21 14:53:15.805	40
cmqnwp6vl009pjxekby3gpsna	cmq0kj2ej0018jx23hz3n6u59	ม.3/4	2026-06-21 14:53:15.922	40
cmqnwp6ym00a8jxf02r0mvniv	cmq0kj2ej0018jx23hz3n6u59	ม.3/5	2026-06-21 14:53:16.03	40
cmqnwp726009ujxek0r2bxxhw	cmq0kj2ej0018jx23hz3n6u59	ม.3/6	2026-06-21 14:53:16.159	40
cmqnwphdd009zjxeksqwmgc90	cmq0kj2ej0018jx23hz3n6u59	ม.4/2	2026-06-21 14:53:29.521	40
cmqnwpho200a4jxekze36lgk4	cmq0kj2ej0018jx23hz3n6u59	ม.4/4	2026-06-21 14:53:29.907	40
cmqnwpi1000a9jxekqz3s3yrx	cmq0kj2ej0018jx23hz3n6u59	ม.4/6	2026-06-21 14:53:30.373	40
cmqnwpxou00bcjxf0rbsiruq3	cmq0kj2ej0018jx23hz3n6u59	ม.6/1	2026-06-21 14:53:50.67	40
cmqnwpxyf00ayjxekdtt1yp6w	cmq0kj2ej0018jx23hz3n6u59	ม.6/4	2026-06-21 14:53:51.016	40
cmqnwpy4q00b3jxekp19bibnt	cmq0kj2ej0018jx23hz3n6u59	ม.6/6	2026-06-21 14:53:51.242	40
\.


--
-- Data for Name: school_teacher_roster; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.school_teacher_roster (id, "schoolId", "firstName", "lastName", email, age, "userRole", "advisoryClass", "schoolRole", "projectRole", "inviteSent", "createdAt", "updatedAt") FROM stdin;
cmp6jc6an0011jxdfoa35dg0a	cmp6j9hjm0005jxdfd9vm0g4e	yingyot	jiteiei	baitongxaxaxa1@gmail.com	35	class_teacher	ม.1/2	ครูรวย	coordinate	t	2026-05-15 06:27:26.303	2026-05-15 06:27:32.936
cmp6jls3s001hjxdfeapglpuv	cmp6j9hjm0005jxdfd9vm0g4e	ทดสอบ	นางฟ้า	yingyot111@test.com	45	school_admin	ทุกห้อง	ครูหนู	coordinate	t	2026-05-15 06:34:54.473	2026-05-15 06:35:00.215
cmq08tcvv0038jxwnbhqfuoij	cmpzr7zap002sjxwn1qukwz8i	อารยา	นิวัฒน์	wanwisa.t@thainhf.org	34	class_teacher	ม.4/1	ครูวิชาคณิตศาสตร์	coordinate	t	2026-06-05 01:25:57.499	2026-06-05 01:27:14.568
cmq0kpvtx004gjx23g3htt9c0	cmq0kga6m000ljx23ghh9yu87	นางสาวมธุริน	วันทะวี	nakyoomg95@gmail.com	35	school_admin	ทุกห้อง	ครูพยาบาล	care	t	2026-06-05 06:59:10.821	2026-06-05 07:00:53.12
cmq0kp17r004cjx2395m7h2a0	cmq0kjrxw001ejx23detqolsk	นางสาวศรัญญา	ดวงอุปะ	saranya34164@gmail.com	24	school_admin	ทุกห้อง	ครูนางฟ้า	care	t	2026-06-05 06:58:31.143	2026-06-05 07:03:29.176
cmq0ktr3x0057jx23j0f23onx	cmq0kjbpl0019jx236ppwjdv2	นางพัทธยา	ชนะพันธ์	pattayak.2512@gmail.com	56	school_admin	ทุกห้อง	ผู้อำนวยการโรงเรียน	lead	t	2026-06-05 07:02:11.326	2026-06-05 07:03:53.026
cmq0kvajt005jjx23x3yh4394	cmq0kj2ej0018jx23hz3n6u59	นายประยูร	มังกร	payoon.1881@gmail.com	55	school_admin	ทุกห้อง	ผู้อำนวยการโรงเรียน	lead	t	2026-06-05 07:03:23.177	2026-06-05 07:04:03.445
cmq0ks3jq004wjx233vswi2w0	cmq0kjrxw001ejx23detqolsk	นายวิฑูลย์	แซมสีม่วง	witoon28012520@gmail.com	50	school_admin	ทุกห้อง	ครูนางฟ้า	care	t	2026-06-05 07:00:54.135	2026-06-05 07:05:07.748
cmq0ksoeu004yjx23ioqs7y5l	cmq0kj2ej0018jx23hz3n6u59	นายพงศ์พิสุทธิ์	ใจคุณ	pongpisut.j@twsc.ac.th	40	school_admin	ทุกห้อง	ครู	care	t	2026-06-05 07:01:21.174	2026-06-05 07:05:50.489
cmq0kug71005bjx23lw3k4an1	cmq0kjrxw001ejx23detqolsk	นายสุรสีห์	จันทร์แสงศรี	surasee1981@gmail.com	45	school_admin	ทุกห้อง	ครูนางฟ้า	care	t	2026-06-05 07:02:43.837	2026-06-05 07:06:02.612
cmq0kyj3l006qjx23926sfb5c	cmpmdqjp8000pjxgmt4j3159q	ลิน	ลาลาลิน	naipaporn.v@thainhf.org	25	class_teacher	ม.2/1	ครูนางฟ้า	coordinate	t	2026-06-05 07:05:54.225	2026-06-05 07:06:03.75
cmq0kpn1o004ejx23ih0aad1f	cmq0kj2ej0018jx23hz3n6u59	นายโกมล	ยงเพชร	komon699@gmail.com	30	school_admin	ทุกห้อง	ครู	care	t	2026-06-05 06:58:59.437	2026-06-05 07:06:27.57
cmq0l0obf0096jx23vq1gmg16	cmq0khbql000ujx237a6k27or	นูรฮีดายะห์	โดดะนะ	nurheedayah041139@gmail.com	31	school_admin	ทุกห้อง	ครูประจำชั้น	care	t	2026-06-05 07:07:34.299	2026-06-05 07:07:43.79
cmq0krv4w004qjx238xxcprcb	cmq0kjbpl0019jx236ppwjdv2	สุภารัตน์	บุญป้อง	pond.soharia@gmail.com	34	school_admin	ทุกห้อง	ครูแกนนำนางฟ้า	care	f	2026-06-05 07:00:43.233	2026-06-05 07:11:33.319
cmq6gh0qm000bjxsdol1aa7cb	cmp6j9hjm0005jxdfd9vm0g4e	ครูรวย	สวยไม่สร่าง	baitong.yingyot@gmail.com	40	class_teacher	ม.1/4	ว่าง	care	t	2026-06-09 09:46:55.871	2026-06-09 09:47:11.946
cmqeyj7zf004ajxopg4vw8yd8	cmq0khbql000ujx237a6k27or	ซัยนับ	อาบู	habiib3290@gmail.com	25	class_teacher	4/1	ครู	coordinate	t	2026-06-15 08:34:41.067	2026-06-15 08:38:03.416
cmqeyeaut0046jxoptswsnlm2	cmq0khbql000ujx237a6k27or	ซุไรดา	ลีปะ	suwaibahyuyu@gmail.com	29	class_teacher	2/3	ครู	coordinate	t	2026-06-15 08:30:51.51	2026-06-15 08:38:29.808
cmqeyg9f80048jxop3y6rt1y3	cmq0khbql000ujx237a6k27or	นูรีซัน	สือแน	nureesan199x@gmail.com	29	class_teacher	3/2	ครู	coordinate	t	2026-06-15 08:32:22.965	2026-06-15 08:38:35.385
cmqeyk2k300yljxp57gg23suc	cmq0khbql000ujx237a6k27or	นูรียะ	ขาเดร์	k.nuuyah@gmail.com	34	class_teacher	5/1	ครู	coordinate	t	2026-06-15 08:35:20.691	2026-06-15 08:38:38.16
cmqeyaqtz0042jxopifv11rad	cmq0khbql000ujx237a6k27or	ปฐพี	จันทร์แก้ว	fee564301016@gmail.com	33	class_teacher	1/1	ครู	coordinate	t	2026-06-15 08:28:05.591	2026-06-15 08:38:41.454
cmqeyi75800yjjxp5ofw7lv41	cmq0khbql000ujx237a6k27or	พาตีเมาะ	เจะมะ	fatmah8977@gmail.com	25	class_teacher	4/2	ครู	coordinate	t	2026-06-15 08:33:53.325	2026-06-15 08:38:44.964
cmqeybkvd00ydjxp5uixc70q4	cmq0khbql000ujx237a6k27or	มาญีดะห์	อาลี	mayeedah616@gmail.com	29	class_teacher	1/2	ครู	coordinate	t	2026-06-15 08:28:44.521	2026-06-15 08:38:47.96
cmqeym8bw004cjxopk0bulntz	cmq0khbql000ujx237a6k27or	มาหาหมัดรอสลัน	ลาเต๊ะ	mahamadroslanlateh@gmail.com	38	class_teacher	6/1	ครู	coordinate	t	2026-06-15 08:37:01.485	2026-06-15 08:38:50.976
cmqeyf26900yhjxp5c088lplb	cmq0khbql000ujx237a6k27or	ยุสรีย๊ะ	ปะแตบือแน	yusreeyah2986@gmail.com	34	class_teacher	3/1	ครู	coordinate	t	2026-06-15 08:31:26.914	2026-06-15 08:38:53.575
cmqeydanj00yfjxp54rhlrcu9	cmq0khbql000ujx237a6k27or	อามีน	โต๊ะเฮง	ameen1464052@gmail.com	27	class_teacher	2/2	ครู	coordinate	t	2026-06-15 08:30:04.591	2026-06-15 08:38:58.252
cmqeyn3xu00ynjxp5w1npmobm	cmq0khbql000ujx237a6k27or	อาลาวียะห์	วาเตง	ala.weewateng@gmail.com	30	class_teacher	6/2	ครู	coordinate	t	2026-06-15 08:37:42.451	2026-06-15 08:39:00.708
cmqeycewj0044jxopuuowki4u	cmq0khbql000ujx237a6k27or	อุสมา	มามะ	usmamamat1990@gmail.com	33	class_teacher	2/1	ครู	coordinate	t	2026-06-15 08:29:23.443	2026-06-15 08:39:03.597
cmqnwl22r0091jxf0jbqwwzz0	cmqn96nzy005fjxekv4ihp11u	นายคุณากร	โมจรินทร์	kunakorn.mojarin@gmail.com	34	school_admin	ทุกห้อง	ครูแนะแนว	care	t	2026-06-21 14:50:03.075	2026-06-21 15:05:42.263
cmqnwvv5e00bsjxf0318mqkkw	cmqn96nzy005fjxekv4ihp11u	นางสาวกมลชนก	ขำวิชัย	kamonchanokoohll@gmail.com	32	school_admin	ทุกห้อง	ครูระบบดูแลช่วยเหลือนักเรียน	care	t	2026-06-21 14:58:27.314	2026-06-21 15:06:34.662
cmqnwp4av009ijxekizlhd9jg	cmqn96nzy005fjxekv4ihp11u	นางสาวรุ้งนภา	มาลัย	khing0526@gmail.com	26	school_admin	ทุกห้อง	ครู Thailand Zero Dropout	care	t	2026-06-21 14:53:12.583	2026-06-21 15:07:03.467
cmqnwueh400b9jxekiz5cixm5	cmqn96nzy005fjxekv4ihp11u	นายชินทัศ	เหลืองประมวล	chin.tas2531@gmail.com	38	school_admin	ทุกห้อง	ครูงานยาเสพติด	care	t	2026-06-21 14:57:19.049	2026-06-21 15:07:29.859
\.


--
-- Data for Name: schools; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schools (id, name, province, "createdAt", "updatedAt") FROM stdin;
cmp6j9hjm0005jxdfd9vm0g4e	โรงเรียนรวยก็ไม่รวยไหวก็ไม่ไหว	\N	2026-05-15 06:25:20.915	2026-05-15 06:25:20.915
cmpjfvisu001bjx2mezlfvfdl	โรงเรียนเอเอ๊สะกะดุ๊งสะกะดิ๊ง	\N	2026-05-24 07:11:30.799	2026-05-24 07:11:30.799
cmpkp9f2g002sjx2mxjfpmxuk	โรงเรียนรร.ครูนางฟ้า	\N	2026-05-25 04:22:01.864	2026-05-25 04:22:01.864
cmpmdqjp8000pjxgmt4j3159q	โรงเรียนสพบ.	กรุงเทพฯ	2026-05-26 08:34:57.98	2026-05-26 08:34:57.98
cmpzr7zap002sjxwn1qukwz8i	โรงเรียนบ้านตรัง	ตรัง	2026-06-04 17:13:26.641	2026-06-04 17:13:26.641
cmq0kga6m000ljx23ghh9yu87	โรงเรียนราชประชานุเคราะห์ 52 จังหวัดเลย	เลย	2026-06-05 06:51:42.863	2026-06-05 06:51:42.863
cmq0khbql000ujx237a6k27or	โรงเรียนอาสาศาสตร์วิทยา	ยะลา	2026-06-05 06:52:31.533	2026-06-05 06:52:31.533
cmq0kj2ej0018jx23hz3n6u59	โรงเรียนเทพสถิตวิทยา	ชัยภูมิ	2026-06-05 06:53:52.748	2026-06-05 06:53:52.748
cmq0kjbpl0019jx236ppwjdv2	โรงเรียนราชประชานุเคราะห์ 52	เลย	2026-06-05 06:54:04.81	2026-06-05 06:54:04.81
cmq0kjrxw001ejx23detqolsk	โรงเรียนเทศบาล3	เพชรบ	2026-06-05 06:54:25.845	2026-06-05 06:54:25.845
cmqn96nzy005fjxekv4ihp11u	โรงเรียนไทรโยคมณีกาญจน์วิทยา	กาญจนบุรี	2026-06-21 03:55:00.478	2026-06-21 03:55:00.478
cmr4ninj7010jjxct7jj0c0q0	โรงเรียนหัวดงราชพรหมาภรณ์	นครนครสวรรค์	2026-07-03 08:08:19.364	2026-07-03 08:08:19.364
\.


--
-- Data for Name: student_referrals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.student_referrals (id, "studentId", "fromTeacherUserId", "toTeacherUserId", "createdAt") FROM stdin;
\.


--
-- Data for Name: students; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.students (id, "studentId", "firstName", "lastName", gender, age, class, "schoolId", "createdAt", "updatedAt", "nationalId", status, "statusChangedAt", "leftAt") FROM stdin;
cmp6jb4ux000jjxdf1gpsl39s	12345	สมชาย	ใจดี	MALE	13	ม.1/1	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-15 06:26:37.786	2026-05-15 06:26:37.786	1103700000011	ACTIVE	\N	\N
cmp6jb4ux000kjxdfnh0bkm21	12346	สมหญิง	รักเรียน	FEMALE	13	ม.1/1	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-15 06:26:37.786	2026-05-15 06:26:37.786	1103700000012	ACTIVE	\N	\N
cmp6jb4ux000mjxdf5pxamnft	12348	สมปอง	ดีใจ	FEMALE	14	ม.1/2	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-15 06:26:37.786	2026-05-15 06:26:37.786	1103700000014	ACTIVE	\N	\N
cmpjfwomm0023jx2mkak9orx7	68001	สมควร	ใจดี	MALE	15	ม.3/2	cmpjfvisu001bjx2mezlfvfdl	2026-05-24 07:12:25.006	2026-05-24 07:12:25.006	1234567890254	ACTIVE	\N	\N
cmpjfwomm0024jx2msn5sgb52	68002	สมน้ำหน้า	ใจดี	MALE	15	ม.3/2	cmpjfvisu001bjx2mezlfvfdl	2026-05-24 07:12:25.006	2026-05-24 07:12:25.006	1234567890568	ACTIVE	\N	\N
cmpjfwomm0025jx2mqp2sarfq	68003	สมส่วน	ใจดี	MALE	15	ม.3/2	cmpjfvisu001bjx2mezlfvfdl	2026-05-24 07:12:25.006	2026-05-24 07:12:25.006	1234567890666	ACTIVE	\N	\N
cmpjfwomm0026jx2m2dnegu2z	68004	สมใจ	ใจดี	MALE	15	ม.3/2	cmpjfvisu001bjx2mezlfvfdl	2026-05-24 07:12:25.006	2026-05-24 07:12:25.006	1234567890877	ACTIVE	\N	\N
cmp6jb4ux000ljxdf32u2b13l	12347	สมศักดิ์	เก่งมาก	MALE	14	ม.1/2	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-15 06:26:37.786	2026-05-27 04:45:37.703	1103700000013	RESIGNED	2026-05-27 04:45:37.701	2026-05-27 04:45:37.701
cmprve8l5000xjx5q8yfs30hz	68001	สมปอง	น้องสมชาย	MALE	15	ม.3/1	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-30 04:48:07.673	2026-05-30 04:48:07.673	1234567890124	ACTIVE	\N	\N
cmprve8l5000zjx5qnhtbywm5	68003	สมหญิง	ศรีประเสริฐ	FEMALE	15	ม.3/5	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-30 04:48:07.673	2026-05-30 04:48:07.673	1234567890010	ACTIVE	\N	\N
cmprve8l50010jx5qlo0nyjtc	68004	พรเพ็ญ	มั่งคั่ง	MALE	15	ม.3/5	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-30 04:48:07.673	2026-05-30 04:48:07.673	1234567890011	ACTIVE	\N	\N
cmprve8l50011jx5qhpm1dvmd	68006	นงลักษณ์	ศรีประเสริฐ	MALE	15	ม.3/5	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-30 04:48:07.673	2026-05-30 04:48:07.673	1234567890013	ACTIVE	\N	\N
cmprve8l50014jx5qsq8okhxj	68009	อุบล	ใจดี	FEMALE	15	ม.3/5	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-30 04:48:07.673	2026-05-30 04:48:07.673	1234567890016	ACTIVE	\N	\N
cmprve8l50018jx5q45abost6	68013	สมหญิง	วงษ์ทอง	FEMALE	15	ม.3/5	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-30 04:48:07.673	2026-05-30 04:48:07.673	1234567890020	ACTIVE	\N	\N
cmprve8l50019jx5qyzrvi13i	68014	สิริ	มั่งคั่ง	FEMALE	15	ม.3/5	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-30 04:48:07.673	2026-05-30 04:48:07.673	1234567890021	ACTIVE	\N	\N
cmprve8l5001ajx5qewbyvflm	68015	สิริ	รักษ์ไทย	MALE	15	ม.3/5	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-30 04:48:07.673	2026-05-30 04:48:07.673	1234567890022	ACTIVE	\N	\N
cmprve8l5001bjx5qvwvekbo3	68016	สมหญิง	รักษ์ไทย	FEMALE	15	ม.3/5	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-30 04:48:07.673	2026-05-30 04:48:07.673	1234567890023	ACTIVE	\N	\N
cmprve8l5001cjx5qpmcf03xl	68017	วิชัย	รักชาติ	MALE	15	ม.3/5	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-30 04:48:07.673	2026-05-30 04:48:07.673	1234567890024	ACTIVE	\N	\N
cmprve8l5001ejx5qyacdv8ge	68019	อดิศักดิ์	รักษ์ไทย	FEMALE	15	ม.3/5	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-30 04:48:07.673	2026-05-30 04:48:07.673	1234567890026	ACTIVE	\N	\N
cmprve8l5001fjx5qwrwbswpu	68020	สมหญิง	มีสุข	MALE	15	ม.3/5	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-30 04:48:07.673	2026-05-30 04:48:07.673	1234567890027	ACTIVE	\N	\N
cmprve8l5001gjx5qqjjvx9qi	68021	อดิศักดิ์	มั่งคั่ง	FEMALE	15	ม.3/5	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-30 04:48:07.673	2026-05-30 04:48:07.673	1234567890028	ACTIVE	\N	\N
cmprve8l5001hjx5qbvppe3pc	68022	ธีรพล	มั่งคั่ง	MALE	15	ม.3/5	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-30 04:48:07.673	2026-05-30 04:48:07.673	1234567890029	ACTIVE	\N	\N
cmprve8l5001njx5qjladhnpl	68028	สมหญิง	มั่งคั่ง	MALE	15	ม.3/5	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-30 04:48:07.673	2026-05-30 04:48:07.673	1234567890035	ACTIVE	\N	\N
cmprve8l5001ojx5q9dn40x1c	68029	สมชาย	รักชาติ	MALE	15	ม.3/5	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-30 04:48:07.673	2026-05-30 04:48:07.673	1234567890036	ACTIVE	\N	\N
cmprve8l5001pjx5qzq4cy4y9	68030	อดิศักดิ์	ใจดี	MALE	15	ม.3/5	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-30 04:48:07.673	2026-05-30 04:48:07.673	1234567890037	ACTIVE	\N	\N
cmprve8l5001qjx5qp9884e4i	68031	พรเพ็ญ	รักชาติ	MALE	15	ม.3/5	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-30 04:48:07.673	2026-05-30 04:48:07.673	1234567890038	ACTIVE	\N	\N
cmprve8l5000yjx5qxjdz6rp8	68005	สมปง	น้องสมหญิง	FEMALE	15	ม.3/1	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-30 04:48:07.673	2026-06-15 09:57:51.17	1234567890012	RESIGNED	2026-06-15 09:57:51.169	2026-06-15 09:57:51.169
cmprve8l50012jx5qj6qlzxu9	68007	วิชัย	รักชาติ	MALE	14	ม.3/5	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-30 04:48:07.673	2026-06-15 09:59:07.258	1234567890014	ACTIVE	\N	\N
cmprve8l5001ijx5q2rbnbp6b	68023	อุบล	มีสุข	MALE	15	ม.3/5	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-30 04:48:07.673	2026-06-16 05:21:52.415	1234567890030	ACTIVE	\N	\N
cmprve8l5001ljx5q0277mh23	68026	อดิศักดิ์	วงษ์ทอง	FEMALE	17	ม.3/5	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-30 04:48:07.673	2026-06-25 08:58:51.396	1234567890033	ACTIVE	\N	\N
cmprve8l50016jx5qimkh5tot	68011	วิชัย	มีสุข	MALE	16	ม.3/5	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-30 04:48:07.673	2026-06-16 05:24:36.623	1234567890018	ACTIVE	\N	\N
cmprve8l50013jx5q08thkxep	68008	อดิศักดิ์	ใจดี	MALE	16	ม.3/5	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-30 04:48:07.673	2026-06-16 11:35:56.65	1234567890015	ACTIVE	\N	\N
cmprve8l50015jx5qtqhy3p8l	68010	นงลักษณ์	รักชาติ	FEMALE	15	ม.3/5	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-30 04:48:07.673	2026-06-19 05:10:18.539	1234567890017	RESIGNED	2026-06-19 05:10:18.538	2026-06-19 05:10:18.538
cmprve8l5001jjx5qp7ocohgz	68024	สมชาย	มั่งคั่ง	MALE	15	ม.3/5	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-30 04:48:07.673	2026-06-18 07:50:34.014	1234567890031	RESIGNED	2026-06-18 07:50:34.012	2026-06-18 07:50:34.012
cmprve8l50017jx5qc1g3ryzt	68012	กิตติ	ใจดีนะจ๊ะ	MALE	15	ม.3/5	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-30 04:48:07.673	2026-06-18 09:14:40.079	1234567890019	ACTIVE	2026-06-18 09:14:40.078	\N
cmpauvmyx0004jxm5zwck4o1s	22422	อนุทิน	พมต	MALE	8	ม.1/1	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-18 07:01:34.857	2026-06-19 06:08:28.595	2103700000111	RESIGNED	2026-06-19 05:08:23.7	2026-06-19 05:08:23.7
cmprve8l5001mjx5qqybqucjk	68027	ธีรพล	วงษ์ทอง	FEMALE	15	ม.3/5	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-30 04:48:07.673	2026-06-18 08:55:43.043	1234567890034	ACTIVE	2026-06-18 08:55:43.042	\N
cmprve8l5001kjx5qops1z6t7	68025	กิตติ	ใจดี	MALE	16	ม.3/5	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-30 04:48:07.673	2026-06-19 02:40:55.043	1234567890032	ACTIVE	2026-06-19 02:40:55.042	\N
cmprve8l5001djx5q6y4qam8e	68018	นงลักษณ์	ใจดี	MALE	15	ม.3/5	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-30 04:48:07.673	2026-06-19 07:55:58.363	1234567890025	ACTIVE	2026-06-19 07:55:58.362	\N
cmprve8l5001rjx5q3rtia0n1	68032	นงลักษณ์	รักษ์ไทย	FEMALE	15	ม.3/5	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-30 04:48:07.673	2026-05-30 04:48:07.673	1234567890039	ACTIVE	\N	\N
cmpvn6thw002kjxjc9nodq7ko	67001	กิตติพงศ์	ศรีสุข	MALE	14	ม.2/1	cmpmdqjp8000pjxgmt4j3159q	2026-06-01 20:09:29.301	2026-06-01 20:09:29.301	1103701234561	ACTIVE	\N	\N
cmpvn6thw002ljxjch14i18id	67002	ณัฐชา	ทองดี	FEMALE	14	ม.2/1	cmpmdqjp8000pjxgmt4j3159q	2026-06-01 20:09:29.301	2026-06-01 20:09:29.301	1103701234562	ACTIVE	\N	\N
cmpvn6thw002mjxjc949hkrkq	67003	ธีรภัทร	บุญมาก	MALE	14	ม.2/1	cmpmdqjp8000pjxgmt4j3159q	2026-06-01 20:09:29.301	2026-06-01 20:09:29.301	1103701234563	ACTIVE	\N	\N
cmpvn6thw002njxjc3ne9m690	67004	ปวีณา	คำแก้ว	FEMALE	14	ม.2/1	cmpmdqjp8000pjxgmt4j3159q	2026-06-01 20:09:29.301	2026-06-01 20:09:29.301	1103701234564	ACTIVE	\N	\N
cmpvn6thw002ojxjci1w6vzmy	67005	ศุภกร	ใจดี	MALE	14	ม.2/1	cmpmdqjp8000pjxgmt4j3159q	2026-06-01 20:09:29.301	2026-06-01 20:09:29.301	1103701234565	ACTIVE	\N	\N
cmpvn6thw002pjxjcpvv8b9pu	67006	ชลธิชา	วงศ์คำ	FEMALE	14	ม.2/1	cmpmdqjp8000pjxgmt4j3159q	2026-06-01 20:09:29.301	2026-06-01 20:09:29.301	1103701234566	ACTIVE	\N	\N
cmpvn6thw002qjxjc4l7qikrp	67007	พงศธร	สิงห์ทอง	MALE	14	ม.2/1	cmpmdqjp8000pjxgmt4j3159q	2026-06-01 20:09:29.301	2026-06-01 20:09:29.301	1103701234567	ACTIVE	\N	\N
cmpvn6thw002rjxjcyujulgg9	67008	สุภัสสรา	บุญเลิศ	FEMALE	14	ม.2/2	cmpmdqjp8000pjxgmt4j3159q	2026-06-01 20:09:29.301	2026-06-01 20:09:29.301	1103701234568	ACTIVE	\N	\N
cmpvn6thw002sjxjcddl37umd	67009	ธนกฤต	รุ่งเรือง	MALE	14	ม.2/2	cmpmdqjp8000pjxgmt4j3159q	2026-06-01 20:09:29.301	2026-06-01 20:09:29.301	1103701234569	ACTIVE	\N	\N
cmpvn6thx002tjxjck9twdrt3	67010	พิมพ์ชนก	แสงทอง	FEMALE	14	ม.2/2	cmpmdqjp8000pjxgmt4j3159q	2026-06-01 20:09:29.301	2026-06-01 20:09:29.301	1103701234570	ACTIVE	\N	\N
cmpvn6thx002ujxjc5a4bxgmx	67011	วรากร	แก้วมณี	MALE	14	ม.2/2	cmpmdqjp8000pjxgmt4j3159q	2026-06-01 20:09:29.301	2026-06-01 20:09:29.301	1103701234571	ACTIVE	\N	\N
cmpvn6thx002vjxjca96funyx	67012	ศิริพร	บุญช่วย	FEMALE	14	ม.2/2	cmpmdqjp8000pjxgmt4j3159q	2026-06-01 20:09:29.301	2026-06-01 20:09:29.301	1103701234572	ACTIVE	\N	\N
cmpvn6thx002wjxjca9hb7g61	67013	จักรินทร์	มีสุข	MALE	14	ม.2/2	cmpmdqjp8000pjxgmt4j3159q	2026-06-01 20:09:29.301	2026-06-01 20:09:29.301	1103701234573	ACTIVE	\N	\N
cmpvn6thx002xjxjcxmgelrm4	67014	กัญญาภัค	ศรีสวัสดิ์	FEMALE	14	ม.2/2	cmpmdqjp8000pjxgmt4j3159q	2026-06-01 20:09:29.301	2026-06-01 20:09:29.301	1103701234574	ACTIVE	\N	\N
cmqalpi960012jxp5rhx9ouoz	533	มารีแย	ขะเด	FEMALE	14	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1900601257821	ACTIVE	\N	\N
cmqalpi960013jxp5wuog0od9	534	รุสนา	ปียา	FEMALE	17	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1959300074563	ACTIVE	\N	\N
cmqalpi960014jxp5tl5up5la	535	นูรฟาติน	อาบายูโสะ	FEMALE	14	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500332649	ACTIVE	\N	\N
cmqalpi960015jxp5nwmfy5v6	536	ฟัรฮานา	สุหลง	FEMALE	14	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1959901291852	ACTIVE	\N	\N
cmqalpi960016jxp5cra084p3	537	ดัยลามี	ตือบิงหม๊ะ	FEMALE	15	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	2900601036296	ACTIVE	\N	\N
cmqalpi960017jxp50ebbggjc	538	อับดุลกอวีม	เลาะมะอะ	MALE	14	3/1	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1900601260104	ACTIVE	\N	\N
cmqalpi960018jxp5s4s050rb	539	ฟาตีฮะห์	สาและ	FEMALE	14	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1900601259173	ACTIVE	\N	\N
cmqalpi960019jxp5ohtf7mj8	540	อิฮซาน	มะลี	MALE	14	3/1	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500337551	ACTIVE	\N	\N
cmqalpi96001ajxp5uqzy8g52	541	มุซซัมมิล	ตาเละ	MALE	14	3/1	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1959901308887	ACTIVE	\N	\N
cmqalpi96001bjxp51pogwo5i	542	ดานิช	อิสมาแอล	MALE	14	3/1	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500336202	ACTIVE	\N	\N
cmqalpi96001cjxp5trw9j8uz	544	นาเดีย	คาเดร์	FEMALE	14	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500340609	ACTIVE	\N	\N
cmqalpi96001djxp5bi4muyu5	545	ฮาฟิส	สาแมสะอุ	MALE	14	3/1	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500332037	ACTIVE	\N	\N
cmqalpi96001ejxp5tx4hlxw5	546	มูฮัมหมัดฟิตรี	อาบู	MALE	14	3/1	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950700079190	ACTIVE	\N	\N
cmqalpi96001fjxp5lo3nxy35	547	อานัส	ปะแนบูงอ	MALE	14	3/1	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500341036	ACTIVE	\N	\N
cmqalpi96001gjxp54ob73o79	548	นูรุซซาม	จาแน	FEMALE	14	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950700079459	ACTIVE	\N	\N
cmqalpi96001hjxp5d80gmqv6	549	ฟิรดาว	สะนิ	FEMALE	14	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500335788	ACTIVE	\N	\N
cmqalpi96001ijxp509o2ix3a	552	นาซอฟา	สาเหาะ	FEMALE	14	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1900601258517	ACTIVE	\N	\N
cmqalpi96001jjxp55llfe3nd	553	นัสริน	มาลี	FEMALE	14	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500332223	ACTIVE	\N	\N
cmqalpi96001kjxp5tzyt114n	554	อาวาติฟ	ยีดา	FEMALE	14	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500340595	ACTIVE	\N	\N
cmqalpi96001ljxp5lana3l03	557	นูรอิฮซาน	เจ๊ะมะ	FEMALE	14	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1949800259678	ACTIVE	\N	\N
cmqalpi96001mjxp5o6bktrmr	560	ภูบดินทร์	สนิแม	MALE	15	3/1	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500334005	ACTIVE	\N	\N
cmqalpi96001njxp5l2jh7n98	561	ฟิตรี	นุ่นแก้ว	MALE	15	3/1	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500333149	ACTIVE	\N	\N
cmqalpi96001ojxp57y0rd6s1	564	อิฟตีซาน	มะตาหยง	FEMALE	15	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1959901285241	ACTIVE	\N	\N
cmqalpi96001pjxp5l0fi6jmt	566	อับดุลเลาะ	ยูโสะ	MALE	14	3/1	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500338817	ACTIVE	\N	\N
cmqalpi96001qjxp528roaybt	567	นูรรอยยาน	ตีมุง	FEMALE	14	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500337438	ACTIVE	\N	\N
cmqalpi96001rjxp588l8e3vd	575	มูฮัมหมัดฮาฟิส	ระสอปุ	MALE	15	3/1	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1900601251172	ACTIVE	\N	\N
cmqalpi96001sjxp5vwnpfxot	576	นุอันวา	เลาะดีสม	MALE	16	3/1	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1900601246993	ACTIVE	\N	\N
cmqalpi96001tjxp5fdpniekj	577	นุรบัดรียะห์	เลาะดีสม	FEMALE	14	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1900601262476	ACTIVE	\N	\N
cmqalpi96001ujxp5tu4c79kh	578	นัจญวา	ดามัน	FEMALE	15	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500333084	ACTIVE	\N	\N
cmqalpi97001vjxp5sdz06dbq	580	นัสรอน	สนิ	MALE	14	3/1	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1941001474457	ACTIVE	\N	\N
cmqalpi97001wjxp5xshf4tfm	581	มูซัมมีน	สมาเฮาะ	MALE	16	3/1	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1949200068260	ACTIVE	\N	\N
cmqalpi97001xjxp5j5wfn9ue	582	นูรีซัน	คาเดร์	FEMALE	15	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1959901201896	ACTIVE	\N	\N
cmqalpi97001yjxp51saawq2l	583	อัสรี	มาดง	MALE	14	3/1	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500333343	ACTIVE	\N	\N
cmqalpi97001zjxp5qg7w9o1c	584	ซีตีรอกีเย๊าะ	สาแม	FEMALE	15	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500325430	ACTIVE	\N	\N
cmqalpi970020jxp550e0ubo0	585	นูรซีลาวาตี	บาโงสือนอ	FEMALE	14	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1940600152049	ACTIVE	\N	\N
cmqalpi970021jxp56ic9dy79	587	นิอัซวานีย๊ะห์	นิดือมอง	FEMALE	14	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500340625	ACTIVE	\N	\N
cmqalpi970022jxp5miadisl2	588	นูรฮีดายะห์	ลาบูอาปี	FEMALE	14	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500339155	ACTIVE	\N	\N
cmqalpi970023jxp5fpz8b79i	589	อามานี	แดวอสนุง	FEMALE	15	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500336261	ACTIVE	\N	\N
cmqalpi970024jxp54fdsncne	590	นัจละ	มะลี	FEMALE	14	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500334307	ACTIVE	\N	\N
cmqalpi970025jxp5qkdn2a9m	591	อัยเสาะ	แดเบ๊าะ	FEMALE	14	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500335419	ACTIVE	\N	\N
cmqalpi970026jxp588tncp69	592	นูรดา	ยูโซะ	FEMALE	14	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1959901265151	ACTIVE	\N	\N
cmqalpi970027jxp5le03ql4h	598	โสรยา	เต๊ะมอบา	FEMALE	15	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1909803589997	ACTIVE	\N	\N
cmqalpi970028jxp5qipn2get	601	ซีตีอาอีเสาะ	สาโมะ	FEMALE	14	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1940201272211	ACTIVE	\N	\N
cmqalpi970029jxp5r8fs4om9	603	นูรฮีดายะห์	บาโงสะตู	FEMALE	14	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500335001	ACTIVE	\N	\N
cmqalpi97002ajxp55fljalc9	604	ฮาฟีซาตี	อะโกะ	FEMALE	14	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1900601260805	ACTIVE	\N	\N
cmqalpi97002bjxp5rl1agw32	605	อัยดา	ลือแบลูวา	FEMALE	15	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500327696	ACTIVE	\N	\N
cmqalpi97002cjxp5z3aptjb3	626	รอกีเยาะห์	สาและ	FEMALE	14	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1900601259866	ACTIVE	\N	\N
cmqalpi97002djxp56b8fbyjn	631	ฟุรกอน	นิยมเจริญ	MALE	14	3/1	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500337730	ACTIVE	\N	\N
cmqalpi97002ejxp5rxc3b0a5	632	บูคอรี	สือรี	MALE	15	3/1	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500337039	ACTIVE	\N	\N
cmqalpi97002fjxp5l0e2p6zj	633	มุสลิม	หม๊ะอี	MALE	15	3/1	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500336971	ACTIVE	\N	\N
cmqalpi97002gjxp537vrw7ny	636	อาลียัส	ขะหลีดี	MALE	15	3/1	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1900601259335	ACTIVE	\N	\N
cmqalpi97002hjxp5m0gkg78j	637	อัฟนาน	ตาเละ	MALE	14	3/1	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500335010	ACTIVE	\N	\N
cmqalpi97002ijxp5xf6xzhce	639	ซัลวา	บาโงสะตู	FEMALE	14	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500338906	ACTIVE	\N	\N
cmqalpi97002jjxp5lvxpic0x	645	นัสรีน	ปาตง	FEMALE	14	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500340749	ACTIVE	\N	\N
cmqalpi97002kjxp5soq40s2v	648	อาดัม	สะนิ	MALE	14	3/1	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950301270821	ACTIVE	\N	\N
cmqalpi97002ljxp5hhwzyzws	652	ซูฮัยลา	สาและ	FEMALE	14	2/3	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1900601266218	ACTIVE	\N	\N
cmqalpi97002mjxp5omcyzqus	656	อัรวา	กาโฮง	FEMALE	15	2/3	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950301254192	ACTIVE	\N	\N
cmqalpi97002njxp581o7fm27	657	สีตีอาอีเสาะ	เจ๊ะมะ	FEMALE	13	2/3	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500342318	ACTIVE	\N	\N
cmqalpi97002ojxp5z2jqvz3k	658	วีอาร์ม	อาแว	FEMALE	13	2/3	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950301276820	ACTIVE	\N	\N
cmqalpi97002pjxp5i6820dlh	660	นูรฟา	เจ๊ะอุบง	FEMALE	13	2/3	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1959901374472	ACTIVE	\N	\N
cmqalpi97002qjxp5cjavuhl8	667	มาซีละห์	วาเด็ง	FEMALE	13	2/3	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1900601272056	ACTIVE	\N	\N
cmqalpi97002rjxp5oe53oyfe	668	ฟัจรียะห์	บาตูขาเด็ง	FEMALE	13	2/3	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950700084916	ACTIVE	\N	\N
cmqalpi97002sjxp51p4tohag	669	ซารีนา	เหงาะ	FEMALE	14	2/3	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1900601270339	ACTIVE	\N	\N
cmqalpi97002tjxp5ot7zb1bq	671	นูรมาลียานา	เติมตำเดาะ	FEMALE	14	2/3	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1909803783629	ACTIVE	\N	\N
cmqalpi97002ujxp5rvgdha4h	675	มูฮำหมัดอาฟีฟี	มณีหิยา	MALE	13	2/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1940300341253	ACTIVE	\N	\N
cmqalpi97002vjxp592oanqth	678	ฮาฟิต	บาโงสะตู	MALE	13	2/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500350892	ACTIVE	\N	\N
cmqalpi97002wjxp5yfhgkmvu	680	อัสซฮา	นุ่นแก้ว	MALE	14	2/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500345902	ACTIVE	\N	\N
cmqalpi97002xjxp5egkpnxmv	682	ฟุรกอน	มะแอ	MALE	14	2/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1959901333156	ACTIVE	\N	\N
cmqalpi97002yjxp5kwr61ko6	685	บัดรี	จินตรา	FEMALE	13	2/3	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1959901331358	ACTIVE	\N	\N
cmqalpi97002zjxp5i817qxzx	686	บัดรียะห์	จินตรา	FEMALE	13	2/3	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1959901331340	ACTIVE	\N	\N
cmqalpi970030jxp5glg0t3do	691	นูรูลนัจวาร์	จารง	FEMALE	13	2/3	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1959901350778	ACTIVE	\N	\N
cmqalpi970031jxp598n1gxtn	694	ฮูษัยฟ๊ะ	จิ	FEMALE	13	2/3	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950700084878	ACTIVE	\N	\N
cmqalpi970032jxp5p7sear8o	702	นูรมี	ยูโซะ	FEMALE	13	2/3	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950700082026	ACTIVE	\N	\N
cmqalpi970033jxp5s0tln28x	703	อานีส	ดือราฮิง	FEMALE	13	2/3	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1959901374430	ACTIVE	\N	\N
cmqalpi970034jxp51mt5i7yj	708	ชลดา	ดาละ	FEMALE	13	2/3	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500342717	ACTIVE	\N	\N
cmqalpi970035jxp568lschn3	709	นัทการณ์	จั่นเผือก	FEMALE	15	2/3	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1969300094548	ACTIVE	\N	\N
cmqalpi970036jxp5nqcpucqm	710	สุพาณี	สูหลง	FEMALE	14	2/3	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500341231	ACTIVE	\N	\N
cmqalpi970037jxp5tv1t3skz	712	นูรฮาฟีซาน	ยูโซ๊ะ	FEMALE	13	2/3	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500350566	ACTIVE	\N	\N
cmqalpi970038jxp54ol4raxk	713	รุสลาน	ติโย	MALE	14	2/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500349185	ACTIVE	\N	\N
cmqalpi980039jxp5m07n54q4	716	นิฮานีซา	หะยีดอเลาะ	FEMALE	13	2/3	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950700082891	ACTIVE	\N	\N
cmqalpi98003ajxp50mzuheex	717	ซากีนะ	มะอีซอ	FEMALE	13	2/3	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1900601266161	ACTIVE	\N	\N
cmqalpi98003bjxp5juah0t8r	727	ฟิรดาวส์	อูเซ็ง	FEMALE	13	2/3	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950700084118	ACTIVE	\N	\N
cmqalpi98003cjxp5qjgexcqv	728	นัสริน	สอละซอ	FEMALE	14	2/3	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500339295	ACTIVE	\N	\N
cmqalpi98003djxp5q66ktksr	730	มูฮัมหมัดชารีฟ	ลาเต๊ะ	MALE	13	2/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950301275505	ACTIVE	\N	\N
cmqalpi98003ejxp51tbimguj	735	อามานี	ซาการี	FEMALE	14	2/3	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950700080058	ACTIVE	\N	\N
cmqalpi98003fjxp5cttap7kg	738	อาฟาฟ	ดอเลาะ	FEMALE	14	2/3	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950700084509	ACTIVE	\N	\N
cmqalpi98003gjxp557e7wlie	740	ซาวาตี	มะมูสอ	FEMALE	13	2/3	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1900601270487	ACTIVE	\N	\N
cmqalpi98003hjxp5lfvhux50	745	มุสลีฮะห์	แวมิง	FEMALE	13	2/3	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1959901355630	ACTIVE	\N	\N
cmqalpi98003ijxp5k1uwndsd	752	นูรฮายาตี	ยะโกะ	FEMALE	14	2/3	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1908500004142	ACTIVE	\N	\N
cmqalpi98003jjxp5zbw16fo4	753	นูรฮาฟีกะห์	บือเฮง	FEMALE	14	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500335371	ACTIVE	\N	\N
cmqalpi98003kjxp5xicb7mfw	754	นูรนัสลิน	บรรดา	FEMALE	14	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500332584	ACTIVE	\N	\N
cmqalpi98003ljxp5s5sb19tr	757	ซาลาฮูดิน	กาเน๊ะ	MALE	14	3/1	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500334790	ACTIVE	\N	\N
cmqalpi98003mjxp5wd31a19h	758	อิลฮัม	บาสอ	MALE	15	3/1	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500331154	ACTIVE	\N	\N
cmqalpi98003njxp5d5xli0u8	772	ฮาซัน	ยูโซ๊ะ	MALE	14	2/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500346798	ACTIVE	\N	\N
cmqalpi98003ojxp50yew7145	773	ซูฟียะห์	นากอหม๊ะ	FEMALE	13	2/3	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500349061	ACTIVE	\N	\N
cmqalpi98003pjxp5wlyaqmir	782	ซูไรยา	ยานยา	FEMALE	13	2/3	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950700084096	ACTIVE	\N	\N
cmqalpi98003qjxp5u7nbs1ow	785	นุรมี	แมเราะ	FEMALE	13	2/3	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1959901366917	ACTIVE	\N	\N
cmqalpi98003rjxp5ba48e688	792	อัสม๊ะ	จิ	FEMALE	14	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950700078606	ACTIVE	\N	\N
cmqalpi98003sjxp5mamtm52a	822	ซูลฟา	ปาแนจะกะ	FEMALE	14	3/2	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500336318	ACTIVE	\N	\N
cmqalpi98003tjxp5mlq4tasj	915	นิสุไลมาน	บากา	MALE	14	3/1	cmq0khbql000ujx237a6k27or	2026-06-12 07:24:34.6	2026-06-12 07:24:34.6	1950500340994	ACTIVE	\N	\N
cmqcf7l3t00djjxp5hga3flde	08812	มุขทิตา	แซ่หลอ	FEMALE	10	ป.5/1	cmq0kjbpl0019jx236ppwjdv2	2026-06-13 13:58:13.145	2026-06-13 13:58:13.145	1420501279339	ACTIVE	\N	\N
cmqcf7l3t00dkjxp5b81qqau5	08817	นิตยา	แซ่ว่าง	FEMALE	10	ป.5/1	cmq0kjbpl0019jx236ppwjdv2	2026-06-13 13:58:13.145	2026-06-13 13:58:13.145	1420501276631	ACTIVE	\N	\N
cmqep6t7x00erjxp54fnk3xqy	694428	กฤตเมธ	เวียงอินทร์	MALE	13	ม.2/1	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900893975	ACTIVE	\N	\N
cmqep6t7x00esjxp5cbdmqqex	694429	เกรียงชัย	ผึ่งผาย	MALE	13	ม.2/1	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900893886	ACTIVE	\N	\N
cmqep6t7x00etjxp5oklc37y3	694430	เกียรติคุณ	เงินคุณด้วง	MALE	13	ม.2/1	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900860040	ACTIVE	\N	\N
cmqep6t7x00eujxp5wceys9yo	694431	ทักษ์ดนัย	จันทร์เทียน	MALE	13	ม.2/1	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900898772	ACTIVE	\N	\N
cmqep6t7x00evjxp5vhoesa20	694432	ธนโชติ	แสงคำ	MALE	13	ม.2/1	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900887860	ACTIVE	\N	\N
cmqep6t7x00ewjxp58q8ujqlw	694433	พชร	ยลเมืองแมน	MALE	14	ม.2/1	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900877015	ACTIVE	\N	\N
cmqep6t7x00exjxp5g48uiw9v	694434	ยศภัทร	สูนปั้ง	MALE	13	ม.2/1	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900871700	ACTIVE	\N	\N
cmqep6t7x00eyjxp55zwq78jl	694435	วศินรวิพล	แจ้งธรรมมา	MALE	14	ม.2/1	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900852551	ACTIVE	\N	\N
cmqep6t7x00ezjxp5vlltxpho	694436	อัครวัฒน์	มีแสงสิน	MALE	13	ม.2/1	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900883597	ACTIVE	\N	\N
cmqep6t7x00f0jxp5gvfwi04n	694550	ทินภัทร	ชาญยุทธ	MALE	13	ม.2/1	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900866731	ACTIVE	\N	\N
cmqep6t7x00f1jxp5twcea6w7	694437	จริญญา	เกยเลื่อน	MALE	13	ม.2/1	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900885441	ACTIVE	\N	\N
cmqep6t7x00f2jxp5sh03nooy	694439	ณัฐฉรียา	นาควันดี	FEMALE	13	ม.2/1	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900877261	ACTIVE	\N	\N
cmqep6t7x00f3jxp5synf5gsg	694440	ณัฐณิชา	เศรษฐี	FEMALE	13	ม.2/1	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900888301	ACTIVE	\N	\N
cmqep6t7x00f4jxp5ifdridnj	694441	นันท์นภัส	คงจีน	FEMALE	13	ม.2/1	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900877490	ACTIVE	\N	\N
cmqep6t7x00f5jxp5kn6gv1ni	694442	ปริยฉัตร	อ่ำศรีเวียง	FEMALE	13	ม.2/1	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1103800051807	ACTIVE	\N	\N
cmqep6t7x00f6jxp5ryay9b35	694443	พิมพ์ชนก	บุตตะเกิง	FEMALE	13	ม.2/1	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900876698	ACTIVE	\N	\N
cmqep6t7x00f7jxp5l3oii2qb	694445	ภาสินี	เจริญศิลป์	FEMALE	14	ม.2/1	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900874059	ACTIVE	\N	\N
cmqep6t7x00f8jxp55qj3x2vc	694446	ศานต์ฤทัย	แสนกาสา	FEMALE	13	ม.2/1	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900883724	ACTIVE	\N	\N
cmqep6t7x00f9jxp5wi3o0rdy	694447	อัฉราพร	สมบูรณ์	FEMALE	14	ม.2/1	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900892367	ACTIVE	\N	\N
cmqep6t7x00fajxp59dpeqyun	694448	อารียา	ศิริประเสริฐ	FEMALE	13	ม.2/1	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900893096	ACTIVE	\N	\N
cmqep6t7x00fbjxp5c1fz5ppe	694449	ไอศิกา	สายแก้ว	FEMALE	13	ม.2/1	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1670401316672	ACTIVE	\N	\N
cmqep6t7x00fcjxp5slrtarvk	694617	ชรินธร	บุญแท่ง	FEMALE	13	ม.2/1	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1209601793841	ACTIVE	\N	\N
cmqep6t7x00fdjxp5phrwrenn	694618	ธาราทิพย์	แก้วดวง	FEMALE	13	ม.2/1	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900901226	ACTIVE	\N	\N
cmqep6t7x00fejxp5o7dl7di4	694452	กิตติ	ส่านสม	MALE	14	ม.2/2	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900867818	ACTIVE	\N	\N
cmqep6t7x00ffjxp5qxsn29jv	694454	ฉัตรชานนท์	บุญเม่น	MALE	13	ม.2/2	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900865386	ACTIVE	\N	\N
cmqep6t7x00fgjxp5q4q2sqhp	694455	โชติยะ	โพธิ์ปลัด	MALE	14	ม.2/2	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900867419	ACTIVE	\N	\N
cmqep6t7x00fhjxp5fpnrj4l7	694456	ฐานวัฒน์	ฐิติบุญญนันท์	MALE	13	ม.2/2	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1102004465651	ACTIVE	\N	\N
cmqep6t7x00fijxp5jyyrjuz8	694457	ณัฐชณณ	ตรีเวส	MALE	13	ม.2/2	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900888645	ACTIVE	\N	\N
cmqep6t7x00fjjxp51to2rjq7	694459	ธนปพล	ตรีกุย	MALE	13	ม.2/2	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900884666	ACTIVE	\N	\N
cmqep6t7x00fkjxp5dokcsihq	694460	นิชนันท์	ทัดช่อม่วง	MALE	13	ม.2/2	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900888891	ACTIVE	\N	\N
cmqep6t7x00fljxp5cyty19cb	694461	พงศกร	สิงห์เปี่ยม	MALE	14	ม.2/2	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679800845230	ACTIVE	\N	\N
cmqep6t7x00fmjxp5sc7vd876	694462	พัทธนน	สีงาม	MALE	13	ม.2/2	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900894211	ACTIVE	\N	\N
cmqep6t7x00fnjxp5bqhzrp6l	694463	ภูริณัฐ	บุญมา	MALE	14	ม.2/2	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1100704333977	ACTIVE	\N	\N
cmqep6t7x00fojxp52gwrmqld	694464	มังกร	อยู่บุรี	MALE	13	ม.2/2	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900898497	ACTIVE	\N	\N
cmqep6t7x00fpjxp5afe8hyp4	694465	วงศ์วุฒิ	แสงภู	MALE	13	ม.2/2	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1200901676817	ACTIVE	\N	\N
cmqep6t7x00fqjxp5np9idghm	694466	วีร์ชาพิภัทร	เนตรภู่	MALE	14	ม.2/2	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900845695	ACTIVE	\N	\N
cmqep6t7x00frjxp5y0vdu581	694467	ศิริวิวัฒน์	ช้อนงาม	MALE	13	ม.2/2	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900886375	ACTIVE	\N	\N
cmqep6t7x00fsjxp5s3lf3hkn	694468	อภิวันท์	บัวคำ	MALE	13	ม.2/2	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900881284	ACTIVE	\N	\N
cmqep6t7x00ftjxp5qcd2510h	694619	จิรชาติ	กุลวงศ์	MALE	14	ม.2/2	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1218800067391	ACTIVE	\N	\N
cmqep6t7x00fujxp5lzrwcrc9	694620	ไรวินท์	คำเบาะ	MALE	14	ม.2/2	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900872421	ACTIVE	\N	\N
cmqep6t7x00fvjxp5jwtduygo	694469	กวินธิดา	แน่นอุดร	FEMALE	13	ม.2/2	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900868644	ACTIVE	\N	\N
cmqep6t7x00fwjxp5he7659eh	694470	กันยารัตน์	ยังเรือง	FEMALE	13	ม.2/2	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900889960	ACTIVE	\N	\N
cmqep6t7x00fxjxp5n1r9qyq3	694471	เขมิกา	มาแก้ว	FEMALE	13	ม.2/2	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900887576	ACTIVE	\N	\N
cmqep6t7x00fyjxp5gd0tiz6q	694472	จรรยพร	บุญทรา	FEMALE	13	ม.2/2	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1100704410076	ACTIVE	\N	\N
cmqep6t7x00fzjxp54fjcjtah	694473	ชัญญานุช	จวงแย้ม	FEMALE	13	ม.2/2	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900896711	ACTIVE	\N	\N
cmqep6t7x00g0jxp5x3rr3z29	694475	เบญญา	ช่วยปุ่น	FEMALE	13	ม.2/2	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900890755	ACTIVE	\N	\N
cmqep6t7x00g1jxp5xksr1is3	694477	ศรีสุดา	บุตราช	FEMALE	14	ม.2/2	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1100801729545	ACTIVE	\N	\N
cmqep6t7x00g2jxp55u0n4faa	694478	ศิริกัญญา	ก้อนทอง	FEMALE	13	ม.2/2	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900877520	ACTIVE	\N	\N
cmqep6t7y00g3jxp5y3q080vj	694480	สุพิชญา	ศรศิลป์	FEMALE	13	ม.2/2	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900876655	ACTIVE	\N	\N
cmqep6t7y00g4jxp56txcwtrq	694552	ปิยาอร	จันทร์คำ	FEMALE	13	ม.2/2	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1134600628861	ACTIVE	\N	\N
cmqep6t7y00g5jxp53scmw13t	694554	พิชามญชุ์	ค้าเจริญ	FEMALE	14	ม.2/2	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900865262	ACTIVE	\N	\N
cmqep6t7y00g6jxp5voah6fkg	694621	นารีรัตน์	ปกสันเทียะ	FEMALE	13	ม.2/2	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900872951	ACTIVE	\N	\N
cmqep6t7y00g7jxp5dadbmh4c	694242	กอร์ดอน	ฮัทตัน  ริตชี่	MALE	14	ม.3/3	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1209601753415	ACTIVE	\N	\N
cmqep6t7y00g8jxp5e5io1j25	694256	จักรี	บุญเลิศ	MALE	14	ม.3/3	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900769654	ACTIVE	\N	\N
cmqep6t7y00g9jxp5yihqococ	694273	ณัฐธวัช	สุขเอม	MALE	14	ม.3/3	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1139600633930	ACTIVE	\N	\N
cmqep6t7y00gajxp56csicf0x	694275	ณัฐวัฒน์	บุญมาก	MALE	14	ม.3/3	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900862221	ACTIVE	\N	\N
cmqep6t7y00gbjxp5vsmxgz5z	694337	ฤทธิชัย	ไร่เจริญ	MALE	14	ม.3/3	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1368900065667	ACTIVE	\N	\N
cmqep6t7y00gcjxp545zm4dej	694339	วัชรวิทย์	พลอยสีสังข์	MALE	14	ม.3/3	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900841754	ACTIVE	\N	\N
cmqep6t7y00gdjxp59lrmb5t2	694348	ศุภกรณ์	ไศลบาท	MALE	14	ม.3/3	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900858258	ACTIVE	\N	\N
cmqep6t7y00gejxp5hwiyumv6	694353	อชิระ	โชติจิตร	MALE	14	ม.3/3	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1469000090517	ACTIVE	\N	\N
cmqep6t7y00gfjxp567zr1gct	694379	สิทธิโชค	รัตนสุทธิ	MALE	15	ม.3/3	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1100202074428	ACTIVE	\N	\N
cmqep6t7y00ggjxp5lamjmi4s	694632	บูรพา	คล้ายละมั่ง	MALE	15	ม.3/3	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1678600053261	ACTIVE	\N	\N
cmqep6t7y00ghjxp58tgg12zq	694244	กัญญาณัฐ	แสนแก้ว	FEMALE	14	ม.3/3	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900858797	ACTIVE	\N	\N
cmqep6t7y00gijxp5hs7idnt2	694267	ฑิฆัมพร	ศรีบรรเทา	FEMALE	14	ม.3/3	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900856638	ACTIVE	\N	\N
cmqep6t7y00gjjxp59b9xkcrz	694272	ณัฐทิตา	เฟิลค์	FEMALE	15	ม.3/3	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900832488	ACTIVE	\N	\N
cmqep6t7y00gkjxp5h4f0156z	694274	ณัฐธิวา	แก้วกิ่งจันทร์	FEMALE	14	ม.3/3	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900856531	ACTIVE	\N	\N
cmqep6t7y00gljxp5et9f6y0c	694277	ณิชาพร	ตู้นก	FEMALE	14	ม.3/3	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900844605	ACTIVE	\N	\N
cmqep6t7y00gmjxp5w0cyfz8a	694318	พิมพ์ชนก	สีดาทอง	FEMALE	14	ม.3/3	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1670201331015	ACTIVE	\N	\N
cmqep6t7y00gnjxp50tru9y0t	694324	ภรภัทร	สำรีย์	FEMALE	14	ม.3/3	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900853060	ACTIVE	\N	\N
cmqep6t7y00gojxp5v1t19fiv	694328	ภัสกมล	จันทรา	FEMALE	14	ม.3/3	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900846764	ACTIVE	\N	\N
cmqep6t7y00gpjxp5s7zduyel	694334	รวิสรา	ค่ายแก้ว	FEMALE	14	ม.3/3	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1380500004485	ACTIVE	\N	\N
cmqep6t7y00gqjxp5i3yv7iln	694340	วรรณษา	ทองโต	FEMALE	14	ม.3/3	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900853167	ACTIVE	\N	\N
cmqep6t7y00grjxp5xaus94pp	694380	ฐานิตา	จำเดิม	FEMALE	14	ม.3/3	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900840626	ACTIVE	\N	\N
cmqep6t7y00gsjxp5mtilww6e	694408	มุฑิตา	แซ่ลิ้ม	FEMALE	14	ม.3/3	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900831546	ACTIVE	\N	\N
cmqep6t7y00gtjxp5zntc9qfk	694240	กฤตพรต	สุวรรณการ	MALE	15	ม.3/4	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900837552	ACTIVE	\N	\N
cmqep6t7y00gujxp58nym0q6l	694245	กันตพงศ์	คำหงษา	MALE	15	ม.3/4	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900863715	ACTIVE	\N	\N
cmqep6t7y00gvjxp59jqt3gqm	694249	กันตินันท์	เล็กมณี	MALE	15	ม.3/4	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900850273	ACTIVE	\N	\N
cmqep6t7y00gwjxp50vs32gfn	694259	เจษฎา	ผดุงโดเมตร	MALE	15	ม.3/4	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900862352	ACTIVE	\N	\N
cmqep6t7y00gxjxp5o36ncraj	694261	ชัยวัฒน์	เติมพรมราช	MALE	15	ม.3/4	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900832054	ACTIVE	\N	\N
cmqep6t7y00gyjxp50orak3f8	694262	ชาญศักดิ์	อินเลี้ยง	MALE	15	ม.3/4	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900847647	ACTIVE	\N	\N
cmqep6t7y00gzjxp5ymu2sdwq	694278	ดนัยกร	ทองผา	MALE	15	ม.3/4	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1110301528117	ACTIVE	\N	\N
cmqep6t7y00h0jxp5b6k9d2ql	694279	ต้นน้ำ	มะลิวัลย์	MALE	15	ม.3/4	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900844109	ACTIVE	\N	\N
cmqep6t7y00h1jxp5kcbzvnst	694286	ธนพร	บัวทอง	MALE	15	ม.3/4	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900862379	ACTIVE	\N	\N
cmqep6t7y00h2jxp5gb0okmzi	694287	ธนพล	เพชรตาด	MALE	15	ม.3/4	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900859807	ACTIVE	\N	\N
cmqep6t7y00h3jxp5nsmq0bu1	694290	ธนวินท์	บริบูรณ์	MALE	15	ม.3/4	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900833166	ACTIVE	\N	\N
cmqep6t7y00h4jxp5jet4udax	694299	ธีรภัทร	ตะกรุดเก่า	MALE	15	ม.3/4	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900854139	ACTIVE	\N	\N
cmqep6t7y00h5jxp53x65440u	694317	พิชญางกูร	ปลัดท้วม	MALE	15	ม.3/4	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900836467	ACTIVE	\N	\N
cmqep6t7y00h6jxp5lq2ohp8z	694338	ลิขสิทธิ	โคตรนารถ	MALE	15	ม.3/4	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900859343	ACTIVE	\N	\N
cmqep6t7y00h7jxp5aomv3xif	694349	ศุภโชติ	อุตแก้ว	MALE	14	ม.3/4	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900842866	ACTIVE	\N	\N
cmqep6t7y00h8jxp5zbds7y6i	694383	ชัยพัฒน์	ธิราช	MALE	14	ม.3/4	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1670401308751	ACTIVE	\N	\N
cmqep6t7y00h9jxp5ov6rpkzw	694384	พัทธดนย์	บริสุทธิ์เพ็ชร	MALE	14	ม.3/4	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900851245	ACTIVE	\N	\N
cmqep6t7y00hajxp53xjfiwp0	694409	ธนพล	จันทร	MALE	16	ม.3/4	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900809265	ACTIVE	\N	\N
cmqep6t7y00hbjxp5na2uvdzn	694425	ธนพล	คำพิรานนท์	MALE	15	ม.3/4	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1103400223058	ACTIVE	\N	\N
cmqep6t7y00hcjxp5o0okg8br	694247	กัลยาณี	งามแม้น	FEMALE	15	ม.3/4	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1100401564590	ACTIVE	\N	\N
cmqep6t7y00hdjxp51yn11mxr	694264	ญาดา	พันให้อุ่น	FEMALE	14	ม.3/4	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900844052	ACTIVE	\N	\N
cmqep6t7y00hejxp5jx21o02o	694265	ฐิตาภา	เสือสอาด	FEMALE	15	ม.3/4	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900872447	ACTIVE	\N	\N
cmqep6t7y00hfjxp5s0yrlw9n	694302	นภัสสร	อ่อนคำ	FEMALE	15	ม.3/4	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900827077	ACTIVE	\N	\N
cmqep6t7y00hgjxp51uc3pwty	694336	รุ้งรดา	นกน้อย	FEMALE	15	ม.3/4	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900829878	ACTIVE	\N	\N
cmqep6t7y00hhjxp595rvk6sq	694354	อภิญญา	จ้อยจำปา	FEMALE	14	ม.3/4	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900834227	ACTIVE	\N	\N
cmqep6t7y00hijxp5mgitskzp	694386	ณัฐณิชา	แพรศรี	FEMALE	14	ม.3/4	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1409904059416	ACTIVE	\N	\N
cmqep6t7y00hjjxp5xa6i02q3	694410	ขวัญฤทัย	คำเผี่ยน	FEMALE	14	ม.3/4	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900852403	ACTIVE	\N	\N
cmqep6t7y00hkjxp50bymz2pu	694411	อริสา	แดงจัด	FEMALE	14	ม.3/4	cmq0kjrxw001ejx23detqolsk	2026-06-15 04:13:05.516	2026-06-15 04:13:05.516	1679900848007	ACTIVE	\N	\N
cmqexodd500twjxp5ozjix5p3	462	หัฟเซาะห์	ดอเลาะแม	FEMALE	15	4/2	cmq0khbql000ujx237a6k27or	2026-06-15 08:10:41.705	2026-06-15 08:10:41.705	1950500323682	ACTIVE	\N	\N
cmqexodd500txjxp59nr26qu8	463	นูรฮาฟีซาร์	เจะมะ	FEMALE	16	4/2	cmq0khbql000ujx237a6k27or	2026-06-15 08:10:41.705	2026-06-15 08:10:41.705	1950500321248	ACTIVE	\N	\N
cmqexodd500tyjxp5spf0vt4l	466	ซอลีฮะห์	ซาราเซะ	FEMALE	15	4/2	cmq0khbql000ujx237a6k27or	2026-06-15 08:10:41.705	2026-06-15 08:10:41.705	1950500324760	ACTIVE	\N	\N
cmqexodd500tzjxp5ey8cx4bn	467	นุรยุสมี	มะหร๊ะ	FEMALE	15	4/2	cmq0khbql000ujx237a6k27or	2026-06-15 08:10:41.705	2026-06-15 08:10:41.705	1950500321833	ACTIVE	\N	\N
cmqexodd500u0jxp5cnf5d5h9	468	ฟิตรี	มามะยะอิง	FEMALE	15	4/2	cmq0khbql000ujx237a6k27or	2026-06-15 08:10:41.705	2026-06-15 08:10:41.705	1950500323704	ACTIVE	\N	\N
cmqexodd500u1jxp5fygnoo9b	470	ฮานีซา	ปะดอ	FEMALE	17	4/2	cmq0khbql000ujx237a6k27or	2026-06-15 08:10:41.705	2026-06-15 08:10:41.705	1950500302766	ACTIVE	\N	\N
cmqexodd500u2jxp5vou9mtno	474	ฮาลีซา	วาเด็ง	FEMALE	15	4/2	cmq0khbql000ujx237a6k27or	2026-06-15 08:10:41.705	2026-06-15 08:10:41.705	1959901237831	ACTIVE	\N	\N
cmqexodd500u3jxp5o7xdka1n	475	การ์ตีนี	บาโงสะตา	FEMALE	15	4/2	cmq0khbql000ujx237a6k27or	2026-06-15 08:10:41.705	2026-06-15 08:10:41.705	1950500325626	ACTIVE	\N	\N
cmqexodd600u4jxp5hx4r479y	479	นาปีสะ	มะอีซอ	FEMALE	15	4/2	cmq0khbql000ujx237a6k27or	2026-06-15 08:10:41.705	2026-06-15 08:10:41.705	1950700075372	ACTIVE	\N	\N
cmqexodd600u5jxp5ysyqeaup	482	รูฮานี	ดอคอ	FEMALE	15	4/2	cmq0khbql000ujx237a6k27or	2026-06-15 08:10:41.705	2026-06-15 08:10:41.705	1959901201047	ACTIVE	\N	\N
cmqexodd600u6jxp59vhjqfw0	483	ฟาตอนะห์	สะอุ	FEMALE	15	4/2	cmq0khbql000ujx237a6k27or	2026-06-15 08:10:41.705	2026-06-15 08:10:41.705	1950500326070	ACTIVE	\N	\N
cmqexodd600u7jxp5jyyu6ovh	486	ต่วนอัสลีนา	สาและ	FEMALE	15	4/2	cmq0khbql000ujx237a6k27or	2026-06-15 08:10:41.705	2026-06-15 08:10:41.705	1959901209471	ACTIVE	\N	\N
cmqexodd600u8jxp5tc7jlxnf	487	ตอยยีบะห์	มามะยะอิง	FEMALE	15	4/2	cmq0khbql000ujx237a6k27or	2026-06-15 08:10:41.705	2026-06-15 08:10:41.705	1950500324867	ACTIVE	\N	\N
cmqexodd600u9jxp5gg5gxyhi	490	อัฟนาน	เลาะราแม	FEMALE	16	4/2	cmq0khbql000ujx237a6k27or	2026-06-15 08:10:41.705	2026-06-15 08:10:41.705	1950500321060	ACTIVE	\N	\N
cmqexodd600uajxp5lqdb8aor	502	นุรฮาซูรา	มามะ	FEMALE	15	4/2	cmq0khbql000ujx237a6k27or	2026-06-15 08:10:41.705	2026-06-15 08:10:41.705	1950500328811	ACTIVE	\N	\N
cmqexodd600ubjxp5392pe7yt	506	นูรฮายาตี	แวหะมะ	FEMALE	15	4/2	cmq0khbql000ujx237a6k27or	2026-06-15 08:10:41.705	2026-06-15 08:10:41.705	1950500330867	ACTIVE	\N	\N
cmqexodd600ucjxp5yylkny0y	511	อิฟตีหย๊ะ	อาบูถัดสา	FEMALE	17	4/2	cmq0khbql000ujx237a6k27or	2026-06-15 08:10:41.705	2026-06-15 08:10:41.705	1809902557211	ACTIVE	\N	\N
cmqexodd600udjxp5yyr5mjxs	649	ซูไรดา สาและ	สาและ	FEMALE	15	4/2	cmq0khbql000ujx237a6k27or	2026-06-15 08:10:41.705	2026-06-15 08:10:41.705	1949900783018	ACTIVE	\N	\N
cmqexodd600uejxp5pmwcsj0o	799	อามานี	ลูโบะยาเซ็ง	FEMALE	16	4/2	cmq0khbql000ujx237a6k27or	2026-06-15 08:10:41.705	2026-06-15 08:10:41.705	1950500316309	ACTIVE	\N	\N
cmqexodd600ufjxp5lg8ivxwe	800	รอกีเย๊าะ	สะอะ	FEMALE	16	4/2	cmq0khbql000ujx237a6k27or	2026-06-15 08:10:41.705	2026-06-15 08:10:41.705	1959901187389	ACTIVE	\N	\N
cmqexodd600ugjxp53cp800t1	801	นุสเร๊าะห์	ราโมง	FEMALE	15	4/2	cmq0khbql000ujx237a6k27or	2026-06-15 08:10:41.705	2026-06-15 08:10:41.705	1950500327548	ACTIVE	\N	\N
cmqexodd600uhjxp5exu9cft6	802	นุรนาอีม	ลาเต๊ะ	FEMALE	15	4/2	cmq0khbql000ujx237a6k27or	2026-06-15 08:10:41.705	2026-06-15 08:10:41.705	1950500328684	ACTIVE	\N	\N
cmqexodd600uijxp5pim3mba1	803	นูรฮาซีกีน	เเหละดำ	FEMALE	16	4/2	cmq0khbql000ujx237a6k27or	2026-06-15 08:10:41.705	2026-06-15 08:10:41.705	1950500317933	ACTIVE	\N	\N
cmqexodd600ujjxp55j4o61zk	806	นูรฮายาตี	เราะแตวา	FEMALE	15	4/2	cmq0khbql000ujx237a6k27or	2026-06-15 08:10:41.705	2026-06-15 08:10:41.705	1950301256462	ACTIVE	\N	\N
cmqexodd600ukjxp5yi3vryh4	814	นูรฮูดา	จินตรา	FEMALE	15	4/2	cmq0khbql000ujx237a6k27or	2026-06-15 08:10:41.705	2026-06-15 08:10:41.705	1959901215650	ACTIVE	\N	\N
cmqexodd600uljxp5g5aiustd	815	นูรอาฟา	ลือแบลูวง	FEMALE	15	4/2	cmq0khbql000ujx237a6k27or	2026-06-15 08:10:41.705	2026-06-15 08:10:41.705	1959901248400	ACTIVE	\N	\N
cmqexodd600umjxp5dlcm8f78	900	อัซรีนา	มาหิเละ	FEMALE	15	4/2	cmq0khbql000ujx237a6k27or	2026-06-15 08:10:41.705	2026-06-15 08:10:41.705	1950500329095	ACTIVE	\N	\N
cmqexodd600unjxp54ae6qmd2	906	นูรีซัน	สะตือบา	FEMALE	16	4/2	cmq0khbql000ujx237a6k27or	2026-06-15 08:10:41.705	2026-06-15 08:10:41.705	1959901175348	ACTIVE	\N	\N
cmqexodd600uojxp55el16rgl	910	มุมีนะห์	บาราเฮ็ง	FEMALE	15	4/2	cmq0khbql000ujx237a6k27or	2026-06-15 08:10:41.705	2026-06-15 08:10:41.705	1950500326657	ACTIVE	\N	\N
cmqexodd600upjxp5l09vyjzr	919	อัสมะ	เเดเบ๊าะ	FEMALE	15	4/2	cmq0khbql000ujx237a6k27or	2026-06-15 08:10:41.705	2026-06-15 08:10:41.705	1940201263386	ACTIVE	\N	\N
cmqf02twi005vjxoph6si1y7m	694311	พงศภัค	อินทร์ช่วย	MALE	14	ม.3/3	cmq0kjrxw001ejx23detqolsk	2026-06-15 09:17:55.554	2026-06-15 09:17:55.554	1679900855089	ACTIVE	\N	\N
cmqf02twi005wjxop1suc7kpd	694332	ยิ่งศัก	ศรีศิริ	MALE	15	ม.3/3	cmq0kjrxw001ejx23detqolsk	2026-06-15 09:17:55.554	2026-06-15 09:17:55.554	1679900844290	ACTIVE	\N	\N
cmqf02twi005xjxop9todeqnc	694444	กฤษดา	แก้วกก	MALE	14	ม.2/3	cmq0kjrxw001ejx23detqolsk	2026-06-15 09:17:55.554	2026-06-15 09:17:55.554	1679900874946	ACTIVE	\N	\N
cmqf02twi005yjxopdari537w	694482	ณเดช	สำลีดี	MALE	14	ม.2/3	cmq0kjrxw001ejx23detqolsk	2026-06-15 09:17:55.554	2026-06-15 09:17:55.554	1679900853531	ACTIVE	\N	\N
cmqf02twi005zjxop5kafgs6v	694484	ณัฐวัฒน์	หอมขจร	MALE	14	ม.2/3	cmq0kjrxw001ejx23detqolsk	2026-06-15 09:17:55.554	2026-06-15 09:17:55.554	1679900895722	ACTIVE	\N	\N
cmqf02twi0060jxopbq0u963r	694485	ณัฐสิทธิ์	ภักดีจิตร	MALE	14	ม.2/3	cmq0kjrxw001ejx23detqolsk	2026-06-15 09:17:55.554	2026-06-15 09:17:55.554	1679900895153	ACTIVE	\N	\N
cmqf02twi0061jxopfw2ixih5	694487	ธนกร	หลูสุริยา	MALE	14	ม.2/3	cmq0kjrxw001ejx23detqolsk	2026-06-15 09:17:55.554	2026-06-15 09:17:55.554	1669800435886	ACTIVE	\N	\N
cmqf02twi0062jxop3z5jrxny	694489	ธนภัทร	คงเจริญ	MALE	14	ม.2/3	cmq0kjrxw001ejx23detqolsk	2026-06-15 09:17:55.554	2026-06-15 09:17:55.554	1679900882621	ACTIVE	\N	\N
cmqf02twi0063jxopuqpquhah	694490	ธีรพล	ปิ่นนาง	MALE	14	ม.2/3	cmq0kjrxw001ejx23detqolsk	2026-06-15 09:17:55.554	2026-06-15 09:17:55.554	1679900893703	ACTIVE	\N	\N
cmqgdycn8001djxy9h4tbxdxf	477	ราเชนทร์	ชัยชนะ	MALE	15	4/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1102004211129	ACTIVE	\N	\N
cmqgdycn8001ejxy9exoa7t0x	760	อารีฟีน	มะหะจิ	MALE	16	4/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1950500325481	ACTIVE	\N	\N
cmqgdycn8001fjxy9zly679kv	640	ซุลกิฟลี	ปูตะ	MALE	17	4/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1950700069844	ACTIVE	\N	\N
cmqgdycn9001gjxy9v9cuoe6b	485	อาริฟ	มานะ	MALE	15	4/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1959901230136	ACTIVE	\N	\N
cmqgdycn9001hjxy9i3kg026e	489	อับดุลมาลิค	หามะ	MALE	15	4/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1940900427337	ACTIVE	\N	\N
cmqgdycn9001ijxy9iunp2rcp	464	นิอัฟฟาน	กามา	MALE	16	4/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1900501225277	ACTIVE	\N	\N
cmqgdycn9001jjxy9tj4en4n8	508	อับดุลมูฮันมีน	วาโด	MALE	15	4/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1950800065051	ACTIVE	\N	\N
cmqgdycn9001kjxy99e4tek05	465	นิอาลีฟ	ยาโงะ	MALE	16	4/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1959901213002	ACTIVE	\N	\N
cmqgdycn9001ljxy9jyeqjz4b	788	อันนูวา	สะดี	MALE	16	4/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1950500322881	ACTIVE	\N	\N
cmqgdycn9001mjxy9ljnm3a73	498	ซูไฮลี	กือลือเเม	MALE	16	4/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1959901185581	ACTIVE	\N	\N
cmqgdycn9001njxy9an6nlwry	492	ซัยยูตี	ปูเต๊ะ	MALE	15	4/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1950500324859	ACTIVE	\N	\N
cmqgdycn9001ojxy9g54zqow0	641	นีรุส	สาแหละ	MALE	15	4/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1950500324646	ACTIVE	\N	\N
cmqgdycn9001pjxy9gc0vlc18	756	ลุกมาน	ยูโซะ	MALE	16	4/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1950500317437	ACTIVE	\N	\N
cmqgdycn9001qjxy9jz62rob0	809	อาติร์	ดีแม่	MALE	15	4/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1959901246881	ACTIVE	\N	\N
cmqgdycn9001rjxy9ktr4obzg	507	รุสลัม	ยามา	MALE	16	4/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1940201262134	ACTIVE	\N	\N
cmqgdycn9001sjxy9jz4l3nkr	500	มูฮัมหมัดอิรฟาน	กาปาแย	MALE	16	4/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1950500324255	ACTIVE	\N	\N
cmqgdycn9001tjxy9t6irqpz8	902	ฮาฟีซัน	สาแหละ	MALE	16	4/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1950500321370	ACTIVE	\N	\N
cmqgdycn9001ujxy9o88iutuy	810	ซูฟียัน	ลาบูอาปี	MALE	15	4/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1959901222681	ACTIVE	\N	\N
cmqgdycn9001vjxy9in1wwxmx	805	อัรฟาน	ซะเร็มดีเย๊าะ	MALE	16	4/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1950500320993	ACTIVE	\N	\N
cmqgdycn9001wjxy9kpqhu7ep	901	อัฟนัน	หะยีเจะมะ	MALE	15	4/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1959901229006	ACTIVE	\N	\N
cmqgdycn9001xjxy9wlw3n593	484	อาหะหมัด	เเฉะ	MALE	15	4/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1950101302665	ACTIVE	\N	\N
cmqgdycn9001yjxy9cp7ipqz9	914	อับบาส	สาระ	MALE	15	4/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1959901242002	ACTIVE	\N	\N
cmqgdycn9001zjxy9d4tpzbfh	653	ฟาตีฮะห์	มะญีดี	FEMALE	13	2/2	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1909803835068	ACTIVE	\N	\N
cmqgdycn90020jxy9ftwb5ojy	661	อัสนีตา	ปาแนจะกะ	FEMALE	13	2/2	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1950500349738	ACTIVE	\N	\N
cmqgdycn90021jxy9vmh2xgxi	665	ซูฮุร	หะยีบาราเฮง	FEMALE	13	2/2	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1959901353815	ACTIVE	\N	\N
cmqgdycn90022jxy97xb1hja1	674	มุสลีฟะห์	สามีแล	FEMALE	13	2/2	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1950500343403	ACTIVE	\N	\N
cmqgdycn90023jxy9l3qdzxdj	690	อาฟัฟ	เอียดบู	FEMALE	13	2/2	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1959901347505	ACTIVE	\N	\N
cmqgdycn90024jxy931kz4zq1	693	นูรฟารีซา	เตะนะ	FEMALE	14	2/2	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1940300339046	ACTIVE	\N	\N
cmqgdycn90025jxy94rcud4ci	700	ตัสนีม	สาเมาะ	FEMALE	13	2/2	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1959901356156	ACTIVE	\N	\N
cmqgdycn90026jxy90k7aemar	707	นิลาตีฟะห์	กามา	FEMALE	13	2/2	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1950500342377	ACTIVE	\N	\N
cmqgdycn90027jxy9acp4i59f	819	นุรมา	เวาะโซ๊ะ	FEMALE	13	2/2	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1950700083308	ACTIVE	\N	\N
cmqgdycn90028jxy94fnhfaz0	664	นริศรา	แดวอสนุง	FEMALE	13	2/2	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1959901371741	ACTIVE	\N	\N
cmqgdycn90029jxy9eb9ejuhg	795	อาซีกีน	อับดุลลี	FEMALE	13	2/2	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1959901351758	ACTIVE	\N	\N
cmqgdycn9002ajxy972fgvbbh	820	นินูรอิลมี	สาอะ	FEMALE	13	2/2	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1195050034569	ACTIVE	\N	\N
cmqgdycn9002bjxy9nejfa9yv	704	มัสตูรอ	เจะแว	FEMALE	14	2/2	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1950700081534	ACTIVE	\N	\N
cmqgdycn9002cjxy9g2voe87k	720	อามาล	มะยีแต	FEMALE	13	2/2	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1950500344426	ACTIVE	\N	\N
cmqgdycn9002djxy94nsh9t22	705	ฮาลีเมาะ	กาเซ็งคือบาง	FEMALE	14	2/2	cmq0khbql000ujx237a6k27or	2026-06-16 08:34:07.364	2026-06-16 08:34:07.364	1950700082573	ACTIVE	\N	\N
cmqgem69r0010jxxt97z9hkxb	651	ซอลฟาน	สาแม	MALE	13	2/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:52:38.848	2026-06-16 08:52:38.848	1950500345872	ACTIVE	\N	\N
cmqgem69r0011jxxtuazyo8z8	654	ซารีฟ	นุเซ็ง	MALE	13	2/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:52:38.848	2026-06-16 08:52:38.848	1950700081755	ACTIVE	\N	\N
cmqgem69r0012jxxtc7jpe7n4	655	อิลฮาม	เจ๊ะเลาะ	MALE	13	2/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:52:38.848	2026-06-16 08:52:38.848	1950700085271	ACTIVE	\N	\N
cmqgem69r0013jxxt66actfu5	659	มูฮัมหมัดดาอี	สะอุ	MALE	13	2/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:52:38.848	2026-06-16 08:52:38.848	1950500331685	ACTIVE	\N	\N
cmqgem69r0014jxxtf48r06rr	662	นาซีรุดดีน	ดือราแม	MALE	13	2/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:52:38.848	2026-06-16 08:52:38.848	1950500348219	ACTIVE	\N	\N
cmqgem69r0015jxxtaduu4v33	663	ซอดีกีม	ระสอปุ	MALE	13	2/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:52:38.848	2026-06-16 08:52:38.848	1900601265734	ACTIVE	\N	\N
cmqgem69r0016jxxt04rvuch5	679	อักมาล	คอลีดี	MALE	14	2/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:52:38.848	2026-06-16 08:52:38.848	1950500342831	ACTIVE	\N	\N
cmqgem69r0017jxxtki2eprim	683	อาหมัดซุลฟาน	ตาเละ	MALE	13	2/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:52:38.848	2026-06-16 08:52:38.848	1900501243470	ACTIVE	\N	\N
cmqgem69s0018jxxtpuo45d2u	684	นูรดิน	ฮามะ	MALE	13	2/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:52:38.848	2026-06-16 08:52:38.848	1950500350779	ACTIVE	\N	\N
cmqgem69s0019jxxt0vx6c2m4	688	อิลลียัส	ยูโสะ	MALE	13	2/1	cmq0khbql000ujx237a6k27or	2026-06-16 08:52:38.848	2026-06-16 08:52:38.848	1950500345911	ACTIVE	\N	\N
cmqo3trrx00ckjxf0vx7oz13b	9372	สรวิชญ์	จันทร์ต๊ะหอม	MALE	14	ม.2/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600059343	ACTIVE	\N	\N
cmqo3trrx00cljxf08shzfqtc	9346	พรพิพัฒน์	สุวรรณศรี	MALE	14	ม.2/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600056571	ACTIVE	\N	\N
cmqo3trrx00cmjxf0hkga2z6b	9337	ฐาปกรณ์	มาลา	MALE	14	ม.2/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600056905	ACTIVE	\N	\N
cmqo3trrx00cnjxf0ucejo8au	9363	พิมพ์ชนก	ชงขุนทด	FEMALE	13	ม.2/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1168900042529	ACTIVE	\N	\N
cmqo3trrx00cojxf0b62gt7kx	9245	ประภาวัลย์	เหมือนสันเทียะ	FEMALE	13	ม.2/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1209301287605	ACTIVE	\N	\N
cmqo3trrx00cpjxf09jq5zwly	9365	รุ่งฤดี	งับสันเทียะ	FEMALE	13	ม.2/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369901021907	ACTIVE	\N	\N
cmqo3trrx00cqjxf07w79kjv8	9347	ภาคิน	ผลจันทร์	MALE	14	ม.2/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1478600227211	ACTIVE	\N	\N
cmqo3trrx00crjxf010d5hn46	9338	ธนดล	อินสุ่ม	MALE	13	ม.2/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1308200148268	ACTIVE	\N	\N
cmqo3trrx00csjxf0a9nxqmj4	9681	ธนกฤต	ธรรมาธิวัฒน์	MALE	13	ม.2/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1169400042059	ACTIVE	\N	\N
cmqo3trrx00ctjxf0ghhxb3qw	9353	สราวุธ	สุวรรณ	MALE	14	ม.2/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1309904016271	ACTIVE	\N	\N
cmqo3trrx00cujxf0pl8ls09k	9366	สาวิตรี	เงินทวี	FEMALE	13	ม.2/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1104200867858	ACTIVE	\N	\N
cmqo3trrx00cvjxf0qgnnuul3	9367	เสาวรส	เอื้อกลาง	FEMALE	13	ม.2/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1309904026471	ACTIVE	\N	\N
cmqo3trrx00cwjxf063cnpksu	9341	นครินทร์	ศิลปมัธยม	MALE	13	ม.2/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369901032097	ACTIVE	\N	\N
cmqo3trrx00cxjxf0yso0kz4l	9342	นนทวัช	บู้ช้วน	MALE	13	ม.2/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600056875	ACTIVE	\N	\N
cmqo3trrx00cyjxf0cbuftbkp	9334	กันต์ดนัย	กดมัจฉา	MALE	13	ม.2/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900070504	ACTIVE	\N	\N
cmqo3trrx00czjxf0edfg8bq8	9355	กันยารัตน์	เจริญศิลป์	MALE	14	ม.2/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1309701368661	ACTIVE	\N	\N
cmqo3trrx00d0jxf02n42ut8g	9360	นัฐวิกา	กลิ่นศรีสุข	FEMALE	13	ม.2/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1628200002121	ACTIVE	\N	\N
cmqo3trrx00d1jxf01suy4i7i	9354	กมลเนตร	อยู่ยิ่ง	FEMALE	13	ม.2/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1168900041280	ACTIVE	\N	\N
cmqo3trrx00d2jxf0j79zga8a	9359	ณัฐหทัย	สุขสีดา	FEMALE	13	ม.2/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1309904100506	ACTIVE	\N	\N
cmqo3trrx00d3jxf0bzc17mdo	9343	บุนนาค	ขวัญสูงเนิน	MALE	14	ม.2/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1169200134693	ACTIVE	\N	\N
cmqo3trrx00d4jxf07ites9wo	9361	ปิ่นมนัส	เพียโคตรแก้ว	FEMALE	13	ม.2/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600058673	ACTIVE	\N	\N
cmqo3trrx00d5jxf0koyl25j4	9356	ชาลิต้า	แต่พลกรัง	FEMALE	14	ม.2/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600052870	ACTIVE	\N	\N
cmqo3trrx00d6jxf0lnowoxwa	9340	ธีรวัตร์	พรมอ่อน	MALE	13	ม.2/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369901037391	ACTIVE	\N	\N
cmqo3trrx00d7jxf0bwir8wrm	9458	สรวิศ	เทพโพธิ์	MALE	17	ม.5/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1103400159708	ACTIVE	\N	\N
cmqo3trrx00d8jxf0rpnpe169	9437	ณัทธกานต์	ประชุมพิมาย	MALE	17	ม.5/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369900878103	ACTIVE	\N	\N
cmqo3trrx00d9jxf0l2v7fbbn	9461	แพรพลอย	คิดเห็น	FEMALE	15	ม.5/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1417100082026	ACTIVE	\N	\N
cmqo3trrx00dajxf0p6k2wvfz	8411	น้ำใจ	ขวางกระโทก	FEMALE	16	ม.5/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1308200112557	ACTIVE	\N	\N
cmqo3trrx00dbjxf0ck4aadua	8395	ปฐมพร	พาขุนทด	MALE	16	ม.5/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1309903749258	ACTIVE	\N	\N
cmqo3trrx00dcjxf0041xwlnt	8484	ศรัญฯา	ชาญศิริ	FEMALE	16	ม.5/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900059314	ACTIVE	\N	\N
cmqo3trrx00ddjxf06e6ec32j	9415	ปรีญาพร	พามขุนทด	FEMALE	16	ม.5/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900053758	ACTIVE	\N	\N
cmqo3trrx00dejxf0006iinz4	8446	ณัฐนรี	นิลวดี	FEMALE	16	ม.5/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1110201378954	ACTIVE	\N	\N
cmqo3trrx00dfjxf020h9ywmf	8423	ขวัญประชา	ยายืน	MALE	17	ม.5/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1308200107677	ACTIVE	\N	\N
cmqo3trrx00dgjxf070co0vw0	9780	มณฑิตา	โพธิ์ศรี	FEMALE	16	ม.5/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1308200129654	ACTIVE	\N	\N
cmqo3trrx00dhjxf0itgnwdn9	9497	สดายุ	ฟองแก้ว	MALE	16	ม.5/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1100202027799	ACTIVE	\N	\N
cmqo3trrx00dijxf04fxwyfes	9435	รังสิมันตุ์	อินทศร	MALE	16	ม.5/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1149901133774	ACTIVE	\N	\N
cmqo3trrx00djjxf0m8hzognb	8343	ทิพารมย์	พรมมาโนช	FEMALE	16	ม.5/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900056871	ACTIVE	\N	\N
cmqo3trrx00dkjxf0qnhcwi7m	9465	ณัฐธิดา	กิจเฉลิม	FEMALE	16	ม.5/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1149901132948	ACTIVE	\N	\N
cmqo3trrx00dljxf03i5faqa1	8420	อังศ์ศุมารี	กรวยสวัสดิ์	FEMALE	16	ม.5/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900053821	ACTIVE	\N	\N
cmqo3trrx00dmjxf04kxojlkl	9409	ล้อมเดช	สมัคการ	MALE	16	ม.5/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1104301249319	ACTIVE	\N	\N
cmqo3trrx00dnjxf0z5o6lea5	9488	กชพร	โสดา	FEMALE	17	ม.5/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1100704127552	ACTIVE	\N	\N
cmqo3trrx00dojxf01csh8119	8441	กมลวรรณ	ขิขุนทด	FEMALE	16	ม.5/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1302601009344	ACTIVE	\N	\N
cmqo3trrx00dpjxf0j3dbd902	9436	รัชตะ	มาลา	MALE	16	ม.5/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600047612	ACTIVE	\N	\N
cmqo3trry00dqjxf07ap4wok0	9455	อนันตญา	สร้างนานอก	FEMALE	16	ม.5/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600045377	ACTIVE	\N	\N
cmqo3trry00drjxf00mvoe6rz	8366	กนิษฐา	หงษ์สีทอง	FEMALE	16	ม.5/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900057362	ACTIVE	\N	\N
cmqo3trry00dsjxf0ee4brpjh	9398	ปิยมาศ	นราธิปบุญเอก	FEMALE	13	ม.2/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1104200860021	ACTIVE	\N	\N
cmqo3trry00dtjxf0ctm12tv7	8313	วิชญาพร	จันทร์ต๊ะหอม	FEMALE	16	ม.5/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600046829	ACTIVE	\N	\N
cmqo3trry00dujxf0vvbiy52a	8380	โยศิตา	สายุทธ	FEMALE	16	ม.5/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900054533	ACTIVE	\N	\N
cmqo3trry00dvjxf08cenbaap	8323	ธนภูมิ	ศรีทองอินทร์	MALE	16	ม.5/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1749800507339	ACTIVE	\N	\N
cmqo3trry00dwjxf0zyktyu8c	9430	สายรุ้ง	พระวิชัย	FEMALE	16	ม.5/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369900884481	ACTIVE	\N	\N
cmqo3trry00dxjxf054rmucid	8333	สืบสกุล	เชิญกลาง	MALE	16	ม.5/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1309903728084	ACTIVE	\N	\N
cmqo3trry00dyjxf0prhrj4ee	9399	พัทธนันท์	นามตะ	FEMALE	14	ม.2/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600059203	ACTIVE	\N	\N
cmqo3trry00dzjxf0avwlh2ob	9401	สุพรรณษา	อาจพังเทียม	FEMALE	13	ม.2/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600058428	ACTIVE	\N	\N
cmqo3trry00e0jxf0hsz5wdjk	9377	นัทธพงศ์	สะอาดม่วง	MALE	14	ม.2/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1120500145706	ACTIVE	\N	\N
cmqo3trry00e1jxf0zw5hipoe	9384	วุฒิศักดิ์	วงษ์ไทย	MALE	14	ม.2/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600058070	ACTIVE	\N	\N
cmqo3trry00e2jxf0gb1stue6	9390	ณัฐสุภา	สีสมุทร์	FEMALE	14	ม.2/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369900988707	ACTIVE	\N	\N
cmqo3trry00e3jxf0nwvzis1r	9402	อรจิรา	จันทร์เพ็ง	FEMALE	13	ม.2/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1309904029445	ACTIVE	\N	\N
cmqo3trry00e4jxf0gqszhsf9	9485	พลกฤษ	ไทยประเสริฐ	MALE	14	ม.2/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1361400100413	ACTIVE	\N	\N
cmqo3trry00e5jxf03blxyoep	9388	อัครชัย	เฉลยกลาง	MALE	14	ม.2/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369901007378	ACTIVE	\N	\N
cmqo3trry00e6jxf0b2xz7tjf	9389	สุรีรัตน์	เมืองเกษม	FEMALE	13	ม.2/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600059998	ACTIVE	\N	\N
cmqo3trry00e7jxf099u1i7bw	9378	บุณยกร	พลเยี่ยม	MALE	13	ม.2/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1929901478782	ACTIVE	\N	\N
cmqo3trry00e8jxf02xkc81sh	9371	ฉัตรดนัย	ลาดนอก	MALE	13	ม.2/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900074291	ACTIVE	\N	\N
cmqo3trry00e9jxf00sk8s4um	9391	จิราพัชร	แสงเดือน	FEMALE	14	ม.2/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900069247	ACTIVE	\N	\N
cmqo3trry00eajxf08o399zhz	9397	ปัณฑิตา	บุญสงกา	FEMALE	14	ม.2/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600058835	ACTIVE	\N	\N
cmqo3trry00ebjxf01zvrx7o7	9424	ณัฏฐธิดา	อุปนันทะ	FEMALE	16	ม.5/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600047906	ACTIVE	\N	\N
cmqo3trry00ecjxf0tqh1zbcq	9403	ไอลดา	ศิริเพ็ง	FEMALE	13	ม.2/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600060511	ACTIVE	\N	\N
cmqo3trry00edjxf0y4sszbb3	8442	กันญญาพัชร	แซ่ลิ้ม	FEMALE	16	ม.5/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900055114	ACTIVE	\N	\N
cmqo3trry00eejxf0iq4el9xy	9373	ณัฐวุฒิ	ลาดขุนทด	MALE	14	ม.2/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1660800160421	ACTIVE	\N	\N
cmqo3trry00efjxf0yhwxeok3	9422	อัษฎากรณ์	ยุ้งจัตุรัส	MALE	17	ม.5/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600046489	ACTIVE	\N	\N
cmqo3trry00egjxf01dy434tu	9386	อชิตพล	ยังสันเทียะ	MALE	14	ม.2/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900073546	ACTIVE	\N	\N
cmqo3trry00ehjxf0a4p2qq96	9421	พรเทพ	สายจันทึก	MALE	16	ม.5/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900054843	ACTIVE	\N	\N
cmqo3trry00eijxf01unwp8tn	8455	พิมพ์ลภัส	ประทุมมาศ	MALE	17	ม.5/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1309903694925	ACTIVE	\N	\N
cmqo3trry00ejjxf0xokr3ofl	9227	เจษฎา	พาขุนทด	MALE	13	ม.2/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1308200141263	ACTIVE	\N	\N
cmqo3trry00ekjxf0t04fza87	9258	อมรกานต์	สิทธิวงศ์	FEMALE	13	ม.2/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1160900067770	ACTIVE	\N	\N
cmqo3trry00eljxf0ylnn2t8p	9247	ปวิชญา	เสรนจอหอ	FEMALE	13	ม.2/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1308200144157	ACTIVE	\N	\N
cmqo3trry00emjxf0pz6fb4an	9238	ภาคภูมิ	อยู่เจริญ	MALE	13	ม.2/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1309904127412	ACTIVE	\N	\N
cmqo3trry00enjxf0py52o7zw	9228	ชินภัทร	สมหวัง	MALE	13	ม.2/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1100600603897	ACTIVE	\N	\N
cmqo3trry00eojxf0zd1iyhx1	9234	นภัทร	ชำนาญสิงห์	MALE	13	ม.2/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1198200023025	ACTIVE	\N	\N
cmqo3trry00epjxf0h7rp4ikb	9259	อรธิชา	พรมโสภา	FEMALE	13	ม.2/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600057537	ACTIVE	\N	\N
cmqo3trry00eqjxf0sy4o72o9	9243	ธนัชพร	กุลรัตน์	FEMALE	13	ม.2/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1308200148004	ACTIVE	\N	\N
cmqo3trry00erjxf0tapbsk8t	9250	เพชรทองธาร	พันธ์ศรี	FEMALE	13	ม.2/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600058959	ACTIVE	\N	\N
cmqo3trry00esjxf0bm0tc1il	9236	บุญมา	ทานโสตถี	MALE	13	ม.2/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1449100114795	ACTIVE	\N	\N
cmqo3trry00etjxf0x1kawj88	9246	ประภาศิริ	แจ่มเพ็ง	FEMALE	13	ม.2/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600059157	ACTIVE	\N	\N
cmqo3trry00eujxf0qvrfyalr	9256	อภิญญา	สีชมภู	FEMALE	13	ม.2/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369901025813	ACTIVE	\N	\N
cmqo3trry00evjxf06x88zpy5	9254	วริศรา	บุตตะ	FEMALE	13	ม.2/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600059009	ACTIVE	\N	\N
cmqo3trry00ewjxf0toodswrr	9240	กฤติพร	เทียมทนงค์	FEMALE	13	ม.2/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600059718	ACTIVE	\N	\N
cmqo3trry00exjxf0u8qwfmo1	9237	ปฏิภาณ	วงษ์ยำหราบ	MALE	13	ม.2/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600058029	ACTIVE	\N	\N
cmqo3trry00eyjxf0d6nvg775	9239	อภิรักษ์	คิดการ	MALE	13	ม.2/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1103101209185	ACTIVE	\N	\N
cmqo3trry00ezjxf0116tbiah	9492	ภาคิน	สุดเเสง	MALE	13	ม.2/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1360501337399	ACTIVE	\N	\N
cmqo3trry00f0jxf020ixwdwi	9490	ณัฐธิดา	ชัยคำนวน	FEMALE	14	ม.2/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1399400099431	ACTIVE	\N	\N
cmqo3trry00f1jxf005seeejt	9007	กิตติกวิน	ตองอ่อน	MALE	15	ม.3/4	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1949900830172	ACTIVE	\N	\N
cmqo3trry00f2jxf0cc2txd99	9028	ภัทรวดี	เกิดเมือง	FEMALE	15	ม.3/4	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600054716	ACTIVE	\N	\N
cmqo3trry00f3jxf0dd448jgh	9026	ปิยธิดา	บุญกว้าง	FEMALE	14	ม.3/4	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600054554	ACTIVE	\N	\N
cmqo3trry00f4jxf086ittq3f	8059	พงษกร	คำยาง	MALE	18	ม.6/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600039792	ACTIVE	\N	\N
cmqo3trry00f5jxf0ahjt6456	8137	วรรณณิสา	เหลือวิชา	FEMALE	17	ม.6/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900050759	ACTIVE	\N	\N
cmqo3trry00f6jxf0xhnsex81	9123	อภิชญา	ดีนันท์	FEMALE	17	ม.6/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1199600467835	ACTIVE	\N	\N
cmqo3trry00f7jxf060hli21q	8113	ชนะพล	ศรีจันทร์	MALE	17	ม.6/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369900883514	ACTIVE	\N	\N
cmqo3trry00f8jxf0aqolapwn	9154	กนกพร	พูศรีเทพ	FEMALE	17	ม.6/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600044702	ACTIVE	\N	\N
cmqo3trry00f9jxf0t1etwy68	8108	สุพรรณ์ษา	สุขหอม	FEMALE	17	ม.6/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600042980	ACTIVE	\N	\N
cmqo3trry00fajxf07zgohl3s	8072	ณัฐณิชา	ครูเกษตร	FEMALE	17	ม.6/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369900865796	ACTIVE	\N	\N
cmqo3trry00fbjxf05gxm8phc	8172	สิริวิมล	กิ่งไทรกลาง	FEMALE	17	ม.6/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369900870285	ACTIVE	\N	\N
cmqo3trry00fcjxf0uv7bwi0f	7992	สิริวัฒน์	ทาบจัตุรัส	MALE	17	ม.6/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369900855375	ACTIVE	\N	\N
cmqo3trry00fdjxf0vyrpd9jw	8077	โสรญา	ข้อไว	FEMALE	18	ม.6/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600041134	ACTIVE	\N	\N
cmqo3trry00fejxf00abhefcg	9573	สหรัฐ	โยธาภักดี	MALE	13	ม.1/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600061275	ACTIVE	\N	\N
cmqo3trry00ffjxf0erpxtj15	9117	ธเนศ	นนท์ขุนทด	FEMALE	17	ม.6/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600043161	ACTIVE	\N	\N
cmqo3trry00fgjxf0ys6a7oaj	9560	ธนาคาร	ธนาคาร บุรีนอก	MALE	12	ม.1/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1169200139989	ACTIVE	\N	\N
cmqo3trry00fhjxf0aurz1l17	9578	จตุทิพย์	ผลสมหวัง	FEMALE	13	ม.1/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1229901513746	ACTIVE	\N	\N
cmqo3trry00fijxf0m7jewnty	9584	ณิชนันท์	น้อยจังหาร	FEMALE	12	ม.1/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1103704919486	ACTIVE	\N	\N
cmqo3trry00fjjxf058vqth05	9588	รัตติยากร	ไทยมณี	FEMALE	12	ม.1/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900078459	ACTIVE	\N	\N
cmqo3trry00fkjxf0wq27hwn0	9585	ประภัสสร	ทวยขุนทด	FEMALE	13	ม.1/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369901045326	ACTIVE	\N	\N
cmqo3trry00fljxf065c5m8rh	9568	ภูริชญา	ดีนันท์	MALE	13	ม.1/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1199600548011	ACTIVE	\N	\N
cmqo3trry00fmjxf0bc1vzbr9	9322	ทิพวรรณ	ศิริเพ็ง	FEMALE	14	ม.2/4	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1149901299249	ACTIVE	\N	\N
cmqo3trry00fnjxf0b023tzml	9307	ธีรยุทธ	ไพลกลาง	MALE	13	ม.2/4	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1209601799067	ACTIVE	\N	\N
cmqo3trry00fojxf03jg7nprj	9331	สิรินทรา	บัวบานงาม	FEMALE	14	ม.2/4	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600056671	ACTIVE	\N	\N
cmqo3trry00fpjxf0bir9c1c1	9313	มาวิน	ศรีษะแก้ว	MALE	13	ม.2/4	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900073635	ACTIVE	\N	\N
cmqo3trry00fqjxf0m5i6wqym	9299	กิตติวัฒน์	อาจกมล	MALE	13	ม.2/4	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369901027221	ACTIVE	\N	\N
cmqo3trrz00frjxf0kbmqurgi	9308	นวพล	เอิบกมล	MALE	14	ม.2/4	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1749800576802	ACTIVE	\N	\N
cmqo3trrz00fsjxf0e31e36cq	9298	กันภิรมย์	ริมสันเทียะ	MALE	14	ม.2/4	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900069921	ACTIVE	\N	\N
cmqo3trrz00ftjxf0atwyzi53	9324	ปวริศา	ศรีวงษา	FEMALE	13	ม.2/4	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1849300176235	ACTIVE	\N	\N
cmqo3trrz00fujxf0w2g6vu17	9321	ณิชนันทน์	บุญไทย	FEMALE	13	ม.2/4	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900072167	ACTIVE	\N	\N
cmqo3trrz00fvjxf0ayg4ehyt	9329	วิชญาพร	พอขุนทด	FEMALE	13	ม.2/4	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1308200141956	ACTIVE	\N	\N
cmqo3trrz00fwjxf0j3a6lvgl	9325	พรชนก	สุระ	FEMALE	13	ม.2/4	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1240600327325	ACTIVE	\N	\N
cmqo3trrz00fxjxf0oivwledo	9304	ธนบดี	คำไขแก้ว	MALE	13	ม.2/4	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900072281	ACTIVE	\N	\N
cmqo3trrz00fyjxf0malpalfg	9314	วทัญญู	ป้อมทอง	MALE	14	ม.2/4	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1309903973361	ACTIVE	\N	\N
cmqo3trrz00fzjxf073ylpnkm	9305	ธันวา	แก่นสาร	MALE	15	ม.2/4	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600055143	ACTIVE	\N	\N
cmqo3trrz00g0jxf037y1iwx6	9328	รัตนาวลี	ประสมสิน	FEMALE	13	ม.2/4	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600060546	ACTIVE	\N	\N
cmqo3trrz00g1jxf01dissupz	9323	นิรดา	คงชาวนา	FEMALE	13	ม.2/4	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1239900563898	ACTIVE	\N	\N
cmqo3trrz00g2jxf0aygn4y0o	8002	กนกพิชญ์	หนูหล่า	FEMALE	17	ม.6/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600042831	ACTIVE	\N	\N
cmqo3trrz00g3jxf0uqzalbg6	9109	ภูตะวัน	ครุรัมย์	MALE	17	ม.6/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1129902164959	ACTIVE	\N	\N
cmqo3trrz00g4jxf0avq9xgzw	8037	ธนัชชา	โคกกรุ่น	FEMALE	17	ม.6/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1100201987772	ACTIVE	\N	\N
cmqo3trrz00g5jxf08254eigw	9113	ศิริวรรณ	โคตะนนท์	FEMALE	17	ม.6/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369908585440	ACTIVE	\N	\N
cmqo3trrz00g6jxf0b3hcn3eo	9114	สิรินัน	อรรถจิตต์	FEMALE	17	ม.6/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900048746	ACTIVE	\N	\N
cmqo3trrz00g7jxf0lnrv18gx	8019	ธนภัทร์	แฟสันเทียะ	MALE	17	ม.6/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1208300059128	ACTIVE	\N	\N
cmqo3trrz00g8jxf0x3sthlu4	9112	ธิยาดา	วิเศษดี	FEMALE	17	ม.6/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900047341	ACTIVE	\N	\N
cmqo3trrz00g9jxf09fpmqbg0	8082	ณัฐสิทธิ์	ฤาชา	MALE	17	ม.6/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369900845477	ACTIVE	\N	\N
cmqo3trrz00gajxf0ed8vdnho	8030	สิรภัทร	สุทธิประภา	MALE	17	ม.6/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1102900168900	ACTIVE	\N	\N
cmqo3trrz00gbjxf03t1f9dhz	8033	อิทธิพัทธ์	สมหวัง	MALE	17	ม.6/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1149901079591	ACTIVE	\N	\N
cmqo3trrz00gcjxf0109hvi6b	8067	กัลยาณี	มูลเพชร	FEMALE	17	ม.6/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369900873136	ACTIVE	\N	\N
cmqo3trrz00gdjxf0v9cmankg	8066	กชกร	พือขุนทด	FEMALE	17	ม.6/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900048584	ACTIVE	\N	\N
cmqo3trrz00gejxf0gy4o0lhe	8031	แสงตะวัน	มูลสันเทียะ	MALE	17	ม.6/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600042190	ACTIVE	\N	\N
cmqo3trrz00gfjxf0rhomr06g	9111	กรรณิกา	จูงกลาง	FEMALE	17	ม.6/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1101801583029	ACTIVE	\N	\N
cmqo3trrz00ggjxf0t6hdtuoc	9108	พงศธร	นาคนิยม	MALE	17	ม.6/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600044141	ACTIVE	\N	\N
cmqo3trrz00ghjxf0acgd18g0	9110	ศิวพัชฏ	มิ่งขวัญ	MALE	17	ม.6/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1305300051344	ACTIVE	\N	\N
cmqo3trrz00gijxf0d49ynohu	8021	ธีรโชติ	ผาอินทร์	MALE	17	ม.6/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1129902130281	ACTIVE	\N	\N
cmqo3trrz00gjjxf084lzjm41	9701	ศิริพร	เเสนศรี	FEMALE	13	ม.1/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600062590	ACTIVE	\N	\N
cmqo3trrz00gkjxf0siyoz3hv	9694	นภัสสร	ศรีห้วยไพร	FEMALE	13	ม.1/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600057529	ACTIVE	\N	\N
cmqo3trrz00gljxf0giokh4dg	9685	ศุภวัตร	เชาว์วันกลาง	MALE	12	ม.1/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369901068881	ACTIVE	\N	\N
cmqo3trrz00gmjxf0b1mr40o3	9705	สุนันทา	แก้วสิงห์	FEMALE	12	ม.1/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600063588	ACTIVE	\N	\N
cmqo3trrz00gnjxf0xhoafl57	8760	จีรชญาณ์	เเสงประสิทธิ์	FEMALE	15	ม.4/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1308200126892	ACTIVE	\N	\N
cmqo3trrz00gojxf057482z7q	8759	นพรัตน์	เทศะบำรุง	FEMALE	15	ม.4/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600052632	ACTIVE	\N	\N
cmqo3trrz00gpjxf0b1blugpc	8693	ธดากรณ์	หอมรวง	FEMALE	15	ม.4/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600051725	ACTIVE	\N	\N
cmqo3trrz00gqjxf08plupf8x	8740	ธนวัฒน์	แซ่เล้า	MALE	15	ม.4/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369900943118	ACTIVE	\N	\N
cmqo3trrz00grjxf0ucn9x9ib	8727	รัชชาณิสา	ทองทะเล	FEMALE	15	ม.4/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1149901175043	ACTIVE	\N	\N
cmqo3trrz00gsjxf0k4eqemjh	9751	จรรยพร	กลิ่นศรีสุจ	FEMALE	15	ม.4/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900061467	ACTIVE	\N	\N
cmqo3trrz00gtjxf09h5slaxo	8416	วารุณี	คำทอง	FEMALE	16	ม.5/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369900916072	ACTIVE	\N	\N
cmqo3trrz00gujxf0tbzg7uku	8448	ณิชานันท์	พันธ์งาม	FEMALE	16	ม.5/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600047281	ACTIVE	\N	\N
cmqo3trrz00gvjxf0sj98j9yo	9748	ณัฐภูมิ	ศิริพร	MALE	15	ม.4/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1139600588462	ACTIVE	\N	\N
cmqo3trrz00gwjxf0yuo0jfqf	8457	พงศธร	พวงสันเทียะ	MALE	16	ม.4/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600046781	ACTIVE	\N	\N
cmqo3trrz00gxjxf07zx5n66d	9413	ปทิตตา	ชอมขุนทด	FEMALE	16	ม.5/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600048244	ACTIVE	\N	\N
cmqo3trrz00gyjxf0wzfurkl8	8338	จิราภรณ์	ชิณวงศ์	FEMALE	16	ม.5/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1309903767086	ACTIVE	\N	\N
cmqo3trrz00gzjxf0qbu15z5k	8412	ปภาว​รินท์​	มาจันทึก	FEMALE	17	ม.5/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900054355	ACTIVE	\N	\N
cmqo3trrz00h0jxf0pm6awfjg	8396	พงศกร	หาดขุนทด	MALE	16	ม.4/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900055301	ACTIVE	\N	\N
cmqo3trrz00h1jxf0qrydpsgd	9752	ณัฏฐธิดา	เเถวจัตุรัส	FEMALE	16	ม.4/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900058075	ACTIVE	\N	\N
cmqo3trrz00h2jxf0ms9tlg8t	9758	สมฤดี	บุตรสูงเนิน	FEMALE	15	ม.4/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600061067	ACTIVE	\N	\N
cmqo3trrz00h3jxf0y15w9r1h	8325	ธนากร	พานิช	MALE	17	ม.5/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1839902091092	ACTIVE	\N	\N
cmqo3trrz00h4jxf08xieam6q	9410	กิติญาดา	มณีวงษ์	FEMALE	16	ม.5/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1169400033637	ACTIVE	\N	\N
cmqo3trrz00h5jxf0go044det	8471	สิรดนัย	พับขุนทด	MALE	17	ม.5/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600045482	ACTIVE	\N	\N
cmqo3trrz00h6jxf052sls66w	8371	ชัญญานุช	จงปลูกกลาง	FEMALE	16	ม.5/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600047744	ACTIVE	\N	\N
cmqo3trrz00h7jxf0phmz4mih	8409	ธิติมา	ฉัตรสุวรรณ	FEMALE	16	ม.5/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600047361	ACTIVE	\N	\N
cmqo3trrz00h8jxf087ldrc29	8400	ภูริษฐ์	พุฒนอก	MALE	18	ม.5/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900043639	ACTIVE	\N	\N
cmqo3trrz00h9jxf04u385z9f	9412	ธนพร	บิงขุนทด	FEMALE	16	ม.5/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900052441	ACTIVE	\N	\N
cmqo3trrz00hajxf05t8nln3k	8415	แพรวา	สื่อวงศ์สุวรรณ	FEMALE	16	ม.5/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369900916188	ACTIVE	\N	\N
cmqo3trrz00hbjxf0voxqxf8y	8318	จักรพงศ์	เจิมจุล	MALE	16	ม.5/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1378600048899	ACTIVE	\N	\N
cmqo3trrz00hcjxf0dh38xmsa	9754	นิภาพร	ไทยสมัคร	FEMALE	15	ม.4/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369900931926	ACTIVE	\N	\N
cmqo3trrz00hdjxf05e3o2pl2	8304	ธารารัตน์	สังข์ทอง	FEMALE	16	ม.5/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369900905691	ACTIVE	\N	\N
cmqo3trrz00hejxf0amg32b9e	8594	อชิรญา	ชัยขุนทด	FEMALE	17	ม.5/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1129902187002	ACTIVE	\N	\N
cmqo3trrz00hfjxf05wn4ufmb	8331	พูลสุข	ชำนาญสิงห์	FEMALE	16	ม.5/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1199901312725	ACTIVE	\N	\N
cmqo3trrz00hgjxf0obtg8071	8490	อรสา	สีพุท	FEMALE	16	ม.5/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600046837	ACTIVE	\N	\N
cmqo3trrz00hhjxf0ib8t6qp9	9177	พัฒนศักดิ์	เอียการนา	MALE	16	ม.5/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1199901272545	ACTIVE	\N	\N
cmqo3trrz00hijxf0ui710mby	9411	คณัสนันท์	อุทัยอัน	FEMALE	16	ม.5/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900052450	ACTIVE	\N	\N
cmqo3trrz00hjjxf0zv1eo0jl	8408	ณัฐณิชา	น้อยพล	FEMALE	16	ม.5/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900052557	ACTIVE	\N	\N
cmqo3trrz00hkjxf0bpnem85n	8649	ภัทรพล	แฟนสันเทียะ	MALE	15	ม.4/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1208300073651	ACTIVE	\N	\N
cmqo3trrz00hljxf07u1tlme0	9756	วันนิสา	พอขุนทด	FEMALE	15	ม.4/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600052161	ACTIVE	\N	\N
cmqo3trrz00hmjxf04tywy4vr	9408	กฤษฎา	นุขุนทด	MALE	16	ม.5/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600047302	ACTIVE	\N	\N
cmqo3trrz00hnjxf0n6h6e20p	9407	กฤษกร	สีมา	MALE	16	ม.5/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1103101068476	ACTIVE	\N	\N
cmqo3trrz00hojxf0u0h2h52t	8445	ณัชชา	ประตังทานัง	FEMALE	16	ม.5/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600045954	ACTIVE	\N	\N
cmqo3trrz00hpjxf0e0guc52t	9753	ธนัชชา	เมืองจำนงค์	FEMALE	16	ม.4/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600048856	ACTIVE	\N	\N
cmqo3trrz00hqjxf0hmac2rbs	9414	ปนิตตา	เพ็ชรวิเศษ	FEMALE	17	ม.5/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1129701463533	ACTIVE	\N	\N
cmqo3trrz00hrjxf00bgjhomy	9417	สุขิตา	เพ็ญมนัส	FEMALE	16	ม.5/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1318700101678	ACTIVE	\N	\N
cmqo3trs000hsjxf03i0g0wzd	9750	ศุภณัฐ	สายเส็น	MALE	15	ม.4/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600049704	ACTIVE	\N	\N
cmqo3trs000htjxf0mugg0128	9749	พีระพัฒน์	อาจอำนวย	MALE	15	ม.4/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600049453	ACTIVE	\N	\N
cmqo3trs000hujxf0plmf6a9q	8317	อัมพร	นิ่มอนงค์	FEMALE	16	ม.5/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1104200731573	ACTIVE	\N	\N
cmqo3trs000hvjxf0hay1yd1b	8422	กิตติวัฒน์	โซ่เซียงคำ	MALE	16	ม.5/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369900901831	ACTIVE	\N	\N
cmqo3trs000hwjxf0onvioxl9	8312	วันดี	เกิดสินธุ์	FEMALE	16	ม.5/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369900910333	ACTIVE	\N	\N
cmqo3trs000hxjxf0ls5ywnyl	9161	กนกณัฐ	อนันตรักษ์	FEMALE	16	ม.5/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1139600573473	ACTIVE	\N	\N
cmqo3trs000hyjxf0xlqjno2q	8362	วิภาวัส	ยังสันเทียะ	MALE	16	ม.5/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900057184	ACTIVE	\N	\N
cmqo3trs000hzjxf0im9nokm9	8383	สุชาวดี	แก้วมะเริง	FEMALE	16	ม.5/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900054886	ACTIVE	\N	\N
cmqo3trs000i0jxf0qsxdnqfp	8361	วณชกร	ชำนาญผิด	MALE	17	ม.5/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1308200109475	ACTIVE	\N	\N
cmqo3trs000i1jxf0xnbsk42d	9452	ณัฐธิดา	สาอุต	FEMALE	16	ม.5/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900051615	ACTIVE	\N	\N
cmqo3trs000i2jxf0ccykf4ve	8356	พลพนา	ชัยปลัด	MALE	16	ม.5/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600046772	ACTIVE	\N	\N
cmqo3trs000i3jxf0nwase7y3	8584	สุณิสา	สีหามาตย์	FEMALE	17	ม.5/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900051275	ACTIVE	\N	\N
cmqo3trs000i4jxf0p4x5qk8h	9279	อัครเดช	ลายทองคำ	MALE	14	ม.2/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1800600261051	ACTIVE	\N	\N
cmqo3trs000i5jxf0dp72j3pq	9262	ขวัญชัย	หาดขุนทด	MALE	14	ม.2/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369901003623	ACTIVE	\N	\N
cmqo3trs000i6jxf07v5el932	9263	จิรายุ	พิลึก	MALE	13	ม.2/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1102004400967	ACTIVE	\N	\N
cmqo3trs000i7jxf0bpqoolun	9277	ศุภณัฐ์	พ่วงระยับ	MALE	15	ม.2/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1759700021574	ACTIVE	\N	\N
cmqo3trs000i8jxf0lj5i6ck7	9292	วรัญญา	พรมโสภา	FEMALE	14	ม.2/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369901000772	ACTIVE	\N	\N
cmqo3trs000i9jxf0jd834eom	9272	พีรพัฒน์	ไขแสง	MALE	14	ม.2/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600058916	ACTIVE	\N	\N
cmqo3trs000iajxf0mybsp82d	9290	พันราดา	หนุนกุศล	FEMALE	13	ม.2/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600058550	ACTIVE	\N	\N
cmqo3trs000ibjxf03zq7wprq	9296	อรชพร	มวยคล่อง	FEMALE	13	ม.2/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1309904029836	ACTIVE	\N	\N
cmqo3trs000icjxf076t59xa6	9288	ธัญรัตน์	สมบัติ	FEMALE	13	ม.2/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1103101242654	ACTIVE	\N	\N
cmqo3trs000idjxf0n2k1bnwt	9293	วรางคนา	เกิดเมือง	FEMALE	13	ม.2/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600059611	ACTIVE	\N	\N
cmqo3trs000iejxf0pg6s3ynp	9273	วรปรัชญ์	มุ่งขอบอกลาง	MALE	14	ม.2/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1309904033051	ACTIVE	\N	\N
cmqo3trs000ifjxf0ucuxayyy	9451	สิทธิ์พสุ	ไชย์ธำรงค์ธาดา	MALE	16	ม.5/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1729100100589	ACTIVE	\N	\N
cmqo3trs000igjxf0j7kpknav	9428	นวรัตน์	อินทร์มณี	FEMALE	16	ม.5/3	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1209000511387	ACTIVE	\N	\N
cmqo3trs000ihjxf0mctf463b	8038	ธนัชชา	หอพิกลาง	FEMALE	17	ม.6/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600044451	ACTIVE	\N	\N
cmqo3trs000iijxf0t31s6fmx	9212	ณัฐชา	เชาว์จอหอ	FEMALE	13	ม.2/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900073830	ACTIVE	\N	\N
cmqo3trs000ijjxf09gsn00fb	9204	กมลชนก	สามารถ	FEMALE	14	ม.2/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1309904026012	ACTIVE	\N	\N
cmqo3trs000ikjxf0c804u77b	9210	ณัชนันทน์	รุ่งเรืองกิจกุล	FEMALE	14	ม.2/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369901002210	ACTIVE	\N	\N
cmqo3trs000iljxf073575yc4	9225	อภิชญา	ภักดิ์ชัยภูมิ	FEMALE	13	ม.2/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1309904115368	ACTIVE	\N	\N
cmqo3trs000imjxf0ylxsla9o	9220	พิราวัลย์	แผ่วกระโทก	FEMALE	13	ม.2/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1308200149043	ACTIVE	\N	\N
cmqo3trs000injxf0ndrfksli	9198	ธนภัทร	เจิม	MALE	13	ม.2/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600058762	ACTIVE	\N	\N
cmqo3trs000iojxf03imlic74	9203	อัครวินท์	รักเมือง	MALE	14	ม.2/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1529902526059	ACTIVE	\N	\N
cmqo3trs000ipjxf0sr9qnjle	9197	ธนโชติ	ยักสกุล	MALE	14	ม.2/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1380100013185	ACTIVE	\N	\N
cmqo3trs000iqjxf0enzzfk5f	9208	จุฑาเพชร	บุญยิ่ง	FEMALE	13	ม.2/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600058797	ACTIVE	\N	\N
cmqo3trs000irjxf0lf2fit85	9219	พิมพ์พิศา	แทนทรัพย์	FEMALE	13	ม.2/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1309904038185	ACTIVE	\N	\N
cmqo3trs000isjxf0pl8pp3o2	9215	ธิราพร	อิงคสฤษฎ์	FEMALE	14	ม.2/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1659902702387	ACTIVE	\N	\N
cmqo3trs000itjxf0sltvmwfn	9221	วรรณิดา	รัตนธรรม	FEMALE	13	ม.2/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900070172	ACTIVE	\N	\N
cmqo3trs000iujxf0onfybrs6	9211	ณัฏฐนิชา	เพชรน้อย	FEMALE	13	ม.2/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1309904038304	ACTIVE	\N	\N
cmqo3trs000ivjxf052cpo9aj	9216	นัดดาว	ประจิตร	FEMALE	13	ม.2/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600057014	ACTIVE	\N	\N
cmqo3trs000iwjxf0hwtqsr99	9206	จารุวรรณ	อยู่เจริญ	FEMALE	13	ม.2/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900072213	ACTIVE	\N	\N
cmqo3trs000ixjxf0hpq061q5	9226	อรอุมา	สุขหวาน	FEMALE	13	ม.2/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600057855	ACTIVE	\N	\N
cmqo3trs000iyjxf0oqdyax91	9224	หทัยรัตน์	เชาระกำ	FEMALE	14	ม.2/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1848100073032	ACTIVE	\N	\N
cmqo3trs000izjxf0j6uj6kux	9193	กนกพล	บูรณะธารารัตน์	MALE	13	ม.2/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1200901676612	ACTIVE	\N	\N
cmqo3trs000j0jxf0ot96m31s	9201	พงศธร	มุ่งคีมกลาง	MALE	13	ม.2/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1309904066561	ACTIVE	\N	\N
cmqo3trs000j1jxf03lktvuey	9218	ปณิตา	บำรุงราษฎร์	FEMALE	13	ม.2/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1309904052137	ACTIVE	\N	\N
cmqo3trs000j2jxf0tinhhty6	9194	กมลเทพ	ชินแสน	MALE	13	ม.2/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369901021273	ACTIVE	\N	\N
cmqo3trs000j3jxf0sv5e3xv1	9195	จิตติพัฒน์	ภูมิยิ่ง	MALE	14	ม.2/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1209702736109	ACTIVE	\N	\N
cmqo3trs000j4jxf0p4rubb8t	9214	ธัญนันท์	แจ่มศรี	FEMALE	13	ม.2/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600060457	ACTIVE	\N	\N
cmqo3trs000j5jxf09zar2gc1	8174	รัตนาวดี	เกิดเมือง	FEMALE	17	ม.6/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369900868345	ACTIVE	\N	\N
cmqo3trs000j6jxf0xczzqby1	9394	อริษา	เอี่ยมเสวก	FEMALE	17	ม.6/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369900864242	ACTIVE	\N	\N
cmqo3trs000j7jxf0jg8102o2	8140	ธิอัญญา	โพธิ์นอก	FEMALE	17	ม.6/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1308200103396	ACTIVE	\N	\N
cmqo3trs000j8jxf0rz8hdwec	8119	เกวลี	เสมาฉิม	FEMALE	17	ม.6/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600042483	ACTIVE	\N	\N
cmqo3trs000j9jxf06zkwvzd9	9140	อัครพล	แน่นอุดร	MALE	17	ม.6/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1279900364674	ACTIVE	\N	\N
cmqo3trs000jajxf01z2bh5iu	9105	นภัสสร	ขรึมสันเทียะ	FEMALE	17	ม.6/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900049521	ACTIVE	\N	\N
cmqo3trs000jbjxf06ln3yal0	8591	สุชานาถ	ขวัญเมือง	FEMALE	17	ม.6/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1308200099003	ACTIVE	\N	\N
cmqo3trs000jcjxf0r10e4feu	8009	บวรลักษณ์	พาโยพัด	FEMALE	17	ม.6/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1209702487010	ACTIVE	\N	\N
cmqo3trs000jdjxf0tbqqkbsy	8127	ณัฐริดา	ตะวันสาย	FEMALE	19	ม.6/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1102003868485	ACTIVE	\N	\N
cmqo3trs000jejxf0lmmwphze	8102	ปิยดา	มิลขุนทด	FEMALE	17	ม.6/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369900864919	ACTIVE	\N	\N
cmqo3trs000jfjxf0658qeity	8012	เมธปรียา	เจียมทอง	FEMALE	17	ม.6/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900047391	ACTIVE	\N	\N
cmqo3trs000jgjxf0vv2t2h95	8602	วีระพงค์	คงกระพัน	MALE	17	ม.6/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1309903631851	ACTIVE	\N	\N
cmqo3trs000jhjxf0t0pfqvi6	8071	ณัฐณิชา	สุขสีดา	FEMALE	17	ม.6/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1309903647102	ACTIVE	\N	\N
cmqo3trs000jijxf0c2mgss0e	8006	จันทกานต์	จงกลาง	FEMALE	17	ม.6/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900050422	ACTIVE	\N	\N
cmqo3trs000jjjxf0kjfj4ptb	8254	พัฒนา	พัฒกิตตพงษ์	MALE	17	ม.6/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1103101041314	ACTIVE	\N	\N
cmqo3trs000jkjxf04p8v0p1e	9182	บุษราคัม	สงนอก	FEMALE	17	ม.6/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1308200102225	ACTIVE	\N	\N
cmqo3trs000jljxf0n1whl2b0	8133	พีรญา	พูนพัฒนาพันธุ์	FEMALE	17	ม.6/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1309903680703	ACTIVE	\N	\N
cmqo3trs100jmjxf0bk391c8p	8001	กชกร	พรทั้งสี่	FEMALE	17	ม.6/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1110301488549	ACTIVE	\N	\N
cmqo3trs100jnjxf04bo0b6mo	8034	ชุติกาญจน์	พูนสวัสดิ์	FEMALE	17	ม.6/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1308200098546	ACTIVE	\N	\N
cmqo3trs100jojxf0nzvb6y5x	8136	รมย์ธีรา	ภาระราช	FEMALE	17	ม.6/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1100501714127	ACTIVE	\N	\N
cmqo3trs100jpjxf0oc730zbi	8138	วิญาดา	วงศ์ตีบ	FEMALE	17	ม.6/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900048941	ACTIVE	\N	\N
cmqo3trs100jqjxf0sz4scm4n	9104	ชบาไพร	หาดขุนทด	FEMALE	17	ม.6/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369900870978	ACTIVE	\N	\N
cmqo3trs100jrjxf07xr2bi8g	9100	ปรัชญา	ดวงส่าน	MALE	17	ม.6/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1709901773689	ACTIVE	\N	\N
cmqo3trs100jsjxf0i1fvu5ef	9103	อดิเรก	แก่นบุบผา	MALE	17	ม.6/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600043277	ACTIVE	\N	\N
cmqo3trs100jtjxf09x089c05	7990	ภาวิน	สุขสวน	MALE	18	ม.6/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900045500	ACTIVE	\N	\N
cmqo3trs100jujxf0bczhn08e	8135	ภัทรนันท์	บัวใหญ่รักษา	FEMALE	17	ม.6/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1369900846333	ACTIVE	\N	\N
cmqo3trs100jvjxf0sdr0cmus	8016	วิลาสินี	โสดา	FEMALE	17	ม.6/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900049891	ACTIVE	\N	\N
cmqo3trs100jwjxf0t2475383	7988	นนทกร	เจริญสุข	MALE	18	ม.6/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1309903582710	ACTIVE	\N	\N
cmqo3trs100jxjxf04s5qfo5x	8052	จักรภัทร	เพชรวิเศษอุดม	MALE	18	ม.6/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600041941	ACTIVE	\N	\N
cmqo3trs100jyjxf0qxkwq3vw	8906	ธีรภัทร	ธาตุประกอบ	MALE	14	ม.3/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1679900844711	ACTIVE	\N	\N
cmqo3trs100jzjxf0k8chpi77	8927	รุ่งฤดี	สังข์คำ	FEMALE	15	ม.3/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1309903898008	ACTIVE	\N	\N
cmqo3trs100k0jxf0s2cnypqs	8929	ศรัญญา	โคตะนนท์	FEMALE	14	ม.3/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600055453	ACTIVE	\N	\N
cmqo3trs100k1jxf08dm66p9q	8919	ณัฐวรินทร์	บรรลือทรัพย์	FEMALE	14	ม.3/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600056484	ACTIVE	\N	\N
cmqo3trs100k2jxf0cm47oiks	8028	วรสรณ์	ชุมวัชรวิทย์	MALE	18	ม.6/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600042343	ACTIVE	\N	\N
cmqo3trs100k3jxf0lbg6txs7	8922	ปุณยวีย์	ชิขุนทด	FEMALE	15	ม.3/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900066191	ACTIVE	\N	\N
cmqo3trs100k4jxf0cq5um2rb	8918	ณัฐมน	กาพย์พิมาย	FEMALE	14	ม.3/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1308200133236	ACTIVE	\N	\N
cmqo3trs100k5jxf0ebzyyxab	9244	ธัญชนก	ฤทธิ์มนตรี	FEMALE	13	ม.2/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600057049	ACTIVE	\N	\N
cmqo3trs100k6jxf097odkcaq	8157	ชุติมา	ม่วงน้ำเงิน	FEMALE	17	ม.6/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1749901267465	ACTIVE	\N	\N
cmqo3trs100k7jxf0d2yw252j	9134	ธิติกานต์	ปานใจนาม	FEMALE	17	ม.6/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1319300079358	ACTIVE	\N	\N
cmqo3trs100k8jxf096uofmtk	7987	เดชาธร	โสภกุล	MALE	17	ม.6/5	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600043251	ACTIVE	\N	\N
cmqo3trs100k9jxf0zd5abti7	8723	กวินธิดา	จิตโคกกรวด	FEMALE	15	ม.4/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600051041	ACTIVE	\N	\N
cmqo3trs100kajxf0afxapwkn	8623	ขรินทร์ทิพย์	โขจัตุรัส	FEMALE	15	ม.4/4	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900062269	ACTIVE	\N	\N
cmqo3trs100kbjxf00at60v0s	8683	ภาณุวิชญ์	ชาติประมง	MALE	16	ม.4/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368900058369	ACTIVE	\N	\N
cmqo3trs100kcjxf03d64gxgg	8775	ธีรภัทร	นกทอง	MALE	15	ม.4/6	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1600300147026	ACTIVE	\N	\N
cmqo3trs100kdjxf0so7lged7	9723	สิรินภาพร	ร่วมศิริ	FEMALE	16	ม.4/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600049089	ACTIVE	\N	\N
cmqo3trs100kejxf06v05c5fm	8798	สุภาวดี	ไขแสง	FEMALE	15	ม.4/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600049909	ACTIVE	\N	\N
cmqo3trs100kfjxf0m4itmu0z	8709	ดนุพร	ภูมิคอนสาร	MALE	16	ม.4/1	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1368600049241	ACTIVE	\N	\N
cmqo3trs100kgjxf0sd21964h	8660	ณัฐลดา	แก้วเกิด	FEMALE	16	ม.4/2	cmq0kj2ej0018jx23hz3n6u59	2026-06-21 18:12:46.937	2026-06-21 18:12:46.937	1839902112235	ACTIVE	\N	\N
cmr254jj6001ijxct0thvp7fd	9090	จรรยาพร	นันตรี	FEMALE	11	ป.5/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420501276909	ACTIVE	\N	\N
cmr254jj6001jjxctvt06lll6	9392	พิชญธิดา	คำนุชิต	FEMALE	11	ป.5/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900941602	ACTIVE	\N	\N
cmr254jj6001kjxct1wt4ieey	9321	ชญาดา	จันทะคุณ	FEMALE	11	ป.5/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420501275571	ACTIVE	\N	\N
cmr254jj6001ljxct3dsq8br7	9031	ธวัลรัตน์	เรื่องรุ่งโรจน์	FEMALE	11	ป.5/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1118700296799	ACTIVE	\N	\N
cmr254jj6001mjxcttgoon3hz	8814	สร้อยสลา	แซ่เถา	FEMALE	11	ป.5/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420501282348	ACTIVE	\N	\N
cmr254jj6001njxctguuj6dv1	9127	ธนัญกรณ์	เทียงดาห์	MALE	10	ป.5/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1102170231070	ACTIVE	\N	\N
cmr254jj6001ojxct93uhsc2s	8808	ศิวะดนัย	สุนาทร	MALE	11	ป.5/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900952183	ACTIVE	\N	\N
cmr254jj6001pjxct30c1mgbd	8552	ชุติมา	อินพรหม	FEMALE	12	ป.6/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429600028529	ACTIVE	\N	\N
cmr254jj6001qjxct1t13zel2	9408	ภาณุวัฒน์	จันทะแจ่ม	MALE	12	ป.6/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1399900535117	ACTIVE	\N	\N
cmr254jj6001rjxctwo94bb0e	9410	รพีพัทร	นันทะพันธ์	MALE	12	ป.6/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1169200144575	ACTIVE	\N	\N
cmr254jj6001sjxctbrd5u4o4	9297	ณัฎฐธิดา	วิลัยล้า	FEMALE	12	ป.6/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1427900013169	ACTIVE	\N	\N
cmr254jj6001tjxct70n7ucdd	8280	ธนภัทร	ราชสีห์	MALE	12	ป.6/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1409904394509	ACTIVE	\N	\N
cmr254jj6001ujxctg4rj6nid	9414	จุฑารัตน์	ชัยกุลรัตน์	FEMALE	12	ป.6/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1279400037585	ACTIVE	\N	\N
cmr254jj6001vjxctb0xb16xc	8698	ก้องฟ้า	คำแก้ว	MALE	12	ป.6/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1199600568925	ACTIVE	\N	\N
cmr254jj6001wjxctpjg6xpx8	9417	จิราวรรณ	ปิยะนันท์	FEMALE	12	ป.6/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1412101116591	ACTIVE	\N	\N
cmr254jj6001xjxctxl5hi4td	9424	ชนัญธิดา	คำนุชิต	FEMALE	12	ป.6/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900904910	ACTIVE	\N	\N
cmr254jj6001yjxctpb8vh5gl	9317	ณัฐธิดา	แซ่เถา	FEMALE	12	ป.6/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1500201388077	ACTIVE	\N	\N
cmr254jj6001zjxcty6l1f2m2	9429	ณิชาภัทร	พันแก่น	FEMALE	12	ป.6/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1119902852791	ACTIVE	\N	\N
cmr254jj60020jxctuhdrxbok	9427	นันทัชพร	โฉมทนงค์	FEMALE	12	ป.6/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1419903022390	ACTIVE	\N	\N
cmr254jj60021jxct8e2jqy0p	9138	ภานุวัฒน์	สำแดงเดช	MALE	12	ป.6/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1390501129907	ACTIVE	\N	\N
cmr254jj60022jxctn4iispfx	9139	ประวิทย์	สีแก้ว	MALE	12	ป.6/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1361400113917	ACTIVE	\N	\N
cmr254jj60023jxctwd7irxur	9318	ณัฐณิชา	แซ่เถา	FEMALE	12	ป.6/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1500201388085	ACTIVE	\N	\N
cmr254jj60024jxct0np4tbk8	9426	ปัทมพร	ลุนะหา	FEMALE	12	ป.6/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900879567	ACTIVE	\N	\N
cmr254jj60025jxct741n3p4j	8829	คำนึงนิจ	ทรงศิริวงศ์	FEMALE	12	ป.6/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420501268175	ACTIVE	\N	\N
cmr254jj60026jxctqe54xgl5	9419	กฤษณพงศ์	สะดาแนน	MALE	12	ป.6/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900919470	ACTIVE	\N	\N
cmr254jj60027jxct36hjoqdt	8605	ชุติมา	ทองปน	FEMALE	13	ม.1/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1417300080876	ACTIVE	\N	\N
cmr254jj60028jxcty4paqbmo	7955	วรกานต์	ทัพศรีรัก	FEMALE	12	ม.1/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900852928	ACTIVE	\N	\N
cmr254jj60029jxct05or0ma1	9437	วราธร	ศรเสนา	MALE	13	ม.1/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1319800682380	ACTIVE	\N	\N
cmr254jj6002ajxct2ybkqca0	8845	นันทัชพร	ภะวัง	FEMALE	12	ม.1/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1417300086858	ACTIVE	\N	\N
cmr254jj6002bjxctnbqb8fw7	9447	ศิริพร	ประชานัน	FEMALE	13	ม.1/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1479901083651	ACTIVE	\N	\N
cmr254jj6002cjxctg6t5rr8z	9454	ดาราวรรณ	พลเสณีย์	FEMALE	13	ม.1/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1219901490371	ACTIVE	\N	\N
cmr254jj6002djxctpng681vy	9012	สุภารัตน์	อโนรัตน์	FEMALE	13	ม.1/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1399400104290	ACTIVE	\N	\N
cmr254jj7002ejxctdh6ru24c	9474	มนรดา	มะลัยคำ	FEMALE	13	ม.1/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	2730701004118	ACTIVE	\N	\N
cmr254jj7002fjxct0wnn4y6u	9475	กิตติกานต์	โสมาศรี	FEMALE	13	ม.1/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420901442032	ACTIVE	\N	\N
cmr254jj7002gjxct30bu8lbq	9036	สุภาพร	ผางสา	FEMALE	13	ม.1/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900854041	ACTIVE	\N	\N
cmr254jj7002hjxctj2eqtt02	9497	คัทรียา	นาเมืองรักษ์	FEMALE	13	ม.1/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1468100046411	ACTIVE	\N	\N
cmr254jj7002ijxctpfcaqnao	9286	วรภพ	จันทะคุณ	MALE	13	ม.1/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900868581	ACTIVE	\N	\N
cmr254jj7002jjxctlupbi8w4	9518	อรพินท์	เชื้อไพบูลย์	FEMALE	12	ม.1/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1409600552961	ACTIVE	\N	\N
cmr254jj7002kjxctnzyfru1y	9505	พีรดนย์	อุทัยวัฒน์	MALE	12	ม.1/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1419902986212	ACTIVE	\N	\N
cmr254jj7002ljxct56w0r9pl	9506	นฤรงค์	คามะเชียงพิญ	MALE	13	ม.1/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1419902957204	ACTIVE	\N	\N
cmr254jj7002mjxctz289p462	9502	ภัทรดนัย	วิโทจิตร	MALE	12	ม.1/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1219400068171	ACTIVE	\N	\N
cmr254jj7002njxctw03m3kv0	9514	ชุติกาญจน์	วิเศษวัน	FEMALE	13	ม.1/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1416200011502	ACTIVE	\N	\N
cmr254jj7002ojxct7oqv16mz	9445	ปณิตา	บุรีเพีย	FEMALE	13	ม.1/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1200901686545	ACTIVE	\N	\N
cmr254jj7002pjxctyevwpk8i	9057	ณวรรษภณ	วงศ์รักษ์พิมพ์	MALE	14	ม.1/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1419902862483	ACTIVE	\N	\N
cmr254jj7002qjxctxjyisl8l	9508	อภิชัย	โนนศรี	MALE	13	ม.1/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1399900482013	ACTIVE	\N	\N
cmr254jj7002rjxctanv8gs8c	9500	พิพัฒน์พล	ผันผ่อน	MALE	13	ม.1/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1399400103188	ACTIVE	\N	\N
cmr254jj7002sjxctktxnj5fz	8178	อาทิตย์	ทิพย์อาสน์	MALE	13	ม.1/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900876916	ACTIVE	\N	\N
cmr254jj7002tjxctms5epztx	9051	ทยาทร	แซ่หลอ	MALE	12	ม.1/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420501265443	ACTIVE	\N	\N
cmr254jj7002ujxct3xaeidb6	9503	ธนสิทธิ์	ทับทิมแดง	MALE	14	ม.1/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1409600522761	ACTIVE	\N	\N
cmr254jj7002vjxctop3e7v09	9443	กุลิสรา	แสนยากุล	FEMALE	13	ม.1/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1671100164904	ACTIVE	\N	\N
cmr254jj7002wjxctfyr3g1vg	9510	กฤตภัค	แซ่หลอ	MALE	12	ม.1/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420501264111	ACTIVE	\N	\N
cmr254jj7002xjxctn1uw6a80	9155	ณัฐวัฒน์	นามคุณ	MALE	16	ม.2/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1341501515581	ACTIVE	\N	\N
cmr254jj7002yjxct9nv0lmyk	8866	เทพทัต	นามาจอมศรี	MALE	14	ม.2/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1417300077832	ACTIVE	\N	\N
cmr254jj7002zjxctn6jn7zey	9184	ธนิดา	คำไพเลื่อน	FEMALE	14	ม.2/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900817651	ACTIVE	\N	\N
cmr254jj70030jxct40ofpuia	8304	สนธยา	เมขุนทด	MALE	16	ม.2/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1308200121181	ACTIVE	\N	\N
cmr254jj70031jxctez0qlkln	9182	รุ่งวรินทร์	บุตรโสม	FEMALE	14	ม.2/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1419902822597	ACTIVE	\N	\N
cmr254jj70032jxctatwgtpr0	9208	ปนัดดา	ไวชมภู	FEMALE	14	ม.2/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900799563	ACTIVE	\N	\N
cmr254jj70033jxctclizgpto	7747	ธนิสรา	จันทนา	FEMALE	14	ม.2/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1409904161989	ACTIVE	\N	\N
cmr254jj70034jxct7ndptjf1	9534	วีรพงค์	คำสอาด	MALE	13	ม.2/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1409600537873	ACTIVE	\N	\N
cmr254jj70035jxctoqk9yw3k	9203	สุประวี	แซ่เถา	FEMALE	13	ม.2/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420501248930	ACTIVE	\N	\N
cmr254jj70036jxctjseudr3n	9536	พิรดา	ถนอมจิตดี	FEMALE	13	ม.2/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1500701512885	ACTIVE	\N	\N
cmr254jj70037jxctlgbgsobx	9204	ณัฐธิดา	เสนาผดุง	FEMALE	13	ม.2/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420800130701	ACTIVE	\N	\N
cmr254jj70038jxctjbykzfgb	8344	สุทธิดา	สมัคร์ราช	FEMALE	14	ม.2/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1399900457345	ACTIVE	\N	\N
cmr254jj70039jxctczd3obvs	9258	ฐานิดา	สอนสุภาพ	FEMALE	13	ม.2/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1102004390139	ACTIVE	\N	\N
cmr254jj7003ajxct6d05b5cf	9542	พีรพงศ์	แซ่งสง	MALE	13	ม.2/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420501257581	ACTIVE	\N	\N
cmr254jj7003bjxctsyxzrora	9228	ณัฏฐณิชา	สอนฤทธิ์	FEMALE	14	ม.2/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900806705	ACTIVE	\N	\N
cmr254jj7003cjxctipojt240	9229	สุพิชชา	แซ่สง	FEMALE	13	ม.2/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1671100163975	ACTIVE	\N	\N
cmr254jj7003djxctqlqpcyzc	9227	รินนภา	จันทะคุณ	FEMALE	13	ม.2/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420501255626	ACTIVE	\N	\N
cmr254jj7003ejxctr1w3ozma	8854	วัชระ	แซ่ซ้ง	MALE	13	ม.2/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1659700070894	ACTIVE	\N	\N
cmr254jj7003fjxctxc8ffa6t	9091	ศิวกร	นันตรี	MALE	13	ม.2/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420501254948	ACTIVE	\N	\N
cmr254jj7003gjxctomi8egy6	9209	กษิดิศ	จันทะคุณ	MALE	13	ม.2/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900822549	ACTIVE	\N	\N
cmr254jj7003hjxct5gqfx5lx	9235	ทศกมล	สาริกาพงษ์	FEMALE	14	ม.3/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900776083	ACTIVE	\N	\N
cmr254jj7003ijxctjbh9avxi	8886	ชลลดา	เฮ้าโฮม	FEMALE	14	ม.3/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1399900427276	ACTIVE	\N	\N
cmr254jj8003jjxctz8xdvrl3	8909	สุภาวณี	บัวระเพชร	FEMALE	15	ม.3/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900772991	ACTIVE	\N	\N
cmr254jj8003kjxctrdrhhw0v	8592	ศุฑิษา	พุฒซ้อน	FEMALE	14	ม.3/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1260401244977	ACTIVE	\N	\N
cmr254jj8003ljxctn2m88vr9	8905	อริศรา	เนื่องด้วย	FEMALE	15	ม.3/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1399400096301	ACTIVE	\N	\N
cmr254jj8003mjxctjqsm5fml	8902	อัจราวดี	ผองแก้ว	FEMALE	14	ม.3/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900764751	ACTIVE	\N	\N
cmr254jj8003njxct1yfejuff	9549	เพชรลดา	สูงสุริยศ	FEMALE	15	ม.3/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1869900827831	ACTIVE	\N	\N
cmr254jj8003ojxctgovae9fb	8899	พิสินี	แซ่หว้า	FEMALE	14	ม.3/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420501247780	ACTIVE	\N	\N
cmr254jj8003pjxct8rwa06d9	8908	วรกานต์	แซ่ลี	FEMALE	14	ม.3/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420501244934	ACTIVE	\N	\N
cmr254jj8003qjxctfrbnb19r	8910	กมลชนก	สามาฐลำ	FEMALE	15	ม.3/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1118700202042	ACTIVE	\N	\N
cmr254jj8003rjxctxia500wk	8918	พงศพัค	จันทร์โท	MALE	14	ม.3/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1399900409715	ACTIVE	\N	\N
cmr254jj8003sjxctz75d4m0f	9285	ไชยนิวัตร	นามแดง	MALE	15	ม.3/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1104200750454	ACTIVE	\N	\N
cmr254jj8003tjxctpex96m2r	8924	สุกัญญา	พิมพ์แน่น	FEMALE	14	ม.3/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1399900433454	ACTIVE	\N	\N
cmr254jj8003ujxctotiq1zwy	9259	ณิดา	ปลัดจ่า	FEMALE	14	ม.3/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1407300031646	ACTIVE	\N	\N
cmr254jj8003vjxctkj6m9wt8	8168	นาขวัญ	แซ่หลอ	FEMALE	14	ม.3/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420501245485	ACTIVE	\N	\N
cmr254jj8003wjxct4scxdfcj	7214	วรวัฒน์	เต่าทอง	MALE	17	ม.4/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1361300206905	ACTIVE	\N	\N
cmr254jj8003xjxct0kzvzjli	8611	สเปน	สวัสดิ์มิ่ง	MALE	16	ม.4/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1650101148693	ACTIVE	\N	\N
cmr254jj8003yjxctgb8nm2ik	9095	ชยาภรณ์	โพธิ์แก้ว	FEMALE	16	ม.4/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900734054	ACTIVE	\N	\N
cmr254jj8003zjxctgslefl05	8979	อรจิรา	แซ่ว่าง	FEMALE	16	ม.4/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1638900070650	ACTIVE	\N	\N
cmr254jj80040jxct7z0rgqa7	7979	ววรนุช	แซ่หลอ	FEMALE	15	ม.4/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420501237016	ACTIVE	\N	\N
cmr254jj80041jxctmnla9ma7	7768	จุฑามาศ	แซ่สง	FEMALE	16	ม.4/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1670401303571	ACTIVE	\N	\N
cmr254jj80042jxcttwpznq8q	9039	ปารญา	ชำนาญรบ	FEMALE	15	ม.4/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1419902712953	ACTIVE	\N	\N
cmr254jj80043jxctb9ly8dom	8616	ทิชานันท์	พานทอง	FEMALE	16	ม.4/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429300042461	ACTIVE	\N	\N
cmr254jj80044jxct1earz6e1	8460	มินฑิตา	หาจำปา	FEMALE	17	ม.4/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900683867	ACTIVE	\N	\N
cmr254jj80045jxctego6v6ne	8625	อรณิชา	ชาทอง	FEMALE	16	ม.4/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1399000083139	ACTIVE	\N	\N
cmr254jj80046jxct3s834408	9564	กุลณัฐ	เถื่อนมา	FEMALE	15	ม.4/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429500028233	ACTIVE	\N	\N
cmr254jj80047jxct6iaq1r3y	8357	อรจิรา	บุตรอด	FEMALE	16	ม.4/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1468400033021	ACTIVE	\N	\N
cmr254jj80048jxctsdu3uoop	9577	จุฑามาศ	พิลา	FEMALE	15	ม.4/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420800127280	ACTIVE	\N	\N
cmr254jj80049jxct1rj1qewz	9576	นันยารัตน์	ผุยทา	FEMALE	16	ม.4/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1427900000156	ACTIVE	\N	\N
cmr254jj8004ajxct2i9jrhd6	9583	ภัทรภร	ปัญญายาว	FEMALE	15	ม.4/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1101000336228	ACTIVE	\N	\N
cmr254jj8004bjxct6ztt3jio	9255	ณัฐณิชา	พรรเพ็ช	FEMALE	15	ม.4/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900734348	ACTIVE	\N	\N
cmr254jj8004cjxctzsdr2b2b	8959	รัชนีกร	อุทอง	FEMALE	17	ม.6/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1104301166383	ACTIVE	\N	\N
cmr254jj8004djxctu66tc348	8954	เขมจิรา	เปี่ยมสา	FEMALE	17	ม.6/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1399900345687	ACTIVE	\N	\N
cmr254jj8004ejxctcbrfp50r	8281	ประภาสิริ	สายจันดา	FEMALE	17	ม.6/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1670401296655	ACTIVE	\N	\N
cmr254jj8004fjxctz1wc7cwl	8054	วิยดา	หาระดี	FEMALE	19	ม.6/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1399200037581	ACTIVE	\N	\N
cmr254jj8004gjxct2tnvqv4u	6764	ทนงศักดิ์	แซ่วื้อ	MALE	17	ม.6/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1650201203050	ACTIVE	\N	\N
cmr254jj8004hjxctedpu9yzb	7556	นวพล	สุขตะคุ	MALE	17	ม.6/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1307200037163	ACTIVE	\N	\N
cmr254jj8004ijxct6cd2ylyk	7782	อัมรินทร์	ทุมโยมา	MALE	17	ม.6/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900678561	ACTIVE	\N	\N
cmr254jj8004jjxctmjhvdgji	8228	ธีรนันท์	สุวรรณ	MALE	18	ม.6/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1481100070758	ACTIVE	\N	\N
cmr254jj8004kjxctcm1579ne	7564	ธัญวลัย	น้อยสิมมะ	FEMALE	18	ม.6/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420501215969	ACTIVE	\N	\N
cmr254jj8004ljxct0nm1kdag	7787	พลอยอันดา	ผดุงโกเม็ด	FEMALE	18	ม.6/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420501215985	ACTIVE	\N	\N
cmr254jj8004mjxct60avukf8	8469	วิภาวี	แสนผุ	FEMALE	17	ม.6/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1219700063247	ACTIVE	\N	\N
cmr254jj8004njxctb05soxf1	8229	กมลชนก	สิงห์ชมภู	FEMALE	17	ม.6/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1219901185676	ACTIVE	\N	\N
cmr254jj8004ojxctr9eyx073	8257	หยาดทิพย์	เกษทองมา	FEMALE	18	ม.6/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1249900891453	ACTIVE	\N	\N
cmr254jj9004pjxcts1r3ba26	9103	ภิญญาพัชญ์	คำแก้ว	FEMALE	14	ม.3/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1629900951380	ACTIVE	\N	\N
cmr254jj9004qjxctccn4l6d0	8942	เขมณีย์	ทรงศิริวงค์	FEMALE	14	ม.3/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420501248000	ACTIVE	\N	\N
cmr254jj9004rjxctv7g9cke4	9072	นลพรรณ	ชั้นพรม	FEMALE	17	ม.5/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1819100031926	ACTIVE	\N	\N
cmr254jj9004sjxct5yjazz84	8640	นัฐพล	จันทะเสน	MALE	17	ม.5/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900686114	ACTIVE	\N	\N
cmr254jj9004tjxctkbasrjun	8787	ปริญญา	เป็ะชาญ	MALE	16	ม.5/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1409600489542	ACTIVE	\N	\N
cmr254jj9004ujxctlqakkxx1	7907	ศุภศิริ	บัวทับ	FEMALE	17	ม.5/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1419902637935	ACTIVE	\N	\N
cmr254jj9004vjxctele0ln6q	8384	ศศิภา	นภารุ่งเรือง	FEMALE	17	ม.5/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1639600018700	ACTIVE	\N	\N
cmr254jj9004wjxct9wavr8x8	8639	ธศร	ฉิมนอก	FEMALE	17	ม.5/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1409903753718	ACTIVE	\N	\N
cmr254jj9004xjxctf82maoas	8783	นันต์ทิตา	ศักดิ์เจริญชัยกุล	FEMALE	16	ม.5/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420501229765	ACTIVE	\N	\N
cmr254jj9004yjxctkqrsx4z0	8784	เดือนดารา	แซ่หลอ	FEMALE	16	ม.5/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420501230810	ACTIVE	\N	\N
cmr254jj9004zjxct8y1cnv8l	8785	นันท์ฤดี	โรจน์ทวีกุล	FEMALE	16	ม.5/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420501231301	ACTIVE	\N	\N
cmr254jj90050jxctgh6bhswf	9024	จารุวรรณ	อมศรี	FEMALE	17	ม.5/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1399400084868	ACTIVE	\N	\N
cmr254jj90051jxcthq83q8vy	9271	กัญญาณัฐ	แซ่ยั้ง	FEMALE	16	ม.5/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1638900065087	ACTIVE	\N	\N
cmr254jj90052jxct91t14y6y	8387	ศุภสรา	ไชยคีนี	FEMALE	18	ม.5/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429300038448	ACTIVE	\N	\N
cmr254jj90053jxcterfpk1zl	9274	ธันยพร	พรมพุทธา	FEMALE	17	ม.5/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420800125287	ACTIVE	\N	\N
cmr254jj90054jxcte8fdkrui	7777	โรจน์ศักดิ์	บริบูรณ์	MALE	18	ม.5/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1306200089375	ACTIVE	\N	\N
cmr254jj90055jxct502vj8jp	8828	ปณิตา	บุญสร้าง	FEMALE	12	ป.6/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1909804008742	ACTIVE	\N	\N
cmr254jj90056jxct8zyd72or	9406	ฤทธิ์สกร	สวรรค์	MALE	12	ป.6/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1428700055144	ACTIVE	\N	\N
cmr254jj90057jxctwje3v43w	9140	ธรรศธนัญ	เทียงดาห์	FEMALE	12	ป.6/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1102004638505	ACTIVE	\N	\N
cmr254jj90058jxctbkeet4dr	9431	เพชรรัตน์	บุญประกอบ	FEMALE	12	ป.6/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1209702969464	ACTIVE	\N	\N
cmr254jj90059jxctbt29cczv	9432	อาธิติญา	สีแก่นเชิน	FEMALE	12	ป.6/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420400170919	ACTIVE	\N	\N
cmr254jj9005ajxctt7n7gdhw	9421	จิรายุ	แสงจันทร์	MALE	12	ป.6/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1399900525855	ACTIVE	\N	\N
cmr254jj9005bjxctzjtz49w2	9422	นันทนนท์	อินทร์หาญ	MALE	12	ป.6/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1102400292776	ACTIVE	\N	\N
cmr254jj9005cjxctxj2sae3q	9420	รฐนนท์	ขะพินิจ	MALE	12	ป.6/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900925267	ACTIVE	\N	\N
cmr254jj9005djxctrkqpkwer	9448	วรรณวิสา	แย้มสำรวล	FEMALE	12	ม.1/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1409904276450	ACTIVE	\N	\N
cmr254jj9005ejxct3dshgd2q	9476	สิรินทรา	แซ่สง	FEMALE	14	ม.1/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1671100166079	ACTIVE	\N	\N
cmr254jj9005fjxctayssosxa	9468	สุวิณี	วงพิลา	FEMALE	13	ม.1/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900847011	ACTIVE	\N	\N
cmr254jj9005gjxctn1kvfmin	8998	จิราภา	พุทธเสน	FEMALE	13	ม.1/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1409904244477	ACTIVE	\N	\N
cmr254jj9005hjxctyx0mufj6	9494	เจนจิรา	บุญเลิศ	FEMALE	13	ม.1/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1929901515173	ACTIVE	\N	\N
cmr254jj9005ijxctepqqasb1	8834	ชลกานต์	วงศ์น้อย	FEMALE	14	ม.1/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1419902902914	ACTIVE	\N	\N
cmr254jj9005jjxct0e2lioa5	9491	ปานรดา	เสนานิคม	FEMALE	12	ม.1/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1399900519529	ACTIVE	\N	\N
cmr254jj9005kjxctdbv3cldg	9517	ทิพปภา	พลร่ม	FEMALE	13	ม.1/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1100202131341	ACTIVE	\N	\N
cmr254jj9005ljxctslhf9zow	9511	เจติยา	ศรีลาอาจ	FEMALE	13	ม.1/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1417300080418	ACTIVE	\N	\N
cmr254jj9005mjxcteseajcaz	9450	ณัฐริดา	มีคุณ	FEMALE	12	ม.1/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1417300085801	ACTIVE	\N	\N
cmr254jj9005njxct0ltbxrfq	9162	ชริกา	ชุมปัญญา	FEMALE	13	ม.2/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1218500055011	ACTIVE	\N	\N
cmr254jj9005ojxctk6aeclko	9230	อภิชญา	โพธิ์อนุศาสน์	FEMALE	14	ม.2/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1390300105610	ACTIVE	\N	\N
cmr254jj9005pjxctteobosx4	9221	ยิ่งลักษณ์	มุกอาษา	FEMALE	14	ม.2/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900814414	ACTIVE	\N	\N
cmr254jj9005qjxctyhfgshq4	9219	พิญชธิดา	แก้วมงคล	FEMALE	13	ม.2/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1417300080175	ACTIVE	\N	\N
cmr254jj9005rjxctiueb7u5g	9216	ฐิติศักดิ์	สิงห์โตทอง	MALE	13	ม.2/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1467800054220	ACTIVE	\N	\N
cmr254jj9005sjxcthtvtizdq	9215	ชาตรี	นามมนตรี	MALE	14	ม.2/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1149901274661	ACTIVE	\N	\N
cmr254jj9005tjxctxewv1rya	9233	รัชฎา	เมืองทา	FEMALE	14	ม.3/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1959800269258	ACTIVE	\N	\N
cmr254jj9005ujxct1acqdna9	8885	ชญาดา	เรืองอนันต์	FEMALE	15	ม.3/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1421300077152	ACTIVE	\N	\N
cmr254jja005vjxct70xecv9o	8710	ไอยรินทร์	ญานเสถียร	FEMALE	15	ม.3/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900787026	ACTIVE	\N	\N
cmr254jja005wjxctiumw4gx6	8590	สรนันท์	เฉลิมพงษ์	FEMALE	14	ม.3/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1679000133222	ACTIVE	\N	\N
cmr254jja005xjxct5pstbp3w	8354	ทับทิม	เสนาเงิน	FEMALE	14	ม.3/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1218700052180	ACTIVE	\N	\N
cmr254jja005yjxct6tr26hcf	8353	นาข้าว	พิลาสุข	FEMALE	15	ม.3/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900785244	ACTIVE	\N	\N
cmr254jja005zjxcth6i2sorj	8922	ขนิษา	ยอดผุด	FEMALE	15	ม.3/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1929901378851	ACTIVE	\N	\N
cmr254jja0060jxct05820s3l	9557	ชนรรทภรณ์	เกิดโพธิ์ทอง	FEMALE	14	ม.3/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1209000628136	ACTIVE	\N	\N
cmr254jja0061jxctqoe104vj	8926	กมลทิพย์	วังคีรี	FEMALE	14	ม.3/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420501245094	ACTIVE	\N	\N
cmr254jja0062jxct35ydfwe7	9565	ชรินรัตน์	วรจักร์	FEMALE	15	ม.4/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900733694	ACTIVE	\N	\N
cmr254jja0063jxctu1a6nkb5	9566	ชลธิชา	ชัยสงค์	FEMALE	15	ม.4/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1399000083546	ACTIVE	\N	\N
cmr254jja0064jxctfu6t21ls	8753	กชมล	แสงขาว	FEMALE	16	ม.4/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900760004	ACTIVE	\N	\N
cmr254jja0065jxct0sakw43p	9045	ธัญพร	บุญขันธ์	FEMALE	15	ม.4/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1399900420352	ACTIVE	\N	\N
cmr254jja0066jxct15e4wlkc	9574	กฏชพักตร์	การพงษ์	FEMALE	16	ม.4/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1427900000083	ACTIVE	\N	\N
cmr254jja0067jxctalxehres	9575	ปรีญานุช	เอละกานุ	FEMALE	17	ม.4/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1329901618041	ACTIVE	\N	\N
cmr254jja0068jxctentnbggv	8962	เทวิกา	สำราญ	FEMALE	18	ม.6/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1500401194144	ACTIVE	\N	\N
cmr254jja0069jxctwhb7t2vp	8232	เสาวภา	สีลาดเลา	FEMALE	17	ม.6/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1418600120181	ACTIVE	\N	\N
cmr254jja006ajxctab9fzoa0	8011	พรพิมล	โนนสุวรรณ	FEMALE	17	ม.6/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1399900344559	ACTIVE	\N	\N
cmr254jja006bjxctyhssqqft	8000	ณัฐนันท์	วรรณชาติ	FEMALE	17	ม.6/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1101000248426	ACTIVE	\N	\N
cmr254jja006cjxct8tc2ylem	8213	ทัตพิชา	สิงห์รักษ์	FEMALE	17	ม.6/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1249900934993	ACTIVE	\N	\N
cmr254jja006djxctcmhnrqvc	9026	นภาภรณ์	โยธี	FEMALE	15	ม.3/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1427900004909	ACTIVE	\N	\N
cmr254jja006ejxct0pf26040	8385	นงนภัส	แก้วทุ่ง	FEMALE	17	ม.5/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900690103	ACTIVE	\N	\N
cmr254jja006fjxctsrpkyaz5	9038	วราภรณ์	สิทธิ	FEMALE	17	ม.5/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1469900862206	ACTIVE	\N	\N
cmr254jja006gjxcth7ncanj6	9263	ณิชนันทน์	หนุนกลาง	FEMALE	16	ม.5/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1101700479561	ACTIVE	\N	\N
cmr254jja006hjxctyy6usdck	9272	ชลธาร	แสนภักดี	FEMALE	16	ม.5/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1399900392880	ACTIVE	\N	\N
cmr254jja006ijxct2hnajz42	8786	กฤษณา	วาระสิทธ์	FEMALE	17	ม.5/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1399400082644	ACTIVE	\N	\N
cmr254jja006jjxctjbrpodxx	9389	ภูมิภัทร	บุตรโยจันโท	MALE	11	ป.5/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900913862	ACTIVE	\N	\N
cmr254jja006kjxct32hn1kjl	9136	กรรณิกา	ขุนสันทัด	FEMALE	12	ป.6/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1419903052205	ACTIVE	\N	\N
cmr254jja006ljxctm2g689nn	9407	ทักษพล	โพธิ์จันทร์	MALE	12	ป.6/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1390501129761	ACTIVE	\N	\N
cmr254jja006mjxctisfb5pzj	9141	ธนพร	หนูช่วย	FEMALE	12	ป.6/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1909804113414	ACTIVE	\N	\N
cmr254jja006njxctwnviiryh	9525	กนกวรรณ์	สีหาคุณ	FEMALE	12	ป.6/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1408500079031	ACTIVE	\N	\N
cmr254jja006ojxct0sxd72c6	9470	ชนกนันท์	แสนโคตร	FEMALE	14	ม.1/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1409600519824	ACTIVE	\N	\N
cmr254jja006pjxctdqrlwhdt	9509	นนทนันท์	อินทร์หาญ	MALE	14	ม.1/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1102400277807	ACTIVE	\N	\N
cmr254jja006qjxctsx693uf5	9236	สุพัทชา	มโนธรรม	FEMALE	15	ม.3/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1368100085043	ACTIVE	\N	\N
cmr254jja006rjxcty8rk0tit	9234	ญาณภา	วงศ์ใหญ่	FEMALE	14	ม.3/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1619700043617	ACTIVE	\N	\N
cmr254jja006sjxcth7kvuqn4	7864	จักรพงศ์	พรหมบรรจง	MALE	15	ม.3/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1819900838093	ACTIVE	\N	\N
cmr254jja006tjxct50nal3zr	8363	ชลดา	สีหาภูธร	FEMALE	15	ม.4/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900731471	ACTIVE	\N	\N
cmr254jja006ujxct5n3k0suz	8364	นฤมล	สีหาภูธร	FEMALE	15	ม.4/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900731489	ACTIVE	\N	\N
cmr254jja006vjxctym6hgo8f	8607	ปวเรศ	ชาบุญเฮียง	MALE	15	ม.4/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1120300220500	ACTIVE	\N	\N
cmr254jja006wjxctjae4lmci	8201	อมรรัตน์	มหิพันธ์	FEMALE	17	ม.5/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900696098	ACTIVE	\N	\N
cmr254jja006xjxctrvbog7ot	7949	ชัยโรจน์	รักอาชญา	MALE	13	ม.1/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1103704961253	ACTIVE	\N	\N
cmr254jjb006yjxcttsje3ebg	8891	ธนวัฒน์	ปัดถาแก้ว	MALE	15	ม.3/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900772843	ACTIVE	\N	\N
cmr254jjb006zjxctj6g8mblk	9191	ทีปกร	มุกดาม่วง	MALE	15	ม.2/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1419902767839	ACTIVE	\N	\N
cmr254jjb0070jxctxlyg0hih	8476	อรรคเดช	เวียงอินทร์	MALE	11	ป.5/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900959391	ACTIVE	\N	\N
cmr254jjb0071jxctd7ohammf	9405	กัญญารัตน์	แก้วพล	FEMALE	11	ป.5/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1399900565041	ACTIVE	\N	\N
cmr254jjb0072jxct8zpc7k02	9316	พิมพ์ชนก	แก้วเหล่ายูง	FEMALE	12	ป.6/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1419903043958	ACTIVE	\N	\N
cmr254jjb0073jxcthzfo7nna	9451	ชุติกานต์	หอมจันทร์	FEMALE	13	ม.1/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	2399000001394	ACTIVE	\N	\N
cmr254jjb0074jxctjjgyxu84	9453	นันทัชพร	หลักทองคำ	FEMALE	13	ม.1/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1428700059352	ACTIVE	\N	\N
cmr254jjb0075jxctnwux8b0m	9452	เมธาพร	อ่อนละมุล	FEMALE	14	ม.1/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1399900487660	ACTIVE	\N	\N
cmr254jjb0076jxctab730zh9	9449	พัชรพร	พรมมี	FEMALE	13	ม.1/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1670401318071	ACTIVE	\N	\N
cmr254jjb0077jxctd0p8mqwn	9463	รัฐภูมิ	จันแสนเสีย	MALE	13	ม.1/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900863784	ACTIVE	\N	\N
cmr254jjb0078jxct3onpnz0j	9473	นัฐญา	เดชโฮม	FEMALE	13	ม.1/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1103200323415	ACTIVE	\N	\N
cmr254jjb0079jxctsb3x0yyd	9466	อธิวัฒน์	แซ่กือ	MALE	15	ม.1/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1240401245361	ACTIVE	\N	\N
cmr254jjb007ajxctk1t57uam	9330	สุเทพ	คุณดา	MALE	13	ม.1/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1139600698322	ACTIVE	\N	\N
cmr254jjb007bjxctps5wn0fy	9456	ธีรเดช	ศรีมหาไชย	MALE	13	ม.1/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900879559	ACTIVE	\N	\N
cmr254jjb007cjxctnrk94efh	9523	เยาวรัตน์	คำสาร	FEMALE	12	ม.1/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1409600558765	ACTIVE	\N	\N
cmr254jjb007djxct8738ahfu	9522	ศิราภา	ทิพโยธา	FEMALE	12	ม.1/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1419902938030	ACTIVE	\N	\N
cmr254jjb007ejxctj7qs658w	9495	กรชนก	วรรณชัย	FEMALE	13	ม.1/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1409600559681	ACTIVE	\N	\N
cmr254jjb007fjxct0gm73973	9493	ณัชชา	ทุมสวัสดิ์	FEMALE	13	ม.1/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1730201537658	ACTIVE	\N	\N
cmr254jjb007gjxctsolxfm1x	9050	ศิรินณา	ศรีสุธรรม	FEMALE	14	ม.1/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1100801742932	ACTIVE	\N	\N
cmr254jjb007hjxctbrvthkrs	9490	อัครพล	บุญพรม	MALE	15	ม.1/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1190201153197	ACTIVE	\N	\N
cmr254jjb007ijxcto4udvtd4	9487	วรเมธ	แสงวิไลย	MALE	14	ม.1/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1419902865962	ACTIVE	\N	\N
cmr254jjb007jjxct7rfv97tf	9481	พุฒิภัทร	พลเสน	MALE	13	ม.1/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1409600542940	ACTIVE	\N	\N
cmr254jjb007kjxctov5vt9p4	8694	ภารากร	เหลืองทอง	MALE	13	ม.1/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1849902502050	ACTIVE	\N	\N
cmr254jjb007ljxcth2xmnajg	9515	พรชิตา	วังคีรี	FEMALE	12	ม.1/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1421100130807	ACTIVE	\N	\N
cmr254jjb007mjxct0mlc9xpz	9516	ณัฐธิชา	ยอดโสดา	FEMALE	14	ม.1/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900842281	ACTIVE	\N	\N
cmr254jjb007njxctq0v70zao	8183	บัวริน	ยาบุษดี	FEMALE	14	ม.2/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1102300153707	ACTIVE	\N	\N
cmr254jjb007ojxctvqvbt60y	9154	กิตติพงศ์	มณีวงศ์	MALE	14	ม.2/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1399900484270	ACTIVE	\N	\N
cmr254jjb007pjxctsq9esh5l	9331	ปัทมา	ราชา	FEMALE	14	ม.2/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1240401267594	ACTIVE	\N	\N
cmr254jjb007qjxctgfnio1o6	9528	ธนพล	พิกุลศรี	MALE	14	ม.2/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900841381	ACTIVE	\N	\N
cmr254jjb007rjxctkoflpezu	9167	ธีระดา	ศรีบุรินทร์	FEMALE	14	ม.2/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420501256584	ACTIVE	\N	\N
cmr254jjb007sjxct2rppw13a	9530	วรกัญญา	บุตรวงศ์	FEMALE	13	ม.2/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1103101252692	ACTIVE	\N	\N
cmr254jjb007tjxctofpwkugb	8573	นันธิดา	จันทบุรี	FEMALE	14	ม.2/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1409904078844	ACTIVE	\N	\N
cmr254jjb007ujxctgyjiw6u1	9186	ขวัญสุดา	เกี้ยงวัน	FEMALE	13	ม.2/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1419902917415	ACTIVE	\N	\N
cmr254jjb007vjxctnj59chg2	8865	พรพิชิต	ศรีชานารถ	MALE	13	ม.2/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1421100129949	ACTIVE	\N	\N
cmr254jjb007wjxctaitrqcxo	9188	สุวิชาดา	ภาวะหาให	FEMALE	15	ม.2/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1399000087681	ACTIVE	\N	\N
cmr254jjb007xjxctlylftu0k	9172	ธนากร	เนื่องชมภู	MALE	16	ม.2/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1399900369161	ACTIVE	\N	\N
cmr254jjb007yjxct45npw5si	9187	ศรสวรรค์	เหล่าสุพระ	FEMALE	15	ม.2/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900779805	ACTIVE	\N	\N
cmr254jjb007zjxctzp7775xa	9193	สันชัย	แซ่หลอ	MALE	14	ม.2/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420501249821	ACTIVE	\N	\N
cmr254jjb0080jxct5110esg8	9535	รดา	บุ่งนาม	FEMALE	14	ม.2/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1469900972311	ACTIVE	\N	\N
cmr254jjb0081jxctkjjaa5rc	7737	สัณหณัฐ	วงษาวิชัยยุทธ	MALE	14	ม.2/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420400170773	ACTIVE	\N	\N
cmr254jjc0082jxct0l7q8r1n	8856	อนงค์ชิตา	ปัดนาถา	FEMALE	14	ม.2/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1219700080397	ACTIVE	\N	\N
cmr254jjc0083jxctmb6u8izj	9214	ณัฐพล	ปิ่นเกตุ	MALE	16	ม.2/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1159900565034	ACTIVE	\N	\N
cmr254jjc0084jxct5y958p7e	9543	ณัฐพัชร์	ปลื้มใจ	FEMALE	13	ม.2/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1409600536834	ACTIVE	\N	\N
cmr254jjc0085jxctor1w3rae	9541	พิภาภรณ์	เหล่ามา	FEMALE	14	ม.2/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1398900002631	ACTIVE	\N	\N
cmr254jjc0086jxctwauc8kfx	9539	พรพระพรหม	ชัยฤทธิ์	FEMALE	13	ม.2/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1417300078251	ACTIVE	\N	\N
cmr254jjc0087jxctpuh1qo85	9540	วายุ	พิทักษ์วาปี	MALE	14	ม.2/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1412101116086	ACTIVE	\N	\N
cmr254jjc0088jxctqw69b6zt	9538	อภิชญา	ตุ่นแก้ว	FEMALE	14	ม.2/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1539300035359	ACTIVE	\N	\N
cmr254jjc0089jxct1qfno2jq	9546	ญาณิศา	ซอมแก้ว	FEMALE	14	ม.3/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900785856	ACTIVE	\N	\N
cmr254jjc008ajxctbodzdw0a	9544	ศุกลวัฒน์	เพียรหัด	MALE	15	ม.3/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1190201153863	ACTIVE	\N	\N
cmr254jjc008bjxctd3417f3c	9547	ยุภาดา	พุ่มทับทิม	FEMALE	15	ม.3/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1399400094898	ACTIVE	\N	\N
cmr254jjc008cjxctwy4crgs8	9048	ณัฐณิชา	แสนรักษา	FEMALE	15	ม.3/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1399400092526	ACTIVE	\N	\N
cmr254jjc008djxcthbmjpwxd	8888	รมิดา	ตรีกุล	FEMALE	14	ม.3/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1417400119952	ACTIVE	\N	\N
cmr254jjc008ejxct2ijbq871	8887	ปณิตา	มณีธรรม	FEMALE	13	ม.3/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900781257	ACTIVE	\N	\N
cmr254jjc008fjxcty5eaj4xg	9232	ราเชนท์	สุวรรณ	MALE	15	ม.3/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1849300149637	ACTIVE	\N	\N
cmr254jjc008gjxctj2zxrchv	8906	พิชญ์สีนี	ต้นพนม	FEMALE	10	ม.3/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420901433378	ACTIVE	\N	\N
cmr254jjc008hjxctzaizg30i	9554	ภัทรกร	ก้อมอ่อน	MALE	17	ม.3/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1416900000457	ACTIVE	\N	\N
cmr254jjc008ijxct6qorkwcl	9260	พัชรพล	รำไพ	MALE	15	ม.3/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1567700024000	ACTIVE	\N	\N
cmr254jjc008jjxctit0vvtr9	8920	สิรินันท์	ภักดีหลวง	FEMALE	15	ม.3/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900761051	ACTIVE	\N	\N
cmr254jjc008kjxct7wxe6h5h	8673	พุฒิพงษ์	พรหมอยู่	MALE	15	ม.3/3	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1839902224459	ACTIVE	\N	\N
cmr254jjc008ljxct81cn5vku	9248	กานต์ธิดา	ยุบลนารถ	FEMALE	17	ม.4/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420800124647	ACTIVE	\N	\N
cmr254jjc008mjxctnfljt48y	8636	ธัญชนก	ดีจ้อย	FEMALE	16	ม.4/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1628800035097	ACTIVE	\N	\N
cmr254jjc008njxctq6ry4k4q	9570	เต็มสิริ	แสงงาม	FEMALE	16	ม.4/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900722820	ACTIVE	\N	\N
cmr254jjc008ojxctiac8twqd	9582	อภิญญา	ชัชวาลย์	MALE	17	ม.4/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900723036	ACTIVE	\N	\N
cmr254jjc008pjxctym9rmi86	9102	ปัฐพร	ถาดดอน	FEMALE	15	ม.4/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1103704651661	ACTIVE	\N	\N
cmr254jjc008qjxct86matvwn	9569	พลอยประกาย	มิสา	FEMALE	15	ม.4/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1340501366194	ACTIVE	\N	\N
cmr254jjc008rjxct1hkdyxje	9581	พีรพล	ตองหว้าน	MALE	15	ม.4/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420901431481	ACTIVE	\N	\N
cmr254jjc008sjxctnpmykhmb	9573	มานิตา	ช่วยรักษา	FEMALE	16	ม.4/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1478800079371	ACTIVE	\N	\N
cmr254jjc008tjxctr64ejdgk	8960	นารีรัตน์	คำสา	FEMALE	18	ม.6/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1468000031790	ACTIVE	\N	\N
cmr254jjc008ujxctrek1f9uu	8958	ขวัญจิรา	ศรีน้อย	FEMALE	18	ม.6/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1417300049863	ACTIVE	\N	\N
cmr254jjc008vjxct5tl2gn1o	8648	ชลชญา	พรมพุทธา	FEMALE	18	ม.6/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900674451	ACTIVE	\N	\N
cmr254jjc008wjxct79sy0vsj	9245	ทิพยาภรณ์	เนาว์สนธ์	FEMALE	15	ม.3/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900762970	ACTIVE	\N	\N
cmr254jjc008xjxctsq4d14hz	9325	รัชดาภรณ์	พรมขรยาง	FEMALE	14	ม.3/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1399900437735	ACTIVE	\N	\N
cmr254jjc008yjxctu4g5esst	9328	จันทร์กระจ่างฟ้า	แสนศรี	FEMALE	14	ม.3/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1390501121418	ACTIVE	\N	\N
cmr254jjc008zjxctqm693s18	9560	ธนทัต	บุญสูง	MALE	14	ม.3/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1469900944172	ACTIVE	\N	\N
cmr254jjc0090jxctcvlxmcmk	9075	ตรีชฎา	ผ่องผาย	FEMALE	14	ม.3/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1399400093387	ACTIVE	\N	\N
cmr254jjc0091jxctmn826440	9097	อภิญญา	อินทิแสง	FEMALE	15	ม.3/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1439900703574	ACTIVE	\N	\N
cmr254jjc0092jxctnqt53ghu	8940	เบญจลักษณ์	ศักดิ์เจริญชัยกุล	FEMALE	14	ม.3/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420501248654	ACTIVE	\N	\N
cmr254jjc0093jxctwrykzvkw	8937	ภัทรวรรณ	แซ่เถา	FEMALE	14	ม.3/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1420501245167	ACTIVE	\N	\N
cmr254jjc0094jxcthlr57zdh	8721	ศิริรัตน์	ไพรสณฑ์	FEMALE	15	ม.3/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900801525	ACTIVE	\N	\N
cmr254jjd0095jxcthb3acy7x	8700	นฤมล	เหมเปา	FEMALE	14	ม.3/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1709800614640	ACTIVE	\N	\N
cmr254jjd0096jxct8eo8fuvo	8585	นภีภัทธ	แฝดสุระ	FEMALE	14	ม.3/4	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1129902288330	ACTIVE	\N	\N
cmr254jjd0097jxct6lmnp6es	6999	ดาราวดี	สีสุก	FEMALE	17	ม.5/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1959800248307	ACTIVE	\N	\N
cmr254jjd0098jxctdrh3tt60	7411	วรรณวิสา	คงดา	FEMALE	17	ม.5/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1102004064771	ACTIVE	\N	\N
cmr254jjd0099jxctfz2b6suv	8754	จารุวรรณ	ผลจันทร์	FEMALE	17	ม.5/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1949900722574	ACTIVE	\N	\N
cmr254jjd009ajxctyl5irdqn	9268	อรัชพร	รัตนวงษ์	FEMALE	17	ม.5/1	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1100801646852	ACTIVE	\N	\N
cmr254jjd009bjxct805du1q8	7547	ภาณุเดช	แซ่กือ	MALE	17	ม.5/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1639800411642	ACTIVE	\N	\N
cmr254jjd009cjxctfiibuqyf	8411	วราภรณ์	ชัยชนะทน	FEMALE	17	ม.5/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1429900689563	ACTIVE	\N	\N
cmr254jjd009djxcttfbwyhkz	8410	ธีรภัทร	พันธ์แน่น	MALE	16	ม.5/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1110201386124	ACTIVE	\N	\N
cmr254jjd009ejxct154gsjnu	9279	จิรวัฒน์	ชุ่มอินทร์จักร	MALE	16	ม.5/2	cmq0kjbpl0019jx236ppwjdv2	2026-07-01 13:57:55.549	2026-07-01 13:57:55.549	1409903888311	ACTIVE	\N	\N
\.


--
-- Data for Name: system_admin_whitelist; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_admin_whitelist (id, email, "isActive", "createdAt") FROM stdin;
cmp6j4rgt0001jxuipo9lusfo	kru.nangfahs@gmail.com	t	2026-05-15 06:21:40.494
cmpm5m3d20008jxgmnkkfdcsn	systemadmin@thainhf.org	t	2026-05-26 04:47:33.254
\.


--
-- Data for Name: teacher_invites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.teacher_invites (id, token, email, "firstName", "lastName", age, "userRole", "advisoryClass", "schoolId", "schoolRole", "projectRole", "invitedById", "expiresAt", "acceptedAt", "createdAt") FROM stdin;
cmp6jcbbk0013jxdf6dfhiig2	759599a50a865ddbe178987fcc58a65202cac6c318d7930776e110de3df50a2b	baitongxaxaxa1@gmail.com	yingyot	jiteiei	35	class_teacher	ม.1/2	cmp6j9hjm0005jxdfd9vm0g4e	ครูรวย	coordinate	cmp6j8ifp0002jxdffdiyvvw3	2026-05-22 06:27:32.816	2026-05-15 06:27:51.454	2026-05-15 06:27:32.817
cmp6jlwfw001jjxdfv326xxri	f6d43a1b46cd5e2ca831897fcdff4694ece136cdea8596fac0a90126bf293a49	yingyot111@test.com	ทดสอบ	นางฟ้า	45	school_admin	ทุกห้อง	cmp6j9hjm0005jxdfd9vm0g4e	ครูหนู	coordinate	cmp6j8ifp0002jxdffdiyvvw3	2026-05-22 06:35:00.091	2026-05-15 06:35:15.509	2026-05-15 06:35:00.092
cmq08v08l003ajxwnbldw0a45	56ad3be205e00140d66cbaad10d1c0fcc5662b6f033ca571c3a0faa8289ff4ca	wanwisa.t@thainhf.org	อารยา	นิวัฒน์	34	class_teacher	ม.4/1	cmpzr7zap002sjxwn1qukwz8i	ครูวิชาคณิตศาสตร์	coordinate	cmpzr4e32002ljxwnl4klwuhq	2026-06-12 01:27:14.42	\N	2026-06-05 01:27:14.421
cmq0kvf3b005mjx23964bxycc	5a49158d4e015e4650a37a3aca8c94e824f09fdbcda62a6e341ac94a03c23f95	saranya34164@gmail.com	นางสาวศรัญญา	ดวงอุปะ	24	school_admin	ทุกห้อง	cmq0kjrxw001ejx23detqolsk	ครูนางฟ้า	care	cmq0khs5m000wjx23jyhqhgkv	2026-06-12 07:03:29.062	2026-06-05 07:04:20.535	2026-06-05 07:03:29.064
cmq0ks2oa004sjx23adpk4q28	6ed7daeef7d03d7907c6eee85fbbf67459ecbe91d7770704223b68d7feebca9d	nakyoomg95@gmail.com	นางสาวมธุริน	วันทะวี	35	school_admin	ทุกห้อง	cmq0kga6m000ljx23ghh9yu87	ครูพยาบาล	care	cmq0kdx110004jx23k3lcvs0z	2026-06-12 07:00:53.001	2026-06-05 07:04:59.113	2026-06-05 07:00:53.002
cmq0kw5hj0060jx23stxuhv3z	2c19b7a8a737ab4f99d86cda5caf98d8fcbd2633de94bedd4e893ca06f5df122	payoon.1881@gmail.com	นายประยูร	มังกร	55	school_admin	ทุกห้อง	cmq0kj2ej0018jx23hz3n6u59	ผู้อำนวยการโรงเรียน	lead	cmq0kgjsg000njx23n27h0rcx	2026-06-12 07:04:03.27	2026-06-05 07:05:50.479	2026-06-05 07:04:03.271
cmq0kxj50006ejx23aqtab663	fd2530e340670e95705e0ca09193fd7633e7595cae50d641cf1dc472287735ab	witoon28012520@gmail.com	นายวิฑูลย์	แซมสีม่วง	50	school_admin	ทุกห้อง	cmq0kjrxw001ejx23detqolsk	ครูนางฟ้า	care	cmq0khs5m000wjx23jyhqhgkv	2026-06-12 07:05:07.619	2026-06-05 07:06:11.229	2026-06-05 07:05:07.62
cmq0kvxgo005wjx23f8yo970f	d1d7daf8c77ab1d976a869c3fd3bbe926add6c0e69aa7e55b2270271b9ef0ba1	pattayak.2512@gmail.com	นางพัทธยา	ชนะพันธ์	56	school_admin	ทุกห้อง	cmq0kjbpl0019jx236ppwjdv2	ผู้อำนวยการโรงเรียน	lead	cmq0kfz02000ijx23kh3yrfbs	2026-06-12 07:03:52.87	2026-06-05 07:06:11.7	2026-06-05 07:03:52.872
cmq0kyfxp006ijx23kvb1c9kb	6b745523280d60072b145984308d7c3e01c62106aab0e90a7b6e29e0def3d606	pongpisut.j@twsc.ac.th	นายพงศ์พิสุทธิ์	ใจคุณ	40	school_admin	ทุกห้อง	cmq0kj2ej0018jx23hz3n6u59	ครู	care	cmq0kgjsg000njx23n27h0rcx	2026-06-12 07:05:50.124	2026-06-05 07:06:43.201	2026-06-05 07:05:50.125
cmq0kypg7007cjx23mj13cuwt	b28937e37e40d553a8e6eec70ed2c68d5ce126af26c2180145acd784af66a01f	surasee1981@gmail.com	นายสุรสีห์	จันทร์แสงศรี	45	school_admin	ทุกห้อง	cmq0kjrxw001ejx23detqolsk	ครูนางฟ้า	care	cmq0khs5m000wjx23jyhqhgkv	2026-06-12 07:06:02.454	2026-06-05 07:07:30.409	2026-06-05 07:06:02.455
cmq0kz653007yjx23lhjsslr3	f8722e2fbea3915ec0b772ff6f2e3cb212168bf71ca1f479faf5e19fda6368fb	komon699@gmail.com	นายโกมล	ยงเพชร	30	school_admin	ทุกห้อง	cmq0kj2ej0018jx23hz3n6u59	ครู	care	cmq0kgjsg000njx23n27h0rcx	2026-06-12 07:06:24.087	2026-06-05 07:08:14.038	2026-06-05 07:06:24.088
cmq0kyqde007gjx239cuk5hbg	f4e595767c76182cedcd1bb3b5e6c47d50514cfc7a590ae0a5d6d240076b1fcb	naipaporn.v@thainhf.org	ลิน	ลาลาลิน	25	class_teacher	ม.2/1	cmpmdqjp8000pjxgmt4j3159q	ครูนางฟ้า	coordinate	cmpmdmbqv000kjxgmprk5t2o6	2026-06-12 07:06:03.649	2026-06-05 07:09:58.245	2026-06-05 07:06:03.651
cmq0l0vht009ejx23c74bxmpc	8d2e1ecc094f76afe652688d3cc5abaac7c1159260e7e5dea0d370d37bdf8550	nurheedayah041139@gmail.com	นูรฮีดายะห์	โดดะนะ	31	school_admin	ทุกห้อง	cmq0khbql000ujx237a6k27or	ครูประจำชั้น	care	cmq0ke15g0007jx23k3ypiimb	2026-06-12 07:07:43.6	2026-06-05 07:17:42.712	2026-06-05 07:07:43.601
cmq6ghd20000gjxrxtchy3yzl	501c5ee7d6b4036cae87b5d8e9c02147ee66f509f51f4ce2516ee5f27d4590b7	baitong.yingyot@gmail.com	ครูรวย	สวยไม่สร่าง	40	class_teacher	ม.1/4	cmp6j9hjm0005jxdfd9vm0g4e	ว่าง	care	cmp6j8ifp0002jxdffdiyvvw3	2026-06-16 09:47:11.831	2026-06-09 09:48:01.838	2026-06-09 09:47:11.833
cmqeyougp0056jxop53rhgi0i	98db10130badeafca3ba74096766413de7854f66c20b5eb3d38850e70dfd28a9	usmamamat1990@gmail.com	อุสมา	มามะ	33	class_teacher	2/1	cmq0khbql000ujx237a6k27or	ครู	coordinate	cmq0ke15g0007jx23k3ypiimb	2026-06-22 08:39:03.481	\N	2026-06-15 08:39:03.482
cmqeyoddc004qjxopdgdqu82y	7ae954c0879968a650a5b044067c667e26bb93aa88f59b29a9de288486c3c1d6	fee564301016@gmail.com	ปฐพี	จันทร์แก้ว	33	class_teacher	1/1	cmq0khbql000ujx237a6k27or	ครู	coordinate	cmq0ke15g0007jx23k3ypiimb	2026-06-22 08:38:41.327	2026-06-15 08:48:12.239	2026-06-15 08:38:41.328
cmqnx6au300bgjxekfr224pxm	bf5de9a20620f76d56526388c2e08834d179757298bfdf309e6f37accd1c6986	kamonchanokoohll@gmail.com	นางสาวกมลชนก	ขำวิชัย	32	school_admin	ทุกห้อง	cmqn96nzy005fjxekv4ihp11u	ครูระบบดูแลช่วยเหลือนักเรียน	care	cmqn94a13005pjxf0c0ewp2xv	2026-06-28 15:06:34.202	2026-06-21 15:08:16.799	2026-06-21 15:06:34.203
cmqnx6xad00bkjxeki4dgmj5y	0d356c96b7dbf9c064694046d24dac2a9ff937d98593f3799db29c35ed178aaa	khing0526@gmail.com	นางสาวรุ้งนภา	มาลัย	26	school_admin	ทุกห้อง	cmqn96nzy005fjxekv4ihp11u	ครู Thailand Zero Dropout	care	cmqn94a13005pjxf0c0ewp2xv	2026-06-28 15:07:03.3	2026-06-21 15:40:44.183	2026-06-21 15:07:03.301
cmqeyo8oz004ijxopx6luvq0v	b970303ead34b61590a5991e4424f32e701e9ee7c99e889507eda6a933d66972	nureesan199x@gmail.com	นูรีซัน	สือแน	29	class_teacher	3/2	cmq0khbql000ujx237a6k27or	ครู	coordinate	cmq0ke15g0007jx23k3ypiimb	2026-06-22 08:38:35.266	\N	2026-06-15 08:38:35.267
cmqeyoatw004mjxoph765z5ix	232d5d17aa23df3e3d072b6558d7a9b21c556646c6dc0ee4bda75a0576214857	k.nuuyah@gmail.com	นูรียะ	ขาเดร์	34	class_teacher	5/1	cmq0khbql000ujx237a6k27or	ครู	coordinate	cmq0ke15g0007jx23k3ypiimb	2026-06-22 08:38:38.035	\N	2026-06-15 08:38:38.036
cmqeyoie900ytjxp50c5sdvvh	1b2d3a0ccf81ab208005f35f62e473a3952e517ff98f1cab79cd92a994b9e53d	mayeedah616@gmail.com	มาญีดะห์	อาลี	29	class_teacher	1/2	cmq0khbql000ujx237a6k27or	ครู	coordinate	cmq0ke15g0007jx23k3ypiimb	2026-06-22 08:38:47.84	\N	2026-06-15 08:38:47.841
cmqeyomq1004yjxopbk8y8c4d	12f87eef4942e3b54ce7ab7f25ff18dabe33f58ef0ec4ef7689edb4ef2fdd4bf	yusreeyah2986@gmail.com	ยุสรีย๊ะ	ปะแตบือแน	34	class_teacher	3/1	cmq0khbql000ujx237a6k27or	ครู	coordinate	cmq0ke15g0007jx23k3ypiimb	2026-06-22 08:38:53.448	\N	2026-06-15 08:38:53.449
cmqeyoqc100z1jxp5lzohl98s	6a57b625e2b188636410fee6ebbd270a8320809d6619cab3f6cec9e9bc202e25	ameen1464052@gmail.com	อามีน	โต๊ะเฮง	27	class_teacher	2/2	cmq0khbql000ujx237a6k27or	ครู	coordinate	cmq0ke15g0007jx23k3ypiimb	2026-06-22 08:38:58.128	\N	2026-06-15 08:38:58.129
cmqeyokpu00yxjxp591bfr1zi	25cf101bc57c99f85357478026cf5fffa0862477b36d9ed63bd8a6104ce28d72	mahamadroslanlateh@gmail.com	มาหาหมัดรอสลัน	ลาเต๊ะ	38	class_teacher	6/1	cmq0khbql000ujx237a6k27or	ครู	coordinate	cmq0ke15g0007jx23k3ypiimb	2026-06-22 08:38:50.849	2026-06-15 08:51:03.034	2026-06-15 08:38:50.85
cmqeyos850052jxopr62isxst	aaccc3dcce2e9165ad41712976e54b79f7f16c9403769782fd926b2aa0395519	ala.weewateng@gmail.com	อาลาวียะห์	วาเตง	30	class_teacher	6/2	cmq0khbql000ujx237a6k27or	ครู	coordinate	cmq0ke15g0007jx23k3ypiimb	2026-06-22 08:39:00.58	2026-06-18 03:52:36.728	2026-06-15 08:39:00.581
cmqeynjyp004ejxop380v0403	73def3f0cb6d86dd27426a702fb3b12ddc4dd4d713d47eb4866668af3a30816b	habiib3290@gmail.com	ซัยนับ	อาบู	25	class_teacher	4/1	cmq0khbql000ujx237a6k27or	ครู	coordinate	cmq0ke15g0007jx23k3ypiimb	2026-06-22 08:38:03.216	2026-06-18 03:56:05.097	2026-06-15 08:38:03.218
cmqeyog2v004ujxopjvdfxa0z	238d0e11b90a56d8b42cfad568f79d2db9c9aa9057dee555cfaa28c73bd5bb11	fatmah8977@gmail.com	พาตีเมาะ	เจะมะ	25	class_teacher	4/2	cmq0khbql000ujx237a6k27or	ครู	coordinate	cmq0ke15g0007jx23k3ypiimb	2026-06-22 08:38:44.838	2026-06-18 03:57:14.807	2026-06-15 08:38:44.839
cmqeyo4e400ypjxp519omkg7w	b3aa52926b91037253e7b1f879dfa63f015d5d689a3fad0d00a93456267a243b	suwaibahyuyu@gmail.com	ซุไรดา	ลีปะ	29	class_teacher	2/3	cmq0khbql000ujx237a6k27or	ครู	coordinate	cmq0ke15g0007jx23k3ypiimb	2026-06-22 08:38:29.691	2026-06-18 04:22:34.354	2026-06-15 08:38:29.692
cmqnx56cy00bcjxekalx8il5r	a45eff815ac7e22b7813397c838d02c54b1ef3f5bc5e56961dca9e0db4759faa	kunakorn.mojarin@gmail.com	นายคุณากร	โมจรินทร์	34	school_admin	ทุกห้อง	cmqn96nzy005fjxekv4ihp11u	ครูแนะแนว	care	cmqn94a13005pjxf0c0ewp2xv	2026-06-28 15:05:41.746	2026-06-22 00:54:07.116	2026-06-21 15:05:41.747
cmqnx7ho200bojxekzdhijgb8	d9dca1f0ff22e5c258cb5647800c43c57ccab82f84538349dd4ad416a2cdbe8b	chin.tas2531@gmail.com	นายชินทัศ	เหลืองประมวล	38	school_admin	ทุกห้อง	cmqn96nzy005fjxekv4ihp11u	ครูงานยาเสพติด	care	cmqn94a13005pjxf0c0ewp2xv	2026-06-28 15:07:29.714	2026-06-22 05:23:08.74	2026-06-21 15:07:29.714
\.


--
-- Data for Name: teachers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.teachers (id, "userId", "firstName", "lastName", age, "advisoryClass", "schoolRole", "projectRole", "createdAt", "updatedAt") FROM stdin;
cmp6j93ym0004jxdfisv6f3rw	cmp6j8ifp0002jxdffdiyvvw3	หนูทิน	จะรวยแล้ว	39	ทุกห้อง	ครูไว	care	2026-05-15 06:25:03.31	2026-05-15 06:25:03.31
cmp6jm8cf001njxdfnwdfvjgu	cmp6jm8cc001ljxdfx7fs20po	ทดสอบ	นางฟ้า	45	ทุกห้อง	ครูหนู	coordinate	2026-05-15 06:35:15.519	2026-05-15 06:35:15.519
cmpjfv5xk0018jx2ms2k4rm7g	cmpjfu3b60016jx2mszo9avsp	ควายแดง	ควายน้ำเงิน	36	ทุกห้อง	ควาย	care	2026-05-24 07:11:14.12	2026-05-24 07:11:14.12
cmpkp97xk002qjx2mew9f0nnx	cmpkp8rvo002ojx2m2jhdnhk0	นัยน์ปพร	วีรศิริยานนท์	28	ทุกห้อง	ครูปจช	care	2026-05-25 04:21:52.617	2026-05-25 04:21:52.617
cmpmdq7ur000mjxgmm6zugwae	cmpmdmbqv000kjxgmprk5t2o6	ครูนางฟ้า	ใจดี	35	ทุกห้อง	ครูระบบกิจการนักเรียน	care	2026-05-26 08:34:42.627	2026-05-26 08:34:42.627
cmpzr74is002pjxwno5rnbbx5	cmpzr4e32002ljxwnl4klwuhq	ซันนี่	สุวรรณเมธานนท์	28	ทุกห้อง	รองผู้อำนวยการฝ่ายห้ะ	lead	2026-06-04 17:12:46.757	2026-06-04 17:12:46.757
cmq0kfyf0000fjx23ys7m0sv0	cmq0kdx110004jx23k3lcvs0z	รัตติยากร	ชนะพันธ์	32	ทุกห้อง	ครูประจำชั้น	care	2026-06-05 06:51:27.613	2026-06-05 06:51:27.613
cmq0kgvkt000rjx23ba74wihb	cmq0ke15g0007jx23k3ypiimb	นูริทรา	แปแนะ	29	ทุกห้อง	ครูผูู้จัดการดูแลระบบ	lead	2026-06-05 06:52:10.589	2026-06-05 06:52:10.589
cmq0ki9k50011jx23q8yubvu8	cmq0kgjsg000njx23n27h0rcx	จาตุรันต์	สีมาเพชร	29	ทุกห้อง	หัวหน้างานแนะแนว	care	2026-06-05 06:53:15.366	2026-06-05 06:53:15.366
cmq0kirxy0016jx23ljj6f7wd	cmq0kfz02000ijx23kh3yrfbs	นางสาวเบญจพร	ครุฑเครือ	28	ทุกห้อง	หัวหน้างานส่งเสริมสุขภาพอนามัยโรงเรียน	care	2026-06-05 06:53:39.191	2026-06-05 06:53:39.191
cmq0kwitb0068jx23whl9wtr5	cmq0kwit80066jx23pw930nx1	นางสาวศรัญญา	ดวงอุปะ	24	ทุกห้อง	ครูนางฟ้า	care	2026-06-05 07:04:20.544	2026-06-05 07:04:20.544
cmq0kxcky006cjx23h5ao7aou	cmq0kxcku006ajx23ut10mnz6	นางสาวมธุริน	วันทะวี	35	ทุกห้อง	ครูพยาบาล	care	2026-06-05 07:04:59.122	2026-06-05 07:04:59.122
cmq0kyg7s006njx231rvlybgi	cmq0kyg7o006ljx23949vl1bi	นายประยูร	มังกร	55	ทุกห้อง	ผู้อำนวยการโรงเรียน	lead	2026-06-05 07:05:50.489	2026-06-05 07:05:50.489
cmq0kywl7007qjx23nrsvvsk5	cmq0kywl5007ojx2302605270	นางพัทธยา	ชนะพันธ์	56	ทุกห้อง	ผู้อำนวยการโรงเรียน	lead	2026-06-05 07:06:11.708	2026-06-05 07:06:11.708
cmq0kzkw90084jx23mdbfir6j	cmq0kzkw60082jx23kdjsy3u5	นายพงศ์พิสุทธิ์	ใจคุณ	40	ทุกห้อง	ครู	care	2026-06-05 07:06:43.209	2026-06-05 07:06:43.209
cmq0l0lbm0094jx23br476wco	cmq0l0lbj0092jx23gy1fgh5q	นายสุรสีห์	จันทร์แสงศรี	45	ทุกห้อง	ครูนางฟ้า	care	2026-06-05 07:07:30.418	2026-06-05 07:07:30.418
cmq0l1izf009sjx23lsi6op18	cmq0l1izd009qjx23prrja72v	นายโกมล	ยงเพชร	30	ทุกห้อง	ครู	care	2026-06-05 07:08:14.043	2026-06-05 07:08:14.043
cmq0l3re400b2jx23s3drnyvl	cmq0l3re200b0jx235badgq3k	ลิน	ลาลาลิน	25	ม.2/1	ครูนางฟ้า	coordinate	2026-06-05 07:09:58.252	2026-06-05 07:09:58.252
cmq0ldps000cfjx231u96bd5t	cmq0ldprx00cdjx23mw4kdumj	นูรฮีดายะห์	โดดะนะ	31	ทุกห้อง	ครูประจำชั้น	care	2026-06-05 07:17:42.721	2026-06-05 07:17:42.721
cmp6jcppm0017jxdf7kt6gv78	cmp6jcpph0015jxdf2vxb3crk	yingyot	jiteiei	35	ทุกห้อง	ครูรวย	coordinate	2026-05-15 06:27:51.466	2026-06-07 05:17:52.645
cmq6gifnf000fjxsd1lym0qbb	cmq6gifn9000djxsdox13m3kp	ครูรวย	สวยไม่สร่าง	40	ม.1/4	ว่าง	care	2026-06-09 09:48:01.851	2026-06-09 09:48:01.851
cmq0kyw88007mjx23bngy4eq8	cmq0kyw85007kjx239k25z1ge	นายวิฑูลย์	แซมสีม่วง	50	ทุกห้อง	ครูนางฟ้า	care	2026-06-05 07:06:11.241	2026-06-14 10:19:18.882
cmq0kjgrf001bjx239tohxraj	cmq0khs5m000wjx23jyhqhgkv	นางกฤติกา	แซมสีม่วง	50	ทุกห้อง	ครูนางฟ้า	care	2026-06-05 06:54:11.355	2026-06-14 10:19:31.935
cmqez0lw7005cjxops5htz0wq	cmqez0lw4005ajxopfcijzz1q	ปฐพี	จันทร์แก้ว	33	1/1	ครู	coordinate	2026-06-15 08:48:12.247	2026-06-15 08:48:12.247
cmqez49of005gjxopvujmnwfa	cmqez49oe005ejxop7bt8v7zm	มาหาหมัดรอสลัน	ลาเต๊ะ	38	6/1	ครู	coordinate	2026-06-15 08:51:03.04	2026-06-15 08:51:03.04
cmqiys137000kjxdpat7i8d0c	cmqiys133000ijxdpsllq3iqv	อาลาวียะห์	วาเตง	30	6/2	ครู	coordinate	2026-06-18 03:52:36.739	2026-06-18 03:52:36.739
cmqiywhv9000rjxe5xr2ptzto	cmqiywhv5000pjxe502qkjrdo	ซัยนับ	อาบู	25	4/1	ครู	coordinate	2026-06-18 03:56:05.11	2026-06-18 03:56:05.11
cmqiyxznk000qjxdpznpjwma3	cmqiyxznh000ojxdp7ho41qil	พาตีเมาะ	เจะมะ	25	4/2	ครู	coordinate	2026-06-18 03:57:14.816	2026-06-18 03:57:14.816
cmqizuk5c0013jxe5sup7lyjj	cmqizuk560011jxe5xc4ibqfr	ซุไรดา	ลีปะ	29	2/3	ครู	coordinate	2026-06-18 04:22:34.368	2026-06-18 04:22:34.368
cmqn962jn005rjxf096m7lk4c	cmqn94a13005pjxf0c0ewp2xv	นางสาวภรณ์ทิพวรรณ	นุชโสภา	32	ทุกห้อง	หัวหน้าระบบดูแลช่วยเหลือนักเรียน	coordinate	2026-06-21 03:54:32.675	2026-06-21 03:54:32.675
cmqnx8i0500bujxekja7eajfp	cmqnx8i0300bsjxekiur21agf	นางสาวกมลชนก	ขำวิชัย	32	ทุกห้อง	ครูระบบดูแลช่วยเหลือนักเรียน	care	2026-06-21 15:08:16.806	2026-06-21 15:12:33.297
cmqnye8mc00c4jxekei2gzcrq	cmqnye8m700c2jxekf3kd0pos	นางสาวรุ้งนภา	มาลัย	26	ทุกห้อง	ครู Thailand Zero Dropout	care	2026-06-21 15:40:44.196	2026-06-21 15:40:44.196
cmqoi5w6200cxjxek04h8qham	cmqoi5w5y00cvjxek58psevzp	นายคุณากร	โมจรินทร์	34	ทุกห้อง	ครูแนะแนว	care	2026-06-22 00:54:07.13	2026-06-22 00:54:07.13
cmqorrv4l0129jxf0f2h2ecg8	cmqorrv4d0127jxf0rja5ghra	นายชินทัศ	เหลืองประมวล	38	ทุกห้อง	ครูงานยาเสพติด	care	2026-06-22 05:23:08.757	2026-06-22 05:23:08.757
cmr4nhz9l001tjxcdpa5qt7go	cmr4ngcvw001rjxcdypri356x	จันทจันทร์นภัส	นิตินิติภูมิไตรลัไตรลักษณ์	44	ทุกห้อง	รองผู้อำนวยการโรงเรียน	lead	2026-07-03 08:07:47.913	2026-07-03 08:07:47.913
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_sessions (id, "sessionTokenHash", "userId", "expiresAt", "lastActivityAt", "revokedAt", "createdAt", "updatedAt", "tokenRotatedAt", "userAgentLabel", "userAgentHash", "lastIpPrefix") FROM stdin;
cmpxhaaqp000kjxmgr8vzfk2y	dbcced094b3d6505f0ac82a7ff96d45f89da6c8efb111581f17c3d073f5f658f	cmp6j8ifp0002jxdffdiyvvw3	2026-06-04 02:59:46.272	2026-06-03 05:18:13.078	2026-06-04 02:46:01.02	2026-06-03 02:59:46.273	2026-06-04 02:46:01.022	2026-06-03 02:59:46.272	Chrome บนคอมพิวเตอร์	9884896580bbd9285b8a0782ea7ae63de01ed5f471d1bab6202de0630c0399a3	184.22.32.0/24
cmpw3995o000gjxbz43zn99db	26746825a516b688402dfcef4450296e384f6fe21ce9926be03ffcc27b1424e2	cmpmdmbqv000kjxgmprk5t2o6	2026-06-03 03:39:16.763	2026-06-02 06:10:44.903	2026-06-02 11:04:24.634	2026-06-02 03:39:16.764	2026-06-02 11:04:24.634	2026-06-02 03:39:16.763	Chrome บนคอมพิวเตอร์	4cbc8039bc8d8badefe54056014551dfd22b5e4a800a9e6305203a5a073e6b48	1.20.93.0/24
cmpyw8wur001xjxwn7sx7uqw1	1c94b02ee1dc9cd7611d7f53d61c57979c6644301d71f3dae40629bf0541248d	cmp6j8ifp0002jxdffdiyvvw3	2026-06-05 02:46:22.034	2026-06-04 02:49:48.518	2026-06-17 12:27:25.768	2026-06-04 02:46:22.035	2026-06-17 12:27:25.769	2026-06-04 02:46:22.034	Chrome บนคอมพิวเตอร์	9884896580bbd9285b8a0782ea7ae63de01ed5f471d1bab6202de0630c0399a3	124.122.9.0/24
cmpvlndmk001ujxjcxm1g3oev	fc3ee8d7a0bf6fc504aca7be7dd2b62f46a6c3d3af896f98c8171dc547d5444a	cmpmdmbqv000kjxgmprk5t2o6	2026-06-02 19:26:22.651	2026-06-01 20:14:32.439	\N	2026-06-01 19:26:22.653	2026-06-01 20:14:32.445	2026-06-01 19:26:22.651	Chrome บนคอมพิวเตอร์	9884896580bbd9285b8a0782ea7ae63de01ed5f471d1bab6202de0630c0399a3	2403:6200:88a4:7bad::/64
cmpurev090001jxjcx1av7dz3	975d4dfe9502f04e62b54027cfe850656f04e24934c8fd53c8c6e9fb718df753	cmp6j8ifp0002jxdffdiyvvw3	2026-06-02 05:19:56.791	2026-06-01 06:39:41.337	2026-06-02 03:20:46.822	2026-06-01 05:19:56.793	2026-06-02 03:20:46.823	2026-06-01 05:19:56.791	Chrome บนคอมพิวเตอร์	9884896580bbd9285b8a0782ea7ae63de01ed5f471d1bab6202de0630c0399a3	184.22.34.0/24
cmpybbc8p000hjxwn9c6gy8eg	a5431dd1b0e50fed05f236095f8d1c04a5ead972806098d896494687092fa105	cmpmdmbqv000kjxgmprk5t2o6	2026-06-04 17:00:23.352	2026-06-03 17:00:26.787	2026-06-03 17:00:29.891	2026-06-03 17:00:23.353	2026-06-03 17:00:29.892	2026-06-03 17:00:23.352	Chrome บนคอมพิวเตอร์	9884896580bbd9285b8a0782ea7ae63de01ed5f471d1bab6202de0630c0399a3	83.118.33.0/24
cmpurfzgh0005jxjcxx1fq17r	4d7e2ca1453ce1ffd1e0b3da3389daf922f086189d6a42baf8b1712cf80585b1	cmp6j8ifp0002jxdffdiyvvw3	2026-06-02 05:20:49.216	2026-06-01 07:13:12.061	2026-06-01 13:15:24.28	2026-06-01 05:20:49.217	2026-06-01 13:15:24.281	2026-06-01 05:20:49.216	Chrome บนมือถือ	ef78bc17265d32e6c02d6cc23189e096909db7f5084bb8d0fe20ac7585d8c803	184.22.34.0/24
cmpxkvqo4000rjxmgiw5i3h26	ba8d74dc21c4de853c32964eae4002837405498750fed24f3418617e0592e407	cmp6j8ifp0002jxdffdiyvvw3	2026-06-04 04:40:25.539	2026-06-03 05:29:37.241	2026-06-03 13:04:18.819	2026-06-03 04:40:25.54	2026-06-03 13:04:18.821	2026-06-03 04:40:25.539	Chrome บนมือถือ	ef78bc17265d32e6c02d6cc23189e096909db7f5084bb8d0fe20ac7585d8c803	184.22.32.0/24
cmpy7fjec0007jxwnkiv5fejd	b5ffeb8adb7c4c03ed95edd55b3247c4707f48553eec005b1cf6c7f0b09df1ff	cmp6j8ifp0002jxdffdiyvvw3	2026-06-04 15:11:40.787	2026-06-03 15:13:30.965	2026-06-03 23:26:32.841	2026-06-03 15:11:40.788	2026-06-03 23:26:32.842	2026-06-03 15:11:40.787	Chrome บนมือถือ	ef78bc17265d32e6c02d6cc23189e096909db7f5084bb8d0fe20ac7585d8c803	2001:44c8:6332:f23d::/64
cmpwj5wp1000fjxmgkyeixxu5	ea6506e1736693cb841ba127b52e67e7b30bfe31e2937b9b69f7b0e2d2d56d11	cmpmdmbqv000kjxgmprk5t2o6	2026-06-03 11:04:34.5	2026-06-02 11:05:53.506	\N	2026-06-02 11:04:34.501	2026-06-02 11:05:53.512	2026-06-02 11:04:34.5	Chrome บนคอมพิวเตอร์	4cbc8039bc8d8badefe54056014551dfd22b5e4a800a9e6305203a5a073e6b48	1.20.93.0/24
cmpvlld76001sjxjcpow1ncng	6c632b2755d442c4864cd36958f3e6cabe64cf806ed249f76f66373a90a99b65	cmp6j4rgk0000jxuitzv4y8us	2026-06-02 19:24:48.785	2026-06-01 19:26:16.071	2026-06-01 19:26:17.807	2026-06-01 19:24:48.786	2026-06-01 19:26:17.808	2026-06-01 19:24:48.785	Chrome บนคอมพิวเตอร์	9884896580bbd9285b8a0782ea7ae63de01ed5f471d1bab6202de0630c0399a3	2403:6200:88a4:7bad::/64
cmpw2qxjq0001jxbzgefurok9	40992b23fb65ee9c96d6043da9665449587927081da32a26f5cd20761d7a215d	cmp6j8ifp0002jxdffdiyvvw3	2026-06-03 03:25:01.909	2026-06-02 08:12:17.107	2026-06-02 08:12:35.278	2026-06-02 03:25:01.911	2026-06-02 08:12:35.28	2026-06-02 03:25:01.909	Chrome บนคอมพิวเตอร์	9884896580bbd9285b8a0782ea7ae63de01ed5f471d1bab6202de0630c0399a3	184.22.32.0/24
cmpw2vs6c000bjxbz6kpryg46	c93c3146a9471be193ed0f8eba8ec4ceb7d0b8aab6d463bfb6900a46c65b1102	cmp6j8ifp0002jxdffdiyvvw3	2026-06-03 03:28:48.227	2026-06-02 03:28:48.488	2026-06-02 08:30:28.042	2026-06-02 03:28:48.228	2026-06-02 08:30:28.043	2026-06-02 03:28:48.227	Chrome บนมือถือ	ef78bc17265d32e6c02d6cc23189e096909db7f5084bb8d0fe20ac7585d8c803	184.22.32.0/24
cmpzqqt7x002ajxwneewi6dlx	26d7e98a6cda0471648d31a83456677227b0ee5412e64a023553b72818dbf9ed	cmp6j4rgk0000jxuitzv4y8us	2026-06-05 17:00:05.612	2026-06-04 17:10:05.361	\N	2026-06-04 17:00:05.613	2026-06-04 17:10:05.364	2026-06-04 17:00:05.612	Chrome บนคอมพิวเตอร์	9884896580bbd9285b8a0782ea7ae63de01ed5f471d1bab6202de0630c0399a3	83.118.33.0/24
cmpwdomml000fjxs0nasn5q6c	3340a7ed8f3cefb7c82a91620ca94194f785b9f172cb53babfced0c730af2232	cmp6j8ifp0002jxdffdiyvvw3	2026-06-03 08:31:10.219	2026-06-02 10:42:11.098	2026-06-03 00:47:23.176	2026-06-02 08:31:10.221	2026-06-03 00:47:23.177	2026-06-02 08:31:10.219	Chrome บนมือถือ	ef78bc17265d32e6c02d6cc23189e096909db7f5084bb8d0fe20ac7585d8c803	184.22.32.0/24
cmpwfpezs0001jxmgeugitqpm	1d9f58d0828381e97c0b46976dbf21a5c767c23c396e4b0bcc3cfcfa2a861dc6	cmp6j8ifp0002jxdffdiyvvw3	2026-06-03 09:27:46.213	2026-06-02 10:13:40.208	2026-06-03 02:59:06.673	2026-06-02 09:27:46.216	2026-06-03 02:59:06.674	2026-06-02 09:27:46.213	Chrome บนคอมพิวเตอร์	9884896580bbd9285b8a0782ea7ae63de01ed5f471d1bab6202de0630c0399a3	184.22.32.0/24
cmpybblvq000mjxwnloixc9zf	45f7f24387d4b36ab98d7f4e4a28f0bb7c12b1f7fe9828c4b8691c7749f58e66	cmp6j4rgk0000jxuitzv4y8us	2026-06-04 17:00:35.845	2026-06-03 17:00:53.648	2026-06-03 17:00:55.862	2026-06-03 17:00:35.846	2026-06-03 17:00:55.863	2026-06-03 17:00:35.845	Chrome บนคอมพิวเตอร์	9884896580bbd9285b8a0782ea7ae63de01ed5f471d1bab6202de0630c0399a3	83.118.33.0/24
cmpybhi7l000ojxwn8esqca6x	e4a09cac48e5a7861e85c727893b3919f97c7271471e5d1050962aef180ad45f	cmpmdmbqv000kjxgmprk5t2o6	2026-06-04 17:05:11.024	2026-06-03 18:40:14.081	2026-06-04 16:46:28.064	2026-06-03 17:05:11.025	2026-06-04 16:46:28.066	2026-06-03 17:05:11.024	Chrome บนคอมพิวเตอร์	9884896580bbd9285b8a0782ea7ae63de01ed5f471d1bab6202de0630c0399a3	83.118.33.0/24
cmpyv4fml001qjxwns4042vy0	250992eaa721068a7273330170d438c16d8d2f8b253363d707474472d8b743d9	cmpmdmbqv000kjxgmprk5t2o6	2026-06-05 02:14:53.468	2026-06-04 02:16:46.032	\N	2026-06-04 02:14:53.469	2026-06-04 02:16:46.037	2026-06-04 02:14:53.468	Chrome บนคอมพิวเตอร์	4cbc8039bc8d8badefe54056014551dfd22b5e4a800a9e6305203a5a073e6b48	83.118.33.0/24
cmq08qds7002ujxwnrlghe8g4	7b7d9734022f3c40427d08edb73272ae92f3a18f4654283fc4fb2aacf08b5b18	cmp6j4rgk0000jxuitzv4y8us	2026-06-06 01:23:38.694	2026-06-05 01:23:38.9	2026-06-05 01:23:59.824	2026-06-05 01:23:38.695	2026-06-05 01:23:59.825	2026-06-05 01:23:38.694	Chrome บนคอมพิวเตอร์	9884896580bbd9285b8a0782ea7ae63de01ed5f471d1bab6202de0630c0399a3	83.118.33.0/24
cmpzq9d2d0024jxwniqih617n	f6d8543afa70b98ec0b700f8cec2875f1fb2b8d6779d9aaa260bf948692eecda	cmpmdmbqv000kjxgmprk5t2o6	2026-06-05 16:46:31.523	2026-06-04 16:54:19.185	2026-06-04 16:54:22.072	2026-06-04 16:46:31.526	2026-06-04 16:54:22.073	2026-06-04 16:46:31.523	Chrome บนคอมพิวเตอร์	9884896580bbd9285b8a0782ea7ae63de01ed5f471d1bab6202de0630c0399a3	83.118.33.0/24
cmpzr4em0002njxwn80hlu1ew	90b7292922204531a91a66476911274533baf6fb06fdc18aeb94b07ec8ef033d	cmpzr4e32002ljxwnl4klwuhq	2026-06-05 17:10:39.862	2026-06-04 17:13:26.627	2026-06-05 01:22:54.544	2026-06-04 17:10:39.864	2026-06-05 01:22:54.545	2026-06-04 17:10:39.862	Chrome บนคอมพิวเตอร์	9884896580bbd9285b8a0782ea7ae63de01ed5f471d1bab6202de0630c0399a3	83.118.33.0/24
cmq0ak0eg003ejxwn88ntelkh	54425f5a84f37371e4e3b23dfd71f21c470b5200b19b872eed43d102008ab125	cmpmdmbqv000kjxgmprk5t2o6	2026-06-06 02:14:40.647	2026-06-05 06:30:11.281	\N	2026-06-05 02:14:40.648	2026-06-05 06:30:11.299	2026-06-05 02:14:40.647	Chrome บนคอมพิวเตอร์	9884896580bbd9285b8a0782ea7ae63de01ed5f471d1bab6202de0630c0399a3	1.46.11.0/24
cmq08r4lc002wjxwnfx8l9rmg	deb70afc53e1c43c424b5119b7e33df326ec34c1cb79db0083ffd08995e0c387	cmpzr4e32002ljxwnl4klwuhq	2026-06-06 01:24:13.44	2026-06-05 01:27:14.71	2026-06-05 02:14:32.428	2026-06-05 01:24:13.441	2026-06-05 02:14:32.43	2026-06-05 01:24:13.44	Chrome บนคอมพิวเตอร์	9884896580bbd9285b8a0782ea7ae63de01ed5f471d1bab6202de0630c0399a3	83.118.33.0/24
cmq0l063z008ejx23jvum8wn0	bbbdf03517a6a332879b1dc0b205e56c2403c828905547c32df13782d1117803	cmq0kzkw60082jx23kdjsy3u5	2026-06-06 07:07:10.702	2026-06-05 07:07:11.276	\N	2026-06-05 07:07:10.703	2026-06-05 07:07:11.28	2026-06-05 07:07:10.702	Chrome บนมือถือ	32e1c59caf6fab0bc91954cd65ae18b319bfa85e644a1c637e018cc822146ebd	2001:44c8:40b2:8c43::/64
cmq0kgkcs000pjx23v4nsjywn	648627208c37c4ea66e551bdbc095399082911c32325d68a1f0041f2d1fd707f	cmq0kgjsg000njx23n27h0rcx	2026-06-06 06:51:56.042	2026-06-05 07:11:18.376	\N	2026-06-05 06:51:56.044	2026-06-05 07:11:18.383	2026-06-05 06:51:56.042	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	49.237.177.0/24
cmq0kznod0086jx23lfuyj0el	2f4489d3f410ca863414f2b4d14482a23bb3da7e9847d985fb73ee9fa36cb7b8	cmq0kyg7o006ljx23949vl1bi	2026-06-06 07:06:46.812	2026-06-05 07:09:27.002	\N	2026-06-05 07:06:46.813	2026-06-05 07:09:27.014	2026-06-05 07:06:46.812	Chrome บนมือถือ	5536e2b6dfaf35cb16d089c1715e4aa180c172bd4efa1d3afb7bcf9b827d72a7	83.118.33.0/24
cmq0kdxju0006jx237b8ijv7d	8f4d86d44fc82710a0f307933d7b2844134fe5e9a81f919e8aa6f64cf502e6fd	cmq0kdx110004jx23k3lcvs0z	2026-06-06 06:49:53.177	2026-06-05 07:01:39.401	\N	2026-06-05 06:49:53.178	2026-06-05 07:01:39.406	2026-06-05 06:49:53.177	Browser บนมือถือ	31d98e431ccc43b3d11f979476abe3847c35a3f6f611b0665a9c051a47288eb5	83.118.33.0/24
cmq0l14el009mjx23rdxt2y1e	09ca6670d5b0f6cc4534a6ecf5cb3fbb554c798995cb5456c0d3b37e379d501c	cmq0l0lbj0092jx23gy1fgh5q	2026-06-06 07:07:55.148	2026-06-05 07:07:55.436	\N	2026-06-05 07:07:55.149	2026-06-05 07:07:55.438	2026-06-05 07:07:55.148	Chrome บนมือถือ	aa6a3fcfe572708436a56b3db50cf68bc0608b78b79c038c2b0b91e71152a445	49.237.23.0/24
cmq0f93r6003ijxwnx6mf46le	7871890bf31bd6aa3c89a9cfc741bbbf202838beb74113e8786957284e15a0a6	cmp6j4rgk0000jxuitzv4y8us	2026-06-06 04:26:09.856	2026-06-05 04:26:46.208	\N	2026-06-05 04:26:09.859	2026-06-05 04:26:46.211	2026-06-05 04:26:09.856	Chrome บนคอมพิวเตอร์	4cbc8039bc8d8badefe54056014551dfd22b5e4a800a9e6305203a5a073e6b48	83.118.33.0/24
cmq0khsoi000yjx23ae6fu34j	bcdd968c0910003ffa61478c3d5ccef6e8397ee2d026b4ece88ebe3d24aec0ae	cmq0khs5m000wjx23jyhqhgkv	2026-06-06 06:52:53.489	2026-06-05 07:14:54.04	2026-06-05 07:23:53.74	2026-06-05 06:52:53.49	2026-06-05 07:23:53.741	2026-06-05 06:52:53.489	Microsoft Edge บนคอมพิวเตอร์	2efe31d10f76c485332c7bf4dba8fe8272eb4cb7f5e35d544dc126eb3bf993be	83.118.33.0/24
cmq0ke2o60009jx239zuz66iv	0339803f28f6d4d92a4c41274f9f6bf6ab117525692a2b9148189bf45b42ac94	cmq0ke15g0007jx23k3ypiimb	2026-06-06 06:49:59.813	2026-06-05 07:07:43.908	\N	2026-06-05 06:49:59.814	2026-06-05 07:07:43.915	2026-06-05 06:49:59.813	Microsoft Edge บนคอมพิวเตอร์	2efe31d10f76c485332c7bf4dba8fe8272eb4cb7f5e35d544dc126eb3bf993be	83.118.33.0/24
cmq0kb16a0001jx23zyeq2oq4	11b553fafc49439a074804505ffd97cc770e3bce78fd13e9fc8e591ce51f21c0	cmpmdmbqv000kjxgmprk5t2o6	2026-06-06 06:47:37.904	2026-06-05 07:08:41.53	\N	2026-06-05 06:47:37.906	2026-06-05 07:08:41.537	2026-06-05 06:47:37.904	Chrome บนคอมพิวเตอร์	9884896580bbd9285b8a0782ea7ae63de01ed5f471d1bab6202de0630c0399a3	83.118.33.0/24
cmq0q542n0001jx1kjna9ruzs	312609599ee86082f659815034af22c787c83c4a52fdb61fd605b1baf130ef2f	cmp6j8ifp0002jxdffdiyvvw3	2026-06-06 09:30:59.422	2026-06-05 09:45:33.812	2026-06-17 12:27:25.768	2026-06-05 09:30:59.424	2026-06-17 12:27:25.769	2026-06-05 09:30:59.422	Chrome บนคอมพิวเตอร์	9884896580bbd9285b8a0782ea7ae63de01ed5f471d1bab6202de0630c0399a3	124.122.9.0/24
cmq0kfdpq000bjx23p2vhpou9	e4c6f4364cc8681a36433e36bd558e740aed820fe5c315d2099d3848ab386d52	cmpkp8rvo002ojx2m2jhdnhk0	2026-06-06 06:51:00.781	2026-06-05 07:09:59.558	\N	2026-06-05 06:51:00.782	2026-06-05 07:09:59.563	2026-06-05 06:51:00.781	Chrome บนคอมพิวเตอร์	9884896580bbd9285b8a0782ea7ae63de01ed5f471d1bab6202de0630c0399a3	83.118.33.0/24
cmq0kzqky008ajx2360f785t8	b10cab24c0373d8c668d0741deb3fb4036e796667d1a2febf0958ae0e3f404fe	cmq0kywl5007ojx2302605270	2026-06-06 07:06:50.577	2026-06-05 07:06:50.744	\N	2026-06-05 07:06:50.578	2026-06-05 07:06:50.746	2026-06-05 07:06:50.577	Microsoft Edge บนคอมพิวเตอร์	2efe31d10f76c485332c7bf4dba8fe8272eb4cb7f5e35d544dc126eb3bf993be	83.118.33.0/24
cmq0l4xrc00bfjx23buc520u6	8af7c2191183a37f37c04cf10b1c8d39cd8a85d9424b5e306d0ec94c242ce5f6	cmq0kyw85007kjx239k25z1ge	2026-06-06 07:10:53.158	2026-06-05 07:10:53.579	\N	2026-06-05 07:10:53.16	2026-06-05 07:10:53.586	2026-06-05 07:10:53.158	Chrome บนมือถือ	f319f4aee39d1c6beb18ea988bc83dde5d014798702722b578c07af7264dabce	223.24.207.0/24
cmq0kqz3g004ljx2354bbxrqb	4172df0eb822e3aa520851ee04f1ace5eeff579ad4c3a391cf9775a94327254b	cmq0kdx110004jx23k3lcvs0z	2026-06-06 07:00:01.707	2026-06-05 07:00:53.219	\N	2026-06-05 07:00:01.709	2026-06-05 07:00:53.225	2026-06-05 07:00:01.707	Safari บนคอมพิวเตอร์	3dc8e91ac9887c764e6ecc9a143411be009abf614a51110c99d095c0ee7a34e1	83.118.33.0/24
cmq0kfzkp000kjx23f95u1jrf	bcaaccc312c158caded3bb5956c1f398bf37f155f338a67437e46bf6e8d91f36	cmq0kfz02000ijx23kh3yrfbs	2026-06-06 06:51:29.112	2026-06-05 07:20:49.121	2026-06-05 07:24:23.087	2026-06-05 06:51:29.113	2026-06-05 07:24:23.088	2026-06-05 06:51:29.112	Chrome บนคอมพิวเตอร์	9884896580bbd9285b8a0782ea7ae63de01ed5f471d1bab6202de0630c0399a3	83.118.33.0/24
cmq0le8x600chjx23twf8w12y	d1376ec70c47d6e413d451a47bcc6b4025cbd742937b0aa3529aaad63103be6b	cmq0ldprx00cdjx23mw4kdumj	2026-06-06 07:18:07.53	2026-06-05 07:18:07.841	\N	2026-06-05 07:18:07.531	2026-06-05 07:18:07.844	2026-06-05 07:18:07.53	Browser บนมือถือ	4efe2b4c3bb62a5391832a15bc2e36c82769eb111c722b2608724f2f7de82cd7	2001:fb1:128:743a::/64
cmq0l2hon009vjx23u0v7pxem	5c8c8c3cbe4c5a86101e5b9431bd300545c96fb17782917de2a7e8da3a3f18e9	cmq0l1izd009qjx23prrja72v	2026-06-06 07:08:59.014	2026-06-05 07:14:50.194	\N	2026-06-05 07:08:59.016	2026-06-05 07:14:50.201	2026-06-05 07:08:59.014	Browser บนมือถือ	31d98e431ccc43b3d11f979476abe3847c35a3f6f611b0665a9c051a47288eb5	83.118.33.0/24
cmq0l8lfq00btjx2307n2p5t3	140aac52adcb5cd050b9040f585506b1f686771c44dbca68083ff9e4f803c716	cmq0kwit80066jx23pw930nx1	2026-06-06 07:13:43.813	2026-06-05 07:32:41.339	\N	2026-06-05 07:13:43.815	2026-06-05 07:32:41.353	2026-06-05 07:13:43.813	Microsoft Edge บนคอมพิวเตอร์	2efe31d10f76c485332c7bf4dba8fe8272eb4cb7f5e35d544dc126eb3bf993be	83.118.33.0/24
cmq0lmk9k00cmjx23gu8nzho9	9d239116dfd37b2635cf190d310977c09a6b85dc58ecda5540035be822fe8c35	cmq0kfz02000ijx23kh3yrfbs	2026-06-06 07:24:35.479	2026-06-05 07:24:58.572	\N	2026-06-05 07:24:35.48	2026-06-05 07:24:58.575	2026-06-05 07:24:35.479	Chrome บนคอมพิวเตอร์	9884896580bbd9285b8a0782ea7ae63de01ed5f471d1bab6202de0630c0399a3	83.118.33.0/24
cmq0slkf40005jx1rzbu7oc72	5438428c4f2ac897800e485fddd54489ce0ece1fa3c683c8626b04f8d38fb035	cmp6j8ifp0002jxdffdiyvvw3	2026-06-06 10:39:46.334	2026-06-05 10:40:13.375	2026-06-06 01:25:27.42	2026-06-05 10:39:46.336	2026-06-06 01:25:27.421	2026-06-05 10:39:46.334	Chrome บนมือถือ	ef78bc17265d32e6c02d6cc23189e096909db7f5084bb8d0fe20ac7585d8c803	49.228.99.0/24
cmq0ln12m00cojx2397psxtwd	9e0dd9751b850c35357fa3e168f81c2f4069cb9769c1f2956becce1a90abda57	cmq0kfz02000ijx23kh3yrfbs	2026-06-06 07:24:57.26	2026-06-05 07:25:33.652	\N	2026-06-05 07:24:57.262	2026-06-05 07:25:33.662	2026-06-05 07:24:57.26	Chrome บนคอมพิวเตอร์	9884896580bbd9285b8a0782ea7ae63de01ed5f471d1bab6202de0630c0399a3	83.118.33.0/24
cmq391ayk000gjx1k573op4cq	5843fb9ee6dc4e01aa4953427bfd8010f87fe92426e88535c0cf6b382cb8931d	cmp6j8ifp0002jxdffdiyvvw3	2026-06-08 03:55:26.778	2026-06-07 07:44:27.327	2026-06-08 03:13:44.799	2026-06-07 03:55:26.78	2026-06-08 03:13:44.8	2026-06-07 03:55:26.778	Chrome บนคอมพิวเตอร์	9884896580bbd9285b8a0782ea7ae63de01ed5f471d1bab6202de0630c0399a3	184.22.137.0/24
cmq4phaky0007jxmh03o5x2nu	32af3842bb6313840baf0a4a91cb201543d5c32570f0af82dee038813a07fe54	cmpmdmbqv000kjxgmprk5t2o6	2026-06-09 04:23:32.817	2026-06-08 05:02:13.592	\N	2026-06-08 04:23:32.818	2026-06-08 05:02:13.603	2026-06-08 04:23:32.817	Chrome บนคอมพิวเตอร์	4cbc8039bc8d8badefe54056014551dfd22b5e4a800a9e6305203a5a073e6b48	1.20.93.0/24
cmq4tlo4l0001jx2taw9i80zq	58ad92a95b22cd9f672269fb21f88546b499d0178012e1e99664dd3bc5b2c95d	cmp6j8ifp0002jxdffdiyvvw3	2026-06-09 06:18:55.46	2026-06-08 09:45:02.697	2026-06-09 02:40:35.978	2026-06-08 06:18:55.461	2026-06-09 02:40:35.979	2026-06-08 06:18:55.46	Chrome บนคอมพิวเตอร์	9884896580bbd9285b8a0782ea7ae63de01ed5f471d1bab6202de0630c0399a3	124.122.9.0/24
cmq6givvs000kjxrxl4tyqdak	fbab051bf077d3a0f5a4dbbf78b4c7d2b6b45a8fe99a68bd172c8420aedcee28	cmq6gifn9000djxsdox13m3kp	2026-06-10 09:48:22.886	2026-06-09 09:52:16.601	2026-06-09 09:52:43.658	2026-06-09 09:48:22.888	2026-06-09 09:52:43.659	2026-06-09 09:48:22.886	Chrome บนคอมพิวเตอร์	9884896580bbd9285b8a0782ea7ae63de01ed5f471d1bab6202de0630c0399a3	124.122.9.0/24
cmq676vc4000hjx2tsj0hrekw	14aa781b88a3979c9176045aab7aa8238a016d9de83f55f64d5ae175d9bb487d	cmp6j8ifp0002jxdffdiyvvw3	2026-06-10 05:27:05.762	2026-06-09 05:28:21.568	2026-06-09 09:39:27.557	2026-06-09 05:27:05.765	2026-06-09 09:39:27.558	2026-06-09 05:27:05.762	Chrome บนมือถือ	ef78bc17265d32e6c02d6cc23189e096909db7f5084bb8d0fe20ac7585d8c803	2001:44c8:48a2:aca0::/64
cmq6imge0000jjxsdw1yimr30	2e76993748cad25da2cb247d1d5d58b74820aa832afde111ec3da962406efc89	cmp6j4rgk0000jxuitzv4y8us	2026-06-10 10:47:08.663	2026-06-09 10:47:08.663	2026-06-09 10:47:47.591	2026-06-09 10:47:08.665	2026-06-09 10:47:47.592	2026-06-09 10:47:08.663	Chrome บนคอมพิวเตอร์	4cbc8039bc8d8badefe54056014551dfd22b5e4a800a9e6305203a5a073e6b48	1.20.93.0/24
cmq6inf69000ljxsdbjfb1e8u	75e400cafa6a3610706c6ad3e5d0a1e635fa835a059f3aeae69b7f6d456ea762	cmpmdmbqv000kjxgmprk5t2o6	2026-06-10 10:47:53.744	2026-06-09 10:47:53.744	\N	2026-06-09 10:47:53.745	2026-06-09 10:47:53.745	2026-06-09 10:47:53.744	Chrome บนคอมพิวเตอร์	4cbc8039bc8d8badefe54056014551dfd22b5e4a800a9e6305203a5a073e6b48	1.20.93.0/24
cmq6q3ug8000ujxsddtgdiztt	ca62accf9351d2d713b721be249555c0112f95889a3a4f89a85fe7f359b1f05a	cmq0kyw85007kjx239k25z1ge	2026-06-10 14:16:37.349	2026-06-09 14:43:29.157	\N	2026-06-09 14:16:37.353	2026-06-09 14:43:29.164	2026-06-09 14:16:37.349	Chrome บนมือถือ	f319f4aee39d1c6beb18ea988bc83dde5d014798702722b578c07af7264dabce	49.237.66.0/24
cmq53homj000djx2tlxw1t80o	fae133487e7fbea6f535c036a64a637778465525b0d08ed895e65246a074581b	cmp6j8ifp0002jxdffdiyvvw3	2026-06-09 10:55:45.641	2026-06-08 10:57:39.617	2026-06-09 02:02:08.118	2026-06-08 10:55:45.643	2026-06-09 02:02:08.119	2026-06-08 10:55:45.641	Chrome บนมือถือ	ef78bc17265d32e6c02d6cc23189e096909db7f5084bb8d0fe20ac7585d8c803	184.22.136.0/24
cmq6g7vh30006jxsdmmt1b34y	11cca19fc6c563888f3379a51e616ac13fa132255341be1ffb8f33d4c7569fcd	cmp6j8ifp0002jxdffdiyvvw3	2026-06-10 09:39:49.142	2026-06-09 12:11:46.718	2026-06-17 12:27:25.768	2026-06-09 09:39:49.144	2026-06-17 12:27:25.769	2026-06-09 09:39:49.142	Chrome บนมือถือ	ef78bc17265d32e6c02d6cc23189e096909db7f5084bb8d0fe20ac7585d8c803	124.122.9.0/24
cmq7ev62m001ejxrxhgrb2ov3	c0c5698aee7cee8724bd71f4297f4140e47f9c23fa78fa6a6c1fccc661a44841	cmq0kyw85007kjx239k25z1ge	2026-06-11 01:49:42.908	2026-06-10 01:55:28.867	2026-06-10 08:12:37.473	2026-06-10 01:49:42.91	2026-06-10 08:12:37.474	2026-06-10 01:49:42.908	Microsoft Edge บนคอมพิวเตอร์	8701240454c90b2df29494afeb42494e58f77041bf8d7482e14b866fd821288c	1.10.247.0/24
cmq6r1syi001cjxrx55dt37v3	5edc9527e02a4196f8eba404fe9a9b0e4207569e44df1b0cbbcc44c86ff60c86	cmq0khs5m000wjx23jyhqhgkv	2026-06-10 14:43:01.721	2026-06-09 14:44:33.224	2026-06-09 14:44:41.946	2026-06-09 14:43:01.722	2026-06-09 14:44:41.947	2026-06-09 14:43:01.721	Chrome บนมือถือ	e5fad26edbdca88d7dba2031a251d659eef6fa383f71ff81a4cb8a2419604430	49.237.66.0/24
cmq6862g7000njx2t4iw0qd2h	c4e153367168e0a6fb7a3008852d5141b80d8f9f876622a0ff0f2a2e4141680a	cmp6j8ifp0002jxdffdiyvvw3	2026-06-10 05:54:27.941	2026-06-09 09:32:20.487	2026-06-09 09:32:29.56	2026-06-09 05:54:27.943	2026-06-09 09:32:29.561	2026-06-09 05:54:27.941	Chrome บนคอมพิวเตอร์	9884896580bbd9285b8a0782ea7ae63de01ed5f471d1bab6202de0630c0399a3	124.122.9.0/24
cmq6fys5e0002jxsdpgsnsj9l	95f01e3396bfb8893ae066a5a512edc3b572df319a85f74ac02c279882805166	cmp6j8ifp0002jxdffdiyvvw3	2026-06-10 09:32:44.929	2026-06-09 09:46:55.833	2026-06-09 09:47:23.996	2026-06-09 09:32:44.931	2026-06-09 09:47:23.997	2026-06-09 09:32:44.929	Chrome บนคอมพิวเตอร์	9884896580bbd9285b8a0782ea7ae63de01ed5f471d1bab6202de0630c0399a3	124.122.9.0/24
cmq9hkubq000rjxh50093fbha	8b989695886eee70bfe588617da7761cb1c28f85798bace3090bf756c88b03d7	cmpmdmbqv000kjxgmprk5t2o6	2026-06-12 12:41:12.324	2026-06-11 12:41:12.324	2026-06-11 12:41:19.722	2026-06-11 12:41:12.326	2026-06-11 12:41:19.724	2026-06-11 12:41:12.324	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	27.145.16.0/24
cmq6qg5y30015jxrxeegjqxyy	463dabf35d4cb23a833293e8424d757cf7b9363752f4ab2dbf6b9adbd9fe5e7a	cmq0khs5m000wjx23jyhqhgkv	2026-06-10 14:26:12.122	2026-06-09 14:41:37.547	2026-06-09 14:42:03.812	2026-06-09 14:26:12.123	2026-06-09 14:42:03.813	2026-06-09 14:26:12.122	Chrome บนมือถือ	e5fad26edbdca88d7dba2031a251d659eef6fa383f71ff81a4cb8a2419604430	49.237.66.0/24
cmq6r1pdi000zjxsdokm0e6pr	1740806a404b61060e61d3d462d353216208b8fae965ee3703d7970dda0a631c	cmq0khs5m000wjx23jyhqhgkv	2026-06-10 14:42:57.077	2026-06-09 14:42:57.077	\N	2026-06-09 14:42:57.078	2026-06-09 14:42:57.078	2026-06-09 14:42:57.077	Chrome บนมือถือ	e5fad26edbdca88d7dba2031a251d659eef6fa383f71ff81a4cb8a2419604430	49.237.66.0/24
cmq7mmans0001jxhl2imm665i	004b83de523723670b8901468e19a33191429c2e81eae1ad7ea666544888f2b2	cmp6j8ifp0002jxdffdiyvvw3	2026-06-11 05:26:45.878	2026-06-10 05:29:55.979	2026-06-11 02:42:16.808	2026-06-10 05:26:45.88	2026-06-11 02:42:16.809	2026-06-10 05:26:45.878	Chrome บนคอมพิวเตอร์	9884896580bbd9285b8a0782ea7ae63de01ed5f471d1bab6202de0630c0399a3	49.228.99.0/24
cmq7pcvpu0006jxhl8y2yz4i4	8b1a59b4f422ec98a7c68a5c0f37bfb944a780b47730a889110ccec5b664dc94	cmq0kyw85007kjx239k25z1ge	2026-06-11 06:43:25.457	2026-06-10 06:43:25.457	\N	2026-06-10 06:43:25.459	2026-06-10 06:43:25.459	2026-06-10 06:43:25.457	Microsoft Edge บนคอมพิวเตอร์	8701240454c90b2df29494afeb42494e58f77041bf8d7482e14b866fd821288c	1.2.206.0/24
cmq7sklwz0009jxhleaaiy2g9	74cbe09175535ee2fd0a3a58681917f48b8a9e29b4e1ecb9402d5109a150bd7b	cmq0kyw85007kjx239k25z1ge	2026-06-11 08:13:24.848	2026-06-10 08:44:59.664	2026-06-10 08:45:47.876	2026-06-10 08:13:24.851	2026-06-10 08:45:47.877	2026-06-10 08:13:24.848	Microsoft Edge บนคอมพิวเตอร์	8701240454c90b2df29494afeb42494e58f77041bf8d7482e14b866fd821288c	1.2.206.0/24
cmq7znqpc000ejxhlwjwpziys	b0410a4fc7858935160e5d3c2cb8b41c679430dfbc911318ae594dbd040d1dba	cmp6j8ifp0002jxdffdiyvvw3	2026-06-11 11:31:48.335	2026-06-10 11:39:41.055	2026-06-11 05:07:34.176	2026-06-10 11:31:48.336	2026-06-11 05:07:34.177	2026-06-10 11:31:48.335	Chrome บนมือถือ	ef78bc17265d32e6c02d6cc23189e096909db7f5084bb8d0fe20ac7585d8c803	184.22.136.0/24
cmq91dnqi000ojxhl54vaka0g	0e559fb02e14e6a9d807ee3d1344a8cc116190273d3871c013e53f6b14dbb908	cmp6j8ifp0002jxdffdiyvvw3	2026-06-12 05:07:43.337	2026-06-11 05:13:09.778	2026-06-11 11:25:32.244	2026-06-11 05:07:43.339	2026-06-11 11:25:32.245	2026-06-11 05:07:43.337	Chrome บนมือถือ	ef78bc17265d32e6c02d6cc23189e096909db7f5084bb8d0fe20ac7585d8c803	2001:44c8:46e2:bb72::/64
cmq9hl6bm0013jxhlh31q6jph	73d6352490b2ebf15802aae0a1fa31ff118defd715f1461b13a27c310c963d19	cmp6j4rgk0000jxuitzv4y8us	2026-06-12 12:41:27.873	2026-06-11 13:53:00.929	\N	2026-06-11 12:41:27.875	2026-06-11 13:53:00.933	2026-06-11 12:41:27.873	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	27.145.16.0/24
cmq98s0wd000hjxh5pt4hyxw6	cd69b24df6e4e5222e9ce5b9f051b410b5f9f0a15cd238d7c1839602dc6b1900	cmp6j8ifp0002jxdffdiyvvw3	2026-06-12 08:34:50.891	2026-06-11 08:41:42.972	2026-06-12 02:37:29.183	2026-06-11 08:34:50.893	2026-06-12 02:37:29.185	2026-06-11 08:34:50.891	Chrome บนคอมพิวเตอร์	9884896580bbd9285b8a0782ea7ae63de01ed5f471d1bab6202de0630c0399a3	124.122.9.0/24
cmq9evthq000ojxh5ul12xiw4	cd3ce7e607f7b2669543e6d61856935189884fef8c7061ee26c673e99ffedb02	cmp6j8ifp0002jxdffdiyvvw3	2026-06-12 11:25:45.612	2026-06-11 11:25:45.612	2026-06-12 04:44:31.261	2026-06-11 11:25:45.614	2026-06-12 04:44:31.262	2026-06-11 11:25:45.612	Chrome บนมือถือ	db2d2b5916fb2ffa469154f9d8cbf4b101eb7de65bf876e6b9f331cc45f529c2	184.22.136.0/24
cmqabgg6p0015jxh543q4v6jm	e1cb3d49389056c71bc76176082b18739f79aed84b91b80d20cd9d02bd1ee7e0	cmp6j8ifp0002jxdffdiyvvw3	2026-06-13 02:37:35.855	2026-06-12 04:42:21.7	2026-06-12 04:43:02.31	2026-06-12 02:37:35.857	2026-06-12 04:43:02.395	2026-06-12 02:37:35.855	Chrome บนคอมพิวเตอร์	9884896580bbd9285b8a0782ea7ae63de01ed5f471d1bab6202de0630c0399a3	124.122.9.0/24
cmqafzwwv0006jxp5klnwmlc0	1198ad68572e110de847acc7c6e22cf36689800fee125a2cde599d1ba0edf258	cmp6j8ifp0002jxdffdiyvvw3	2026-06-13 04:44:42.462	2026-06-12 05:10:25.778	2026-06-12 11:55:50.283	2026-06-12 04:44:42.464	2026-06-12 11:55:50.284	2026-06-12 04:44:42.462	Chrome บนมือถือ	db2d2b5916fb2ffa469154f9d8cbf4b101eb7de65bf876e6b9f331cc45f529c2	2001:44c8:46e7:afba::/64
cmqg6j7aa0009jxy9hd208w3v	5e389156b337436c4e3673be7f54e2285b713e2105e0170942466586c41e61cc	cmp6j8ifp0002jxdffdiyvvw3	2026-06-17 05:06:23.265	2026-06-16 05:08:28.849	2026-06-16 05:09:07.551	2026-06-16 05:06:23.266	2026-06-16 05:09:07.552	2026-06-16 05:06:23.265	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	124.122.9.0/24
cmqapkkq500cmjxp57gswg931	798efab48a92805ba29fb6350c0a18ca3d8bf0551d4f9e0b44ea9b11690fe473	cmq0kyw85007kjx239k25z1ge	2026-06-13 09:12:42.988	2026-06-12 09:23:55.502	\N	2026-06-12 09:12:42.989	2026-06-12 09:23:55.509	2026-06-12 09:12:42.988	Microsoft Edge บนคอมพิวเตอร์	8701240454c90b2df29494afeb42494e58f77041bf8d7482e14b866fd821288c	182.53.118.0/24
cmqezuvzn005ljxoppinu19q7	caabb7dc035accf69f7db60fa7e0886693864a13982094d13e76380bd48b4c33	cmq0khs5m000wjx23jyhqhgkv	2026-06-16 09:11:45.01	2026-06-15 09:17:44.903	2026-06-15 09:21:56.262	2026-06-15 09:11:45.012	2026-06-15 09:21:56.264	2026-06-15 09:11:45.01	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	119.110.209.0/24
cmqapycfu00cvjxp5y5nhieqp	8f7897ae89c1e6d0560f47d6730c2a46320cbc01d06f2ee01dc336f0916ae8f7	cmq0khs5m000wjx23jyhqhgkv	2026-06-13 09:23:25.433	2026-06-12 09:27:09.284	\N	2026-06-12 09:23:25.435	2026-06-12 09:27:09.288	2026-06-12 09:23:25.433	Microsoft Edge บนคอมพิวเตอร์	8701240454c90b2df29494afeb42494e58f77041bf8d7482e14b866fd821288c	182.53.118.0/24
cmqafyr4y0004jxopd06wlpxw	985690783974c72d30ff58039964bd53fa3f4118523d5cd0802ec82b8d88609e	cmp6j8ifp0002jxdffdiyvvw3	2026-06-13 04:43:48.321	2026-06-12 04:48:07.91	2026-06-13 03:59:42.764	2026-06-12 04:43:48.323	2026-06-13 03:59:42.765	2026-06-12 04:43:48.321	Chrome บนคอมพิวเตอร์	9884896580bbd9285b8a0782ea7ae63de01ed5f471d1bab6202de0630c0399a3	124.122.9.0/24
cmqavey9u00d2jxp57nc2at55	f19402eb4e56045938ddd68130d99cdf2f56e82ff3d5c84f98d9f349e914aad4	cmp6j8ifp0002jxdffdiyvvw3	2026-06-13 11:56:18.305	2026-06-12 11:57:19.825	2026-06-13 04:01:47.936	2026-06-12 11:56:18.307	2026-06-13 04:01:47.937	2026-06-12 11:56:18.305	Chrome บนมือถือ	db2d2b5916fb2ffa469154f9d8cbf4b101eb7de65bf876e6b9f331cc45f529c2	184.22.136.0/24
cmqal6tbh000gjxop3i4xs7av	388eac27633825de4740515e124f087b9c3e5263b36ea34080fb5760dee7d8c5	cmq0ke15g0007jx23k3ypiimb	2026-06-13 07:10:02.475	2026-06-12 07:24:25.005	2026-06-12 07:32:29.875	2026-06-12 07:10:02.477	2026-06-12 07:32:29.876	2026-06-12 07:10:02.475	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	2001:44c8:4501:80c9::/64
cmqev56mj0030jxopamnthquy	1a1341d81d7b98af4ec65095a26d9c7f44505b35be90d0aceae9bd92f63e72e8	cmq0ke15g0007jx23k3ypiimb	2026-06-16 06:59:47.274	2026-06-15 08:39:03.458	2026-06-15 08:54:16.865	2026-06-15 06:59:47.275	2026-06-15 08:54:16.866	2026-06-15 06:59:47.274	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	2001:fb1:12b:e36f::/64
cmqaoujcn0011jxops7c6e39x	9446792c2c150df1f80868340578fb19d45c6b033d5d943a446d65d6840e2284	cmq0khs5m000wjx23jyhqhgkv	2026-06-13 08:52:28.15	2026-06-12 09:04:03.115	2026-06-12 09:09:40.15	2026-06-12 08:52:28.152	2026-06-12 09:09:40.152	2026-06-12 08:52:28.15	Microsoft Edge บนคอมพิวเตอร์	8701240454c90b2df29494afeb42494e58f77041bf8d7482e14b866fd821288c	182.53.118.0/24
cmqdmrhcq00e4jxp58gz3tzs1	a549b7a7f410000596420a2fc7efa434cecb651bfe1f02ea141cb7c98f09c40b	cmq0kyw85007kjx239k25z1ge	2026-06-15 10:17:24.889	2026-06-14 10:18:11.326	2026-06-14 10:18:48.338	2026-06-14 10:17:24.891	2026-06-14 10:18:48.339	2026-06-14 10:17:24.889	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	119.110.209.0/24
cmqepta2000tkjxp5rcrynf6o	6a870df63d04ae3f8e5a7a4e41b7bbba920e21b1631b6b11117f1cd87d650915	cmp6j4rgk0000jxuitzv4y8us	2026-06-16 04:30:33.766	2026-06-15 04:32:56.058	2026-06-15 09:01:53.256	2026-06-15 04:30:33.768	2026-06-15 09:01:53.257	2026-06-15 04:30:33.766	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	119.110.209.0/24
cmqdmtd15002bjxoph1dzgc2e	14ca4dc7818fb06fce79d9562ac79e054242c33afb4bc787efb20ee6e8feb993	cmp6j4rgk0000jxuitzv4y8us	2026-06-15 10:18:52.6	2026-06-14 10:51:30.571	2026-06-15 03:50:06.964	2026-06-14 10:18:52.602	2026-06-15 03:50:06.966	2026-06-14 10:18:52.6	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	119.110.209.0/24
cmqcdtxez00dgjxp5sxmi6w8a	c135fd0b9ee94d624febe0ea93bd2f3cbf60046a85aa3c652591a7a0bf3c0d55	cmq0kfz02000ijx23kh3yrfbs	2026-06-14 13:19:36.297	2026-06-13 14:19:56.926	\N	2026-06-13 13:19:36.299	2026-06-13 14:19:56.936	2026-06-13 13:19:36.297	Microsoft Edge บนคอมพิวเตอร์	8701240454c90b2df29494afeb42494e58f77041bf8d7482e14b866fd821288c	27.145.249.0/24
cmqbtu5la001gjxope748qr3a	fd71e9d3cbd91b57503e746e4ddcf65336a5e91b8167ee9f49832b24b6906647	cmp6j8ifp0002jxdffdiyvvw3	2026-06-14 03:59:54.572	2026-06-13 04:08:17.72	2026-06-14 03:59:18.508	2026-06-13 03:59:54.574	2026-06-14 03:59:18.509	2026-06-13 03:59:54.572	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	184.22.35.0/24
cmqeodr0200ecjxp5rfbfqbdp	4ebb58446f49af5686919090c460f141c7db3bf2580b5a24261c1ddb2006abb2	cmq0khs5m000wjx23jyhqhgkv	2026-06-16 03:50:29.616	2026-06-15 04:13:05.474	2026-06-15 04:30:29.321	2026-06-15 03:50:29.618	2026-06-15 04:30:29.325	2026-06-15 03:50:29.616	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	119.110.209.0/24
cmqeziw5p005ijxopj08s0c6l	1c9ea0a48c7436acf04020ce92540611141e081191f4f59510d95ed9383e245b	cmp6j4rgk0000jxuitzv4y8us	2026-06-16 09:02:25.355	2026-06-15 09:10:08.239	2026-06-15 09:11:06.092	2026-06-15 09:02:25.357	2026-06-15 09:11:06.093	2026-06-15 09:02:25.355	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	119.110.209.0/24
cmqenz264002djxopwcvjn3ri	bec6c65fada55c0142c0f685decfb4918e3ff1e2bc578f4fe2dc3345ec25df77	cmq0kfz02000ijx23kh3yrfbs	2026-06-16 03:39:04.25	2026-06-15 04:55:17.431	\N	2026-06-15 03:39:04.252	2026-06-15 04:55:17.479	2026-06-15 03:39:04.25	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	119.76.128.0/24
cmqf08sx8007kjxop6dzw74xm	6f26f11046098efd3b02dfe7cf9707e902a071b2284644976e2db6cab9c35616	cmp6j4rgk0000jxuitzv4y8us	2026-06-16 09:22:34.219	2026-06-15 09:22:34.219	2026-06-16 02:58:44.365	2026-06-15 09:22:34.22	2026-06-16 02:58:44.366	2026-06-15 09:22:34.219	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	119.110.209.0/24
cmqf086nq007gjxophoj26o6c	df5d78e1ec065887ee7c27eabc4b867911c62649f40b454456bb6cfbd4414438	cmq0khs5m000wjx23jyhqhgkv	2026-06-16 09:22:05.365	2026-06-15 09:22:05.365	2026-06-15 09:22:25.41	2026-06-15 09:22:05.366	2026-06-15 09:22:25.411	2026-06-15 09:22:05.365	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	119.110.209.0/24
cmqf1y54i0004jx16ng8ckefi	ea53540e79a4a82c115782157c389327621963251c8111eb78ce001f39c6412a	cmp6j8ifp0002jxdffdiyvvw3	2026-06-16 10:10:16.049	2026-06-15 15:18:24.867	2026-06-16 01:08:38.011	2026-06-15 10:10:16.051	2026-06-16 01:08:38.012	2026-06-15 10:10:16.049	Chrome บนมือถือ	db2d2b5916fb2ffa469154f9d8cbf4b101eb7de65bf876e6b9f331cc45f529c2	184.22.35.0/24
cmqg1z4uj000ijx1nn0asvn35	5c03f6cce3fbdd6f557fd4869a72c1e65dd2ee59f1b5d56d83c2e4b91b5a990f	cmp6j4rgk0000jxuitzv4y8us	2026-06-17 02:58:48.521	2026-06-16 03:00:48.083	\N	2026-06-16 02:58:48.523	2026-06-16 03:00:48.093	2026-06-16 02:58:48.521	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	119.110.209.0/24
cmqf1e7bm0001jx1n9jniffdx	a342623a49424be11453b8255728837c477e511a6415d34de97bd417f7fdf286	cmp6j8ifp0002jxdffdiyvvw3	2026-06-16 09:54:45.776	2026-06-15 09:58:52.349	2026-06-16 03:13:35.877	2026-06-15 09:54:45.778	2026-06-16 03:13:35.877	2026-06-15 09:54:45.776	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	124.122.9.0/24
cmqg2i8pe000kjx1n4i0x0cv9	9c8f69378e1f4cc2152e01e59348e94bdeafe8200aa171d009200d7aafbccc98	cmp6j8ifp0002jxdffdiyvvw3	2026-06-17 03:13:39.985	2026-06-16 05:05:33.217	2026-06-16 05:05:59.73	2026-06-16 03:13:39.986	2026-06-16 05:05:59.731	2026-06-16 03:13:39.985	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	124.122.9.0/24
cmqhp9mq20001jxe5f7uf5m2g	add9eadb7b0509318f74610cee3ce1c686234dafb39ec452a9e7b957f9c66bdb	cmp6j8ifp0002jxdffdiyvvw3	2026-06-18 06:38:35.592	2026-06-17 06:50:15.574	2026-06-17 12:27:25.768	2026-06-17 06:38:35.594	2026-06-17 12:27:25.769	2026-06-17 06:38:35.592	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	124.122.9.0/24
cmqho04xf0011jxvx0fhdtsq1	b54493d3fa450c6c26461be5d445b1114e82ab6907b070b25c8ed91b9bf1e8b5	cmq0kyw85007kjx239k25z1ge	2026-06-18 06:03:13.01	2026-06-17 06:14:05.807	\N	2026-06-17 06:03:13.011	2026-06-17 06:14:05.815	2026-06-17 06:03:13.01	Chrome บนมือถือ	31d8e44f8904e2edc85e2b5934a44c8fba1fff06407225aa5402c948e1736f12	1.2.207.0/24
cmqgfkcil0001jxcq60618gwr	e08e377c036369e0977f77277244f2f7cdca4a743fc53961f51925b5f0ec4744	cmp6j8ifp0002jxdffdiyvvw3	2026-06-17 09:19:13.241	2026-06-16 09:24:59.427	2026-06-16 09:25:25.282	2026-06-16 09:19:13.245	2026-06-16 09:25:25.283	2026-06-16 09:19:13.241	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	124.122.9.0/24
cmqgr91h5000cjxvxpk0d2l7l	1e8091cfd7a309b20b206458cfe53ce0e01dcca837d28f87981cbad7190175c6	cmq0ke15g0007jx23k3ypiimb	2026-06-17 14:46:21.111	2026-06-16 14:50:22.277	\N	2026-06-16 14:46:21.113	2026-06-16 14:50:22.283	2026-06-16 14:46:21.111	Safari บนมือถือ	8e514a094230e9b937672f320d6341a17e2c9eeb3509d70a4ae44642c15cdc55	2001:44c8:48d0:eb32::/64
cmqg6nlx2000cjxxtbi78d2za	2529719c616d8ad10cec11e9b9e50421c5f52d26d898744ae33a6e4c9a858aff	cmp6j8ifp0002jxdffdiyvvw3	2026-06-17 05:09:48.853	2026-06-16 13:44:40.309	2026-06-17 01:55:14.383	2026-06-16 05:09:48.854	2026-06-17 01:55:14.384	2026-06-16 11:35:09.299	Chrome บนมือถือ	db2d2b5916fb2ffa469154f9d8cbf4b101eb7de65bf876e6b9f331cc45f529c2	2001:44c8:46e5:d54e::/64
cmqgfsdt80006jxcqa0ltxo5j	021373f16c749dc2da279c6bd314e243b91e5d119f90f41edc200dc6aa0f048a	cmp6j8ifp0002jxdffdiyvvw3	2026-06-17 09:25:28.171	2026-06-16 09:51:41.692	2026-06-17 06:38:31.873	2026-06-16 09:25:28.172	2026-06-17 06:38:31.874	2026-06-16 09:25:28.171	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	124.122.9.0/24
cmqgduo790018jxy9ezhtravg	f0bccc0d4112683af4a447aebf2bbbcd311a4f08ac729e0a060f2adea03964b6	cmq0kyw85007kjx239k25z1ge	2026-06-17 08:31:15.716	2026-06-16 08:32:54.219	2026-06-16 08:34:18.106	2026-06-16 08:31:15.717	2026-06-16 08:34:18.107	2026-06-16 08:31:15.716	Microsoft Edge บนคอมพิวเตอร์	8701240454c90b2df29494afeb42494e58f77041bf8d7482e14b866fd821288c	1.2.206.0/24
cmqiyykbh000xjxe586eejpem	fd3b5862e5f43c14d17a232b09a79ca863b7edb1dd627704cfe5fb89e42279bc	cmqiyxznh000ojxdp7ho41qil	2026-06-19 03:57:41.596	2026-06-18 03:57:41.596	\N	2026-06-18 03:57:41.597	2026-06-18 03:57:41.597	2026-06-18 03:57:41.596	Browser บนมือถือ	c4e4fa0d3d1a6163179538dcd8bcb40092c2f4b6def06dd38960b678e7bf9d7e	2001:fb1:12b:e36f::/64
cmqhidgr5000kjxvx8j47mi41	216dc0f362be14577613f5934e40eff1e6986b904495b710bfdd26ff9f294492	cmpmdmbqv000kjxgmprk5t2o6	2026-06-18 03:25:37.168	2026-06-17 04:30:09.203	\N	2026-06-17 03:25:37.169	2026-06-17 04:30:09.291	2026-06-17 03:25:37.168	Safari บนมือถือ	36709a46e19405c3706894c673dbb5b2b55893ebfc03ce488a370fab29ef487a	1.20.93.0/24
cmqiyspr5000mjxe59qrxrkqd	102ab83050d8f573a5733c38824bbbab50b526ab751cd1a9943890c0dcb120ca	cmqiys133000ijxdpsllq3iqv	2026-06-19 03:53:08.704	2026-06-18 03:57:53.656	\N	2026-06-18 03:53:08.705	2026-06-18 03:57:53.661	2026-06-18 03:53:08.704	Browser บนมือถือ	aa643a38ec54934022a0b23fe387e60194204214a36a9a47da22747d70bee4a5	2001:44c8:45a5:15f::/64
cmqgds3vn0015jxy9kvgjeli7	78f76da0f47e00b8744d6f82051d6e86d43bb5b337f2ca169e169967bc686c18	cmq0ke15g0007jx23k3ypiimb	2026-06-17 08:29:16.065	2026-06-16 08:58:57.148	\N	2026-06-16 08:29:16.067	2026-06-16 08:58:57.172	2026-06-16 08:29:16.065	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	2001:fb1:12b:e36f::/64
cmqiyi345000ijxe5jt8e36ww	1a5e5fad1b82d185f3ca6601f031a1990ad7f71e7c16b9600ac1bf98f610e259	cmq0ke15g0007jx23k3ypiimb	2026-06-19 03:44:52.803	2026-06-18 03:49:44.777	\N	2026-06-18 03:44:52.806	2026-06-18 03:49:44.787	2026-06-18 03:44:52.803	Safari บนมือถือ	8e514a094230e9b937672f320d6341a17e2c9eeb3509d70a4ae44642c15cdc55	2001:44c8:44bf:5bf8::/64
cmqhnv2v7000xjxvx8mhcaufg	0c92dd7aee9ee0f7c9507e71fd8aada793b126117b55bab003b164851076982e	cmq0kyw85007kjx239k25z1ge	2026-06-18 05:59:17.058	2026-06-17 06:00:38.441	\N	2026-06-17 05:59:17.06	2026-06-17 06:00:38.447	2026-06-17 05:59:17.058	Microsoft Edge บนคอมพิวเตอร์	8701240454c90b2df29494afeb42494e58f77041bf8d7482e14b866fd821288c	1.2.207.0/24
cmqiywxqj000tjxe5sdv0jr1e	2b0764f2d5ccebd54a1e2915b9b9ae7e0a7a9314ca67b8d7b5701d47f4bba827	cmqiywhv5000pjxe502qkjrdo	2026-06-19 03:56:25.674	2026-06-18 03:56:25.674	\N	2026-06-18 03:56:25.676	2026-06-18 03:56:25.676	2026-06-18 03:56:25.674	Browser บนมือถือ	7c3aadbbbe01d3c7a7f51d2b97ef276dcee84c7b2aaefe92010b68edbdc8e709	2001:fb1:12b:e36f::/64
cmqbtwn9n001kjxopdn2mnsks	a260e144bd275a68fc980abd22dabc4401bd10f9a3ba0104283a062b14937908	cmp6j8ifp0002jxdffdiyvvw3	2026-06-14 04:01:50.794	2026-06-13 09:35:48.946	2026-06-17 12:27:25.768	2026-06-13 04:01:50.796	2026-06-17 12:27:25.769	2026-06-13 04:01:50.794	Chrome บนมือถือ	db2d2b5916fb2ffa469154f9d8cbf4b101eb7de65bf876e6b9f331cc45f529c2	184.22.35.0/24
cmqd99dhq00dzjxp51hpu8ggm	aa0f75dc7b72fc20c790e697a6ccdb60fba29954bbff2ea23ccaa046b0da2393	cmp6j8ifp0002jxdffdiyvvw3	2026-06-15 03:59:25.068	2026-06-14 04:07:45.896	2026-06-17 12:27:25.768	2026-06-14 03:59:25.07	2026-06-17 12:27:25.769	2026-06-14 03:59:25.068	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	184.22.35.0/24
cmqizv24v000xjxdp2fhfop3z	e589d216319e6eb0ca4e6f2343a9dfa140801930bc98100f6a5e77e39ee8b9c7	cmqizuk560011jxe5xc4ibqfr	2026-06-19 04:22:57.678	2026-06-18 04:22:57.678	\N	2026-06-18 04:22:57.679	2026-06-18 04:22:57.679	2026-06-18 04:22:57.678	Browser บนมือถือ	52857a420190db4d14a337268bf42a87dc785882ed20c5fb7259643a9fb05b7c	2001:44c8:48d7:8be9::/64
cmqiyy5vs000sjxdpyqudm9da	d68135baa01ab806fc0bc5b06a87d02548a16d0d5fc7114705ae289b76bf87ff	cmqiywhv5000pjxe502qkjrdo	2026-06-19 03:57:22.887	2026-06-18 04:02:37.397	2026-06-18 14:23:53.352	2026-06-18 03:57:22.888	2026-06-18 14:23:53.354	2026-06-18 03:57:22.887	Safari บนมือถือ	e97887180ce58770004b06c8a8b7fbdf647d5aadee30f7814e858e5ed4ff0e1a	2001:fb1:12b:e36f::/64
cmqkfmzie000cjxtd83bs4kj8	2315f9fd3c038eb6124e2ac709eaa4c8c5e60ecedc14ca1229aac63222d4c368	cmq0ke15g0007jx23k3ypiimb	2026-06-20 04:32:21.06	2026-06-19 04:32:21.06	2026-06-19 11:51:33.84	2026-06-19 04:32:21.062	2026-06-19 11:51:33.841	2026-06-19 04:32:21.06	Safari บนมือถือ	8e514a094230e9b937672f320d6341a17e2c9eeb3509d70a4ae44642c15cdc55	2001:44c8:44be:62bc::/64
cmqj0v0ny0001jx82a17lbm2h	577e1948a90de42adcbec29d150d2c3abcd1d14b7d257d90c1e8864463321b56	cmp6j8ifp0002jxdffdiyvvw3	2026-06-19 04:50:55.388	2026-06-18 10:32:24.425	2026-06-25 09:56:14.754	2026-06-18 04:50:55.39	2026-06-25 09:56:14.755	2026-06-18 04:50:55.388	Chrome บนมือถือ	db2d2b5916fb2ffa469154f9d8cbf4b101eb7de65bf876e6b9f331cc45f529c2	184.22.42.0/24
cmqkgst4a0008jxsxrr5xx81l	dbb982d88bea4238092fd0583fccec1bd6b818711ec4fc8c9ffe1f1ef4a9c5e1	cmp6j8ifp0002jxdffdiyvvw3	2026-06-20 05:04:52.327	2026-06-19 07:37:57.18	2026-06-19 11:52:37.721	2026-06-19 05:04:52.33	2026-06-19 11:52:37.722	2026-06-19 05:04:52.327	Chrome บนมือถือ	db2d2b5916fb2ffa469154f9d8cbf4b101eb7de65bf876e6b9f331cc45f529c2	2001:44c8:40e3:f4bf::/64
cmqkx1o6l0008jxek04bvu2to	634e0e5dd6b41801009d934d2813a686019dff9943f7c8765938e6deba21306e	cmq0kyw85007kjx239k25z1ge	2026-06-20 12:39:39.691	2026-06-19 13:41:14.465	\N	2026-06-19 12:39:39.693	2026-06-19 13:41:14.474	2026-06-19 12:39:39.691	Browser บนมือถือ	4efe2b4c3bb62a5391832a15bc2e36c82769eb111c722b2608724f2f7de82cd7	182.53.116.0/24
cmqkk9c7a000tjxtd8xiucdkc	8cba371ffe2cdde90a3b57352ee262b7668e6de124fd0527f9f1d907a8b0157c	cmq0kyw85007kjx239k25z1ge	2026-06-20 06:41:42.404	2026-06-19 06:46:30.525	\N	2026-06-19 06:41:42.406	2026-06-19 06:46:30.533	2026-06-19 06:41:42.404	Chrome บนมือถือ	31d8e44f8904e2edc85e2b5934a44c8fba1fff06407225aa5402c948e1736f12	1.2.205.0/24
cmqkkiqf2000kjxsxkssji3jb	74e94e72d536f3498fa92eaa661df7774ac9ed4afadff9e7add13fca8755a67f	cmq0khs5m000wjx23jyhqhgkv	2026-06-20 06:49:00.733	2026-06-19 06:53:27.705	\N	2026-06-19 06:49:00.734	2026-06-19 06:53:27.711	2026-06-19 06:49:00.733	Chrome บนมือถือ	f6944e059655c5cfa3d1929063174fdb02835ff411404017c2479fb845160acc	1.2.205.0/24
cmqkxbyta000ijxf0esdl37cl	3e602a67fe5880d5551995817da19cce8f219417136287e36139042a3a6a6dd2	cmq0kwit80066jx23pw930nx1	2026-06-20 12:47:40.029	2026-06-19 13:43:25.035	\N	2026-06-19 12:47:40.031	2026-06-19 13:43:25.041	2026-06-19 12:47:40.029	Browser บนมือถือ	1424719459d3d568e44b8102ced00ba389274106cd2b211bea57561e67f09f53	182.53.116.0/24
cmqkkjt430012jxtdtz4qgjev	83ab00daff8f98af5f95996042ee8e383818ce83d40f82dcbe9e2542b50e33ef	cmq0kyw85007kjx239k25z1ge	2026-06-20 06:49:50.881	2026-06-19 06:54:28.646	\N	2026-06-19 06:49:50.883	2026-06-19 06:54:28.652	2026-06-19 06:49:50.881	Chrome บนมือถือ	8b772d1dce7ad049f586812fd1c550a4816080eef4b157612982c19970d231c0	1.2.205.0/24
cmqkki9fm000ijxsxqfxi82o8	8f2a0fc1e5a4348385640fdb53c38cb76703daa1986577ae0aedb3b3947e181a	cmq0kyw85007kjx239k25z1ge	2026-06-20 06:48:38.721	2026-06-19 07:09:35.43	\N	2026-06-19 06:48:38.723	2026-06-19 07:09:35.496	2026-06-19 06:48:38.721	Browser บนมือถือ	7bcb639bf804730e9ebd1d6bd5de1867ed87eea6e196eef80a378469c305c096	49.237.203.0/24
cmql0wb9e0058jxeks9b66mhw	a201b1bad991ab9e24e2e8c948de5374810b72078936df35a69ebae685918d57	cmq0kyw85007kjx239k25z1ge	2026-06-20 14:27:28.128	2026-06-19 14:33:37.873	\N	2026-06-19 14:27:28.13	2026-06-19 14:33:37.878	2026-06-19 14:27:28.128	Microsoft Edge บนคอมพิวเตอร์	8701240454c90b2df29494afeb42494e58f77041bf8d7482e14b866fd821288c	182.53.116.0/24
cmqkx1njk0006jxekdqvxtonz	07ccd3dcd29c9bfe2fd9ec9c460312ee9ab4dba8efc40e6e44a2c339a5a57404	cmq0kyw85007kjx239k25z1ge	2026-06-20 12:39:38.863	2026-06-19 13:45:08.838	2026-06-20 01:55:31.005	2026-06-19 12:39:38.864	2026-06-20 01:55:31.006	2026-06-19 12:39:38.863	Safari บนคอมพิวเตอร์	613665f459baefd923e20ade88f6eb1c73a851d4a14ff08b4cbeb50bf5b1c7e1	182.53.116.0/24
cmqkx1wb0000cjxeka73eby4g	fee98548382c97f39f7aea91a689d80e0b7d16ec69467bee8f02d4c41a6b8567	cmq0khs5m000wjx23jyhqhgkv	2026-06-20 12:39:50.219	2026-06-19 13:44:51.039	\N	2026-06-19 12:39:50.22	2026-06-19 13:44:51.044	2026-06-19 12:39:50.219	Browser บนมือถือ	82e68664434234f145db618f20d647000ebcbd538fa2be6874a15c1e5fb5d381	182.53.116.0/24
cmqnsp0b5005mjxekq7d1wopu	b4218d4d04970dc3d9096121e2cabf6a089957b265577be8ab29bb0728248576	cmpmdmbqv000kjxgmprk5t2o6	2026-06-22 13:01:08.944	2026-06-21 13:01:08.944	2026-06-22 04:44:47.293	2026-06-21 13:01:08.945	2026-06-22 04:44:47.294	2026-06-21 13:01:08.944	Safari บนมือถือ	36709a46e19405c3706894c673dbb5b2b55893ebfc03ce488a370fab29ef487a	2403:6200:88a2:d7ab::/64
cmqn94agr005djxekxakmh9im	0175262f5a54a435624e4ea36736041b0e64c225c21164222a19c7f3e6414fef	cmqn94a13005pjxf0c0ewp2xv	2026-06-22 03:53:09.625	2026-06-21 04:07:12.28	2026-06-21 10:32:50.684	2026-06-21 03:53:09.627	2026-06-21 10:32:50.686	2026-06-21 03:53:09.625	Safari บนมือถือ	40eaeed115c336cf037ef7761cd0c6b38dfc7e85c4ba6cfe529572bc31037d63	2001:44c8:40a3:f808::/64
cmqoi65e2011qjxf0k6x3k91d	18a0e5466cd220b6a7a171a1d763298037c54d62339417e8d3d304e2940871ee	cmqoi5w5y00cvjxek58psevzp	2026-06-23 00:54:19.081	2026-06-22 00:54:19.081	2026-06-30 10:12:12.091	2026-06-22 00:54:19.082	2026-06-30 10:12:12.092	2026-06-22 00:54:19.081	Chrome บนมือถือ	17173fd24b6e000cd5ba64a12ca58941617b823f43eb3f617f07601df1ffef08	182.52.165.0/24
cmqkxbyfi000ojxek1xnge4dp	8c00e529609854e8b15b3b9340c0808de3ade1cc833b5228e703d61201b11482	cmq0kwit80066jx23pw930nx1	2026-06-20 12:47:39.533	2026-06-19 13:45:17.8	\N	2026-06-19 12:47:39.534	2026-06-19 13:45:17.806	2026-06-19 12:47:39.533	Browser บนมือถือ	7bcb639bf804730e9ebd1d6bd5de1867ed87eea6e196eef80a378469c305c096	182.53.116.0/24
cmqkx0xyt0004jxf0i7k0gyfr	d9b889de10a77d828253fc17f2c13647641062ecd8932f1ba9353ff64ff61dec	cmq0khs5m000wjx23jyhqhgkv	2026-06-20 12:39:05.715	2026-06-19 13:46:48.415	\N	2026-06-19 12:39:05.717	2026-06-19 13:46:48.418	2026-06-19 12:39:05.715	Browser บนมือถือ	166840017e5d66bfef44951d6bc245fde33acf160a3511d62475877816cce140	182.53.116.0/24
cmqkm401s0017jxtddmc9ybbk	44cac49e7bda1e6f1ecfc3ff56c696fa97607e8c036aaa52fb286f094a237765	cmq0kyw85007kjx239k25z1ge	2026-06-20 07:33:32.607	2026-06-19 07:34:33.846	2026-06-19 14:26:47.189	2026-06-19 07:33:32.609	2026-06-19 14:26:47.19	2026-06-19 07:33:32.607	Microsoft Edge บนคอมพิวเตอร์	8701240454c90b2df29494afeb42494e58f77041bf8d7482e14b866fd821288c	1.2.205.0/24
cmqnark1b005zjxf03f6hyssr	3d1eb9852a1dc9a2fbebdf53caf5b37d00a3a97eda5f47712f4b3009773b90ea	cmq0ke15g0007jx23k3ypiimb	2026-06-22 04:39:14.733	2026-06-21 07:28:34.559	2026-06-22 03:26:46.755	2026-06-21 04:39:14.735	2026-06-22 03:26:46.756	2026-06-21 04:39:14.733	Safari บนมือถือ	8e514a094230e9b937672f320d6341a17e2c9eeb3509d70a4ae44642c15cdc55	49.230.170.0/24
cmqnvcmll0066jxf0ltlsz2uz	8af9d682317e0e5409c35e5c716edb6ce108bcb351dcebe4a58cd0d39158f0fe	cmqn94a13005pjxf0c0ewp2xv	2026-06-22 14:15:30.151	2026-06-21 15:45:19.246	2026-06-22 00:06:13.033	2026-06-21 14:15:30.153	2026-06-22 00:06:13.034	2026-06-21 14:15:30.151	Safari บนมือถือ	40eaeed115c336cf037ef7761cd0c6b38dfc7e85c4ba6cfe529572bc31037d63	2001:44c8:41e1:ebc2::/64
cmqntpffr005qjxekbddrxhwd	6002e5053e2f41fe972dc115cf78b8eccd20e0378aefad0af1bedef1dc65723c	cmq0kgjsg000njx23n27h0rcx	2026-06-22 13:29:28.166	2026-06-21 18:14:28.615	\N	2026-06-21 13:29:28.167	2026-06-21 18:14:28.62	2026-06-21 13:29:28.166	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	1.2.237.0/24
cmqnyi2kx00c7jxek3rye020m	daf63b88bceb89b489be88e220456ea8ea7d109b006e45ea89dc50d2f82800de	cmqnye8m700c2jxekf3kd0pos	2026-06-22 15:43:42.991	2026-06-21 15:43:42.991	\N	2026-06-21 15:43:42.993	2026-06-21 15:43:42.993	2026-06-21 15:43:42.991	Browser บนมือถือ	b793f3eba90c755f8be79614dc95b36601cb92dbdb6699b528418741d1d81824	125.25.47.0/24
cmqnyp46v00ccjxekaefhvi7p	0af4dcb6e2f629510180633a811a3d4d35b5186038ccdd764f34bfecf4e976d8	cmqnx8i0300bsjxekiur21agf	2026-06-22 15:49:11.67	2026-06-21 15:49:11.67	\N	2026-06-21 15:49:11.672	2026-06-21 15:49:11.672	2026-06-21 15:49:11.67	Safari บนมือถือ	0eebaa9a4b1b82947c1bb6fe1b16b67c1411d4cbb9a4c6f4661f4d039d3e5059	2001:44c8:4404:69f1::/64
cmqnvdry90069jxf0mq5s02rr	40afdccd691b0a9b0a258fe5fec6ad4305525b937e94d14dc4a0649c51631d79	cmqn94a13005pjxf0c0ewp2xv	2026-06-22 14:16:23.744	2026-06-21 16:10:57.576	\N	2026-06-21 14:16:23.745	2026-06-21 16:10:57.647	2026-06-21 14:16:23.744	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	2001:44c8:41e1:ebc2::/64
cmqnym33t00c8jxf02crzt4dw	73e3e5019fa6e724cc2dab5540ce54d952062fc63ffe0e5aa38ee64c8c1835a6	cmqnx8i0300bsjxekiur21agf	2026-06-22 15:46:50.295	2026-06-21 15:54:10.011	\N	2026-06-21 15:46:50.297	2026-06-21 15:54:10.017	2026-06-21 15:46:50.295	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	2001:44c8:4404:69f1::/64
cmqludxno005ijxf0m00ndidq	209bf81dee971a129c42604edcf79ecc84bf5de62b91f485fff8b2d108d2db76	cmp6j8ifp0002jxdffdiyvvw3	2026-06-21 04:12:59.17	2026-06-20 04:17:51.874	2026-06-25 09:56:14.754	2026-06-20 04:12:59.172	2026-06-25 09:56:14.755	2026-06-20 04:12:59.17	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	184.22.17.0/24
cmqn90laq005mjxf0svixuo5j	17a494fbe26e728ea6aedf76f54555d2361ad8174724091845faaff1f97375ba	cmp6j4rgk0000jxuitzv4y8us	2026-06-22 03:50:17.041	2026-06-21 03:51:25.583	2026-06-22 02:47:16.197	2026-06-21 03:50:17.042	2026-06-22 02:47:16.198	2026-06-21 03:50:17.041	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	2403:6200:88a2:d7ab::/64
cmqriabf6000ujx44o9c8r7m5	caf4516503e20ce5fd0bac2efc82dd7c9b3ac44785b45afbb59fb93ee6324b8f	cmp6j4rgk0000jxuitzv4y8us	2026-06-25 03:20:52.048	2026-06-24 03:22:00.615	\N	2026-06-24 03:20:52.05	2026-06-24 03:22:00.621	2026-06-24 03:20:52.048	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	2403:6200:88a2:d7ab::/64
cmqonmdz800d6jxekft6hewz2	ed101899485470d6f1dae080b04ba519f35b9ebd067b332672b8a5f097e8656a	cmq0ke15g0007jx23k3ypiimb	2026-06-23 03:26:54.786	2026-06-22 03:26:54.786	\N	2026-06-22 03:26:54.788	2026-06-22 03:26:54.788	2026-06-22 03:26:54.786	Safari บนมือถือ	8e514a094230e9b937672f320d6341a17e2c9eeb3509d70a4ae44642c15cdc55	2001:44c8:45a7:60ea::/64
cmqonaiol011tjxf0o5ivmuvf	aa46f2c4485132f8ef4f0a93d7616a225dfef3681b1355ca8391e03f7b98c2c1	cmp6j8ifp0002jxdffdiyvvw3	2026-06-23 03:17:41.012	2026-06-22 03:19:03.588	2026-06-23 01:50:07.348	2026-06-22 03:17:41.013	2026-06-23 01:50:07.349	2026-06-22 03:17:41.012	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	115.87.99.0/24
cmqophdc200d9jxekrrinjmat	6e56f6f0b26632c3a811c1b8febe32926cf3f2e72eaa840ca2837eb2eed0b162	cmp6j4rgk0000jxuitzv4y8us	2026-06-23 04:18:59.905	2026-06-22 04:23:57.733	\N	2026-06-22 04:18:59.906	2026-06-22 04:23:57.737	2026-06-22 04:18:59.905	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	2403:6200:88a2:d7ab::/64
cmqoswh2k012bjxf0fgwraeq9	c59f6c78c9cab487db8c4e0de624b848e4a4db44423b2bd09c7855e0ce93a1e0	cmqoswgix00dcjxekbvbk3x2z	2026-06-23 05:54:43.435	2026-06-22 05:54:43.435	\N	2026-06-22 05:54:43.436	2026-06-22 05:54:43.436	2026-06-22 05:54:43.435	Chrome บนมือถือ	9c37de0a24ad7dc804f7e6d9a547c1b58382fa9fc4520fd6fd1e1c19270026f4	2001:44c8:6793:fd::/64
cmqpcuxzu00dijxek0qqbfwtd	036c156e30f17547b4d11d30eb737f101fd69069f3e4336a30661ea17a6ed94f	cmp6j8ifp0002jxdffdiyvvw3	2026-06-23 15:13:24.376	2026-06-22 15:17:04.699	2026-06-23 01:55:54.007	2026-06-22 15:13:24.378	2026-06-23 01:55:54.008	2026-06-22 15:13:24.376	Chrome บนมือถือ	db2d2b5916fb2ffa469154f9d8cbf4b101eb7de65bf876e6b9f331cc45f529c2	184.22.17.0/24
cmqqaffr7000bjx4mj4mlwrvk	26eaa54bf19f8006fde2b1da9b78ff942b9ac4b2ffacf19ca465492e9da639ff	cmq0khs5m000wjx23jyhqhgkv	2026-06-24 06:53:07.842	2026-06-23 06:54:54.986	\N	2026-06-23 06:53:07.843	2026-06-23 06:54:54.993	2026-06-23 06:53:07.842	Chrome บนมือถือ	c8f39c3c3b810de853a22d55b764d70cdf85da8af8dc4115b116e0ac582c348b	1.2.201.0/24
cmqqj5l3e000ijx441prmwu20	c94869946fee9c8e695fcfe8e20eb76d57f6997af860dcf584892f82444bb7c6	cmp6j8ifp0002jxdffdiyvvw3	2026-06-24 10:57:24.745	2026-06-23 10:57:24.745	2026-06-25 09:56:14.754	2026-06-23 10:57:24.746	2026-06-25 09:56:14.755	2026-06-23 10:57:24.745	Chrome บนแท็บเล็ต	aeacf7a77b7598b35cb72c59beff84bcd2963b3819f3c5270e41ec9152237adf	2001:44c8:4224:73bf::/64
cmqolae6o00d1jxekoym67kvc	268a77475b215393de0fa1155e1361748b9c635f0a1c4f6ffc218ba5d8371bad	cmq0kyw85007kjx239k25z1ge	2026-06-23 02:21:35.95	2026-06-22 06:52:46.221	\N	2026-06-22 02:21:35.952	2026-06-22 06:52:46.234	2026-06-22 02:21:35.95	Microsoft Edge บนคอมพิวเตอร์	8701240454c90b2df29494afeb42494e58f77041bf8d7482e14b866fd821288c	1.10.219.0/24
cmqqc4y5s000ejx44r8g48v0p	4724ff676ccf72202f91040d548e8b0b9db79f586c2933fe43ba469bc82d5693	cmp6j4rgk0000jxuitzv4y8us	2026-06-24 07:40:57.71	2026-06-23 07:40:57.71	2026-06-23 07:41:18.254	2026-06-23 07:40:57.712	2026-06-23 07:41:18.255	2026-06-23 07:40:57.71	Chrome บนมือถือ	e7b310a18ad16700e974d369d617f7135e8159f4bc2cbf9f04e71d03ce8b0fc7	1.20.93.0/24
cmqotmb6t012djxf0xy0mizpe	346403da45e9df4b0c8f2029a7bafb29ae7a5d9b1998ac155d39119dc1f2976e	cmq0khs5m000wjx23jyhqhgkv	2026-06-23 06:14:48.867	2026-06-22 07:01:26.448	\N	2026-06-22 06:14:48.869	2026-06-22 07:01:26.456	2026-06-22 06:14:48.867	Microsoft Edge บนคอมพิวเตอร์	8701240454c90b2df29494afeb42494e58f77041bf8d7482e14b866fd821288c	1.10.219.0/24
cmqp16mz5012gjxf00d071erx	9dda3858c238c5151b5a8377aa5d879a34cbe022c3a72c2db7bcb3ce3c3d846a	cmq0kgjsg000njx23n27h0rcx	2026-06-23 09:46:34.576	2026-06-22 09:46:34.576	\N	2026-06-22 09:46:34.577	2026-06-22 09:46:34.577	2026-06-22 09:46:34.576	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	1.2.237.0/24
cmqq0b002012ojxf0v0qyr6k9	48f3bf0578018e075040ba2bfb6f1a6ef67c7b89fc6c7fb329200d12abf01001	cmp6j8ifp0002jxdffdiyvvw3	2026-06-24 02:09:44.641	2026-06-23 03:47:22.859	2026-06-23 10:54:03.65	2026-06-23 02:09:44.642	2026-06-23 10:54:03.651	2026-06-23 02:09:44.641	Chrome บนมือถือ	db2d2b5916fb2ffa469154f9d8cbf4b101eb7de65bf876e6b9f331cc45f529c2	2001:44c8:41a1:13fd::/64
cmqqc6d9a000fjx4m63ksyfrk	106015858d0b470ea69238eb27ed7ac42ed3e8c4a789519155a8b735192cde5c	cmq0khs5m000wjx23jyhqhgkv	2026-06-24 07:42:03.933	2026-06-23 07:55:42.654	\N	2026-06-23 07:42:03.934	2026-06-23 07:55:42.703	2026-06-23 07:42:03.933	Chrome บนมือถือ	e7b310a18ad16700e974d369d617f7135e8159f4bc2cbf9f04e71d03ce8b0fc7	1.20.93.0/24
cmqpzrslm00dpjxeka476o23f	753f734cb2fcbf4b4f886e9989d85ac2dc35fc536017f2c5f6bd8b2773ffdc8e	cmp6j8ifp0002jxdffdiyvvw3	2026-06-24 01:54:48.584	2026-06-23 03:50:21.792	2026-06-23 09:47:15.957	2026-06-23 01:54:48.586	2026-06-23 09:47:15.958	2026-06-23 01:54:48.584	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	115.87.99.0/24
cmqqgngpi000kjx4mfz0n2yjm	46739d7782b38b8d55dbe7ca821efcdfad8a7488683fc33fdffc53340c8bca2e	cmp6j8ifp0002jxdffdiyvvw3	2026-06-24 09:47:20.021	2026-06-23 09:52:48.394	2026-06-24 02:38:29.566	2026-06-23 09:47:20.022	2026-06-24 02:38:29.567	2026-06-23 09:47:20.021	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	115.87.99.0/24
cmqqj7wi6000njx44s48ptpwx	bd53e754a63e7395e97e1bcf3c2245b77463ab591e14c9cf36b997d2f83e614d	cmp6j8ifp0002jxdffdiyvvw3	2026-06-24 10:59:12.845	2026-06-23 11:37:38.695	2026-06-24 03:51:52.322	2026-06-23 10:59:12.846	2026-06-24 03:51:52.323	2026-06-23 10:59:12.845	Chrome บนมือถือ	db2d2b5916fb2ffa469154f9d8cbf4b101eb7de65bf876e6b9f331cc45f529c2	184.22.40.0/24
cmqq9syz9000bjx44y0d73ms3	21142b0b8529cd1e10bbfb02a61cde4904b23ec59a467fae6bb1d0c8f6b41711	cmq0ke15g0007jx23k3ypiimb	2026-06-24 06:35:39.667	2026-06-23 07:26:23.002	2026-06-24 04:00:30.782	2026-06-23 06:35:39.669	2026-06-24 04:00:30.783	2026-06-23 06:35:39.667	Safari บนมือถือ	8e514a094230e9b937672f320d6341a17e2c9eeb3509d70a4ae44642c15cdc55	2001:44c8:48e7:9ad1::/64
cmqrje96z0004jx1on3fopru9	e3fe6397f670dbdfc09b6cbd4278c92bbf5359131021b942e2336cfa53db8370	cmp6j8ifp0002jxdffdiyvvw3	2026-06-25 03:51:55.402	2026-06-24 03:55:20.871	2026-06-24 03:52:31.008	2026-06-24 03:51:55.404	2026-06-24 03:55:20.88	2026-06-24 03:51:55.402	Chrome บนมือถือ	db2d2b5916fb2ffa469154f9d8cbf4b101eb7de65bf876e6b9f331cc45f529c2	184.22.9.0/24
cmqrnqjgr000ejx18x41wfzvo	d3b071c4af786f003c5ea85fdbb19412f5c61ccb578acf03f7c81e69854d9dd9	cmp6j4rgk0000jxuitzv4y8us	2026-06-25 05:53:27.05	2026-06-24 06:00:58.769	\N	2026-06-24 05:53:27.052	2026-06-24 06:00:58.775	2026-06-24 05:53:27.05	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	1.20.93.0/24
cmqrlycy0000ajx180s5z3e0q	b33f9e65bb907e4a3b848b9d81527762eb75599cee0a79d652278630f8e938b4	cmp6j8ifp0002jxdffdiyvvw3	2026-06-25 05:03:32.614	2026-06-24 05:03:32.614	2026-06-24 10:53:13.66	2026-06-24 05:03:32.616	2026-06-24 10:53:13.661	2026-06-24 05:03:32.614	Chrome บนมือถือ	db2d2b5916fb2ffa469154f9d8cbf4b101eb7de65bf876e6b9f331cc45f529c2	2001:44c8:4156:f260::/64
cmqrgrzxz000ujx4mcvysyti2	03b55c1517cba68d9e5d34f7a4f862d14d09fbb77f51eb1f8bc341c9e887ecfc	cmp6j8ifp0002jxdffdiyvvw3	2026-06-25 02:38:37.749	2026-06-24 03:54:38.462	2026-06-25 01:12:19.499	2026-06-24 02:38:37.751	2026-06-25 01:12:19.5	2026-06-24 02:38:37.749	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	115.87.99.0/24
cmqs6st5e000ijx1okwj4r2as	f6a95cabc5d7911614ac0f8761c085e9024d71a2f402996ca89f040fb5c724b7	cmp6j8ifp0002jxdffdiyvvw3	2026-06-25 14:47:05.616	2026-06-24 14:52:52.691	2026-06-25 00:03:09.238	2026-06-24 14:47:05.618	2026-06-25 00:03:09.239	2026-06-24 14:47:05.616	Chrome บนมือถือ	db2d2b5916fb2ffa469154f9d8cbf4b101eb7de65bf876e6b9f331cc45f529c2	184.22.41.0/24
cmqtlafg9000ajxt6z3jujjxl	4c8a2809b96a09efe76d8ee401082be691c07fcbff06985afab0a3ff760bca42	cmp6j4rgk0000jxuitzv4y8us	2026-06-26 14:20:28.472	2026-06-25 14:33:13.499	\N	2026-06-25 14:20:28.473	2026-06-25 14:33:13.503	2026-06-25 14:20:28.472	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	2405:9800:b510:ca20::/64
cmqsyhnvh000qjx1ovykhufx9	dba9205b552c09dee8444af2eeb1977b80c69484b987615157f4431ebb126aaa	cmq0kyw85007kjx239k25z1ge	2026-06-26 03:42:14.812	2026-06-25 03:49:53.061	\N	2026-06-25 03:42:14.813	2026-06-25 03:49:53.074	2026-06-25 03:42:14.812	Chrome บนมือถือ	d79e8575cc2aeec4c70631fbefffee2b71e5b6609179c8642282da37b5019676	1.2.205.0/24
cmqsy6fm4000njx1ow5meulfp	56248482bdfa0a464b7b84dacc7e09a579b724bfde902357c5dc0b93891f0a24	cmq0kyw85007kjx239k25z1ge	2026-06-26 03:33:30.89	2026-06-25 04:20:13.862	\N	2026-06-25 03:33:30.892	2026-06-25 04:20:13.928	2026-06-25 03:33:30.89	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	1.2.205.0/24
cmqtbseyn0007jxt6jeu1lfce	76e2d5f14b6d8dbd98c4bd9532fc70e2ecc343cddbe4f11d1cd1be5d5dfff22d	cmp6j8ifp0002jxdffdiyvvw3	2026-06-26 09:54:31.486	2026-06-25 09:56:20.882	2026-06-25 14:57:28.366	2026-06-25 09:54:31.487	2026-06-25 14:57:28.367	2026-06-25 09:54:31.486	Chrome บนมือถือ	db2d2b5916fb2ffa469154f9d8cbf4b101eb7de65bf876e6b9f331cc45f529c2	184.22.40.0/24
cmqucwurs000njxu6smp6tcvc	80ff7177d6ec32bfda84b00f96b073a0590c2d89a92e86eb25d535c3bd4cdd35	cmq0kyw85007kjx239k25z1ge	2026-06-27 03:13:44.39	2026-06-26 03:14:56.265	\N	2026-06-26 03:13:44.392	2026-06-26 03:14:56.274	2026-06-26 03:13:44.39	Microsoft Edge บนคอมพิวเตอร์	8701240454c90b2df29494afeb42494e58f77041bf8d7482e14b866fd821288c	1.2.197.0/24
cmquv6lvr0095jxu6f8uwhzds	fbcfeae5f27434f1c3f5cbdfa31c9328b402429ec8dbaa4005c2b4bbcba8df74	cmp6j8ifp0002jxdffdiyvvw3	2026-06-27 11:45:12.517	2026-06-26 11:51:52.246	\N	2026-06-26 11:45:12.52	2026-06-26 11:51:52.25	2026-06-26 11:45:12.517	Chrome บนมือถือ	db2d2b5916fb2ffa469154f9d8cbf4b101eb7de65bf876e6b9f331cc45f529c2	184.22.40.0/24
cmqt6efgf0005jxu6mw6h4714	5a701188c54401dfbb123f2331a3346948692bc9aaa0081e9d0a7a27b7f392dd	cmp6j8ifp0002jxdffdiyvvw3	2026-06-26 07:23:40.862	2026-06-25 07:23:40.862	2026-06-25 07:24:12.865	2026-06-25 07:23:40.864	2026-06-25 07:24:12.866	2026-06-25 07:23:40.862	Chrome บนมือถือ	db2d2b5916fb2ffa469154f9d8cbf4b101eb7de65bf876e6b9f331cc45f529c2	184.22.41.0/24
cmqhf7sw0000gjxvxwgdprri4	bd8c29bc6a1047711301ad621363d728325c9ced8f8d7dd2d4b0555c60dc3100	cmp6j8ifp0002jxdffdiyvvw3	2026-06-18 01:57:14.111	2026-06-17 15:34:02.06	2026-06-25 09:56:14.754	2026-06-17 01:57:14.113	2026-06-25 09:56:14.755	2026-06-17 15:31:48.16	Chrome บนมือถือ	db2d2b5916fb2ffa469154f9d8cbf4b101eb7de65bf876e6b9f331cc45f529c2	184.22.34.0/24
cmqkbmsfe0006jxtdni3dyxkn	6bcaa15e57394ca6a1a922791a16b3de0068d1c04f5511100d9d9faf059f3c23	cmp6j8ifp0002jxdffdiyvvw3	2026-06-20 02:40:13.416	2026-06-19 07:56:37.669	2026-06-25 09:56:14.754	2026-06-19 02:40:13.419	2026-06-25 09:56:14.755	2026-06-19 02:40:13.416	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	124.122.9.0/24
cmqiuvbi8000ajxdp2hz1m9v4	6d004de60405bd40f2e3770c53ee0ce9e9b5b603ff8ede717052346cb43b96fa	cmp6j8ifp0002jxdffdiyvvw3	2026-06-19 02:03:11.743	2026-06-18 09:00:22.154	2026-06-25 09:56:14.754	2026-06-18 02:03:11.745	2026-06-25 09:56:14.755	2026-06-18 08:49:52.198	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	184.22.42.0/24
cmqt6a3o40001jxu6ucojrpam	2d937a24f51b096c197eef6d4d6692e12d694d3b69cc3207cc9f3ab5c6e94447	cmp6j8ifp0002jxdffdiyvvw3	2026-06-26 07:20:18.962	2026-06-25 09:00:20.855	2026-06-25 09:56:14.754	2026-06-25 07:20:18.964	2026-06-25 09:56:14.755	2026-06-25 07:20:18.962	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	184.22.41.0/24
cmquoipsf000ujxu6c0ceo3tm	bcb397d6eac6d3edb4d310ef30dbb19bb54a8cb439ce7328173bce930c362149	cmq0kwit80066jx23pw930nx1	2026-06-27 08:38:40.142	2026-06-26 09:56:27.559	\N	2026-06-26 08:38:40.143	2026-06-26 09:56:27.562	2026-06-26 08:38:40.142	Browser บนมือถือ	1424719459d3d568e44b8102ced00ba389274106cd2b211bea57561e67f09f53	2001:44c8:4668:4dc7::/64
cmqufmdjw000pjxu6h6sp916c	635f1c7cb3ec492922cd73b095817377f6d9f5932a6328c0ed56dfb8fc570725	cmp6j8ifp0002jxdffdiyvvw3	2026-06-27 04:29:34.363	2026-06-26 04:30:38.202	2026-06-26 04:31:01.076	2026-06-26 04:29:34.364	2026-06-26 04:31:01.077	2026-06-26 04:29:34.363	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	115.87.99.0/24
cmqurmyyj00bjjxt6f83agjze	df84b5ca3c6fe560f3451433fd492a4650988e197319929daa9c5396e810ac85	cmq0kyw85007kjx239k25z1ge	2026-06-27 10:05:57.497	2026-06-26 10:08:43.592	\N	2026-06-26 10:05:57.499	2026-06-26 10:08:43.599	2026-06-26 10:05:57.497	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	1.2.197.0/24
cmqufnzkr000kjxt6209yiayz	be5fcff69abefc6159d9dcd3be5f3229ec7d3657ea230abb9595ffbcc2aad152	cmp6j8ifp0002jxdffdiyvvw3	2026-06-27 04:30:49.562	2026-06-26 04:31:10.101	2026-06-26 10:32:58.345	2026-06-26 04:30:49.563	2026-06-26 10:32:58.346	2026-06-26 04:30:49.562	Chrome บนมือถือ	db2d2b5916fb2ffa469154f9d8cbf4b101eb7de65bf876e6b9f331cc45f529c2	184.22.9.0/24
cmquomme2000pjxt6atyuibmr	cf758bdf9ea48519706d02628edbdf851002addbd2229c0385452b5ce79e3c9b	cmq0khs5m000wjx23jyhqhgkv	2026-06-27 08:41:42.361	2026-06-26 09:57:29.221	\N	2026-06-26 08:41:42.362	2026-06-26 09:57:29.226	2026-06-26 08:41:42.361	Browser บนมือถือ	166840017e5d66bfef44951d6bc245fde33acf160a3511d62475877816cce140	1.2.197.0/24
cmquoj3si000xjxu6mn89ig79	f39b95d51fc72382f7c827f519c468ba31f934a6792a59173cd8fdd05296e58e	cmq0kwit80066jx23pw930nx1	2026-06-27 08:38:58.289	2026-06-26 09:55:32.442	\N	2026-06-26 08:38:58.291	2026-06-26 09:55:32.446	2026-06-26 08:38:58.289	Browser บนมือถือ	82e68664434234f145db618f20d647000ebcbd538fa2be6874a15c1e5fb5d381	1.2.197.0/24
cmquqvxym0078jxu6zv2kje4k	c9a6e7bf1ad9a27a331b785e40ea4a72d4c5839f124f9eb0554d09ae75759b4b	cmp6j8ifp0002jxdffdiyvvw3	2026-06-27 09:44:56.492	2026-06-26 09:48:41.688	\N	2026-06-26 09:44:56.494	2026-06-26 09:48:41.694	2026-06-26 09:44:56.492	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	115.87.99.0/24
cmquon7jo0011jxu6k183dhhp	81ec0a24b7c5262d02fb25958aa97ea73f1067bcbafb4e64cfe7397c82962bd3	cmq0khs5m000wjx23jyhqhgkv	2026-06-27 08:42:09.779	2026-06-26 09:33:05.541	\N	2026-06-26 08:42:09.78	2026-06-26 09:33:05.551	2026-06-26 08:42:09.779	Safari บนคอมพิวเตอร์	613665f459baefd923e20ade88f6eb1c73a851d4a14ff08b4cbeb50bf5b1c7e1	1.2.197.0/24
cmqup0jlc002njxt63qn21ns4	64d01ae9ed70f80cad32f8a0cd5a23d1f824766b5ed40f92985838fdec09f884	cmq0kyw85007kjx239k25z1ge	2026-06-27 08:52:31.919	2026-06-26 11:56:59.601	\N	2026-06-26 08:52:31.921	2026-06-26 11:56:59.63	2026-06-26 08:52:31.919	Safari บนคอมพิวเตอร์	613665f459baefd923e20ade88f6eb1c73a851d4a14ff08b4cbeb50bf5b1c7e1	1.2.197.0/24
cmqup0a5l0024jxu67n83dwg9	13e26f99baa8a6f1de696147ddcaf0cf9d13ee8a654fd6780488470ccc9f4637	cmq0kyw85007kjx239k25z1ge	2026-06-27 08:52:19.688	2026-06-26 09:57:08.941	\N	2026-06-26 08:52:19.69	2026-06-26 09:57:08.945	2026-06-26 08:52:19.688	Browser บนมือถือ	4efe2b4c3bb62a5391832a15bc2e36c82769eb111c722b2608724f2f7de82cd7	1.2.197.0/24
cmqxia0470004jxct1cugwu1s	86b5135dcb8d9bd1390f9839f9b5a2485c2e9c8e1a2dc7228f3c8c27fe1244f2	cmq0ke15g0007jx23k3ypiimb	2026-06-29 08:07:14.453	2026-06-28 08:07:14.453	\N	2026-06-28 08:07:14.455	2026-06-28 08:07:14.455	2026-06-28 08:07:14.453	Safari บนมือถือ	8e514a094230e9b937672f320d6341a17e2c9eeb3509d70a4ae44642c15cdc55	49.229.234.0/24
cmqwhmifz009fjxu6uroutclw	07d6cfe0ccda8c69ad6bfed443b31c1472f0c5a387da4dec521c4817388c2c9c	cmp6j8ifp0002jxdffdiyvvw3	2026-06-28 15:01:12.286	2026-06-27 15:03:21.337	2026-06-28 07:23:59.098	2026-06-27 15:01:12.288	2026-06-28 07:23:59.099	2026-06-27 15:01:12.286	Chrome บนมือถือ	db2d2b5916fb2ffa469154f9d8cbf4b101eb7de65bf876e6b9f331cc45f529c2	184.22.9.0/24
cmqxbufi7009mjxu6notcmsvu	91352b514057555223f50bdc65282e2006cc1b108e1a261b5d7bb25427b19e57	cmp6j8ifp0002jxdffdiyvvw3	2026-06-29 05:07:10.207	2026-06-28 09:22:51.52	\N	2026-06-28 05:07:10.208	2026-06-28 09:22:51.549	2026-06-28 05:07:10.207	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	184.22.40.0/24
cmr04g10i0010jxctrcs1hnd9	9df1b3c642bc85585972a796498bbbc0662f7247b4df0076810100ab48be9778	cmq0kgjsg000njx23n27h0rcx	2026-07-01 04:03:19.457	2026-06-30 04:04:41.919	\N	2026-06-30 04:03:19.458	2026-06-30 04:04:41.925	2026-06-30 04:03:19.457	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	1.2.237.0/24
cmr0fzqqq0015jxct4zhyknih	e1d7f622243f59d2a855122eefe0e898785f08025901fa0368c1fcadbd6b6a63	cmp6j8ifp0002jxdffdiyvvw3	2026-07-01 09:26:35.042	2026-06-30 09:26:35.042	\N	2026-06-30 09:26:35.043	2026-06-30 09:26:35.043	2026-06-30 09:26:35.042	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	124.122.9.0/24
cmr0hmvf10012jxcd0xs33iz0	a37d4e62ef4f007491521f33767c4fc36b61f861e09587d983755a8605691f74	cmqoi5w5y00cvjxek58psevzp	2026-07-01 10:12:33.804	2026-06-30 10:12:33.804	\N	2026-06-30 10:12:33.806	2026-06-30 10:12:33.806	2026-06-30 10:12:33.804	Chrome บนมือถือ	c31ec7730f6433c8c94d311339d033992d285c1248a56a0d864ec72b61745b24	2001:44c8:4231:774::/64
cmr1l88mt0016jxcdgrosy21u	b1f9cc9d1d6d3b62e2cf0cfecc47857fe0b34a5fcc3b1fc239647ac63bc1e9cd	cmp6j4rgk0000jxuitzv4y8us	2026-07-02 04:40:55.732	2026-07-01 04:42:31.126	\N	2026-07-01 04:40:55.733	2026-07-01 04:42:31.135	2026-07-01 04:40:55.732	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	223.204.187.0/24
cmr07yp98000xjxcddwarmlv2	b3fbcbb849416decb514520e3eeea5bae1124626b41346e5d58653e5edc53ac6	cmq0ke15g0007jx23k3ypiimb	2026-07-01 05:41:49.531	2026-06-30 08:46:47.074	2026-07-01 05:41:48.465	2026-06-30 05:41:49.532	2026-07-01 05:41:48.466	2026-06-30 05:41:49.531	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	2001:fb1:128:13af::/64
cmqz38piz000fjxcdycdku6kx	8b4c8c5f6ad6d3ec02f08b58e94704d3d3c446857049e412c52eaf86d0997a42	cmp6j8ifp0002jxdffdiyvvw3	2026-06-30 10:41:52.185	2026-06-29 11:35:26.016	2026-06-29 11:35:31.33	2026-06-29 10:41:52.187	2026-06-29 11:35:31.331	2026-06-29 10:41:52.185	Chrome บนมือถือ	db2d2b5916fb2ffa469154f9d8cbf4b101eb7de65bf876e6b9f331cc45f529c2	184.22.40.0/24
cmr1nezn7001ajxct8dkjkdr1	ee7da166d9047917810f4804e3171ed9647bb536127f97ee059ce98eabadf183	cmq0ke15g0007jx23k3ypiimb	2026-07-02 05:42:09.906	2026-07-01 05:42:09.906	2026-07-02 05:18:16.706	2026-07-01 05:42:09.907	2026-07-02 05:18:16.708	2026-07-01 05:42:09.906	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	2001:fb1:128:13af::/64
cmqz56i2t000qjxcdck88syfz	5888af1ff2e5e6b4c75f95f7db65a36d7376b6067f1289fd4e169f459b43730f	cmp6jcpph0015jxdf2vxb3crk	2026-06-30 11:36:08.452	2026-06-29 15:11:30.843	\N	2026-06-29 11:36:08.454	2026-06-29 15:11:30.853	2026-06-29 11:36:08.452	Chrome บนมือถือ	db2d2b5916fb2ffa469154f9d8cbf4b101eb7de65bf876e6b9f331cc45f529c2	184.22.40.0/24
cmqyjswd8000djxct3vdx48mc	0249f482e8a6ee6d341d3d4c472c6a46b66ae521ef0c3990dda8f834b8f56007	cmq0kyw85007kjx239k25z1ge	2026-06-30 01:37:41.85	2026-06-29 08:00:57.006	2026-06-30 01:37:35.809	2026-06-29 01:37:41.852	2026-06-30 01:37:35.81	2026-06-29 01:37:41.85	Microsoft Edge บนคอมพิวเตอร์	8701240454c90b2df29494afeb42494e58f77041bf8d7482e14b866fd821288c	1.2.201.0/24
cmqxkgxhb0005jxcd68y281ei	a4721d2d67503285405bcf7a6977532f564e089dae8c2545d82ce4af37d768d3	cmp6j8ifp0002jxdffdiyvvw3	2026-06-29 09:08:36.861	2026-06-28 12:01:28.498	2026-06-29 04:52:50.031	2026-06-28 09:08:36.863	2026-06-29 04:52:50.032	2026-06-28 09:08:36.861	Chrome บนมือถือ	db2d2b5916fb2ffa469154f9d8cbf4b101eb7de65bf876e6b9f331cc45f529c2	184.22.40.0/24
cmr4n6upd001qjxcdfvb0lv49	a121e0b30dd62944d3f42ddd9b10b6d455ee2b1725a61845a8e24d02b1e1f1e4	cmp6j4rgk0000jxuitzv4y8us	2026-07-04 07:59:08.783	2026-07-03 08:02:21.456	\N	2026-07-03 07:59:08.785	2026-07-03 08:02:21.461	2026-07-03 07:59:08.783	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	2001:44c8:6425:4450::/64
cmqyyz9ah000cjxcdfwmb72m4	7bedcd063e228449949df171eb9441de9002bb955f4cd35f86c24eb1cc32fcfc	cmqizuk560011jxe5xc4ibqfr	2026-06-30 08:42:32.776	2026-06-29 09:00:30.454	\N	2026-06-29 08:42:32.778	2026-06-29 09:00:30.51	2026-06-29 08:42:32.776	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	2001:fb1:128:13af::/64
cmr1roxcb001cjxctnnbn6yo4	a1eced08170badb4fdf400c213818766b350816bbf031964d42aa5ad16bd0065	cmp6j4rgk0000jxuitzv4y8us	2026-07-02 07:41:51.945	2026-07-01 07:48:31.423	\N	2026-07-01 07:41:51.947	2026-07-01 07:48:31.433	2026-07-01 07:41:51.945	Microsoft Edge บนคอมพิวเตอร์	8701240454c90b2df29494afeb42494e58f77041bf8d7482e14b866fd821288c	1.20.93.0/24
cmqzz8xvr000ujxcdra831ylu	34e2189bbf13b9a75bcea65ae4a144565865366c41aac886d505aaf9b4e548e7	cmq0kyw85007kjx239k25z1ge	2026-07-01 01:37:50.723	2026-06-30 01:42:41.021	\N	2026-06-30 01:37:50.727	2026-06-30 01:42:41.029	2026-06-30 01:37:50.723	Microsoft Edge บนคอมพิวเตอร์	8701240454c90b2df29494afeb42494e58f77041bf8d7482e14b866fd821288c	1.2.207.0/24
cmr4ngdci010hjxctfh93dt0l	67de729a7e9c9f4ccaa0a81ef3b6010b62aa7f4d19c66384ab1ccd62a56d70cd	cmr4ngcvw001rjxcdypri356x	2026-07-04 08:06:32.849	2026-07-03 08:09:52.116	2026-07-03 08:10:39.171	2026-07-03 08:06:32.851	2026-07-03 08:10:39.172	2026-07-03 08:06:32.849	Safari บนมือถือ	434e6d43bf6697dc3a4cd74b74bd12cef292194994cce46ef89991dcff8d02c9	2001:44c8:46c0:c2c::/64
cmr38zdnt0109jxctnja5s8nc	4db21da9e7fca771b59b46444278aa8d93b3435c1026bb7b079831917efc0120	cmp6j8ifp0002jxdffdiyvvw3	2026-07-03 08:33:39.303	2026-07-02 08:37:45.121	\N	2026-07-02 08:33:39.305	2026-07-02 08:37:48.003	2026-07-02 08:33:39.303	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	184.22.40.0/24
cmr320zrk001ijxcdvacyu6f5	271de8c8a6230a7432ae2ff1403a9b7d6aa4523b57513895a659d54a0babc8c4	cmq0ke15g0007jx23k3ypiimb	2026-07-03 05:18:57.294	2026-07-02 06:58:44.588	\N	2026-07-02 05:18:57.296	2026-07-02 06:58:44.651	2026-07-02 05:18:57.294	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	2001:fb1:128:13af::/64
cmr24zb4c001ejxctkwxjnp09	fe8b977cd34c9cd0121c25450266bdf7b734050e10dbfddd04a92368bb636f22	cmq0kfz02000ijx23kh3yrfbs	2026-07-02 13:53:51.37	2026-07-01 14:05:28.741	2026-07-01 14:06:18.334	2026-07-01 13:53:51.372	2026-07-01 14:06:18.335	2026-07-01 13:53:51.37	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	119.42.113.0/24
cmr2ar8u40105jxctvr6eyzqq	dde7c2ee451a80cef7ce7b381dd2e77e836c5f0c4e25d6a3bd0b1dd6bb44373a	cmq0ke15g0007jx23k3ypiimb	2026-07-02 16:35:32.858	2026-07-01 16:36:36.535	2026-07-02 13:27:23.011	2026-07-01 16:35:32.86	2026-07-02 13:27:23.012	2026-07-01 16:35:32.858	Safari บนมือถือ	8e514a094230e9b937672f320d6341a17e2c9eeb3509d70a4ae44642c15cdc55	2001:44c8:45a9:12d0::/64
cmr4oh0zl010pjxctf1e420cq	1a7ca276ea0eb4c5015ea113da3bcddf5bf5ce4e6c54b98cf5dea4d27350549c	cmp6j8ifp0002jxdffdiyvvw3	2026-07-04 08:35:03.104	2026-07-03 08:35:03.104	\N	2026-07-03 08:35:03.105	2026-07-03 08:35:03.105	2026-07-03 08:35:03.104	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	124.122.9.0/24
cmr4nnjv4001xjxcdhsou3ou9	bef63b2a1c128d7e72d66a08101c8deac67e9138306ce806276da4fe914dcbff	cmr4ngcvw001rjxcdypri356x	2026-07-04 08:12:07.884	2026-07-03 08:40:41.517	\N	2026-07-03 08:12:07.888	2026-07-03 08:40:41.552	2026-07-03 08:12:07.884	Safari บนมือถือ	434e6d43bf6697dc3a4cd74b74bd12cef292194994cce46ef89991dcff8d02c9	2001:44c8:46c0:c2c::/64
cmr4oqrhy0021jxcdilbxlixe	81f38e56f618a758a5e7ad3db75cdf1f42f12fc5b4a9b06fe4704e9f721e589c	cmr4ngcvw001rjxcdypri356x	2026-07-04 08:42:37.365	2026-07-03 08:44:02.202	\N	2026-07-03 08:42:37.366	2026-07-03 08:44:02.213	2026-07-03 08:42:37.365	Safari บนมือถือ	434e6d43bf6697dc3a4cd74b74bd12cef292194994cce46ef89991dcff8d02c9	2001:44c8:46c0:c2c::/64
cmr4q9iu30024jxcd8hs2st8v	a1bbe069c0eb83ff55e8e8deaf2675fb72723cfe85e40978243cd22298ae0209	cmq0kyw85007kjx239k25z1ge	2026-07-04 09:25:12.218	2026-07-03 09:57:25.297	\N	2026-07-03 09:25:12.219	2026-07-03 09:57:25.304	2026-07-03 09:25:12.218	Safari บนคอมพิวเตอร์	613665f459baefd923e20ade88f6eb1c73a851d4a14ff08b4cbeb50bf5b1c7e1	49.237.68.0/24
cmr4q9s8l0027jxcd74l60s3i	7ceea7ddf7e2ae801d50359e24f441065bddbd038f4c05de4e6e97caad0c93fe	cmq0kyw85007kjx239k25z1ge	2026-07-04 09:25:24.404	2026-07-03 09:28:47.008	\N	2026-07-03 09:25:24.406	2026-07-03 09:28:47.013	2026-07-03 09:25:24.404	Browser บนมือถือ	8c4af624ee0783bc593de2a70ba1302085aa5f0a1c04f26d28a7ba68c6716588	49.237.68.0/24
cmr4q9028010xjxcty263abxd	c76225b368df455cc48975fee33d30062fdb693b3d317404d9a2466796e5500d	cmq0khs5m000wjx23jyhqhgkv	2026-07-04 09:24:47.886	2026-07-03 10:03:36.705	\N	2026-07-03 09:24:47.888	2026-07-03 10:03:36.71	2026-07-03 09:24:47.886	Browser บนมือถือ	ac799ff1704e26606ab864f12c99c1c280436e5e8f4dbb3af71b5cc1b31d7ee9	49.237.68.0/24
cmr4s0wup005zjxcd1h5ecv5l	c18a1c687eb3691494e7976df1343713f6368f7912cd23bda5381e6ad3acf741	cmq0khs5m000wjx23jyhqhgkv	2026-07-04 10:14:29.712	2026-07-03 10:14:29.712	\N	2026-07-03 10:14:29.714	2026-07-03 10:14:29.714	2026-07-03 10:14:29.712	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	223.204.187.0/24
cmr4u2uq0013tjxcta3h7bqre	9821800344a2c75e9780fde0436613f0eb5f0bc95a6daae052e0bb3ed237035c	cmq0ke15g0007jx23k3ypiimb	2026-07-04 11:11:59.494	2026-07-03 11:11:59.494	\N	2026-07-03 11:11:59.496	2026-07-03 11:11:59.496	2026-07-03 11:11:59.494	Safari บนมือถือ	8e514a094230e9b937672f320d6341a17e2c9eeb3509d70a4ae44642c15cdc55	2001:44c8:45a0:c248::/64
cmr4qgmxd002zjxcdcg7x0wxe	54410d4c7918f8148fe2d741c3cf243254256846ab45209c7ca40a37af81e766	cmq0kyw85007kjx239k25z1ge	2026-07-04 09:30:44.112	2026-07-03 09:56:20.351	2026-07-04 00:36:13.859	2026-07-03 09:30:44.113	2026-07-04 00:36:13.86	2026-07-03 09:30:44.112	Safari บนมือถือ	0eebaa9a4b1b82947c1bb6fe1b16b67c1411d4cbb9a4c6f4661f4d039d3e5059	49.237.68.0/24
cmr4q9t9e0112jxcto95lz3vj	e756ad8479fd14852fc6251ea77c51e827093b8a4d07ad628f49144581d99c43	cmq0khs5m000wjx23jyhqhgkv	2026-07-04 09:25:25.729	2026-07-03 09:50:15.823	\N	2026-07-03 09:25:25.73	2026-07-03 09:50:15.827	2026-07-03 09:25:25.729	Safari บนคอมพิวเตอร์	613665f459baefd923e20ade88f6eb1c73a851d4a14ff08b4cbeb50bf5b1c7e1	223.24.201.0/24
cmr7dm16f0001jx4b44ymtkqo	4dc608e3213172fa47f4f1d9d48840d877fd4a7a7eea17030003ad8bdd4ce5a7	cmp6j8ifp0002jxdffdiyvvw3	2026-07-06 05:54:19.381	2026-07-05 08:32:37.361	2026-07-05 12:33:35.01	2026-07-05 05:54:19.383	2026-07-05 12:33:35.011	2026-07-05 05:54:19.381	Chrome บนมือถือ	db2d2b5916fb2ffa469154f9d8cbf4b101eb7de65bf876e6b9f331cc45f529c2	184.22.18.0/24
cmr5ugmc00141jxcthl2y3bj9	0dfdb06af3cbd8b1868396675f5adbf633ac03c1aadb895363391077e6e693ef	cmq0khs5m000wjx23jyhqhgkv	2026-07-05 04:10:27.983	2026-07-04 04:46:19.072	\N	2026-07-04 04:10:27.984	2026-07-04 04:46:19.078	2026-07-04 04:10:27.983	Chrome บนมือถือ	19f67f92d52875f3a1c28e409928e62b5f9ae8332368833973ea2761b8111ba2	49.237.46.0/24
cmr5qineo0063jxcdo23q0mwx	1505e342f3a717f453ecfc44da84db8c01f733cd90d6db30079d6765f9852e01	cmp6j8ifp0002jxdffdiyvvw3	2026-07-05 02:20:04.223	2026-07-04 05:11:45.15	2026-07-04 13:14:15.875	2026-07-04 02:20:04.225	2026-07-04 13:14:15.876	2026-07-04 02:20:04.223	Chrome บนมือถือ	db2d2b5916fb2ffa469154f9d8cbf4b101eb7de65bf876e6b9f331cc45f529c2	184.22.18.0/24
cmr4qsvpv0044jxcdrvxkuftt	4f02882a06095fb99a3ae6e9740027d8d0eebedb621deb118302457dc9104607	cmp6j4rgk0000jxuitzv4y8us	2026-07-04 09:40:15.377	2026-07-03 09:58:52.267	\N	2026-07-03 09:40:15.379	2026-07-03 09:58:52.278	2026-07-03 09:40:15.377	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	1.20.93.0/24
cmr7yxmso0009jx4rdcri2kkr	5afef5eb0272c299d20bd7de81964fbe6178d85741942c031b10d4fa7c9a0f9e	cmq0khs5m000wjx23jyhqhgkv	2026-07-06 15:51:12.55	2026-07-05 15:58:15.322	2026-07-05 16:01:41.333	2026-07-05 15:51:12.552	2026-07-05 16:01:41.334	2026-07-05 15:51:12.55	Chrome บนมือถือ	19f67f92d52875f3a1c28e409928e62b5f9ae8332368833973ea2761b8111ba2	223.24.201.0/24
cmr7bppv20001jxhdup22dzdv	aab5905782c23f850bf046eaa4b795d2dff9fd8d38decce9cc1d134d77bdc428	cmp6j8ifp0002jxdffdiyvvw3	2026-07-06 05:01:12.107	2026-07-05 06:44:15.991	2026-07-06 01:53:52.833	2026-07-05 05:01:12.11	2026-07-06 01:53:52.834	2026-07-05 05:01:12.107	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	184.22.18.0/24
cmr8qenyh000ajx4b8din93ln	e71f9708175a549f5029edcc3e4bad8df5aced35a804bef8e27f2f4f21b01222	cmr4ngcvw001rjxcdypri356x	2026-07-07 04:40:16.84	2026-07-06 04:40:16.84	\N	2026-07-06 04:40:16.841	2026-07-06 04:40:16.841	2026-07-06 04:40:16.84	Chrome บนคอมพิวเตอร์	f9d9e5fc7a9e5166686bdd114f1297037eeccac3a3d2e78979e5f727bf4bb895	203.172.187.0/24
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, name, email, "emailVerified", image, password, role, "isPrimary", "schoolId", "createdAt", "updatedAt", "deletedAt") FROM stdin;
cmq0kfz02000ijx23kh3yrfbs	นางสาวเบญจพร ครุฑเครือ	benjaporn1863@gmail.com	\N	\N	$2b$12$zIPQQipWN9bJlKL6EpzukezqqOLfaGUZa8wCm3JydAa45OCbVm9HG	school_admin	t	cmq0kjbpl0019jx236ppwjdv2	2026-06-05 06:51:28.371	2026-06-05 06:54:04.811	\N
cmp6j8ifp0002jxdffdiyvvw3	หนูทิน จะรวยแล้ว	yingyot.j@thainhf.org	\N	\N	$2b$12$Qi02g.h5N8U9OMlsbVir/.kObdgE0aJpBb24oTokAUeBarOYZfIIq	school_admin	t	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-15 06:24:35.413	2026-05-15 06:25:20.917	\N
cmq0kywl5007ojx2302605270	นางพัทธยา ชนะพันธ์	pattayak.2512@gmail.com	\N	\N	$2b$12$GZY.Urqi33SczeFUxLWPO.zbyZSmCa3R/.bJ5z4bWYwcVOwnEyFFi	school_admin	f	cmq0kjbpl0019jx236ppwjdv2	2026-06-05 07:06:11.705	2026-06-13 14:00:33.515	\N
cmqez49oe005ejxop7bt8v7zm	มาหาหมัดรอสลัน ลาเต๊ะ	mahamadroslanlateh@gmail.com	\N	\N	$2b$12$zY4Wvi4vZTMV/83ajP6h/e4OkAlqGdegQj9Rq3pBH1HOcJDB.TXIC	class_teacher	f	cmq0khbql000ujx237a6k27or	2026-06-15 08:51:03.038	2026-06-15 08:51:03.038	\N
cmq0kwit80066jx23pw930nx1	นางสาวศรัญญา ดวงอุปะ	saranya34164@gmail.com	\N	\N	$2b$12$0PWc1/kW3icFQEGKi0JaC.PUHQhno3V3gobUoM4czP2Lv74in.IlO	school_admin	f	cmq0kjrxw001ejx23detqolsk	2026-06-05 07:04:20.541	2026-06-05 07:04:20.541	\N
cmpjfu3b60016jx2mszo9avsp	ควายแดง ควายน้ำเงิน	yingyot123@test.com	\N	\N	$2b$12$EIMWHtX0kgj294e/lDIOSO/dr/v3.V79hdRb51OtRkhpQ.PRB5UZW	school_admin	t	cmpjfvisu001bjx2mezlfvfdl	2026-05-24 07:10:24.066	2026-05-24 07:11:30.801	\N
cmq0kxcku006ajx23ut10mnz6	นางสาวมธุริน วันทะวี	nakyoomg95@gmail.com	\N	\N	$2b$12$ZXcCfiHSuoyQHbMqGtnvOO/yPu6p9tVOM6ophXFmqEK4WScY6xsVi	school_admin	f	cmq0kga6m000ljx23ghh9yu87	2026-06-05 07:04:59.119	2026-06-05 07:04:59.119	\N
cmpkp8rvo002ojx2m2jhdnhk0	นัยน์ปพร วีรศิริยานนท์	naipaporn.v@gmail.com	\N	\N	$2b$12$Bga0ecF5oCOsMCDErsnMoOJzLXf7xNaohMGt6Mxvb5xWvvbC6YZVi	school_admin	t	cmpkp9f2g002sjx2mxjfpmxuk	2026-05-25 04:21:31.813	2026-05-25 04:22:01.866	\N
cmpm5m3cy0007jxgmqzi2glsr	\N	systemadmin@thainhf.org	\N	\N	$2b$12$eazzihSMJlZ3H76XvbhGxu5hWrqp8wiuiZ.EDLJOhUHYWj5ibeVV.	system_admin	f	\N	2026-05-26 04:47:33.25	2026-05-26 04:47:33.25	\N
cmq0kyg7o006ljx23949vl1bi	นายประยูร มังกร	payoon.1881@gmail.com	\N	\N	$2b$12$lm5KjQ58PsAWT7PkMrF6QeXXSyrzctT1tm1uue1HXls/yF7nhYLRC	school_admin	f	cmq0kj2ej0018jx23hz3n6u59	2026-06-05 07:05:50.485	2026-06-05 07:05:50.485	\N
cmpmdmbqv000kjxgmprk5t2o6	ครูนางฟ้า ใจดี	dear-wanwisa@hotmail.com	\N	\N	$2b$12$foMNC/dfDSeB6L90Rz.VjeW1q9xVxKC5DZ/XHXURV1n9GNbqjTdOK	school_admin	t	cmpmdqjp8000pjxgmt4j3159q	2026-05-26 08:31:41.047	2026-05-26 08:34:57.984	\N
cmp6j4rgk0000jxuitzv4y8us	\N	kru.nangfahs@gmail.com	\N	\N	$2b$12$wxbNelRb.5dn69o65rGWFuhPaBg/zr/gYHbAJ/EGzQediFbIUpU8m	system_admin	f	\N	2026-05-15 06:21:40.484	2026-06-04 16:59:37.134	\N
cmpzr4e32002ljxwnl4klwuhq	ซันนี่ สุวรรณเมธานนท์	shreandlearn555@gmail.com	\N	\N	$2b$12$esK5aKVzCzvPxQ.xPYBFQeP2pWfUxgv.D3uYLVYiKlHrS2HyWXz.S	school_admin	t	cmpzr7zap002sjxwn1qukwz8i	2026-06-04 17:10:39.183	2026-06-04 17:13:26.644	\N
cmq0kzkw60082jx23kdjsy3u5	นายพงศ์พิสุทธิ์ ใจคุณ	pongpisut.j@twsc.ac.th	\N	\N	$2b$12$iP5TII1HUMS51cwzzoUZ2.1R3P2G9GD/XfDZ2NKDUz1PooDA/1Slq	school_admin	f	cmq0kj2ej0018jx23hz3n6u59	2026-06-05 07:06:43.207	2026-06-05 07:06:43.207	\N
cmq0kdx110004jx23k3lcvs0z	รัตติยากร ชนะพันธ์	bombamadm@gmail.com	\N	\N	$2b$12$gRsIuU5rlVZXC4VZ6VAGMesFs4brlu.dMkx/Z/R86QmlIa/en4gSe	school_admin	t	cmq0kga6m000ljx23ghh9yu87	2026-06-05 06:49:52.501	2026-06-05 06:51:42.865	\N
cmq0l0lbj0092jx23gy1fgh5q	นายสุรสีห์ จันทร์แสงศรี	surasee1981@gmail.com	\N	\N	$2b$12$vhVL5GuZe9AxoxLBRgyaN.w5I6iI0utBm.ukDyhHgZaMZxj6GeJFq	school_admin	f	cmq0kjrxw001ejx23detqolsk	2026-06-05 07:07:30.415	2026-06-05 07:07:30.415	\N
cmq0ke15g0007jx23k3ypiimb	นูริทรา แปแนะ	nurissawarid@gmail.com	\N	\N	$2b$12$oWLuL1h1EpW38v1OOSGGh.iOMQw71ACT6ALLAtjEuDEjalE5IJCbu	school_admin	t	cmq0khbql000ujx237a6k27or	2026-06-05 06:49:57.845	2026-06-05 06:52:31.534	\N
cmq0l1izd009qjx23prrja72v	นายโกมล ยงเพชร	komon699@gmail.com	\N	\N	$2b$12$9gH52aWB7pH6x0ovDYsdTuQyxyk7hJwWugP58tcrLaF4X0vS6SltS	school_admin	f	cmq0kj2ej0018jx23hz3n6u59	2026-06-05 07:08:14.042	2026-06-05 07:08:14.042	\N
cmq0kyw85007kjx239k25z1ge	นายวิฑูลย์ แซมสีม่วง	witoon28012520@gmail.com	\N	\N	$2b$12$ng7JoQy2Tytd0t/0kLkF1uLn1dchOkeeTA4C0L2jsvTQeGn3dhKeq	school_admin	f	cmq0kjrxw001ejx23detqolsk	2026-06-05 07:06:11.237	2026-06-14 10:19:18.882	\N
cmq0kgjsg000njx23n27h0rcx	จาตุรันต์ สีมาเพชร	jaturan092@gmail.com	\N	\N	$2b$12$FMTcCpE6gwdpm1Q30gIaIuWIF8bz.y9PuaO0j0CisaifwqbpMw.jG	school_admin	t	cmq0kj2ej0018jx23hz3n6u59	2026-06-05 06:51:55.313	2026-06-05 06:53:52.749	\N
cmq0ldprx00cdjx23mw4kdumj	นูรฮีดายะห์ โดดะนะ	nurheedayah041139@gmail.com	\N	\N	$2b$12$85Xjg6gW2vvVlyjDhTXvIu8EYsh4C8c3UnWeB6QdcQIqYUP80TUW6	school_admin	f	cmq0khbql000ujx237a6k27or	2026-06-05 07:17:42.717	2026-06-05 07:17:42.717	\N
cmq0khs5m000wjx23jyhqhgkv	นางกฤติกา แซมสีม่วง	kkika052519@gmail.com	\N	\N	$2b$12$7/HtA35XTlVdgzaaod43.u/DSzbQGHdc0HXGz5RAZR.Jo3diFjs36	school_admin	t	cmq0kjrxw001ejx23detqolsk	2026-06-05 06:52:52.811	2026-06-14 10:19:31.935	\N
cmqiyxznh000ojxdp7ho41qil	พาตีเมาะ เจะมะ	fatmah8977@gmail.com	\N	\N	$2b$12$vnMlWOHYbpKIiGMvoZorm.hafRXLNpSgmBouCY3f1ZLB4XA4CpsDS	class_teacher	f	cmq0khbql000ujx237a6k27or	2026-06-18 03:57:14.813	2026-06-18 03:57:14.813	\N
cmqizuk560011jxe5xc4ibqfr	ซุไรดา ลีปะ	suwaibahyuyu@gmail.com	\N	\N	$2b$12$a.ixbSu5FBYcv.E4xY4SWOy0agcKwKdBYj.weyaZmh9Ztq5U9x.hO	class_teacher	f	cmq0khbql000ujx237a6k27or	2026-06-18 04:22:34.362	2026-06-18 04:22:34.362	\N
cmq6gifn9000djxsdox13m3kp	ครูรวย สวยไม่สร่าง	baitong.yingyot@gmail.com	\N	\N	\N	class_teacher	f	cmp6j9hjm0005jxdfd9vm0g4e	2026-06-09 09:48:01.845	2026-06-14 10:19:38.718	2026-06-14 10:19:38.717
cmq0l3re200b0jx235badgq3k	ลิน ลาลาลิน	naipaporn.v@thainhf.org	\N	\N	\N	class_teacher	f	cmpmdqjp8000pjxgmt4j3159q	2026-06-05 07:09:58.25	2026-06-14 10:19:44.437	2026-06-14 10:19:44.436
cmqez0lw4005ajxopfcijzz1q	ปฐพี จันทร์แก้ว	fee564301016@gmail.com	\N	\N	$2b$12$Js1MyDwu5YuO2GOjZb.ac.LD5gSV1.66CaFDeeCFQjiZDdkoWeLa.	class_teacher	f	cmq0khbql000ujx237a6k27or	2026-06-15 08:48:12.244	2026-06-15 08:48:12.244	\N
cmp6jm8cc001ljxdfx7fs20po	ทดสอบ นางฟ้า	yingyot111@test.com	\N	\N	\N	school_admin	f	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-15 06:35:15.516	2026-06-16 05:07:19.954	2026-05-23 11:05:18.375
cmp6jcpph0015jxdf2vxb3crk	yingyot jiteiei	baitongxaxaxa1@gmail.com	\N	\N	$2b$12$n5qJNvAzm6kfa7L2mwDj/.XoQS0ij/vzyy.AB5U1rlStQs6WKc6Ly	school_admin	f	cmp6j9hjm0005jxdfd9vm0g4e	2026-05-15 06:27:51.461	2026-06-16 05:08:39.753	\N
cmqiys133000ijxdpsllq3iqv	อาลาวียะห์ วาเตง	ala.weewateng@gmail.com	\N	\N	$2b$12$u0FPaJnQcPjQkXjJjwd4m.JqQuWN5ksVxIsKjYX5hndJBCbHw2JCG	class_teacher	f	cmq0khbql000ujx237a6k27or	2026-06-18 03:52:36.735	2026-06-18 03:52:36.735	\N
cmqiywhv5000pjxe502qkjrdo	ซัยนับ อาบู	habiib3290@gmail.com	\N	\N	$2b$12$ZdCpKq2bMDO617wH7JfLy.4yyHcs1RuOK5ibWYQ0piQLddbn9qjci	class_teacher	f	cmq0khbql000ujx237a6k27or	2026-06-18 03:56:05.105	2026-06-18 03:56:05.105	\N
cmqn94a13005pjxf0c0ewp2xv	นางสาวภรณ์ทิพวรรณ นุชโสภา	phonthipphawann@gmail.com	\N	\N	$2b$12$jluMlhlsVyn8qeocEDze/.VVmPbFVPPszxKrrIbtnfq.oHEO9LVrG	school_admin	t	cmqn96nzy005fjxekv4ihp11u	2026-06-21 03:53:09.063	2026-06-21 03:55:00.481	\N
cmqnx8i0300bsjxekiur21agf	นางสาวกมลชนก ขำวิชัย	kamonchanokoohll@gmail.com	\N	\N	$2b$12$yO79VvnREQo/VZG1RWEhAuRjqjpk2YULvXv3lbpPDw/JVFLspLQ1e	school_admin	f	cmqn96nzy005fjxekv4ihp11u	2026-06-21 15:08:16.803	2026-06-21 15:12:55.449	\N
cmqnye8m700c2jxekf3kd0pos	นางสาวรุ้งนภา มาลัย	khing0526@gmail.com	\N	\N	$2b$12$rK7Z4MBVN9WoQcxuYOiN..jnAG.8jECpoRKwjNAyr48qcsqm5MB2m	school_admin	f	cmqn96nzy005fjxekv4ihp11u	2026-06-21 15:40:44.192	2026-06-21 15:40:44.192	\N
cmqorrv4d0127jxf0rja5ghra	นายชินทัศ เหลืองประมวล	chin.tas2531@gmail.com	\N	\N	$2b$12$vuHFWLrUMahf8is2i7IrfeHg7Euh3zL1DbzigJDU4HTpJjOcmMjbm	school_admin	f	cmqn96nzy005fjxekv4ihp11u	2026-06-22 05:23:08.749	2026-06-22 05:23:08.749	\N
cmqoswgix00dcjxekbvbk3x2z	\N	moytanatha12@gmail.com	\N	\N	$2b$12$QTiKBOXlGt3e71uSw3cIUOdd0qunMEeh3oWVc.z5cUuoytp4CucXu	school_admin	t	\N	2026-06-22 05:54:42.729	2026-06-22 05:54:42.729	\N
cmqoi5w5y00cvjxek58psevzp	นายคุณากร โมจรินทร์	kunakorn.mojarin@gmail.com	\N	\N	$2b$12$hKWZUyBV64AZfEHGHY8.MeSR56TlE1FGRAFCuuyLErK4sY6kUuyg2	school_admin	f	cmqn96nzy005fjxekv4ihp11u	2026-06-22 00:54:07.126	2026-06-30 10:12:12.089	\N
cmr4ngcvw001rjxcdypri356x	จันทจันทร์นภัส นิตินิติภูมิไตรลัไตรลักษณ์	channapatios9@gmail.com	\N	\N	$2b$12$PLHbwUp12WB9ypudv.aNTeawfmYWhlB67MdWs60D7BwPQADt6Uvt.	school_admin	t	cmr4ninj7010jjxct7jj0c0q0	2026-07-03 08:06:32.253	2026-07-03 08:08:19.365	\N
\.


--
-- Data for Name: worksheet_uploads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.worksheet_uploads (id, "activityProgressId", "worksheetNumber", "fileName", "fileUrl", "fileType", "fileSize", "uploadedById", "uploadedAt", "idempotencyKey") FROM stdin;
cmpawsrn50003jxsx99b2v4n0	cmp6jb4vg000rjxdfdy058obw	1	Kimi Deal Results.jpg	/api/uploads/worksheets/cmp6jb4ux000kjxdfnh0bkm21_activity1_1779090920172.jpg	image/jpeg	61528	cmp6j8ifp0002jxdffdiyvvw3	2026-05-18 07:55:20.178	\N
cmpawsxhs0005jxsxgv0ebp67	cmp6jb4vg000rjxdfdy058obw	2	NEW_NHF_Logo.png	/api/uploads/worksheets/cmp6jb4ux000kjxdfnh0bkm21_activity1_1779090927754.png	image/png	35642	cmp6j8ifp0002jxdffdiyvvw3	2026-05-18 07:55:27.76	\N
cmpgt47id000hjx9dbixlah3e	cmpauvmza0006jxm5fjde095z	1	1000030881.jpg	/api/uploads/worksheets/cmpauvmyx0004jxm5zwck4o1s_activity1_1779447532546.jpg	image/jpeg	136802	cmp6j8ifp0002jxdffdiyvvw3	2026-05-22 10:58:52.549	\N
cmpgt4awa000jjx9dhohems69	cmpauvmza0006jxm5fjde095z	2	1000030803.jpg	/api/uploads/worksheets/cmpauvmyx0004jxm5zwck4o1s_activity1_1779447536934.jpg	image/jpeg	111220	cmp6j8ifp0002jxdffdiyvvw3	2026-05-22 10:58:56.938	\N
cmpgtau4v000wjx9d8h4al3qd	cmp6jb4vg000sjxdfmukrrspx	1	1000030651.jpg	/api/uploads/worksheets/cmp6jb4ux000kjxdfnh0bkm21_activity2_1779447841805.jpg	image/jpeg	71575	cmp6j8ifp0002jxdffdiyvvw3	2026-05-22 11:04:01.807	\N
cmpgtaylh000yjx9d16coq7m3	cmp6jb4vg000sjxdfmukrrspx	2	1000030346.jpg	/api/uploads/worksheets/cmp6jb4ux000kjxdfnh0bkm21_activity2_1779447847586.jpg	image/jpeg	212644	cmp6j8ifp0002jxdffdiyvvw3	2026-05-22 11:04:07.589	\N
cmpvncgsx0040jxjcxdhkwpnx	cmpvn6tie003ijxjce90vzloi	1	Artboard 1@3x-100.jpg	/api/uploads/worksheets/cmpvn6thw002pjxjcpvv8b9pu_activity1_1780344832782.jpg	image/jpeg	194501	cmpmdmbqv000kjxgmprk5t2o6	2026-06-01 20:13:52.785	\N
cmpvnckzy0042jxjchu49qfjq	cmpvn6tie003ijxjce90vzloi	2	Screenshot 2025-11-11 164814.png	/api/uploads/worksheets/cmpvn6thw002pjxjcpvv8b9pu_activity1_1780344838218.png	image/png	160327	cmpmdmbqv000kjxgmprk5t2o6	2026-06-01 20:13:58.222	\N
cmpyeuk2g001ljxwncon7y5i9	cmpvn6tie003jjxjcbjh21oa7	1	105.jpg	/api/uploads/worksheets/cmpvn6thw002pjxjcpvv8b9pu_activity2_1780511958805.jpg	image/jpeg	205740	cmpmdmbqv000kjxgmprk5t2o6	2026-06-03 18:39:18.808	\N
cmpyeurie001njxwn3usqfhm1	cmpvn6tie003jjxjcbjh21oa7	2	117.jpg	/api/uploads/worksheets/cmpvn6thw002pjxjcpvv8b9pu_activity2_1780511968451.jpg	image/jpeg	136814	cmpmdmbqv000kjxgmprk5t2o6	2026-06-03 18:39:28.454	\N
cmq4py7ou000ajxmhmwmg2myl	cmpvn6tie003fjxjc0hu1emp7	1	คัดกรองสุขภาพใจ (4).png	/api/uploads/worksheets/cmpvn6thw002ojxjci1w6vzmy_activity1_1780893402218.png	image/png	132233	cmpmdmbqv000kjxgmprk5t2o6	2026-06-08 04:36:42.222	\N
cmq4pyf0s0008jxmxa9jk024j	cmpvn6tie003fjxjc0hu1emp7	2	ชื่อเรื่องย่อย.png	/api/uploads/worksheets/cmpvn6thw002ojxjci1w6vzmy_activity1_1780893411720.png	image/png	33399	cmpmdmbqv000kjxgmprk5t2o6	2026-06-08 04:36:51.724	\N
cmq4qj4xd000bjxmxs9wza170	cmpvn6tie003cjxjcyu4v1g5p	1	คัดกรองสุขภาพใจ (4).png	/api/uploads/worksheets/cmpvn6thw002njxjc3ne9m690_activity1_1780894378412.png	image/png	132233	cmpmdmbqv000kjxgmprk5t2o6	2026-06-08 04:52:58.417	\N
cmq4qj9wt000djxmhj7lcwowf	cmpvn6tie003cjxjcyu4v1g5p	2	ชื่อเรื่องย่อย.png	/api/uploads/worksheets/cmpvn6thw002njxjc3ne9m690_activity1_1780894384873.png	image/png	33399	cmpmdmbqv000kjxgmprk5t2o6	2026-06-08 04:53:04.878	\N
cmq4ql9ky000gjxmhdm2b77y9	cmpvn6tie003djxjc76yah9fb	1	คัดกรองสุขภาพใจ.png	/api/uploads/worksheets/cmpvn6thw002njxjc3ne9m690_activity2_1780894477759.png	image/png	103849	cmpmdmbqv000kjxgmprk5t2o6	2026-06-08 04:54:37.762	\N
cmq4qldib000ijxmhmlwfelue	cmpvn6tie003djxjc76yah9fb	2	คัดกรองสุขภาพใจ (3).png	/api/uploads/worksheets/cmpvn6thw002njxjc3ne9m690_activity2_1780894482849.png	image/png	86143	cmpmdmbqv000kjxgmprk5t2o6	2026-06-08 04:54:42.851	\N
cmqg7wpir000rjxxtvpwkez16	cmp6jb4vg000tjxdfzq969hzm	1	1000032702.jpg	/api/uploads/worksheets/cmp6jb4ux000kjxdfnh0bkm21_activity5_1781588693038.jpg	image/jpeg	283877	cmp6j8ifp0002jxdffdiyvvw3	2026-06-16 05:44:53.043	\N
cmqg84on20010jxy90asqzoj4	cmprve8mc002njx5qe5b4id62	1	1000032857.png	/api/uploads/worksheets/cmprve8l5000yjx5qxjdz6rp8_activity1_1781589065145.png	image/png	118108	cmp6j8ifp0002jxdffdiyvvw3	2026-06-16 05:51:05.15	\N
cmqg84sbp0012jxy9h1extu5z	cmprve8mc002njx5qe5b4id62	2	1000032783.png	/api/uploads/worksheets/cmprve8l5000yjx5qxjdz6rp8_activity1_1781589069922.png	image/png	114686	cmp6j8ifp0002jxdffdiyvvw3	2026-06-16 05:51:09.925	\N
cmqgfnokh0004jxcqv0lf2sae	cmp6jb4vg000ujxdf34vopj68	1	Screenshot 2025-03-14 095029.png	/api/uploads/worksheets/cmp6jb4ux000mjxdf5pxamnft_activity1_1781601708831.png	image/png	46233	cmp6j8ifp0002jxdffdiyvvw3	2026-06-16 09:21:48.834	\N
cmqgfnz5k0002jxaoomrcsdjq	cmp6jb4vg000ujxdf34vopj68	2	pexels-padrinan-255379.jpg	/api/uploads/worksheets/cmp6jb4ux000mjxdf5pxamnft_activity1_1781601722549.jpg	image/jpeg	92541	cmp6j8ifp0002jxdffdiyvvw3	2026-06-16 09:22:02.553	\N
cmqhijbl7000vjxvh6z92motf	cmpvn6tie003ejxjcpcnnbkqh	1	image.jpg	/api/uploads/worksheets/cmpvn6thw002njxjc3ne9m690_activity5_1781667010408.jpg	image/jpeg	153275	cmpmdmbqv000kjxgmprk5t2o6	2026-06-17 03:30:10.411	\N
cmqhjeb5p000pjxvx9kwxinrr	cmpvn6tie003njxjcqcpjbirf	1	image.jpg	/api/uploads/worksheets/cmpvn6thx002tjxjck9twdrt3_activity1_1781668456186.jpg	image/jpeg	144190	cmpmdmbqv000kjxgmprk5t2o6	2026-06-17 03:54:16.189	\N
cmqhjeigg000rjxvxd4lbh65g	cmpvn6tie003njxjcqcpjbirf	2	image.jpg	/api/uploads/worksheets/cmpvn6thx002tjxjck9twdrt3_activity1_1781668465645.jpg	image/jpeg	136247	cmpmdmbqv000kjxgmprk5t2o6	2026-06-17 03:54:25.648	\N
cmqhjlmxq0011jxvhw583b0e5	cmpvn6tie003qjxjceen74w8z	1	image.jpg	/api/uploads/worksheets/cmpvn6thx002ujxjc5a4bxgmx_activity1_1781668798043.jpg	image/jpeg	134868	cmpmdmbqv000kjxgmprk5t2o6	2026-06-17 03:59:58.046	\N
cmqhjlt860013jxvhd8l4bt8h	cmpvn6tie003qjxjceen74w8z	2	image.jpg	/api/uploads/worksheets/cmpvn6thx002ujxjc5a4bxgmx_activity1_1781668806194.jpg	image/jpeg	141537	cmpmdmbqv000kjxgmprk5t2o6	2026-06-17 04:00:06.198	\N
cmqkkjnal0010jxtdkbkgszey	cmqep6tah00p6jxp5p8gfttcn	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00g7jxp5dadbmh4c_activity1_1781851783338.jpg	image/jpeg	216939	cmq0kyw85007kjx239k25z1ge	2026-06-19 06:49:43.342	\N
cmqkkjztr0015jxtdzjn1qo48	cmqep6tah00p6jxp5p8gfttcn	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00g7jxp5dadbmh4c_activity1_1781851799579.jpg	image/jpeg	161158	cmq0kyw85007kjx239k25z1ge	2026-06-19 06:49:59.583	\N
cmqkx9v4v000ajxf0zdv1rft0	cmqep6tai00q3jxp5tf5z03xa	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gjjxp59b9xkcrz_activity1_1781873161947.jpg	image/jpeg	162623	cmq0kyw85007kjx239k25z1ge	2026-06-19 12:46:01.952	\N
cmqkx9vzg000gjxekj9t83gy3	cmqep6tai00q0jxp5n901ajlc	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00ghjxp58tgg12zq_activity1_1781873163047.jpg	image/jpeg	202175	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 12:46:03.052	\N
cmqkx9wd9000ijxekph3nn7t7	cmqep6tah00p9jxp5t7c8whwm	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00g8jxp5e5io1j25_activity1_1781873163546.jpg	image/jpeg	174042	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 12:46:03.549	\N
cmqkx9wla000cjxf0r73cvnh0	cmqep6tai00q7jxp5zfws1ogk	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gkjxp5h4f0156z_activity1_1781873163834.jpg	image/jpeg	189952	cmq0kyw85007kjx239k25z1ge	2026-06-19 12:46:03.838	\N
cmqkxa795000ejxf0iln23ajb	cmqep6tai00q0jxp5n901ajlc	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00ghjxp58tgg12zq_activity1_1781873177655.jpg	image/jpeg	172372	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 12:46:17.657	\N
cmqkxad9k000kjxekbvaxzpr7	cmqep6tai00q7jxp5zfws1ogk	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gkjxp5h4f0156z_activity1_1781873185444.jpg	image/jpeg	174080	cmq0kyw85007kjx239k25z1ge	2026-06-19 12:46:25.448	\N
cmqkxaiit000gjxf0hp4n0yzx	cmqep6tah00p9jxp5t7c8whwm	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00g8jxp5e5io1j25_activity1_1781873192259.jpg	image/jpeg	179565	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 12:46:32.262	\N
cmqkxgpsf000ujxek6antltu5	cmqep6tai00qzjxp5ag9h6oxy	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00grjxp5xaus94pp_activity1_1781873481611.jpg	image/jpeg	209842	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 12:51:21.615	\N
cmqkxjqax0015jxekscj2kiji	cmqf02tx9006djxop42fvws8c	1	image.jpg	/api/uploads/worksheets/cmqf02twi005vjxoph6si1y7m_activity1_1781873622246.jpg	image/jpeg	196786	cmq0kyw85007kjx239k25z1ge	2026-06-19 12:53:42.249	\N
cmqkxk4rj000tjxf089c6xva9	cmqep6tai00qbjxp5s7cp3vn7	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gljxp5et9f6y0c_activity1_1781873640988.jpg	image/jpeg	165463	cmq0kyw85007kjx239k25z1ge	2026-06-19 12:54:00.991	\N
cmqkxkerh0017jxeknuxglhm1	cmqep6tai00qbjxp5s7cp3vn7	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gljxp5et9f6y0c_activity1_1781873653946.jpg	image/jpeg	153221	cmq0kyw85007kjx239k25z1ge	2026-06-19 12:54:13.949	\N
cmqkxkszh000xjxf056637r9y	cmqep6tah00pfjxp5spm3q8j2	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gajxp56csicf0x_activity1_1781873672364.jpg	image/jpeg	177221	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 12:54:32.381	\N
cmqkxljrd001hjxekrqrwvfk4	cmqep6tai00pxjxp5fj8n0t6o	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00ggjxp5lamjmi4s_activity1_1781873707068.jpg	image/jpeg	136198	cmq0kwit80066jx23pw930nx1	2026-06-19 12:55:07.081	\N
cmqkxovaj0011jxf01d9y2cg3	cmqep6tai00qcjxp5o7jklvp8	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gljxp5et9f6y0c_activity2_1781873861992.jpg	image/jpeg	160433	cmq0kyw85007kjx239k25z1ge	2026-06-19 12:57:41.995	\N
cmqkxp1it001ljxekzc6nx8h6	cmqep6tai00qcjxp5o7jklvp8	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gljxp5et9f6y0c_activity2_1781873870065.jpg	image/jpeg	159066	cmq0kyw85007kjx239k25z1ge	2026-06-19 12:57:50.069	\N
cmqkxajlo000mjxekflf6bha8	cmqep6tai00q3jxp5tf5z03xa	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gjjxp59b9xkcrz_activity1_1781873193658.jpg	image/jpeg	165944	cmq0kyw85007kjx239k25z1ge	2026-06-19 12:46:33.661	\N
cmqkxh4ec000wjxekn0hmpjej	cmqep6tai00qzjxp5ag9h6oxy	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00grjxp5xaus94pp_activity1_1781873500546.jpg	image/jpeg	194914	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 12:51:40.549	\N
cmqkxh8l6000mjxf0ndohnlvq	cmqep6tah00pcjxp5m95u1coe	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00g9jxp5yihqococ_activity1_1781873505974.jpg	image/jpeg	178349	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 12:51:45.978	\N
cmqkxhkwh000yjxekaqfbfwb4	cmqep6tah00pcjxp5m95u1coe	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00g9jxp5yihqococ_activity1_1781873521935.jpg	image/jpeg	171191	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 12:52:01.938	\N
cmqkxijvz000rjxf0ktmmulm4	cmqep6tai00qjjxp5lrasw9rz	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gnjxp50tru9y0t_activity1_1781873567275.jpg	image/jpeg	188423	cmq0kwit80066jx23pw930nx1	2026-06-19 12:52:47.279	\N
cmqkxl6ok001fjxekbmglmutd	cmqep6tah00pijxp5zldp0o2u	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gbjxp5vsmxgz5z_activity1_1781873690129.jpg	image/jpeg	185292	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 12:54:50.132	\N
cmqkxqp46001sjxekkamt9k4r	cmqep6tai00qfjxp57u3dmokc	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gmjxp5w0cyfz8a_activity1_1781873947278.jpg	image/jpeg	163119	cmq0kyw85007kjx239k25z1ge	2026-06-19 12:59:07.303	\N
cmqkxtgaq001ejxf0evsjwc69	cmqep6tai00qojxp5y8dtu0b5	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gojxp5v1t19fiv_activity1_1781874075839.jpg	image/jpeg	179940	cmq0kyw85007kjx239k25z1ge	2026-06-19 13:01:15.842	\N
cmqkxu8tb001ljxf07da5do7v	cmqf02tx9006hjxopae8zwuwx	2	image.jpg	/api/uploads/worksheets/cmqf02twi005wjxop1suc7kpd_activity1_1781874112788.jpg	image/jpeg	145369	cmq0kwit80066jx23pw930nx1	2026-06-19 13:01:52.8	\N
cmqkxwbph001qjxf0vnwokin0	cmqep6tai00prjxp5k5ki8rv2	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gejxp5hwiyumv6_activity1_1781874209858.jpg	image/jpeg	186222	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:03:29.861	\N
cmqkxwz4k0028jxeklpoyeedt	cmqep6tai00qsjxp509wnhjrm	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gpjxp5s7zduyel_activity1_1781874240209.jpg	image/jpeg	156849	cmq0kyw85007kjx239k25z1ge	2026-06-19 13:04:00.212	\N
cmqkxirxn0012jxekqooovmp6	cmqep6tai00qjjxp5lrasw9rz	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gnjxp50tru9y0t_activity1_1781873577703.jpg	image/jpeg	188511	cmq0kwit80066jx23pw930nx1	2026-06-19 12:52:57.708	\N
cmqkxkga2000vjxf06tpj04zj	cmqf02tx9006djxop42fvws8c	2	image.jpg	/api/uploads/worksheets/cmqf02twi005vjxoph6si1y7m_activity1_1781873655910.jpg	image/jpeg	178581	cmq0kyw85007kjx239k25z1ge	2026-06-19 12:54:15.914	\N
cmqkxkncd0019jxekx1430x0e	cmqep6tah00pfjxp5spm3q8j2	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gajxp56csicf0x_activity1_1781873665066.jpg	image/jpeg	198949	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 12:54:25.069	\N
cmqkxkrmg001bjxekgdm4w1hn	cmqep6tah00pijxp5zldp0o2u	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gbjxp5vsmxgz5z_activity1_1781873670613.jpg	image/jpeg	194905	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 12:54:30.617	\N
cmqkxkt0o001djxekzueydp13	cmqep6tai00pxjxp5fj8n0t6o	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00ggjxp5lamjmi4s_activity1_1781873672422.jpg	image/jpeg	127232	cmq0kwit80066jx23pw930nx1	2026-06-19 12:54:32.425	\N
cmqkxpuxo0014jxf02b56n229	cmqep6tai00qwjxp5c96eje9e	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gqjxp5i3yv7iln_activity1_1781873908184.jpg	image/jpeg	189941	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 12:58:28.188	\N
cmqkxq37l001njxekphl6zhes	cmqep6tai00qwjxp5c96eje9e	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gqjxp5i3yv7iln_activity1_1781873918909.jpg	image/jpeg	181386	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 12:58:38.913	\N
cmqkxq40e0016jxf0q8i2cteb	cmqep6tah00pljxp54oayeo39	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gcjxp545zm4dej_activity1_1781873919947.jpg	image/jpeg	179712	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 12:58:39.95	\N
cmqkxq9h9001pjxekehuck10d	cmqep6tah00pljxp54oayeo39	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gcjxp545zm4dej_activity1_1781873927034.jpg	image/jpeg	178192	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 12:58:47.038	\N
cmqkxqvj9001ujxek5zfrz1zo	cmqep6tai00qfjxp57u3dmokc	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gmjxp5w0cyfz8a_activity1_1781873955617.jpg	image/jpeg	163080	cmq0kyw85007kjx239k25z1ge	2026-06-19 12:59:15.621	\N
cmqkxsnij0018jxf02su1y45s	cmqep6tai00pojxp54bmndmvi	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gdjxp59lrmb5t2_activity1_1781874038536.jpg	image/jpeg	197220	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:00:38.539	\N
cmqkxsuj1001ajxf0qeq7liei	cmqep6tai00pojxp54bmndmvi	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gdjxp59lrmb5t2_activity1_1781874047626.jpg	image/jpeg	184876	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:00:47.629	\N
cmqkxsusm001zjxekz8zusvk4	cmqep6tai00pujxp5oyhlxnf0	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gfjxp567zr1gct_activity1_1781874047971.jpg	image/jpeg	193360	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:00:47.974	\N
cmqkxsw6r001cjxf0p7bkxwyd	cmqep6tai00qojxp5y8dtu0b5	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gojxp5v1t19fiv_activity1_1781874049775.jpg	image/jpeg	207163	cmq0kyw85007kjx239k25z1ge	2026-06-19 13:00:49.779	\N
cmqkxt1dz0021jxek4xjijmoi	cmqep6tai00pujxp5oyhlxnf0	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gfjxp567zr1gct_activity1_1781874056516.jpg	image/jpeg	185954	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:00:56.519	\N
cmqkxthu70023jxekwfzi35v3	cmqep6tai00r2jxp5utjyurzv	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gsjxp5mtilww6e_activity1_1781874077837.jpg	image/jpeg	178071	cmq0kwit80066jx23pw930nx1	2026-06-19 13:01:17.84	\N
cmqkxtm0x001gjxf0b575x03r	cmqf02tx9006hjxopae8zwuwx	1	image.jpg	/api/uploads/worksheets/cmqf02twi005wjxop1suc7kpd_activity1_1781874083262.jpg	image/jpeg	151024	cmq0kwit80066jx23pw930nx1	2026-06-19 13:01:23.265	\N
cmqkxtnzi001ijxf0tyu3g5ji	cmqep6tai00r2jxp5utjyurzv	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gsjxp5mtilww6e_activity1_1781874085803.jpg	image/jpeg	191168	cmq0kwit80066jx23pw930nx1	2026-06-19 13:01:25.807	\N
cmqkxvi90001ojxf0na2cx9zr	cmqep6tai00prjxp5k5ki8rv2	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gejxp5hwiyumv6_activity1_1781874171681.jpg	image/jpeg	185376	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:02:51.685	\N
cmqkxwrp90026jxekcmg6til2	cmqep6tai00qsjxp509wnhjrm	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gpjxp5s7zduyel_activity1_1781874230586.jpg	image/jpeg	159812	cmq0kyw85007kjx239k25z1ge	2026-06-19 13:03:50.589	\N
cmqky2ax4001tjxf0q686h3vx	cmqep6tai00r6jxp5r5r0quj7	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gtjxp5zntc9qfk_activity1_1781874488774.jpg	image/jpeg	176592	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:08:08.776	\N
cmqky2jny001vjxf0x904qbcz	cmqep6tai00r6jxp5r5r0quj7	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gtjxp5zntc9qfk_activity1_1781874500106.jpg	image/jpeg	175865	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:08:20.11	\N
cmqky3bqq002djxek5mv0hf0p	cmqep6tai00r9jxp52ywbd3w3	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gvjxp59jqt3gqm_activity1_1781874536492.jpg	image/jpeg	217560	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:08:56.498	\N
cmqky3fz2001xjxf0zm2t39fi	cmqep6tak00tcjxp5s4je3gyp	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00hjjxp5xa6i02q3_activity1_1781874541979.jpg	image/jpeg	213179	cmq0kyw85007kjx239k25z1ge	2026-06-19 13:09:01.983	\N
cmqky3kc4001zjxf01dvi0564	cmqep6tai00r9jxp52ywbd3w3	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gvjxp59jqt3gqm_activity1_1781874547634.jpg	image/jpeg	179720	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:09:07.637	\N
cmqky3ohv0021jxf0dv0kvo7r	cmqep6tak00tcjxp5s4je3gyp	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00hjjxp5xa6i02q3_activity1_1781874553024.jpg	image/jpeg	190147	cmq0kyw85007kjx239k25z1ge	2026-06-19 13:09:13.027	\N
cmqky3tv2002fjxektp4psenm	cmqep6taj00ssjxp5knzlg5ay	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00hcjxp5o0okg8br_activity1_1781874559978.jpg	image/jpeg	198606	cmq0kyw85007kjx239k25z1ge	2026-06-19 13:09:19.982	\N
cmqky3u690023jxf0u717vcxh	cmqep6taj00szjxp5gnxnr18i	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00hejxp5jx21o02o_activity1_1781874560381.jpg	image/jpeg	155251	cmq0kwit80066jx23pw930nx1	2026-06-19 13:09:20.385	\N
cmqky41rv0025jxf0obc6lgaw	cmqep6taj00ssjxp5knzlg5ay	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00hcjxp5o0okg8br_activity1_1781874570232.jpg	image/jpeg	196215	cmq0kyw85007kjx239k25z1ge	2026-06-19 13:09:30.236	\N
cmqky46gb0027jxf0potrwjk9	cmqep6taj00szjxp5gnxnr18i	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00hejxp5jx21o02o_activity1_1781874576296.jpg	image/jpeg	151588	cmq0kwit80066jx23pw930nx1	2026-06-19 13:09:36.3	\N
cmqky4dxo002hjxek6qmqkmoi	cmqep6taj00rhjxp5ez1hp62e	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gyjxp50orak3f8_activity1_1781874585983.jpg	image/jpeg	164371	cmq0kwit80066jx23pw930nx1	2026-06-19 13:09:45.997	\N
cmqky4jzf0029jxf0lbd9oix5	cmqep6taj00rhjxp5ez1hp62e	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gyjxp50orak3f8_activity1_1781874593832.jpg	image/jpeg	168983	cmq0kwit80066jx23pw930nx1	2026-06-19 13:09:53.835	\N
cmqky69eh002djxf0jhj9jmty	cmqep6tak00t9jxp5925pd5yg	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00hijxp5mgitskzp_activity1_1781874673430.jpg	image/jpeg	202083	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:11:13.434	\N
cmqky6a1z002fjxf04x2e88wk	cmqep6taj00rpjxp50nreu26u	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00h0jxp5b6k9d2ql_activity1_1781874674276.jpg	image/jpeg	186535	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:11:14.279	\N
cmqky6e06002ljxekc58kkv6d	cmqep6tak00t9jxp5925pd5yg	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00hijxp5mgitskzp_activity1_1781874679391.jpg	image/jpeg	199500	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:11:19.399	\N
cmqky6fq5002njxekap7tqz9u	cmqep6taj00rpjxp50nreu26u	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00h0jxp5b6k9d2ql_activity1_1781874681626.jpg	image/jpeg	168232	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:11:21.629	\N
cmqky7o0i002qjxekfob43aaj	cmqep6taj00sljxp5cpo760li	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00hajxp53xjfiwp0_activity1_1781874739022.jpg	image/jpeg	149701	cmq0kwit80066jx23pw930nx1	2026-06-19 13:12:19.026	\N
cmqky8cqz002sjxek548zc657	cmqep6taj00rxjxp5rbgwkpys	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00h2jxp5gb0okmzi_activity1_1781874771080.jpg	image/jpeg	171204	cmq0kyw85007kjx239k25z1ge	2026-06-19 13:12:51.083	\N
cmqky903j002ljxf0ghgpuxnu	cmqep6taj00s4jxp5cqd3j9df	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00h4jxp5jet4udax_activity1_1781874801339.jpg	image/jpeg	194580	cmq0kyw85007kjx239k25z1ge	2026-06-19 13:13:21.343	\N
cmqky9zpv002rjxf0y8s8e39m	cmqep6tak00tfjxp53xrvbsqt	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00hkjxp50bymz2pu_activity1_1781874847505.jpg	image/jpeg	179794	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:14:07.507	\N
cmqkycffy002zjxf0zg64yxz0	cmqep6taj00s0jxp5h5bwajyo	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00h3jxp5nsmq0bu1_activity1_1781874961195.jpg	image/jpeg	163168	cmq0kyw85007kjx239k25z1ge	2026-06-19 13:16:01.198	\N
cmqkye11v0035jxf0ffucuqdr	cmqep6tak00t5jxp5z92erwcp	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00hhjxp595rvk6sq_activity1_1781875035855.jpg	image/jpeg	200497	cmq0kyw85007kjx239k25z1ge	2026-06-19 13:17:15.859	\N
cmqkyg1e4003hjxekgd3pgm8g	cmqep6tai00rcjxp5dnaav6je	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gwjxp50vs32gfn_activity1_1781875129609.jpg	image/jpeg	197329	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:18:49.612	\N
cmqkymean003ejxf01pl1aphh	cmqep6tag00mfjxp5x7xu61is	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fejxp5o7dl7di4_activity1_1781875426268.jpg	image/jpeg	175800	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:23:46.272	\N
cmqkyp5uk003ljxf0gox0v8rx	cmqep6tag00mqjxp5f9vuhif8	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fhjxp5fpnrj4l7_activity1_1781875555290.jpg	image/jpeg	210203	cmq0kyw85007kjx239k25z1ge	2026-06-19 13:25:55.292	\N
cmqkypcm2003ojxekxagx78ze	cmqep6tag00n6jxp53ced8pkg	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fljxp5cyty19cb_activity1_1781875564047.jpg	image/jpeg	194382	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:26:04.058	\N
cmqkytqul0049jxek6ha1nbqk	cmqep6tah00omjxp5xpfrqi59	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00g1jxp5xksr1is3_activity1_1781875769131.jpg	image/jpeg	169751	cmq0kwit80066jx23pw930nx1	2026-06-19 13:29:29.133	\N
cmqky7itz002jjxf02rgyknmh	cmqep6taj00sljxp5cpo760li	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00hajxp53xjfiwp0_activity1_1781874732302.jpg	image/jpeg	179044	cmq0kwit80066jx23pw930nx1	2026-06-19 13:12:12.312	\N
cmqkybufz0034jxekm36b14a5	cmqep6taj00svjxp5f2j1fghe	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00hdjxp51yn11mxr_activity1_1781874933981.jpg	image/jpeg	192559	cmq0kwit80066jx23pw930nx1	2026-06-19 13:15:33.984	\N
cmqkyc7cl0036jxek33jxk05g	cmqep6taj00svjxp5f2j1fghe	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00hdjxp51yn11mxr_activity1_1781874950706.jpg	image/jpeg	179339	cmq0kwit80066jx23pw930nx1	2026-06-19 13:15:50.709	\N
cmqkyluy5003cjxf0gsxzbzii	cmqep6tag00mfjxp5x7xu61is	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fejxp5o7dl7di4_activity1_1781875401194.jpg	image/jpeg	171371	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:23:21.197	\N
cmqkymq79003gjxf0jt8wo6g2	cmqep6tag00nujxp5o54ztmua	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00ftjxp5qcd2510h_activity1_1781875441698.jpg	image/jpeg	199169	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:24:01.701	\N
cmqkyswrq0040jxf04fdyx582	cmqep6tah00ojjxp5sze7k8vi	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00g0jxp5x3rr3z29_activity1_1781875730147.jpg	image/jpeg	184718	cmq0kyw85007kjx239k25z1ge	2026-06-19 13:28:50.15	\N
cmqkyt24f0041jxek8ptdqa6v	cmqep6tah00ojjxp5sze7k8vi	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00g0jxp5x3rr3z29_activity1_1781875737085.jpg	image/jpeg	170236	cmq0kyw85007kjx239k25z1ge	2026-06-19 13:28:57.087	\N
cmqkyt3cb0042jxf0skjwahf3	cmqep6tah00p3jxp56fosqqz5	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00g6jxp5voah6fkg_activity1_1781875738665.jpg	image/jpeg	172020	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:28:58.667	\N
cmqkytlex0047jxf0snjgzj2j	cmqep6tah00osjxp5mjo9f31e	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00g3jxp5y3q080vj_activity1_1781875762085.jpg	image/jpeg	194122	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:29:22.089	\N
cmqky8j2x002vjxekw4b7je18	cmqep6taj00rxjxp5rbgwkpys	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00h2jxp5gb0okmzi_activity1_1781874779287.jpg	image/jpeg	160518	cmq0kyw85007kjx239k25z1ge	2026-06-19 13:12:59.29	\N
cmqky98bm002njxf00gvr0sxl	cmqep6taj00s4jxp5cqd3j9df	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00h4jxp5jet4udax_activity1_1781874811999.jpg	image/jpeg	181480	cmq0kyw85007kjx239k25z1ge	2026-06-19 13:13:32.002	\N
cmqky98cd002xjxekwfdppkgq	cmqep6taj00t2jxp5wdtn0ady	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00hgjxp51uc3pwty_activity1_1781874812027.jpg	image/jpeg	197523	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:13:32.03	\N
cmqky9eqj002pjxf0hupmtbyo	cmqep6taj00t2jxp5wdtn0ady	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00hgjxp51uc3pwty_activity1_1781874820312.jpg	image/jpeg	188371	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:13:40.315	\N
cmqkya5sa002tjxf0z8zo6akv	cmqep6taj00sdjxp55omhcud3	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00h7jxp5aomv3xif_activity1_1781874855367.jpg	image/jpeg	143858	cmq0kwit80066jx23pw930nx1	2026-06-19 13:14:15.37	\N
cmqkyaby1002vjxf013nkyb9x	cmqep6tak00tfjxp53xrvbsqt	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00hkjxp50bymz2pu_activity1_1781874863350.jpg	image/jpeg	179532	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:14:23.353	\N
cmqkyaipu0030jxeki1sa8mgx	cmqep6taj00sdjxp55omhcud3	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00h7jxp5aomv3xif_activity1_1781874872117.jpg	image/jpeg	144252	cmq0kwit80066jx23pw930nx1	2026-06-19 13:14:32.13	\N
cmqkyckh90031jxf0v7n5jt0e	cmqep6taj00s0jxp5h5bwajyo	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00h3jxp5nsmq0bu1_activity1_1781874967722.jpg	image/jpeg	156502	cmq0kyw85007kjx239k25z1ge	2026-06-19 13:16:07.725	\N
cmqkydgax0033jxf0jkz1hytn	cmqep6taj00rkjxp5bp36b887	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gzjxp5ymu2sdwq_activity1_1781875008967.jpg	image/jpeg	195741	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:16:48.97	\N
cmqkydln30038jxekve6tnou9	cmqep6taj00rkjxp5bp36b887	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gzjxp5ymu2sdwq_activity1_1781875015885.jpg	image/jpeg	189897	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:16:55.888	\N
cmqkye4xa0037jxf02qssqm3p	cmqep6taj00sgjxp5zb6x2opq	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00h9jxp5ov6rpkzw_activity1_1781875040876.jpg	image/jpeg	174209	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:17:20.878	\N
cmqkyebj1003bjxekca6rpgg5	cmqep6taj00sgjxp5zb6x2opq	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00h9jxp5ov6rpkzw_activity1_1781875049434.jpg	image/jpeg	186505	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:17:29.438	\N
cmqkyeqk1003djxekmj4vgvi0	cmqep6tak00t5jxp5z92erwcp	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00hhjxp595rvk6sq_activity1_1781875068908.jpg	image/jpeg	188787	cmq0kyw85007kjx239k25z1ge	2026-06-19 13:17:48.914	\N
cmqkyg6qd003kjxekjl0aqiji	cmqep6tai00rcjxp5dnaav6je	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gwjxp50vs32gfn_activity1_1781875136530.jpg	image/jpeg	181534	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:18:56.533	\N
cmqkymvac003ijxf0y3gpb6oj	cmqep6tag00nujxp5o54ztmua	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00ftjxp5qcd2510h_activity1_1781875448290.jpg	image/jpeg	189192	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:24:08.292	\N
cmqkyphub003qjxek3wq3xwb3	cmqep6tag00n6jxp53ced8pkg	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fljxp5cyty19cb_activity1_1781875570831.jpg	image/jpeg	192360	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:26:10.835	\N
cmqkyplvo003sjxek4mu19g7s	cmqep6tag00mqjxp5f9vuhif8	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fhjxp5fpnrj4l7_activity1_1781875576065.jpg	image/jpeg	188576	cmq0kyw85007kjx239k25z1ge	2026-06-19 13:26:16.068	\N
cmqkyq3nq003ujxek9gwjr1vo	cmqep6tah00ovjxp5vhgzu8de	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00g4jxp56txcwtrq_activity1_1781875599106.jpg	image/jpeg	177109	cmq0kwit80066jx23pw930nx1	2026-06-19 13:26:39.111	\N
cmqkyq4gd003wjxekugz305go	cmqep6tah00opjxp5r154rrkv	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00g2jxp55u0n4faa_activity1_1781875600138.jpg	image/jpeg	171024	cmq0kwit80066jx23pw930nx1	2026-06-19 13:26:40.141	\N
cmqkyqdbk003njxf0bj1km2pb	cmqep6tah00ovjxp5vhgzu8de	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00g4jxp56txcwtrq_activity1_1781875611628.jpg	image/jpeg	195205	cmq0kwit80066jx23pw930nx1	2026-06-19 13:26:51.632	\N
cmqkyqjtq003pjxf07tfwton5	cmqep6tah00opjxp5r154rrkv	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00g2jxp55u0n4faa_activity1_1781875620060.jpg	image/jpeg	157508	cmq0kwit80066jx23pw930nx1	2026-06-19 13:27:00.062	\N
cmqkyr2v8003rjxf0ro9ep2ct	cmqep6tag00nmjxp542ai2iju	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00frjxp5y0vdu581_activity1_1781875644736.jpg	image/jpeg	185194	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:27:24.74	\N
cmqkyr7ij003yjxekiwa34bsp	cmqep6tag00nmjxp542ai2iju	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00frjxp5y0vdu581_activity1_1781875650761.jpg	image/jpeg	188489	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:27:30.764	\N
cmqkysu13003yjxf05ubeccr9	cmqep6tah00p3jxp56fosqqz5	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00g6jxp5voah6fkg_activity1_1781875726597.jpg	image/jpeg	165796	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:28:46.6	\N
cmqkyt6gj0043jxek5oi4d4ri	cmqep6tag00nxjxp5l6c9g8j0	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fujxp5lzrwcrc9_activity1_1781875742704.jpg	image/jpeg	185919	cmq0kyw85007kjx239k25z1ge	2026-06-19 13:29:02.708	\N
cmqkytf8p0044jxf0y4etapd5	cmqep6tah00osjxp5mjo9f31e	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00g3jxp5y3q080vj_activity1_1781875754086.jpg	image/jpeg	213227	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:29:14.09	\N
cmqkytg3l0045jxekkf9klw2m	cmqep6tah00omjxp5xpfrqi59	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00g1jxp5xksr1is3_activity1_1781875755197.jpg	image/jpeg	143525	cmq0kwit80066jx23pw930nx1	2026-06-19 13:29:15.201	\N
cmqkytlza0047jxekmshbltze	cmqep6tag00nxjxp5l6c9g8j0	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fujxp5lzrwcrc9_activity1_1781875762819.jpg	image/jpeg	175291	cmq0kyw85007kjx239k25z1ge	2026-06-19 13:29:22.823	\N
cmqkyvhto004cjxf0i1c1coqo	cmqep6tag00mijxp5k0mcbru7	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00ffjxp5qxsn29jv_activity1_1781875850745.jpg	image/jpeg	185676	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:30:50.749	\N
cmqkyvlnv004ejxf0kyhp5zzg	cmqep6tah00o5jxp51uqmmh97	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fwjxp5he7659eh_activity1_1781875855721.jpg	image/jpeg	214673	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:30:55.724	\N
cmqkyvwd6004gjxf07wcy431q	cmqep6tag00mijxp5k0mcbru7	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00ffjxp5qxsn29jv_activity1_1781875869592.jpg	image/jpeg	168881	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:31:09.595	\N
cmqkyw2ym004cjxekyoye0qak	cmqep6tah00o5jxp51uqmmh97	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fwjxp5he7659eh_activity1_1781875878139.jpg	image/jpeg	201230	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:31:18.142	\N
cmqkyw6ts004ejxekzwm21krk	cmqep6tag00mtjxp5psg80trx	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fijxp5jyyrjuz8_activity1_1781875883149.jpg	image/jpeg	160619	cmq0kwit80066jx23pw930nx1	2026-06-19 13:31:23.152	\N
cmqkywdfe004ijxf08hp9xu3z	cmqep6tag00mtjxp5psg80trx	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fijxp5jyyrjuz8_activity1_1781875891703.jpg	image/jpeg	164366	cmq0kwit80066jx23pw930nx1	2026-06-19 13:31:31.706	\N
cmqkywyvt004kjxf0n144569v	cmqep6tag00n2jxp5l6efpj4t	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fkjxp5dokcsihq_activity1_1781875919510.jpg	image/jpeg	190572	cmq0kyw85007kjx239k25z1ge	2026-06-19 13:31:59.513	\N
cmqkyx6yf004mjxf04st2bhtu	cmqep6tag00n2jxp5l6efpj4t	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fkjxp5dokcsihq_activity1_1781875929973.jpg	image/jpeg	182015	cmq0kyw85007kjx239k25z1ge	2026-06-19 13:32:09.975	\N
cmqkz5pbq0051jxf0sia64yqy	cmqep6tag00mxjxp5kyg8s55h	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fjjxp51to2rjq7_activity1_1781876327027.jpg	image/jpeg	184845	cmq0kyw85007kjx239k25z1ge	2026-06-19 13:38:47.03	\N
cmqkz5s1j004xjxek9m73wrnm	cmqep6tah00oyjxp5hrce1ci3	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00g5jxp53scmw13t_activity1_1781876330549.jpg	image/jpeg	199005	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:38:50.552	\N
cmqkz60qi0053jxf0kr0j85l3	cmqep6tah00o9jxp5hmnr19ba	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fyjxp5gd0tiz6q_activity1_1781876341814.jpg	image/jpeg	217172	cmq0kwit80066jx23pw930nx1	2026-06-19 13:39:01.818	\N
cmqkz65hz004zjxek5x4qhs5a	cmqep6tah00oyjxp5hrce1ci3	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00g5jxp53scmw13t_activity1_1781876347989.jpg	image/jpeg	209870	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:39:07.991	\N
cmqkz66n00055jxf06dm0fxbn	cmqep6tah00o9jxp5hmnr19ba	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fyjxp5gd0tiz6q_activity1_1781876349465.jpg	image/jpeg	211039	cmq0kwit80066jx23pw930nx1	2026-06-19 13:39:09.468	\N
cmqkyyxki004ojxf0niuzetup	cmqep6tag00nejxp5t5xdacb2	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fpjxp5afe8hyp4_activity1_1781876011120.jpg	image/jpeg	184909	cmq0kwit80066jx23pw930nx1	2026-06-19 13:33:31.123	\N
cmqkyz6xw004jjxekpswng945	cmqep6tag00nejxp5t5xdacb2	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fpjxp5afe8hyp4_activity1_1781876023265.jpg	image/jpeg	176750	cmq0kwit80066jx23pw930nx1	2026-06-19 13:33:43.268	\N
cmqkyzvn3004ljxektmsqkh52	cmqep6tag00nijxp5mr9x9803	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fqjxp5np9idghm_activity1_1781876055276.jpg	image/jpeg	174488	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:34:15.279	\N
cmqkyzzyn004qjxf0hakpkdfm	cmqep6tag00mmjxp5osl2gpuy	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fgjxp5q4q2sqhp_activity1_1781876060876.jpg	image/jpeg	193875	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:34:20.879	\N
cmqkz06nj004sjxf04u2wqdxw	cmqep6tag00mmjxp5osl2gpuy	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fgjxp5q4q2sqhp_activity1_1781876069548.jpg	image/jpeg	196697	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:34:29.551	\N
cmqkz0eo2004njxekh4xmmeut	cmqep6tag00nijxp5mr9x9803	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fqjxp5np9idghm_activity1_1781876079934.jpg	image/jpeg	163429	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:34:39.938	\N
cmqkz4fah004tjxekeqxlgm1w	cmqep6tah00oejxp5b93u9tei	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fzjxp54fjcjtah_activity1_1781876267367.jpg	image/jpeg	166889	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:37:47.37	\N
cmqkz4uqr004vjxek866vklif	cmqep6tah00o0jxp5xsrc3nkd	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fvjxp5jwtduygo_activity1_1781876287391.jpg	image/jpeg	168264	cmq0kwit80066jx23pw930nx1	2026-06-19 13:38:07.395	\N
cmqkz50bz004vjxf0s2oudw55	cmqep6tah00o0jxp5xsrc3nkd	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fvjxp5jwtduygo_activity1_1781876294635.jpg	image/jpeg	148820	cmq0kwit80066jx23pw930nx1	2026-06-19 13:38:14.639	\N
cmqkz5g35004zjxf0xkabi3dh	cmqep6tah00oejxp5b93u9tei	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fzjxp54fjcjtah_activity1_1781876315054.jpg	image/jpeg	177120	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:38:35.057	\N
cmqkz6n4z0057jxf0g8b7mbh8	cmqep6tag00mxjxp5kyg8s55h	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fjjxp51to2rjq7_activity1_1781876370847.jpg	image/jpeg	182980	cmq0kyw85007kjx239k25z1ge	2026-06-19 13:39:30.851	\N
cmqkzcb1w005cjxf0k48emcsz	cmqep6tag00npjxp5dzn5jhit	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fsjxp5s3lf3hkn_activity1_1781876635108.jpg	image/jpeg	200452	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:43:55.124	\N
cmqkzch6w0053jxekkio5q2o9	cmqep6tag00n9jxp52xc0a3gs	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fnjxp5bqhzrp6l_activity1_1781876643077.jpg	image/jpeg	192610	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:44:03.081	\N
cmqkzclyv0055jxek89m5448o	cmqep6tag00npjxp5dzn5jhit	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fsjxp5s3lf3hkn_activity1_1781876649270.jpg	image/jpeg	184775	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:44:09.272	\N
cmqkzcm4v005ejxf0d9jw3brz	cmqep6tag00n9jxp52xc0a3gs	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fnjxp5bqhzrp6l_activity1_1781876649484.jpg	image/jpeg	192157	cmq0khs5m000wjx23jyhqhgkv	2026-06-19 13:44:09.488	\N
cmquopiw7000tjxt6u0d08xz8	cmqep6tai00r7jxp5uy4yb2v5	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gtjxp5zntc9qfk_activity2_1782463437796.jpg	image/jpeg	191324	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:43:57.799	abaadb62-97da-4aea-92df-c5c91d7d3edb
cmquor2hh0014jxu6y765ijl1	cmqep6tai00r7jxp5uy4yb2v5	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gtjxp5zntc9qfk_activity2_1782463509841.jpg	image/jpeg	185217	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:45:09.845	ba8c6c0c-aa18-4d68-afdc-c0303c9984a1
cmquorbjq0016jxu63a3l0ba7	cmqep6tah00p7jxp53nbp6cru	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00g7jxp5dadbmh4c_activity2_1782463521587.jpg	image/jpeg	176313	cmq0kwit80066jx23pw930nx1	2026-06-26 08:45:21.591	630607d7-558f-40f9-823a-5eb8fc788ae9
cmquorh92000vjxt6wtw3h8gs	cmqep6tah00p7jxp53nbp6cru	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00g7jxp5dadbmh4c_activity2_1782463528979.jpg	image/jpeg	174173	cmq0kwit80066jx23pw930nx1	2026-06-26 08:45:28.982	0055ea52-1db0-4d21-aff3-2121c9a20475
cmquorr4h000xjxt6ukmnjofz	cmqep6tai00q1jxp5ma2ex0y8	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00ghjxp58tgg12zq_activity2_1782463541775.jpg	image/jpeg	174483	cmq0kwit80066jx23pw930nx1	2026-06-26 08:45:41.778	43460241-3414-470d-8f79-5e2a737c60ed
cmquorwex0019jxu6yzn13nhv	cmqep6tai00q1jxp5ma2ex0y8	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00ghjxp58tgg12zq_activity2_1782463548630.jpg	image/jpeg	146452	cmq0kwit80066jx23pw930nx1	2026-06-26 08:45:48.634	07e9c9cb-4053-4db2-b976-9a33aecf65d4
cmquos3q70011jxt6m1br8w81	cmqep6tai00rajxp50xwn83zl	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gvjxp59jqt3gqm_activity2_1782463558108.jpg	image/jpeg	223415	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:45:58.112	a1e08c3b-8dbe-43ea-9228-d9bfec879791
cmquoshl2001bjxu6grzyl85h	cmqep6tah00pajxp54kn6sbhs	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00g8jxp5e5io1j25_activity2_1782463576066.jpg	image/jpeg	176327	cmq0kwit80066jx23pw930nx1	2026-06-26 08:46:16.07	fbf8da06-c265-4a4d-8250-e8b685d6341f
cmquosoth0013jxt6ju9wglln	cmqep6tah00pajxp54kn6sbhs	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00g8jxp5e5io1j25_activity2_1782463585443.jpg	image/jpeg	144743	cmq0kwit80066jx23pw930nx1	2026-06-26 08:46:25.446	234366f2-6fc3-427e-8f0a-86f9ae1a606d
cmquot3bl0015jxt6lb8n3qca	cmqep6tai00rajxp50xwn83zl	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gvjxp59jqt3gqm_activity2_1782463604238.jpg	image/jpeg	187099	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:46:44.241	f37d51b9-bd51-453d-88cd-d94f840fd35a
cmquot89m001ejxu6z26ofd1v	cmqep6tai00r0jxp5o79femym	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00grjxp5xaus94pp_activity2_1782463610648.jpg	image/jpeg	181928	cmq0kwit80066jx23pw930nx1	2026-06-26 08:46:50.651	75de72d9-9a6c-466f-a951-f23e5f049090
cmquotfpp0018jxt6pl9ggsus	cmqep6tah00pdjxp58355pnvb	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00g9jxp5yihqococ_activity2_1782463620298.jpg	image/jpeg	184417	cmq0kwit80066jx23pw930nx1	2026-06-26 08:47:00.301	7f43d591-4523-4d50-b395-627f421fe1b6
cmquothyp001ajxt6ezfkubg0	cmqep6taj00stjxp5f5mpxrl6	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00hcjxp5o0okg8br_activity2_1782463623207.jpg	image/jpeg	210641	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:47:03.217	ca182cab-5adb-448d-a053-625204418d73
cmquotjfh001cjxt6d83xx4qc	cmqep6tai00r0jxp5o79femym	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00grjxp5xaus94pp_activity2_1782463625114.jpg	image/jpeg	141526	cmq0kwit80066jx23pw930nx1	2026-06-26 08:47:05.117	a0bc6578-4083-42cb-8d2b-ad59d311b408
cmquotlce001ejxt60qjluah0	cmqep6tah00pdjxp58355pnvb	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00g9jxp5yihqococ_activity2_1782463627596.jpg	image/jpeg	154504	cmq0kwit80066jx23pw930nx1	2026-06-26 08:47:07.599	e7980a28-9e29-4786-aec9-1bf2ffb0e746
cmquotp3b001hjxt6xxy7q9fo	cmqep6taj00stjxp5f5mpxrl6	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00hcjxp5o0okg8br_activity2_1782463632452.jpg	image/jpeg	210197	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:47:12.455	9f0df0c9-a57a-40bd-9e3e-a65e586ced51
cmquov3f3001jjxu6owifpsmr	cmqep6tak00tdjxp5p1i6es6k	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00hjjxp5xa6i02q3_activity2_1782463697677.jpg	image/jpeg	257533	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:48:17.679	6c1075af-ee4a-4108-a58b-bf583f5a5506
cmquovafm001ljxu6xpxj6om2	cmqep6tak00tdjxp5p1i6es6k	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00hjjxp5xa6i02q3_activity2_1782463706753.jpg	image/jpeg	229580	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:48:26.771	02b8ee1b-6e5c-40f6-b601-d6a0105412a1
cmquovbhk001njxu6pe7qphg4	cmqep6tah00pgjxp5vpst4wb1	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gajxp56csicf0x_activity2_1782463708134.jpg	image/jpeg	175707	cmq0kwit80066jx23pw930nx1	2026-06-26 08:48:28.136	031a4d5c-8795-4717-84b9-5b55e72a4ac9
cmquovh6r001kjxt6q0i0ypnc	cmqep6tah00pgjxp5vpst4wb1	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gajxp56csicf0x_activity2_1782463715521.jpg	image/jpeg	155273	cmq0kwit80066jx23pw930nx1	2026-06-26 08:48:35.524	91e55b5b-3eca-4a05-bde1-4b92b552c09a
cmquowfy3001qjxu6zig11bh9	cmqep6tah00pjjxp5hexoqq72	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gbjxp5vsmxgz5z_activity2_1782463760568.jpg	image/jpeg	182669	cmq0kwit80066jx23pw930nx1	2026-06-26 08:49:20.571	b7d2a8a3-f101-4dcf-b4fe-5cb3dbefd6a1
cmquowx1y001tjxt63uexoaap	cmqep6taj00rijxp557niep4u	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gyjxp50orak3f8_activity2_1782463782738.jpg	image/jpeg	149651	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:49:42.742	020778bf-e34c-4395-b434-fd4de28d2635
cmquoxoxa001wjxu62nxbkqbe	cmqep6tai00qxjxp532bbvrud	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gqjxp5i3yv7iln_activity2_1782463818860.jpg	image/jpeg	191374	cmq0kwit80066jx23pw930nx1	2026-06-26 08:50:18.862	644ff115-a48f-4db3-907f-c6c74d4af52b
cmquoym8f001zjxt6falyxxgv	cmqep6tak00tajxp5hhcp9r8i	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00hijxp5mgitskzp_activity2_1782463862029.jpg	image/jpeg	215045	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:51:02.031	eba3794e-4fc5-457d-955a-fcfab56c0e7d
cmquoymm00021jxt6rlslupdo	cmqep6tah00pmjxp56x3pm3aq	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gcjxp545zm4dej_activity2_1782463862517.jpg	image/jpeg	168400	cmq0kwit80066jx23pw930nx1	2026-06-26 08:51:02.52	62d7667d-a7d2-49f6-a97a-b3d155035003
cmquoyrrt0024jxt6q9t63mfp	cmqep6tah00pmjxp56x3pm3aq	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gcjxp545zm4dej_activity2_1782463869208.jpg	image/jpeg	132092	cmq0kwit80066jx23pw930nx1	2026-06-26 08:51:09.21	8b647605-a2d7-4c7f-8286-c479b0f0bb0e
cmquozpgu0029jxt62zup0it1	cmqep6tai00ppjxp5rgbfcf31	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gdjxp59lrmb5t2_activity2_1782463912875.jpg	image/jpeg	159773	cmq0kwit80066jx23pw930nx1	2026-06-26 08:51:52.878	824ffae1-5a7a-44cd-85c5-643863a7179c
cmquozq5u002bjxt6lkay8sl6	cmqep6tak00tajxp5hhcp9r8i	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00hijxp5mgitskzp_activity2_1782463913776.jpg	image/jpeg	160067	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:51:53.779	50cf3d91-1431-4ed3-a63d-56804b262e77
cmqup00ys002ejxt6f2exqpg4	cmqep6taj00rqjxp5eyutrxxk	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00h0jxp5b6k9d2ql_activity2_1782463927778.jpg	image/jpeg	280278	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:52:07.78	6b3b497e-4fd0-4d9b-a49a-5a9a78fc15c8
cmqup05fr002gjxt6hislxi4y	cmqep6tai00pvjxp5u8lovby9	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gfjxp567zr1gct_activity2_1782463933572.jpg	image/jpeg	166063	cmq0kwit80066jx23pw930nx1	2026-06-26 08:52:13.575	1e9f7f91-a71e-403e-84e1-f62522e1b8ac
cmqup0bjo002ljxt6em80co2i	cmqep6taj00rqjxp5eyutrxxk	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00h0jxp5b6k9d2ql_activity2_1782463941490.jpg	image/jpeg	190483	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:52:21.492	e5d9afa3-bd42-4be4-bd68-cb95dea1a51c
cmqup0xqd002bjxu6rojrqyod	cmqep6tai00psjxp5teda891e	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gejxp5hwiyumv6_activity2_1782463970242.jpg	image/jpeg	153319	cmq0kwit80066jx23pw930nx1	2026-06-26 08:52:50.245	65fe9e25-9cc4-4bf1-8118-eec34a515352
cmqup2kmq002sjxt6m1surn9t	cmqep6taj00smjxp5fepno62h	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00hajxp53xjfiwp0_activity2_1782464046576.jpg	image/jpeg	192404	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:54:06.578	a5cab69d-0425-475a-b092-db6796140342
cmqup2tky002ujxt64vovmmpx	cmqep6taj00smjxp5fepno62h	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00hajxp53xjfiwp0_activity2_1782464058175.jpg	image/jpeg	149050	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:54:18.178	3076fd17-1586-4f70-9d08-c1db85292ae9
cmqup3org002yjxt6ghwbpzsw	cmqf02txa006tjxopdeesu8su	1	image.jpg	/api/uploads/worksheets/cmqf02twi005zjxop5kafgs6v_activity1_1782464098586.jpg	image/jpeg	151291	cmq0kyw85007kjx239k25z1ge	2026-06-26 08:54:58.588	3fe37b43-ab9e-4bb2-9983-48f987c9d74f
cmqup4a7d0032jxt64tcvfoqs	cmqf02txa006ljxop8hhz7bqi	2	image.jpg	/api/uploads/worksheets/cmqf02twi005xjxop9todeqnc_activity1_1782464126374.jpg	image/jpeg	183659	cmq0kyw85007kjx239k25z1ge	2026-06-26 08:55:26.377	0c24be19-c5d3-469b-b01f-4ef49483aa13
cmqup4o120034jxt68fbqtzxk	cmqep6tai00q4jxp5kyz686pg	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gjjxp59b9xkcrz_activity2_1782464144291.jpg	image/jpeg	180817	cmq0kwit80066jx23pw930nx1	2026-06-26 08:55:44.294	6950267e-3867-4dfc-a229-c843e4821e38
cmqup4qrh0036jxt61xig7qge	cmqep6tai00q8jxp5j3sw5p0h	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gkjxp5h4f0156z_activity2_1782464147834.jpg	image/jpeg	165144	cmq0kwit80066jx23pw930nx1	2026-06-26 08:55:47.838	ed757829-cc47-4e9b-841b-f9be39298d8f
cmqup4vee003ajxt6uvkpe27x	cmqep6tai00q8jxp5j3sw5p0h	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gkjxp5h4f0156z_activity2_1782464153844.jpg	image/jpeg	141047	cmq0kwit80066jx23pw930nx1	2026-06-26 08:55:53.846	ac22827a-a55c-4145-9ad7-1bd6d876334b
cmqup4x8c002ljxu6f77et8uo	cmqep6taj00t3jxp5349w8cxc	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00hgjxp51uc3pwty_activity2_1782464156218.jpg	image/jpeg	222682	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:55:56.22	7e3c1e0d-9ed6-44c4-a5d9-356e312e3ed9
cmqup4xmq002njxu6d29b1dmf	cmqep6taj00s7jxp5r40tmtpe	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00h5jxp53x65440u_activity1_1782464156735.jpg	image/jpeg	205010	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:55:56.738	b6e39541-7303-42d2-a997-6dd2fbfacef2
cmqup53mq002pjxu6di9a5lbh	cmqep6taj00t3jxp5349w8cxc	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00hgjxp51uc3pwty_activity2_1782464164512.jpg	image/jpeg	177074	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:56:04.515	fd8618a6-38e7-4c6c-be7f-73402fdf8105
cmqup542s003cjxt6cne6zg34	cmqep6taj00s7jxp5r40tmtpe	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00h5jxp53x65440u_activity1_1782464165089.jpg	image/jpeg	152835	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:56:05.092	f2c6f4bf-d4ff-42cd-9d56-51cc2fd5b60a
cmqup6rll003fjxt6b29jr84c	cmqep6taj00sajxp5apttdphx	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00h6jxp5lq2ohp8z_activity1_1782464242231.jpg	image/jpeg	186144	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:57:22.234	236a8fcb-5d55-4721-bfc6-305c0a318061
cmqup8fr5003ljxt6bfpqxc86	cmqf02txa006xjxopxlgsu7s0	2	image.jpg	/api/uploads/worksheets/cmqf02twi0060jxopbq0u963r_activity1_1782464320190.jpg	image/jpeg	156227	cmq0kyw85007kjx239k25z1ge	2026-06-26 08:58:40.193	fe298098-fdb8-478b-8ae1-9b66f614fbc7
cmqup8xkq003pjxt65dxlynr6	cmqf02txa006mjxop8n28wa17	1	image.jpg	/api/uploads/worksheets/cmqf02twi005xjxop9todeqnc_activity2_1782464343288.jpg	image/jpeg	185809	cmq0kyw85007kjx239k25z1ge	2026-06-26 08:59:03.29	572b717a-3249-44cf-be3b-83f121b0f7e5
cmqup8yfc002xjxu6bs3ql3ib	cmqep6taj00sbjxp59d9tfy00	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00h6jxp5lq2ohp8z_activity2_1782464344391.jpg	image/jpeg	164205	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:59:04.393	d7b4c989-7ac4-413b-9545-339f16dbb80a
cmqup9f7k002zjxu6pievxhzu	cmqf02txa006mjxop8n28wa17	2	image.jpg	/api/uploads/worksheets/cmqf02twi005xjxop9todeqnc_activity2_1782464366141.jpg	image/jpeg	185382	cmq0kyw85007kjx239k25z1ge	2026-06-26 08:59:26.144	e8f3f8fc-c7bb-43bb-bff2-6b02df1e8f4f
cmqup9fil003sjxt6furahxux	cmqep6taj00s8jxp5qxz0kup1	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00h5jxp53x65440u_activity2_1782464366539.jpg	image/jpeg	195885	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:59:26.541	c95a7716-d2a0-4fd0-96ba-f3b54c4dfd41
cmqup9kei0031jxu613glfwsh	cmqep6taj00s8jxp5qxz0kup1	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00h5jxp53x65440u_activity2_1782464372871.jpg	image/jpeg	165087	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:59:32.874	3bcef84e-62cd-47e3-b9f3-b5a9223f1919
cmqup9x2b003vjxt6fygvb3g9	cmqf02tx9006ejxop4z9mgpb7	1	image.jpg	/api/uploads/worksheets/cmqf02twi005vjxoph6si1y7m_activity2_1782464389281.jpg	image/jpeg	176704	cmq0kwit80066jx23pw930nx1	2026-06-26 08:59:49.284	c7969761-6a04-4dd3-a555-88b6b38fd7cf
cmqupa2190034jxu6iz6v4rly	cmqf02tx9006ejxop4z9mgpb7	2	image.jpg	/api/uploads/worksheets/cmqf02twi005vjxoph6si1y7m_activity2_1782464395722.jpg	image/jpeg	146694	cmq0kwit80066jx23pw930nx1	2026-06-26 08:59:55.725	70ac72da-efdb-446d-8aa6-0d3613172340
cmquowkya001njxt68ztghiaj	cmqep6tah00pjjxp5hexoqq72	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gbjxp5vsmxgz5z_activity2_1782463767055.jpg	image/jpeg	148688	cmq0kwit80066jx23pw930nx1	2026-06-26 08:49:27.059	0e9631bb-0aa1-4679-9078-907732dd3861
cmquowmnf001pjxt6df5yktmv	cmqep6taj00rijxp557niep4u	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gyjxp50orak3f8_activity2_1782463769257.jpg	image/jpeg	150456	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:49:29.259	a6ded653-9613-45bd-b320-2e92933215f6
cmquoxu1c001vjxt6k1ltoyv5	cmqep6tai00qxjxp532bbvrud	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gqjxp5i3yv7iln_activity2_1782463825486.jpg	image/jpeg	169647	cmq0kwit80066jx23pw930nx1	2026-06-26 08:50:25.488	4105caf6-2e03-4514-80d2-e9129021253f
cmquoy46y001yjxu68rngvv1z	cmqep6taj00t0jxp5oknq0hgl	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00hejxp5jx21o02o_activity2_1782463838647.jpg	image/jpeg	264097	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:50:38.65	5153c32a-67ad-4e68-bbc6-ffd272c3bde5
cmquoyhg6001xjxt6d2fy3j79	cmqep6taj00t0jxp5oknq0hgl	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00hejxp5jx21o02o_activity2_1782463855827.jpg	image/jpeg	202762	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:50:55.83	0eb308d4-1ba6-455f-a351-895710f61e2e
cmquoz90f0027jxt6yw6krdzh	cmqep6tai00ppjxp5rgbfcf31	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gdjxp59lrmb5t2_activity2_1782463891548.jpg	image/jpeg	181738	cmq0kwit80066jx23pw930nx1	2026-06-26 08:51:31.551	65b07e70-df38-4fff-aeb3-9ed3a95dfc1d
cmqup09zp002ijxt60kcgb94y	cmqep6tai00pvjxp5u8lovby9	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gfjxp567zr1gct_activity2_1782463939475.jpg	image/jpeg	151373	cmq0kwit80066jx23pw930nx1	2026-06-26 08:52:19.477	7d85b9fe-c5e8-4b6f-8062-643c8bc9ccd8
cmqup0sq60029jxu6gvat6ml2	cmqep6tai00psjxp5teda891e	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gejxp5hwiyumv6_activity2_1782463963755.jpg	image/jpeg	188038	cmq0kwit80066jx23pw930nx1	2026-06-26 08:52:43.758	e977222f-7053-4c70-b562-2072be864e84
cmqup1gra002qjxt6q49uu596	cmqep6taj00ryjxp5e48c123c	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00h2jxp5gb0okmzi_activity2_1782463994899.jpg	image/jpeg	219612	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:53:14.902	f566ae6a-ec8c-4630-9beb-24cf63d16e68
cmqup1lqg002ejxu647yge9lu	cmqep6taj00ryjxp5e48c123c	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00h2jxp5gb0okmzi_activity2_1782464001350.jpg	image/jpeg	176146	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:53:21.353	3c851183-850e-4e26-93ca-8c76c03fbd2a
cmqup3g8s002hjxu6y1gm4hy1	cmqep6taj00s5jxp5ieg0s142	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00h4jxp5jet4udax_activity2_1782464087546.jpg	image/jpeg	225292	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:54:47.549	708208ba-1ab0-40d4-af03-a233d955da2d
cmqup3n81002wjxt6e9afaj9x	cmqf02txa006ljxop8hhz7bqi	1	image.jpg	/api/uploads/worksheets/cmqf02twi005xjxop9todeqnc_activity1_1782464096591.jpg	image/jpeg	221543	cmq0kyw85007kjx239k25z1ge	2026-06-26 08:54:56.594	2a6a89fd-f042-4a72-b95d-e08dcc278de3
cmqup3nc0002jjxu6uncpcceb	cmqep6taj00s5jxp5ieg0s142	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00h4jxp5jet4udax_activity2_1782464096734.jpg	image/jpeg	190264	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:54:56.736	a217213a-971f-466a-9feb-957bb45fa0e0
cmqup41m10030jxt6n3s51krp	cmqf02txa006tjxopdeesu8su	2	image.jpg	/api/uploads/worksheets/cmqf02twi005zjxop5kafgs6v_activity1_1782464115238.jpg	image/jpeg	188769	cmq0kyw85007kjx239k25z1ge	2026-06-26 08:55:15.241	e0cc5b33-4563-4a83-bb16-70f3164bf29c
cmqup4u180038jxt6kk1bmjup	cmqep6tai00q4jxp5kyz686pg	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gjjxp59b9xkcrz_activity2_1782464152075.jpg	image/jpeg	170549	cmq0kwit80066jx23pw930nx1	2026-06-26 08:55:52.077	697978b8-1c9a-4831-85bb-2e249d11665f
cmqup6a7i002sjxu6kty10mj2	cmqep6taj00sajxp5apttdphx	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00h6jxp5lq2ohp8z_activity1_1782464219691.jpg	image/jpeg	260153	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:56:59.694	663d52f0-49a2-43fd-ac7e-969126598b34
cmqup89lx003jjxt6uk4i28vy	cmqf02txa006xjxopxlgsu7s0	1	image.jpg	/api/uploads/worksheets/cmqf02twi0060jxopbq0u963r_activity1_1782464312227.jpg	image/jpeg	184146	cmq0kyw85007kjx239k25z1ge	2026-06-26 08:58:32.23	9f0a36d3-ddf5-4ae2-8f11-b5f5304d1454
cmqup8mfu002vjxu6w4fv6gyx	cmqep6taj00sbjxp59d9tfy00	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00h6jxp5lq2ohp8z_activity2_1782464328856.jpg	image/jpeg	255133	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 08:58:48.858	1d60be0f-fbf8-4574-9706-849dc54b5229
cmqup9y66003xjxt64wy3mfiq	cmqep6tai00qdjxp5ofl8ae82	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gljxp5et9f6y0c_activity3_1782464390715.jpg	image/jpeg	188236	cmq0kwit80066jx23pw930nx1	2026-06-26 08:59:50.718	d7543dcc-1693-40bd-84cb-f3b382f8fde4
cmqupa8c70043jxt6iqfnfgvm	cmqep6taj00sejxp5xa5bit93	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00h7jxp5aomv3xif_activity2_1782464403892.jpg	image/jpeg	213944	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:00:03.896	b63223e0-9e84-4712-a3ed-791832439e28
cmqupae140037jxu623ntgfdf	cmqep6taj00sejxp5xa5bit93	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00h7jxp5aomv3xif_activity2_1782464411270.jpg	image/jpeg	178623	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:00:11.273	f94e8ea6-00bf-464a-82c7-d09673562189
cmqupb8ut003ajxu63fv9qry4	cmqf02txa0071jxopdog77t1s	1	image.jpg	/api/uploads/worksheets/cmqf02twi0061jxopfw2ixih5_activity1_1782464451218.jpg	image/jpeg	213668	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:00:51.221	7dcdbaf1-9c10-4e85-b8c7-26ecb72354a5
cmqupbdie0047jxt6zm09jr2o	cmqep6tak00tgjxp5uiwbipcc	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00hkjxp50bymz2pu_activity2_1782464457252.jpg	image/jpeg	218844	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:00:57.254	517e3c87-59e9-4a79-a776-6c7a2ed01c52
cmqupa2nv003zjxt63drb5cmj	cmqep6tai00qdjxp5ofl8ae82	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gljxp5et9f6y0c_activity3_1782464396537.jpg	image/jpeg	166177	cmq0kwit80066jx23pw930nx1	2026-06-26 08:59:56.54	f918c98c-97b4-406a-8b88-13e300e8f98d
cmqupbbyu0045jxt6x1b73pj8	cmqep6tai00qgjxp5cq4musn4	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gmjxp5w0cyfz8a_activity2_1782464455252.jpg	image/jpeg	193072	cmq0kwit80066jx23pw930nx1	2026-06-26 09:00:55.255	774aa414-cc29-410e-b7f3-9ad7f89a636c
cmqupbjqg003cjxu6ylrankwt	cmqep6tai00qgjxp5cq4musn4	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gmjxp5w0cyfz8a_activity2_1782464465317.jpg	image/jpeg	165634	cmq0kwit80066jx23pw930nx1	2026-06-26 09:01:05.32	be771fa8-f4e3-4a9e-9030-aa34c2e34f13
cmqupblld0049jxt6zacasiem	cmqep6tai00qpjxp5pvas09k2	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gojxp5v1t19fiv_activity2_1782464467726.jpg	image/jpeg	183122	cmq0kwit80066jx23pw930nx1	2026-06-26 09:01:07.729	74db317c-b4d9-42f5-996c-f3844bf81dbb
cmqupboxd003ejxu69y2a6hba	cmqf02txa006ojxopsrzv36nb	1	image.jpg	/api/uploads/worksheets/cmqf02twi005yjxopdari537w_activity1_1782464472047.jpg	image/jpeg	163584	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:01:12.05	8aed76f4-d1f4-41ee-8dc8-2bfc90805cde
cmqupbp8m004bjxt6ar4w9owt	cmqep6tak00tgjxp5uiwbipcc	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00hkjxp50bymz2pu_activity2_1782464472451.jpg	image/jpeg	191263	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:01:12.454	ae5820ee-4c4a-4766-abfe-ed2fe9deef99
cmqupbvo4003hjxu6l3xp9m88	cmqf02txa0071jxopdog77t1s	2	image.jpg	/api/uploads/worksheets/cmqf02twi0061jxopfw2ixih5_activity1_1782464480786.jpg	image/jpeg	184875	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:01:20.789	ae0daf44-7695-4163-a008-a2398d99a3f0
cmqupc0qw004ejxt63drn2w6x	cmqep6tai00qpjxp5pvas09k2	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gojxp5v1t19fiv_activity2_1782464487364.jpg	image/jpeg	159564	cmq0kwit80066jx23pw930nx1	2026-06-26 09:01:27.368	9e224820-969d-46ce-bcbc-d0ed495518cf
cmqupc7hu003kjxu6aj58cpdj	cmqf02txa006ojxopsrzv36nb	2	image.jpg	/api/uploads/worksheets/cmqf02twi005yjxopdari537w_activity1_1782464496111.jpg	image/jpeg	153352	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:01:36.114	8a559113-7eeb-490d-baa3-29f7614129be
cmqupcq5i004hjxt6o0v32kr1	cmqep6tai00r3jxp58ltfatzw	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gsjxp5mtilww6e_activity2_1782464520292.jpg	image/jpeg	164216	cmq0kwit80066jx23pw930nx1	2026-06-26 09:02:00.295	73ec3ec9-f78b-4ee7-b885-321bc03e5fd6
cmqupcwsw003mjxu62c7a7xk4	cmqep6taj00swjxp5vif4iinb	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00hdjxp51yn11mxr_activity2_1782464528909.jpg	image/jpeg	198017	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:02:08.913	24493acd-400d-4a18-88c8-682c611b34d3
cmqupd0hr004jjxt63yx5y2x8	cmqep6tai00r3jxp58ltfatzw	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gsjxp5mtilww6e_activity2_1782464533693.jpg	image/jpeg	142763	cmq0kwit80066jx23pw930nx1	2026-06-26 09:02:13.695	2bb90e44-252f-488d-8712-32445ef7c9be
cmqupd393003ojxu6u551atdz	cmqep6taj00swjxp5vif4iinb	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00hdjxp51yn11mxr_activity2_1782464537268.jpg	image/jpeg	211106	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:02:17.271	488aca7f-99ff-4c6e-ae58-b12c0c9758a1
cmqupdk8a004ljxt638yo7hht	cmqep6taj00sojxp5lc75s9he	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00hbjxp5na2uvdzn_activity1_1782464559271.jpg	image/jpeg	175327	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:02:39.274	01c1c96a-910c-45f6-b238-cefa61ce8e3e
cmqupdvqv004njxt6zu6xaaml	cmqep6taj00sojxp5lc75s9he	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00hbjxp5na2uvdzn_activity1_1782464574197.jpg	image/jpeg	162714	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:02:54.2	e0f0020a-22ad-4ec3-a86e-916659c2ada8
cmqupen4z003rjxu64c0t057s	cmqep6taj00s1jxp5ddbwgbnp	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00h3jxp5nsmq0bu1_activity2_1782464609696.jpg	image/jpeg	190460	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:03:29.699	439be720-94d9-47e5-a5ad-63b2625382b7
cmqupeu0r003ujxu6aenc28h5	cmqep6taj00s1jxp5ddbwgbnp	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00h3jxp5nsmq0bu1_activity2_1782464618616.jpg	image/jpeg	174072	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:03:38.619	4f2fda08-3734-4b80-8d75-21ccd45d0582
cmqupfh2m004rjxt6q79qmfyo	cmqf02tx9006ijxop21fes6vb	1	image.jpg	/api/uploads/worksheets/cmqf02twi005wjxop1suc7kpd_activity2_1782464648491.jpg	image/jpeg	148766	cmq0kwit80066jx23pw930nx1	2026-06-26 09:04:08.494	58958ab9-f693-4dd2-8ecc-d02374bb2ef4
cmqupfip0004tjxt6qu4ppgew	cmqf02txa0072jxopltnwnhhu	1	image.jpg	/api/uploads/worksheets/cmqf02twi0061jxopfw2ixih5_activity2_1782464650595.jpg	image/jpeg	214621	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:04:10.597	b689e63a-f75c-4d08-9493-528f833ed1d1
cmqupfir8003wjxu6bm3667ks	cmqep6tai00qtjxp5y1ykevay	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gpjxp5s7zduyel_activity2_1782464650674.jpg	image/jpeg	197801	cmq0kwit80066jx23pw930nx1	2026-06-26 09:04:10.676	dca3e243-3f64-45f3-b167-c9709b548247
cmqupfop6004vjxt6a4a2cob6	cmqf02txa0072jxopltnwnhhu	2	image.jpg	/api/uploads/worksheets/cmqf02twi0061jxopfw2ixih5_activity2_1782464658376.jpg	image/jpeg	173781	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:04:18.379	475d55f3-379b-4866-9e0d-615502a091ad
cmqupft6a004xjxt6iit0nia1	cmqf02tx9006ijxop21fes6vb	2	image.jpg	/api/uploads/worksheets/cmqf02twi005wjxop1suc7kpd_activity2_1782464664174.jpg	image/jpeg	136307	cmq0kwit80066jx23pw930nx1	2026-06-26 09:04:24.179	b6d3e85d-c69e-47b3-a07b-8715ef14c1eb
cmqupfy4j004zjxt62me30ad6	cmqep6tai00qtjxp5y1ykevay	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gpjxp5s7zduyel_activity2_1782464670593.jpg	image/jpeg	177917	cmq0kwit80066jx23pw930nx1	2026-06-26 09:04:30.596	3d7bf90e-29de-4bef-9701-a24879217149
cmqupgjb6003zjxu60vvn4585	cmqf02txa0075jxop3x8b5yvu	1	image.jpg	/api/uploads/worksheets/cmqf02twi0062jxop3z5jrxny_activity1_1782464698048.jpg	image/jpeg	159164	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:04:58.051	c6e9c463-7fe9-4017-a276-a33d272ac51e
cmqupgr0r0053jxt6pgv2f8ne	cmqf02txa0075jxop3x8b5yvu	2	image.jpg	/api/uploads/worksheets/cmqf02twi0062jxop3z5jrxny_activity1_1782464708040.jpg	image/jpeg	132481	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:05:08.043	26c91313-c1d7-4df6-bc97-d89af3f6a885
cmqupgxe00041jxu66aenqeyb	cmqep6taj00spjxp52tkl75k5	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00hbjxp5na2uvdzn_activity2_1782464716290.jpg	image/jpeg	182598	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:05:16.296	80a4954e-4e18-4e42-a2f8-e3ed1f64c4db
cmquph6g20043jxu6t5f73lwh	cmqep6taj00spjxp52tkl75k5	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00hbjxp5na2uvdzn_activity2_1782464728030.jpg	image/jpeg	160879	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:05:28.034	7c351858-aaf4-48cc-96e8-e69cc06b8d28
cmquphect0045jxu6owt0txuh	cmqep6tak00t6jxp5dubgtvok	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00hhjxp595rvk6sq_activity2_1782464738282.jpg	image/jpeg	213820	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:05:38.285	a9aa612a-3ebe-4629-9755-994a0054be1b
cmquphiqt0057jxt6d6q69tst	cmqep6tak00t6jxp5dubgtvok	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00hhjxp595rvk6sq_activity2_1782464743971.jpg	image/jpeg	182524	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:05:43.973	ef1bfd0f-2cf8-48b8-904d-c75f9958d205
cmqupilcf005ajxt6e7a7vjrd	cmqf02txb007ajxopj9xm39oc	1	image.jpg	/api/uploads/worksheets/cmqf02twi0063jxopuqpquhah_activity1_1782464793996.jpg	image/jpeg	213360	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:06:33.999	c985f726-8f31-4559-81f7-75212bf13697
cmqupir9z0049jxu6tuszz4lc	cmqf02txb007ajxopj9xm39oc	2	image.jpg	/api/uploads/worksheets/cmqf02twi0063jxopuqpquhah_activity1_1782464801683.jpg	image/jpeg	182180	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:06:41.687	2b20d6d5-3105-4a34-869b-31558c896615
cmqupivy9005cjxt6cy2rcz39	cmqep6tai00qkjxp5nous76nk	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gnjxp50tru9y0t_activity2_1782464807743.jpg	image/jpeg	195669	cmq0kwit80066jx23pw930nx1	2026-06-26 09:06:47.746	54a9867e-627f-420f-92c7-0a0a2ab96adb
cmqupjd17004bjxu6whtpo0av	cmqep6tai00qkjxp5nous76nk	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gnjxp50tru9y0t_activity2_1782464829881.jpg	image/jpeg	182756	cmq0kwit80066jx23pw930nx1	2026-06-26 09:07:09.884	3b079501-4af6-4515-b509-367b1bfe35f3
cmqupjmks004ejxu6swbfmdmj	cmqep6tai00rdjxp5i0oqdhai	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gwjxp50vs32gfn_activity2_1782464842249.jpg	image/jpeg	258850	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:07:22.252	e29da1eb-a7c4-4bde-9a17-101266234629
cmqupow7i005rjxt6a9ux0lgi	cmqep6taj00rtjxp5sm52leb4	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00h1jxp5kcbzvnst_activity2_1782465088011.jpg	image/jpeg	247366	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:11:28.014	3516db84-d02c-4d49-86bd-f1e149d68b13
cmqupqj1s004rjxu6lxz2czce	cmqep6tae00l7jxp5p21vs13f	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00f0jxp5gvfwi04n_activity1_1782465164258.jpg	image/jpeg	215370	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:12:44.272	7faed8c6-065e-4675-8bdf-391cd367245d
cmqupwo2y004wjxu6rs6b7uz2	cmqep6tae00ldjxp5yytzy8qi	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00f2jxp5sh03nooy_activity1_1782465450727.jpg	image/jpeg	153192	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:17:30.731	6dc861d9-ac0e-4c91-af06-7f053903e80e
cmqupwz970066jxt6i54z7qze	cmqep6tae00ldjxp5yytzy8qi	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00f2jxp5sh03nooy_activity1_1782465465208.jpg	image/jpeg	190842	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:17:45.211	812a3d37-f249-4ac8-a6e3-9441ea3a590f
cmquq2f9x0053jxu6y3frkfsv	cmqep6taf00lejxp5jgsi4pad	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00f2jxp5sh03nooy_activity2_1782465719251.jpg	image/jpeg	153985	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:21:59.253	3c841d32-9c68-47e8-b6a0-cbcf1460f624
cmquq2ww6006njxt6xav17433	cmqep6tag00mcjxp5n05ybmqc	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fdjxp5phrwrenn_activity2_1782465742084.jpg	image/jpeg	195508	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:22:22.087	742c643d-9536-49c4-8584-27d3eb04f3b9
cmquq3w77006rjxt6oejvk7ls	cmqep6tae00kmjxp5mwqtzbh5	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00etjxp5oklc37y3_activity2_1782465787840.jpg	image/jpeg	143863	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:23:07.843	20c7faa9-8711-4956-914f-42e32b2aa876
cmquq4f6w006vjxt6cjfx6mno	cmqep6tae00kvjxp506he1qdw	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00ewjxp58q8ujqlw_activity2_1782465812453.jpg	image/jpeg	248790	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:23:32.456	a9bdd024-5e00-4aaa-928f-08519bea9ceb
cmquq6da20072jxt6v35s4hqh	cmqep6tae00krjxp5vypyf6yf	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00evjxp5vhoesa20_activity1_1782465903288.jpg	image/jpeg	187644	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:25:03.291	cf32caae-dd8f-4195-83b2-c06e953337af
cmquq6nct0074jxt6y2pd1ugv	cmqep6tae00krjxp5vypyf6yf	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00evjxp5vhoesa20_activity1_1782465916347.jpg	image/jpeg	173125	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:25:16.35	3ec3ab1b-daf2-4801-bfa4-155ddf469f44
cmquq78o1005fjxu6gm3jqxak	cmqep6taf00lljxp542gk4j6j	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00f4jxp5ifdridnj_activity1_1782465943965.jpg	image/jpeg	200497	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:25:43.97	fd16d143-6642-43d6-82a4-e49734d27b9d
cmqupjux9004gjxu6twvixg75	cmqep6taj00rljxp5bwtc826w	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gzjxp5ymu2sdwq_activity2_1782464853067.jpg	image/jpeg	200707	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:07:33.07	daae0baa-6f9f-4a73-8e47-622cb3905845
cmqupjxss005ejxt62xf465ii	cmqep6tai00rdjxp5i0oqdhai	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gwjxp50vs32gfn_activity2_1782464856794.jpg	image/jpeg	185205	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:07:36.797	f4996170-d6de-4dac-8ace-1657e7847a44
cmqupkek7004ijxu6nuz1yg8f	cmqep6taj00rljxp5bwtc826w	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gzjxp5ymu2sdwq_activity2_1782464878517.jpg	image/jpeg	168780	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:07:58.52	0d6a6901-9b57-49ed-a122-455c2bdbc615
cmquplx8d005hjxt6vtzw9c9a	cmqep6taj00rsjxp5u3dk66t6	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00h1jxp5kcbzvnst_activity1_1782464949371.jpg	image/jpeg	207832	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:09:09.374	1c2e5ab5-9000-4636-9f2c-bdf03e8a2401
cmquplzmr004mjxu6sgwv299z	cmqep6taj00shjxp5zp07hdae	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00h9jxp5ov6rpkzw_activity2_1782464952481.jpg	image/jpeg	193582	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:09:12.484	1c86851a-c1de-425e-bab6-4174c43e6eb5
cmqupp9st005ujxt6h38pc0t7	cmqep6taj00rtjxp5sm52leb4	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00h1jxp5kcbzvnst_activity2_1782465105614.jpg	image/jpeg	198721	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:11:45.629	c2618d5a-00a4-4cdb-ab25-10bd3f6053c2
cmqupr2dl004tjxu6oybfpthd	cmqep6tae00l7jxp5p21vs13f	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00f0jxp5gvfwi04n_activity1_1782465189318.jpg	image/jpeg	196045	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:13:09.321	4b1d7a75-74dd-4c84-b88d-bfce942a3f1e
cmqupr7yv005xjxt69h38ewx7	cmqep6tae00kljxp5bna5lssm	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00etjxp5oklc37y3_activity1_1782465196565.jpg	image/jpeg	153119	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:13:16.568	24a188c9-e52f-4906-bed7-76a51db4e14a
cmqupyxca004yjxu66amt5ora	cmqep6tag00mbjxp5thy3ikfq	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fdjxp5phrwrenn_activity1_1782465556039.jpg	image/jpeg	164897	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:19:16.042	9c22b510-ec49-4537-95c2-2a4ac90ba313
cmquq3tdo006pjxt6lyihynhb	cmqep6tae00kvjxp506he1qdw	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00ewjxp58q8ujqlw_activity2_1782465784185.jpg	image/jpeg	238371	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:23:04.188	ec8b080b-d4ba-48b7-9d54-3cd88867fad8
cmqupm47u004ojxu6nar5zks0	cmqep6taj00rsjxp5u3dk66t6	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00h1jxp5kcbzvnst_activity1_1782464958424.jpg	image/jpeg	188769	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:09:18.426	37955aff-1bed-4000-807a-79555d85d909
cmqupmal4005jjxt69wwv1blq	cmqep6taj00shjxp5zp07hdae	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00h9jxp5ov6rpkzw_activity2_1782464966678.jpg	image/jpeg	155381	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:09:26.68	02e7dc97-d3c4-4708-9c7d-c9e1ed1f897a
cmqupmj1r005njxt6v4zqeq26	cmqf02txb007bjxopcpogputz	1	image.jpg	/api/uploads/worksheets/cmqf02twi0063jxopuqpquhah_activity2_1782464977644.jpg	image/jpeg	205572	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:09:37.647	51b636e3-65d6-4d86-bd8d-d2f687b5e818
cmqupmq2r005pjxt6t4kw3xa6	cmqf02txb007bjxopcpogputz	2	image.jpg	/api/uploads/worksheets/cmqf02twi0063jxopuqpquhah_activity2_1782464986752.jpg	image/jpeg	188948	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:09:46.755	f98f9de5-91d2-42c6-9116-3063eaf04adf
cmqupy4hv0069jxt6itx31ef9	cmqep6tag00mbjxp5thy3ikfq	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fdjxp5phrwrenn_activity1_1782465518655.jpg	image/jpeg	172709	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:18:38.659	626fd956-5622-4ef1-b65f-af634e44d920
cmqupzrgb006bjxt6zs8fmp8h	cmqep6tae00kujxp5dnxertgl	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00ewjxp58q8ujqlw_activity1_1782465595064.jpg	image/jpeg	205988	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:19:55.067	3099ecd1-2e65-4c12-8c5a-3232e4a601f0
cmquq3z070058jxu698pazh58	cmqep6taf00lxjxp5hyf8ebmi	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00f7jxp5l3oii2qb_activity2_1782465791476.jpg	image/jpeg	225968	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:23:11.479	2ee7fdfa-7223-4db1-aaef-229eb46e6bc7
cmquq458t005ajxu6xgs78p5y	cmqep6taf00lxjxp5hyf8ebmi	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00f7jxp5l3oii2qb_activity2_1782465799563.jpg	image/jpeg	188682	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:23:19.565	d38c395f-f1e2-454e-abf0-330d0901172b
cmquq5yzq006yjxt6y607n6uu	cmqep6taf00m2jxp58agqvld9	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00f9jxp5wi3o0rdy_activity1_1782465884771.jpg	image/jpeg	208655	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:24:44.775	27ebcb62-7ae7-4c59-8d85-45a52dcdf7e1
cmquq664u0070jxt64q0h21so	cmqep6taf00m2jxp58agqvld9	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00f9jxp5wi3o0rdy_activity1_1782465894020.jpg	image/jpeg	196842	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:24:54.031	68dbec5b-c422-492e-81a3-06ab5fe52f1c
cmquq6uuk005djxu6ntcurn3w	cmqep6taf00lljxp542gk4j6j	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00f4jxp5ifdridnj_activity1_1782465926049.jpg	image/jpeg	187567	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:25:26.061	c339260c-805e-4381-8ca2-2556426fceb5
cmquprcmr005zjxt6x9rdmxx6	cmqep6tae00kljxp5bna5lssm	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00etjxp5oklc37y3_activity1_1782465202608.jpg	image/jpeg	154955	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:13:22.612	251ed990-acdc-4094-932a-5308e2d39f7b
cmqupunhb0062jxt61rqb5t2x	cmqep6tae00l8jxp5b07r9x0d	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00f0jxp5gvfwi04n_activity2_1782465356636.jpg	image/jpeg	199457	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:15:56.639	ffa0d30f-bfe0-4b03-ac1a-d17bd1e221bd
cmqupuzyc0064jxt6e0beklz7	cmqep6tae00l8jxp5b07r9x0d	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00f0jxp5gvfwi04n_activity2_1782465372802.jpg	image/jpeg	193799	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:16:12.805	41fae5db-d811-401d-846a-26b4b269a9ac
cmquq141y006ejxt673ewkjkl	cmqep6tae00kujxp5dnxertgl	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00ewjxp58q8ujqlw_activity1_1782465658051.jpg	image/jpeg	185977	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:20:58.054	3a0af44c-1c61-45d6-847a-acad23188a07
cmquq1jzp0051jxu6uuqao1ni	cmqep6taf00lwjxp5yqeihwvy	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00f7jxp5l3oii2qb_activity1_1782465678707.jpg	image/jpeg	205887	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:21:18.71	0eccd287-e35f-40b9-9b17-e1dc4dd6dfe8
cmquq1olq006gjxt6eya0bw5u	cmqep6taf00lwjxp5yqeihwvy	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00f7jxp5l3oii2qb_activity1_1782465684683.jpg	image/jpeg	199382	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:21:24.686	152aa54e-c181-4ea9-a264-16fccdc665a0
cmquq2jm8006ijxt6wxskav9p	cmqep6taf00lejxp5jgsi4pad	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00f2jxp5sh03nooy_activity2_1782465724879.jpg	image/jpeg	142999	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:22:04.881	19ca6150-75b0-40d2-9207-8e09b8ecb0c6
cmquq3iz90055jxu6u1466p0v	cmqep6tag00mcjxp5n05ybmqc	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fdjxp5phrwrenn_activity2_1782465770707.jpg	image/jpeg	160295	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:22:50.71	04c8d9e2-5b03-4937-a4bb-b395a727068a
cmquq44x8006tjxt67m6bod1n	cmqep6tae00kmjxp5mwqtzbh5	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00etjxp5oklc37y3_activity2_1782465799147.jpg	image/jpeg	168859	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:23:19.149	2463db66-7ace-4736-9abb-9fcb30d5e3ab
cmquq91qr005ijxu6gtjt8z8f	cmqep6tae00lajxp5h4zdtjc5	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00f1jxp5twcea6w7_activity1_1782466028304.jpg	image/jpeg	179962	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:27:08.307	f965e39e-43a2-40c5-8c9e-ec286b6ce63d
cmquq9byy0079jxt6xbwt7x8k	cmqep6taf00lmjxp585xu8d0b	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00f4jxp5ifdridnj_activity2_1782466041546.jpg	image/jpeg	194762	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:27:21.563	838e9568-cc96-4fb6-a501-e30742c22ad5
cmquq9cth007bjxt6wub9vgrm	cmqep6taf00m3jxp5qzt1lfcc	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00f9jxp5wi3o0rdy_activity2_1782466042658.jpg	image/jpeg	230095	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:27:22.662	e2ca799e-e370-48c9-b0c7-c09e9dbfce74
cmquq9i7e007djxt64nowgrri	cmqep6taf00m3jxp5qzt1lfcc	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00f9jxp5wi3o0rdy_activity2_1782466049638.jpg	image/jpeg	177044	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:27:29.642	7779b542-66a7-4455-a51e-8850f74cff44
cmquq9mik007fjxt60yrroghs	cmqep6taf00lmjxp585xu8d0b	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00f4jxp5ifdridnj_activity2_1782466055225.jpg	image/jpeg	169706	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:27:35.228	a972a4e9-5090-4890-a53e-73e9e29d2ff1
cmquq9mlb005kjxu6qz834z1w	cmqep6tae00lajxp5h4zdtjc5	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00f1jxp5twcea6w7_activity1_1782466055325.jpg	image/jpeg	131001	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:27:35.328	898086f0-b40b-461c-90f5-4f3646fc74d7
cmquqbpkw007jjxt6drtfhd7t	cmqep6tae00ksjxp5zeym81zm	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00evjxp5vhoesa20_activity2_1782466152507.jpg	image/jpeg	186696	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:29:12.512	c019c899-f3f7-4059-9db0-1567bbff1c65
cmquqbunt007ljxt6kd6oe43o	cmqep6tae00ksjxp5zeym81zm	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00evjxp5vhoesa20_activity2_1782466159095.jpg	image/jpeg	206900	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:29:19.097	05dd7a10-910b-4ec1-acff-47c4d8ecdc89
cmquqc7a8005pjxu6vs00urs8	cmqep6taf00lsjxp57evc17m2	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00f6jxp5ryay9b35_activity1_1782466175453.jpg	image/jpeg	208455	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:29:35.456	ef42da8c-bc0b-41e6-b7ce-d2d2cb2b0006
cmquqceen007njxt6xj6174as	cmqep6taf00lsjxp57evc17m2	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00f6jxp5ryay9b35_activity1_1782466184684.jpg	image/jpeg	192445	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:29:44.687	d74dde5e-3a4b-47c9-a702-fc3801045fe1
cmquqcu94007pjxt6k1wea4x2	cmqep6tad00kijxp521e73zq0	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00esjxp5cbdmqqex_activity1_1782466205221.jpg	image/jpeg	210252	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:30:05.224	b86eeea5-d952-4b01-8695-a9d08cb80c12
cmquqd3wu005rjxu62dyglr2z	cmqep6tad00kijxp521e73zq0	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00esjxp5cbdmqqex_activity1_1782466217740.jpg	image/jpeg	204451	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:30:17.742	ae05d270-af28-44f0-8ceb-f37bcb57c37f
cmquqdh7p005tjxu6xbly3ain	cmqep6tae00l1jxp5258qfq4b	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00eyjxp55zwq78jl_activity1_1782466234978.jpg	image/jpeg	189026	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:30:34.981	049e402f-f072-44ae-92c3-e9d73f7f5c7b
cmquqdq5t005vjxu6ia1gey8o	cmqep6tae00l1jxp5258qfq4b	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00eyjxp55zwq78jl_activity1_1782466246574.jpg	image/jpeg	173884	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:30:46.577	dbf1cb46-50a1-4752-974f-959e1c376926
cmquqedak007sjxt63z0o5zhg	cmqep6tae00lbjxp5y4x8nkgy	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00f1jxp5twcea6w7_activity2_1782466276554.jpg	image/jpeg	150948	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:31:16.556	32cfb8fb-1095-4fd4-9bf6-a4f53aa54b05
cmquqehgb005xjxu6pjuhq7k1	cmqep6tae00lbjxp5y4x8nkgy	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00f1jxp5twcea6w7_activity2_1782466281944.jpg	image/jpeg	138167	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:31:21.947	cb32fffb-30e2-4ec9-9659-9844d2df6efd
cmquqem0d005zjxu6311zmoe1	cmqep6tae00kjjxp5vi4bc7k3	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00esjxp5cbdmqqex_activity2_1782466287850.jpg	image/jpeg	238449	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:31:27.853	a6314289-d1e2-48d5-9464-75bc2ff108d8
cmquqer2t0061jxu6jbavu1gk	cmqep6tae00kjjxp5vi4bc7k3	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00esjxp5cbdmqqex_activity2_1782466294419.jpg	image/jpeg	227940	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:31:34.421	8fd52571-90a2-4057-8967-c541dfe43f87
cmquqf71u007vjxt6e7rnhqbu	cmqep6taf00ltjxp51jfefb7g	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00f6jxp5ryay9b35_activity2_1782466315120.jpg	image/jpeg	209566	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:31:55.122	5fd2ab80-5562-4e2a-be47-f67af0eb1af3
cmquqfkbc0065jxu6oduiw87d	cmqep6taf00ltjxp51jfefb7g	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00f6jxp5ryay9b35_activity2_1782466332309.jpg	image/jpeg	218273	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:32:12.312	e74d125d-a2bf-413e-81a4-7b20c235ef8e
cmquqfq2k0067jxu68yxcxdo4	cmqep6taf00m8jxp54rg3cm83	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fcjxp5slrtarvk_activity1_1782466339770.jpg	image/jpeg	215795	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:32:19.773	e76e8542-f1d5-406f-ac78-fe4611b1410e
cmquqfvdm007xjxt6x8ynwxhu	cmqep6taf00m8jxp54rg3cm83	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fcjxp5slrtarvk_activity1_1782466346646.jpg	image/jpeg	201992	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:32:26.65	9e904f8d-7d30-435d-9ce4-8b945285675b
cmquqg8w70069jxu6323jyc8p	cmqep6tae00l2jxp5j96lsa0u	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00eyjxp55zwq78jl_activity2_1782466364165.jpg	image/jpeg	188513	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:32:44.167	4b6d3652-e25c-45f8-9918-2c007f4883da
cmquqgfp9006bjxu6xmnh6yld	cmqep6tae00l2jxp5j96lsa0u	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00eyjxp55zwq78jl_activity2_1782466372987.jpg	image/jpeg	203266	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:32:52.99	0387010c-dc8a-471a-8dc8-aa55014f389a
cmquqh2ga007zjxt69wnfvwd0	cmqep6taf00m9jxp57z2zn6f0	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fcjxp5slrtarvk_activity2_1782466402472.jpg	image/jpeg	217367	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:33:22.474	d3cc38fc-8ecd-4135-9dc2-2f7b89f2a048
cmquqjgcx0085jxt6f85glzcq	cmqep6tah00oajxp5198ghjny	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fyjxp5gd0tiz6q_activity2_1782466513806.jpg	image/jpeg	220740	cmq0kwit80066jx23pw930nx1	2026-06-26 09:35:13.809	b974059a-c241-437b-876e-95cb24af3ac5
cmquqmb17008djxt6z1xd87zx	cmqep6tad00kfjxp5oyn4ub93	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00erjxp54fnk3xqy_activity1_1782466646855.jpg	image/jpeg	161959	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:37:26.875	936592af-7209-492e-bc82-3d09490ab028
cmquqh6qg0081jxt6xpslj1f6	cmqep6taf00m9jxp57z2zn6f0	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fcjxp5slrtarvk_activity2_1782466408022.jpg	image/jpeg	242005	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:33:28.025	ae6cc7b7-c2c6-43f4-aa0e-b852a78989a8
cmquqhs1q0083jxt6ra9fby5w	cmqep6taf00m5jxp5w2tp8ov6	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fbjxp5c1fz5ppe_activity1_1782466435643.jpg	image/jpeg	174295	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:33:55.647	8543b840-ed08-494a-bc1b-4c82109fd0ce
cmquqi022006fjxu6txqcn1aj	cmqep6taf00m5jxp5w2tp8ov6	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fbjxp5c1fz5ppe_activity1_1782466446023.jpg	image/jpeg	170819	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:34:06.027	679f3fe1-0ae3-45ce-a15b-7c86048a31c7
cmquqkac90088jxt6wz9bxw4q	cmqep6taf00m6jxp5las1v0s5	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fbjxp5c1fz5ppe_activity2_1782466552661.jpg	image/jpeg	175747	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:35:52.666	ed149f4b-6f9a-4823-bdc4-2afa2a44a913
cmquqkm6z006kjxu63s37jj1b	cmqep6taf00m6jxp5las1v0s5	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fbjxp5c1fz5ppe_activity2_1782466568023.jpg	image/jpeg	142194	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:36:08.027	91323551-f1c2-471c-87db-b7d125caa898
cmquqqi2k0072jxu6l0f6j7t9	cmqep6tag00najxp5pa0647l0	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fnjxp5bqhzrp6l_activity2_1782466842617.jpg	image/jpeg	221071	cmq0kwit80066jx23pw930nx1	2026-06-26 09:40:42.62	725b9303-0be3-4e14-9fe5-fc75955aeb90
cmquqqn6r008jjxt6ui0uhck3	cmqep6tag00najxp5pa0647l0	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fnjxp5bqhzrp6l_activity2_1782466849248.jpg	image/jpeg	189711	cmq0kwit80066jx23pw930nx1	2026-06-26 09:40:49.251	bda88d6a-502d-4b4c-800c-e72f8d08cf9d
cmquqqqfu008ljxt6ree3yf8z	cmqep6tad00kgjxp5qt9lei1v	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00erjxp54fnk3xqy_activity2_1782466853462.jpg	image/jpeg	168600	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:40:53.467	01ce270f-b571-43fc-b7ff-645a3c6d87ee
cmquqrw5h008rjxt6yidm5ev0	cmqep6taf00lpjxp5tc5l73qs	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00f5jxp5kn6gv1ni_activity1_1782466907522.jpg	image/jpeg	180931	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:41:47.525	e16ddb73-1808-4840-940d-406cca3866e8
cmquqv1lx0094jxt66802h52m	cmqep6tah00o6jxp5yx9g0xv0	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fwjxp5he7659eh_activity2_1782467054562.jpg	image/jpeg	197601	cmq0kwit80066jx23pw930nx1	2026-06-26 09:44:14.565	c91a9063-af58-4c27-8fb3-8df864269108
cmquqv88l0096jxt6weqa4yt1	cmqep6tah00o6jxp5yx9g0xv0	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fwjxp5he7659eh_activity2_1782467063154.jpg	image/jpeg	177127	cmq0kwit80066jx23pw930nx1	2026-06-26 09:44:23.158	3a519f72-a50f-401b-805c-b8a7698940d4
cmquqvjik0099jxt6kaldhobv	cmqep6tae00kojxp5rruxzuod	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00eujxp5wceys9yo_activity1_1782467077770.jpg	image/jpeg	193326	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:44:37.772	ad119872-6a7c-4571-8ffd-3e51bebdf710
cmquqx986009jjxt6j306z3zd	cmqep6taf00lqjxp53hm8u98g	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00f5jxp5kn6gv1ni_activity2_1782467157748.jpg	image/jpeg	130244	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:45:57.751	dc36f5b4-1702-4dfa-9000-11973b0ceeb1
cmquqxosg007gjxu6u7dnmi17	cmqep6tag00mujxp5c1ni7f1w	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fijxp5jyyrjuz8_activity2_1782467177916.jpg	image/jpeg	198783	cmq0kwit80066jx23pw930nx1	2026-06-26 09:46:17.921	863522a1-d294-4d2f-8d60-45e7d2f33c67
cmqur1s1c007wjxu6hejs1oak	cmqep6tag00njjxp503nen2o3	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fqjxp5np9idghm_activity2_1782467368750.jpg	image/jpeg	139503	cmq0kwit80066jx23pw930nx1	2026-06-26 09:49:28.752	378b23f3-803d-43f7-bef8-6ffada573a7e
cmqur1u6s009vjxt6cq0u2xmp	cmqep6taf00lzjxp5bwjlk05a	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00f8jxp55qj3x2vc_activity1_1782467371537.jpg	image/jpeg	142015	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:49:31.541	11a4b570-f6c9-43af-b6e8-0136cb3c5933
cmqur1w8r007yjxu6rultt0px	cmqep6tae00kpjxp5plx2tggc	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00eujxp5wceys9yo_activity2_1782467374200.jpg	image/jpeg	197963	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:49:34.203	9ac57ec0-4cc9-4839-a6eb-f6c0f85ca2b5
cmqur21lq0080jxu672cx1pzr	cmqep6taf00lzjxp5bwjlk05a	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00f8jxp55qj3x2vc_activity1_1782467381147.jpg	image/jpeg	143152	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:49:41.15	fe71453d-8537-41e3-b9f7-cb72e601bca8
cmqur2a2m009xjxt61nnl9l1f	cmqep6tae00kyjxp5564s6uu3	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00exjxp5g48uiw9v_activity1_1782467392123.jpg	image/jpeg	196424	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:49:52.126	3016238a-265e-40b8-a4ba-13a6fe1f8b8c
cmquqjl9b006ijxu6axldh0nh	cmqep6tah00oajxp5198ghjny	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fyjxp5gd0tiz6q_activity2_1782466520156.jpg	image/jpeg	191715	cmq0kwit80066jx23pw930nx1	2026-06-26 09:35:20.159	13989493-b4ca-4866-9115-5c2d0b91fff3
cmquqlsfo006sjxu6grxaay8f	cmqep6tad00kfjxp5oyn4ub93	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00erjxp54fnk3xqy_activity1_1782466622761.jpg	image/jpeg	186123	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:37:02.772	b4b8d45d-f20a-4157-9e36-da282b25d784
cmquqnvai006vjxu6uwlbgd2j	cmqep6tah00o1jxp5dfoplbbl	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fvjxp5jwtduygo_activity2_1782466719784.jpg	image/jpeg	197255	cmq0kwit80066jx23pw930nx1	2026-06-26 09:38:39.787	72965bb7-e136-44ed-9ca5-4a8303e2b899
cmquqo3tt006xjxu6r6uoy7z2	cmqep6tah00o1jxp5dfoplbbl	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fvjxp5jwtduygo_activity2_1782466730846.jpg	image/jpeg	177941	cmq0kwit80066jx23pw930nx1	2026-06-26 09:38:50.85	48cfd044-963a-4bd6-8a41-40938ac93f0c
cmquqsp3d0090jxt6yvko8q57	cmqep6taf00lpjxp5tc5l73qs	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00f5jxp5kn6gv1ni_activity1_1782466945025.jpg	image/jpeg	164523	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:42:25.033	cbdbf840-8fbd-473a-8dd4-1de1a7b44125
cmquql46m008ajxt6eox7i9y3	cmqep6tah00ofjxp58keolg9h	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fzjxp54fjcjtah_activity2_1782466591339.jpg	image/jpeg	188288	cmq0kwit80066jx23pw930nx1	2026-06-26 09:36:31.343	9c044dd5-6221-4997-944d-93e1d4b15551
cmquql8iw006njxu6szs02cd8	cmqep6tah00ofjxp58keolg9h	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fzjxp54fjcjtah_activity2_1782466596965.jpg	image/jpeg	172658	cmq0kwit80066jx23pw930nx1	2026-06-26 09:36:36.968	59a75209-37b5-4243-8c69-861ca0b5ad73
cmquqo6el006zjxu6hntnth3j	cmqep6tag00myjxp5c2o430fo	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fjjxp51to2rjq7_activity2_1782466734186.jpg	image/jpeg	204900	cmq0kwit80066jx23pw930nx1	2026-06-26 09:38:54.189	f7835a9d-c310-4bf9-8d44-805b5a610b4a
cmquqoc20008gjxt6w940b7kc	cmqep6tag00myjxp5c2o430fo	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fjjxp51to2rjq7_activity2_1782466741508.jpg	image/jpeg	164677	cmq0kwit80066jx23pw930nx1	2026-06-26 09:39:01.513	8be7dd1f-ee07-4d94-9ff0-1ad014860579
cmquqqxtg008njxt6vjq5auv8	cmqep6tad00kgjxp5qt9lei1v	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00erjxp54fnk3xqy_activity2_1782466863025.jpg	image/jpeg	148654	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:41:03.029	b100a42b-70bd-4b40-8787-f6039cdc74e8
cmquqrsw8008pjxt6xdqnd1ar	cmqep6tah00ozjxp5xbuex5h1	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00g5jxp53scmw13t_activity2_1782466903302.jpg	image/jpeg	211722	cmq0kwit80066jx23pw930nx1	2026-06-26 09:41:43.305	7746076a-8367-4c30-b1a5-f2862d504019
cmquqs1iz008tjxt61eko4knu	cmqep6tag00nqjxp5v71nwxj5	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fsjxp5s3lf3hkn_activity2_1782466914488.jpg	image/jpeg	178801	cmq0kwit80066jx23pw930nx1	2026-06-26 09:41:54.492	0957fb06-0a84-46f6-b9c8-2fadcffe94e5
cmquqs8kv008vjxt6jrwmda5s	cmqep6tah00ozjxp5xbuex5h1	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00g5jxp53scmw13t_activity2_1782466923629.jpg	image/jpeg	153216	cmq0kwit80066jx23pw930nx1	2026-06-26 09:42:03.631	48dab548-0950-4150-b071-b7ae691c6886
cmquqscfn008xjxt6hs1j68b1	cmqep6tag00nqjxp5v71nwxj5	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fsjxp5s3lf3hkn_activity2_1782466928624.jpg	image/jpeg	179835	cmq0kwit80066jx23pw930nx1	2026-06-26 09:42:08.627	b9598992-4a77-4edd-a686-a5032c11508a
cmquqvvs4009bjxt63mw1arvv	cmqep6tag00mjjxp5vhojhp11	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00ffjxp5qxsn29jv_activity2_1782467093666.jpg	image/jpeg	213385	cmq0kwit80066jx23pw930nx1	2026-06-26 09:44:53.669	5fe02c86-60e4-48fd-9079-9e151124470e
cmquqw2w1007cjxu64cog5wha	cmqep6tag00mjjxp5vhojhp11	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00ffjxp5qxsn29jv_activity2_1782467102878.jpg	image/jpeg	145677	cmq0kwit80066jx23pw930nx1	2026-06-26 09:45:02.882	b003202f-4355-41a2-9c08-4b2c0119848e
cmquqw7x5007ejxu6wkr6aafd	cmqep6tae00kojxp5rruxzuod	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00eujxp5wceys9yo_activity1_1782467109399.jpg	image/jpeg	182975	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:45:09.402	34beb99b-a4ef-4a33-8e65-9139b420cd59
cmquqx3l5009hjxt6nibxpeor	cmqep6taf00lqjxp53hm8u98g	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00f5jxp5kn6gv1ni_activity2_1782467150438.jpg	image/jpeg	140852	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:45:50.442	53a7bb23-a8a1-482f-a86b-8690ee27ca8c
cmquqy6rg007ijxu6o4mnjcu7	cmqep6tag00mujxp5c1ni7f1w	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fijxp5jyyrjuz8_activity2_1782467201205.jpg	image/jpeg	189636	cmq0kwit80066jx23pw930nx1	2026-06-26 09:46:41.212	9e12cb93-315e-4d77-8211-9178ca21752c
cmquqzfku009mjxt6j34f5s7g	cmqep6tag00nfjxp5lqmchcea	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fpjxp5afe8hyp4_activity2_1782467259292.jpg	image/jpeg	163726	cmq0kwit80066jx23pw930nx1	2026-06-26 09:47:39.295	7dc414a0-d8d7-4471-9724-1b4ef6435635
cmquqzk1f007ljxu690kq8jd4	cmqep6tag00nfjxp5lqmchcea	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fpjxp5afe8hyp4_activity2_1782467265073.jpg	image/jpeg	152730	cmq0kwit80066jx23pw930nx1	2026-06-26 09:47:45.075	5e3f7cb5-9de8-468c-aeda-2f7880d3457b
cmqur0zxc009pjxt6l12m1jh5	cmqep6tag00n3jxp54lh5wami	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fkjxp5dokcsihq_activity2_1782467332318.jpg	image/jpeg	170024	cmq0kwit80066jx23pw930nx1	2026-06-26 09:48:52.321	bb384fab-461f-4dce-90d2-dce0fa1ba642
cmqur15yh009sjxt6qcmf0v65	cmqep6tag00n3jxp54lh5wami	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fkjxp5dokcsihq_activity2_1782467340135.jpg	image/jpeg	140075	cmq0kwit80066jx23pw930nx1	2026-06-26 09:49:00.137	7c43f535-716f-4324-8937-f04b83410524
cmqur1fnf007sjxu6rhv26z9k	cmqep6tag00njjxp503nen2o3	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fqjxp5np9idghm_activity2_1782467352696.jpg	image/jpeg	170719	cmq0kwit80066jx23pw930nx1	2026-06-26 09:49:12.699	ad034b3f-30cd-4263-ba0a-c0c450281285
cmqur1l72007ujxu67dn3v4m9	cmqep6tae00kpjxp5plx2tggc	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00eujxp5wceys9yo_activity2_1782467359882.jpg	image/jpeg	190616	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:49:19.886	9b96a592-be06-43f3-9f98-1de69492d13c
cmqur2gq40082jxu6geq8ofm3	cmqep6tae00kyjxp5564s6uu3	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00exjxp5g48uiw9v_activity1_1782467400745.jpg	image/jpeg	167065	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:50:00.748	c0acbef7-33f9-45e8-8cb3-6ef65e4b434c
cmqur3x2z0085jxu6rw2obi2p	cmqep6tag00mnjxp59hl9tbmt	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fgjxp5q4q2sqhp_activity2_1782467468600.jpg	image/jpeg	200166	cmq0kwit80066jx23pw930nx1	2026-06-26 09:51:08.603	02070477-cc68-44a9-9ccf-429c0d44b45b
cmqur4f5u00a1jxt6nusaz1d2	cmqep6tae00kzjxp552fvi9nx	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00exjxp5g48uiw9v_activity2_1782467492031.jpg	image/jpeg	190562	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:51:32.035	93419db8-a219-428a-9bc3-6d074f389b48
cmqur4mi800a3jxt65zpdrlon	cmqep6tag00mnjxp59hl9tbmt	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fgjxp5q4q2sqhp_activity2_1782467501549.jpg	image/jpeg	156307	cmq0kwit80066jx23pw930nx1	2026-06-26 09:51:41.552	c06e5841-f92c-405b-a61b-b69266dcc747
cmqur4pbv00a5jxt68seboscw	cmqep6tae00kzjxp552fvi9nx	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00exjxp5g48uiw9v_activity2_1782467505199.jpg	image/jpeg	213225	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:51:45.211	1035a638-8dc9-4f1e-b5c6-1ab1f803539e
cmqur5cs300abjxt6w8jveosw	cmqep6taf00m0jxp5h51gbmg2	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00f8jxp55qj3x2vc_activity2_1782467535600.jpg	image/jpeg	158430	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:52:15.603	425164a2-33b2-4219-867c-f5fa698038e9
cmqur5meb00adjxt6euuf143k	cmqep6tag00mgjxp5x2a4woek	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fejxp5o7dl7di4_activity2_1782467548064.jpg	image/jpeg	162170	cmq0kwit80066jx23pw930nx1	2026-06-26 09:52:28.067	9f3b43bf-4378-4f58-80d8-4aeae81a3497
cmqur5ps40088jxu6pnugugfu	cmqep6tag00nvjxp5jlwom1ah	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00ftjxp5qcd2510h_activity2_1782467552450.jpg	image/jpeg	168792	cmq0kwit80066jx23pw930nx1	2026-06-26 09:52:32.452	00dea56a-dc77-462b-88aa-5f55906e2887
cmqur5pwq00afjxt6ak1df1k4	cmqep6taf00m0jxp5h51gbmg2	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00f8jxp55qj3x2vc_activity2_1782467552614.jpg	image/jpeg	147054	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:52:32.618	88ac774f-456d-4d86-9b74-b0ddafb95df0
cmqur5ukg00ahjxt66lt1yi9x	cmqep6tag00nvjxp5jlwom1ah	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00ftjxp5qcd2510h_activity2_1782467558655.jpg	image/jpeg	141897	cmq0kwit80066jx23pw930nx1	2026-06-26 09:52:38.657	fccad0a1-4326-43c5-b493-514010a690e2
cmqur66cg00akjxt6jrl4tq1h	cmqep6tag00mgjxp5x2a4woek	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fejxp5o7dl7di4_activity2_1782467573918.jpg	image/jpeg	200367	cmq0kwit80066jx23pw930nx1	2026-06-26 09:52:53.92	86051216-5856-4d9c-b84d-86315081a241
cmqur6o4e008ajxu68t0da94f	cmqep6taf00lijxp5e139svam	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00f3jxp5synf5gsg_activity1_1782467596956.jpg	image/jpeg	180460	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:53:16.959	99fdf29b-a601-4eaa-946e-2e2ea6dd3bd1
cmqur738f00anjxt6rhkuyhi2	cmqep6taf00lijxp5e139svam	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00f3jxp5synf5gsg_activity1_1782467616541.jpg	image/jpeg	186141	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:53:36.543	35dbb340-68da-48c7-b556-3960bff964a9
cmqur7i12008djxu60974k4fw	cmqep6tag00mrjxp5zhqy9rpu	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fhjxp5fpnrj4l7_activity2_1782467635715.jpg	image/jpeg	178930	cmq0kwit80066jx23pw930nx1	2026-06-26 09:53:55.718	302ad252-e848-4966-97c5-0bf6bf6fd69e
cmqur7mqi008fjxu6brrvrzwu	cmqep6tag00mrjxp5zhqy9rpu	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fhjxp5fpnrj4l7_activity2_1782467641816.jpg	image/jpeg	142964	cmq0kwit80066jx23pw930nx1	2026-06-26 09:54:01.819	4b5f135a-0bf1-44a6-88bd-7bc6177ed54a
cmqur9gh5008njxu634mlknqn	cmqep6tah00onjxp58m3vccb3	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00g1jxp5xksr1is3_activity2_1782467727014.jpg	image/jpeg	172233	cmq0kwit80066jx23pw930nx1	2026-06-26 09:55:27.017	30e029a7-9b13-4313-b7d7-6b66b1819480
cmqur9kug00azjxt62bx68ffq	cmqep6tah00onjxp58m3vccb3	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00g1jxp5xksr1is3_activity2_1782467732678.jpg	image/jpeg	159546	cmq0kwit80066jx23pw930nx1	2026-06-26 09:55:32.681	23d0572f-5967-463c-aa7d-2f4d73dc71f1
cmqur9w5x00b1jxt68zodrbhg	cmqep6tah00oqjxp50jjkbmzs	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00g2jxp55u0n4faa_activity2_1782467747346.jpg	image/jpeg	153688	cmq0kwit80066jx23pw930nx1	2026-06-26 09:55:47.349	94f0acad-811a-417c-83ef-ca9af6425bba
cmqurarfo00b8jxt6wkuunu6n	cmqep6tah00okjxp5gw39fbrt	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00g0jxp5x3rr3z29_activity2_1782467787872.jpg	image/jpeg	210541	cmq0kwit80066jx23pw930nx1	2026-06-26 09:56:27.876	bc82abe2-204f-4892-bbc8-7e84893fbd40
cmqurc0xx0090jxu6haadapmq	cmqep6tag00n7jxp5vo5e30br	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fljxp5cyty19cb_activity2_1782467846850.jpg	image/jpeg	186361	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:57:26.853	06c1c714-2894-4feb-a2a6-aadb3d0f5b8d
cmqur7y4500apjxt6jbh1fspg	cmqep6tah00p4jxp5y7vlgu2v	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00g6jxp5voah6fkg_activity2_1782467656563.jpg	image/jpeg	168634	cmq0kwit80066jx23pw930nx1	2026-06-26 09:54:16.566	3cb6801a-1cec-49dd-aa87-e1ebf2ea49d9
cmqur8gs5008jjxu62pogfj7g	cmqep6tah00owjxp5hu9r2sji	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00g4jxp56txcwtrq_activity2_1782467680753.jpg	image/jpeg	197213	cmq0kwit80066jx23pw930nx1	2026-06-26 09:54:40.757	e4a2f4b7-87f8-4417-ae23-6560602074cc
cmqur947i008ljxu6llc5ac8u	cmqep6taf00ljjxp5kxia7ix5	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00f3jxp5synf5gsg_activity2_1782467711115.jpg	image/jpeg	215291	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:55:11.118	60ed65b9-e2f9-4a82-8875-c0883030a6e2
cmqura00a008ujxu6ne6cvnko	cmqep6tag00nnjxp5bcu5m5pt	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00frjxp5y0vdu581_activity2_1782467752328.jpg	image/jpeg	175507	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:55:52.33	c3ed611a-40a0-4b46-90de-d98ae81b530c
cmqur89qs00arjxt6mhs7q8g7	cmqep6tah00p4jxp5y7vlgu2v	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00g6jxp5voah6fkg_activity2_1782467671633.jpg	image/jpeg	144723	cmq0kwit80066jx23pw930nx1	2026-06-26 09:54:31.637	87cb1ba8-da29-4cfc-b39a-174337d26b1f
cmqur8sgo00aujxt6sz3gcfka	cmqep6tah00owjxp5hu9r2sji	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00g4jxp56txcwtrq_activity2_1782467695893.jpg	image/jpeg	162119	cmq0kwit80066jx23pw930nx1	2026-06-26 09:54:55.896	9ce761ae-0dc7-4196-b217-3ffcad8c1450
cmqura5ib00b3jxt6kgw2vk19	cmqep6tag00nnjxp5bcu5m5pt	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00frjxp5y0vdu581_activity2_1782467759457.jpg	image/jpeg	155678	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:55:59.459	edba99ae-cb91-424c-9c52-83b70e7e2d63
cmqurb3ii00bajxt6x6nbaoqk	cmqep6tah00okjxp5gw39fbrt	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00g0jxp5x3rr3z29_activity2_1782467803527.jpg	image/jpeg	183223	cmq0kwit80066jx23pw930nx1	2026-06-26 09:56:43.53	f1406d35-1280-4b4b-870c-5b2d5819dcc1
cmqurb93d00bcjxt6iy4td98d	cmqep6tag00n7jxp5vo5e30br	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fljxp5cyty19cb_activity2_1782467810759.jpg	image/jpeg	229885	cmq0kyw85007kjx239k25z1ge	2026-06-26 09:56:50.761	b4226ce8-a62d-4706-b64e-9a85301c3051
cmqur9ec700axjxt6kvsor04a	cmqep6taf00ljjxp5kxia7ix5	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00f3jxp5synf5gsg_activity2_1782467724243.jpg	image/jpeg	201178	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:55:24.247	87d87812-9225-4bc3-a9a8-cf0b702b168e
cmqur9qok008qjxu6n1cg86hp	cmqep6tah00oqjxp50jjkbmzs	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00g2jxp55u0n4faa_activity2_1782467740242.jpg	image/jpeg	190577	cmq0kwit80066jx23pw930nx1	2026-06-26 09:55:40.244	316fb411-79df-4699-a3c6-afd836c48cc5
cmquracvj00b5jxt6lwn4ew2k	cmqep6tah00otjxp5nwykt18t	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00g3jxp5y3q080vj_activity2_1782467769004.jpg	image/jpeg	195859	cmq0kwit80066jx23pw930nx1	2026-06-26 09:56:09.007	cd0b71d7-46ed-4774-b197-e60d202b849a
cmquraj0t008xjxu603u63sml	cmqep6tah00otjxp5nwykt18t	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00g3jxp5y3q080vj_activity2_1782467776969.jpg	image/jpeg	212043	cmq0kwit80066jx23pw930nx1	2026-06-26 09:56:16.973	49ebd706-1a94-4d02-8486-1fef7b7a6e81
cmqurbopf00bfjxt66dj3dwf8	cmqep6tag00nyjxp50u57ywab	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fujxp5lzrwcrc9_activity2_1782467830993.jpg	image/jpeg	208046	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:57:10.995	f5fa3f1d-bd78-4ea4-9c06-7aa732ff0c64
cmqurc2zs0092jxu6n9mv19u9	cmqep6tag00nyjxp50u57ywab	2	image.jpg	/api/uploads/worksheets/cmqep6t7x00fujxp5lzrwcrc9_activity2_1782467849496.jpg	image/jpeg	156941	cmq0khs5m000wjx23jyhqhgkv	2026-06-26 09:57:29.512	ffffe9f9-eba4-47cb-95d9-e122bfcdf090
cmr4qamye0114jxctd5pr71hk	cmqep6tak00tbjxp5pr69czif	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00hijxp5mgitskzp_activity5_1783070764210.jpg	image/jpeg	217270	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:26:04.215	1620e0c9-49fa-4fa4-91d2-1b4d961b6bd2
cmr4qb4kz002cjxcddalmult9	cmqep6tai00pwjxp5375oozbj	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gfjxp567zr1gct_activity5_1783070787056.jpg	image/jpeg	211032	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:26:27.059	6f69d4e2-b2ea-4353-b578-a751ce9a4c7c
cmr4qbew50117jxctj95aaf53	cmqep6taj00s9jxp5bnhzmr9q	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00h5jxp53x65440u_activity5_1783070800416.jpg	image/jpeg	178567	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:26:40.421	78d56dcf-a9c6-493b-ab5e-385d097b0509
cmr4qbsf1002fjxcdhbymezqa	cmqep6tah00phjxp5cv6jvy22	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gajxp56csicf0x_activity5_1783070817945.jpg	image/jpeg	182800	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:26:57.949	8412c080-ae77-4ae2-b142-2a9868545386
cmr4qccio002hjxcdksvnm22k	cmqep6taj00rzjxp5ityje44g	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00h2jxp5gb0okmzi_activity5_1783070843997.jpg	image/jpeg	202811	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:27:24	c5474476-83fd-4c70-8b23-de38f5118694
cmr4qcmzt002jjxcdassfehf4	cmqep6tai00r8jxp5dec6e0np	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gtjxp5zntc9qfk_activity5_1783070857574.jpg	image/jpeg	210082	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:27:37.578	8a6555cd-1f2e-4abd-b7ad-d719aac0b4f6
cmr4qcq1u011ajxctuu3q7q66	cmqep6tai00r1jxp5yhr1zfi5	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00grjxp5xaus94pp_activity5_1783070861534.jpg	image/jpeg	203860	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:27:41.538	6e47caf6-3982-4517-8ac2-e3eb6a63298a
cmr4qd8j9011djxctb0qgmiaq	cmqep6taj00sujxp5r6d0ibx1	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00hcjxp5o0okg8br_activity5_1783070885485.jpg	image/jpeg	209494	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:28:05.493	def7f51a-32f7-4f3c-8164-80f8436c5d2c
cmr4qdy34002mjxcd6ff5xx71	cmqep6taj00t1jxp5905k7z9f	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00hejxp5jx21o02o_activity5_1783070918605.jpg	image/jpeg	202578	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:28:38.609	b2469ddc-b948-492a-8a8b-1bde1f7bbf9c
cmr4qe62d011gjxctkvnmiwzs	cmqep6tak00thjxp578p80x21	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00hkjxp50bymz2pu_activity5_1783070928945.jpg	image/jpeg	206425	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:28:48.949	28fc0198-3356-44be-8d8a-25928e279a6c
cmr4qemjx002qjxcd13t18zg4	cmqep6tah00p8jxp5pcqv2mzs	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00g7jxp5dadbmh4c_activity5_1783070950314.jpg	image/jpeg	191259	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:29:10.317	b467b1cb-3c1c-4b89-8d50-e0086981f932
cmr4qet3f011ijxct3dvvcv5k	cmqep6tah00pejxp5jzau997h	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00g9jxp5yihqococ_activity5_1783070958793.jpg	image/jpeg	189084	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:29:18.795	3da97154-b220-4f4d-b013-8b1171fb501b
cmr4qf366002tjxcdfau0ebby	cmqep6taj00s6jxp50sckpr5x	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00h4jxp5jet4udax_activity5_1783070971852.jpg	image/jpeg	214759	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:29:31.855	649c0221-6054-4f64-91e5-73b4a7815ca6
cmr4qf3e4011kjxct1wkauk9h	cmqep6taj00rjjxp5gs75w40x	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gyjxp50orak3f8_activity5_1783070972137.jpg	image/jpeg	192820	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:29:32.14	625034f6-b60b-40b9-a30d-86e7edabb6cb
cmr4qge5q011njxct0itce4ic	cmqep6tak00tejxp5vnccqcrj	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00hjjxp5xa6i02q3_activity5_1783071032746.jpg	image/jpeg	211380	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:30:32.75	a87365a0-6032-4243-9d61-afcba527b102
cmr4qgi8w002wjxcdoeqzua9u	cmqep6taj00rrjxp5x1c7gucn	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00h0jxp5b6k9d2ql_activity5_1783071038045.jpg	image/jpeg	214484	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:30:38.048	1bf41b8e-2821-48c6-9cf5-cfb7465e40b3
cmr4qhfi30032jxcd5ut3dp9d	cmqep6tai00rbjxp5e4y0iv2n	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gvjxp59jqt3gqm_activity5_1783071081143.jpg	image/jpeg	220791	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:31:21.147	2b5db65b-4321-4a7d-9840-9f7f7245c968
cmr4qhqlv0034jxcdmcs7g44m	cmqep6tah00pbjxp5kd3b100j	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00g8jxp5e5io1j25_activity5_1783071095531.jpg	image/jpeg	193465	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:31:35.539	e3c475af-e1ed-4a5b-b995-ae80653eea00
cmr4qhw1u011sjxctm43474gz	cmqep6taj00scjxp5b9obj5gb	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00h6jxp5lq2ohp8z_activity5_1783071102591.jpg	image/jpeg	202622	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:31:42.595	9f296fe9-4b6f-40bd-8cdc-226cdf3d53b9
cmr4qiiry0037jxcd8p30bqol	cmqep6tai00q2jxp5cetek9dm	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00ghjxp58tgg12zq_activity5_1783071132043.jpg	image/jpeg	179563	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:32:12.046	259b1000-cebe-4ddd-8f60-317fed763cdc
cmr4qisvm011vjxctecgmcdbj	cmqep6taj00sfjxp5wz9pc3x8	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00h7jxp5aomv3xif_activity5_1783071145136.jpg	image/jpeg	202447	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:32:25.138	04c83f34-b5ed-46e8-8b9f-c1d15175532d
cmr4qjg5b011yjxct3ws7w3tu	cmqep6tah00pnjxp5v8fgelut	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gcjxp545zm4dej_activity5_1783071175293.jpg	image/jpeg	196635	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:32:55.296	c9864593-9b3b-41e7-ba5f-9eea67ed596a
cmr4qklok003ajxcd5dmozcz0	cmqep6tak00t4jxp54u256vum	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00hgjxp51uc3pwty_activity5_1783071229121.jpg	image/jpeg	191141	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:33:49.124	adcacb01-d7d1-47bd-b84f-34c809b8e301
cmr4ql3j00121jxct5o891vzy	cmqep6tai00pqjxp5iwbppnif	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gdjxp59lrmb5t2_activity5_1783071252250.jpg	image/jpeg	206332	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:34:12.253	34aa162a-623b-48e4-a8a8-1f17cf7fc941
cmr4qlpnc003ejxcdx546jwjn	cmqep6taf00lkjxp54s8m5lpa	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00f3jxp5synf5gsg_activity5_1783071280918.jpg	image/jpeg	215986	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:34:40.921	2837fce9-9e7f-47b0-96cd-961022294938
cmr4qm9l50124jxctj49stdrq	cmqep6tah00pkjxp5hh1kmg4e	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gbjxp5vsmxgz5z_activity5_1783071306758.jpg	image/jpeg	197132	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:35:06.762	73865276-cae0-4ff9-a740-53f51cd99786
cmr4qmcyk0126jxctiej9f7i5	cmqep6tai00qyjxp5hcnc89ts	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gqjxp5i3yv7iln_activity5_1783071311130.jpg	image/jpeg	173068	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:35:11.133	a452db5e-41cf-4545-a992-756c74cf579d
cmr4qn02s003hjxcdr6y0mqn6	cmqep6taf00m7jxp5c4hqpylg	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fbjxp5c1fz5ppe_activity5_1783071341088.jpg	image/jpeg	217429	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:35:41.092	ffa45dcd-2eb6-4019-b5c8-f7751f53e062
cmr4qn17f003jjxcdga7c876w	cmqep6tae00knjxp55547qqfn	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00etjxp5oklc37y3_activity5_1783071342553.jpg	image/jpeg	200090	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:35:42.556	887b02c5-8d08-47bf-9dff-742a30abe269
cmr4qoxoj003ujxcdusex16cm	cmqep6tae00lcjxp5ec3jc2zw	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00f1jxp5twcea6w7_activity5_1783071431296.jpg	image/jpeg	216423	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:37:11.299	3bffbe4b-6f4b-455b-9a2a-20c279044df7
cmr4qrtj90040jxcd5z5i6qev	cmqep6tag00nwjxp5gegzdelr	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00ftjxp5qcd2510h_activity5_1783071565889.jpg	image/jpeg	171352	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:39:25.893	717d96f0-e88f-426d-9ded-04fc13d89bc7
cmr4qto33004bjxcd8tal0y14	cmqep6tah00oujxp5of76dk71	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00g3jxp5y3q080vj_activity5_1783071652141.jpg	image/jpeg	197237	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:40:52.144	1eaba309-e4ee-4492-9e17-5f4d64b90af6
cmr4qnr3r003ljxcdng7rtnbv	cmqep6tai00ptjxp5ynbr7fhg	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gejxp5hwiyumv6_activity5_1783071376117.jpg	image/jpeg	183442	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:36:16.119	1eb96b67-4566-496b-8bf8-e158607bb815
cmr4qnt6z003njxcd9kca64kl	cmqep6taf00lrjxp5a1zzam9g	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00f5jxp5kn6gv1ni_activity5_1783071378824.jpg	image/jpeg	209741	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:36:18.827	4871d77b-21e5-40c4-97ec-d58a36384743
cmr4qvt6r004ljxcd02lnwwcg	cmqep6tah00oojxp5tziu8leu	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00g1jxp5xksr1is3_activity5_1783071752064.jpg	image/jpeg	190626	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:42:32.067	7de39945-40c4-4761-950a-52bbfc76d33f
cmr4qo0s5003pjxcd28rje7uu	cmqep6taf00majxp5xypczcw6	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fcjxp5slrtarvk_activity5_1783071388645.jpg	image/jpeg	203359	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:36:28.66	8f493e0d-7149-4f40-af0b-55d4dea169ad
cmr4qsb5i012fjxctapuahbn1	cmqep6tae00l0jxp597apocg0	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00exjxp5g48uiw9v_activity5_1783071588723.jpg	image/jpeg	236921	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:39:48.727	e90a58fd-c949-48b7-b519-5c21f2e984cc
cmr4qso3f012jjxcti5kkl5qj	cmqep6tag00nojxp54qeklzd4	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00frjxp5y0vdu581_activity5_1783071605489.jpg	image/jpeg	200512	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:40:05.499	00c30ff2-3e50-475f-8e27-ff9c15707f0f
cmr4qsuy30042jxcdm6cciwvh	cmqep6tae00l3jxp59jwixvk8	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00eyjxp55zwq78jl_activity5_1783071614375.jpg	image/jpeg	206894	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:40:14.379	790db18a-d605-4577-b8d0-656336687102
cmr4qti6o0047jxcdy5hhn37f	cmqep6tae00kkjxp5vegcivof	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00esjxp5cbdmqqex_activity5_1783071644493.jpg	image/jpeg	187898	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:40:44.496	221495b0-2abd-427c-9de2-24525287d7b6
cmr4qtn0k0049jxcdmqfzay17	cmqep6tae00ktjxp54hnktjq0	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00evjxp5vhoesa20_activity5_1783071650753.jpg	image/jpeg	213765	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:40:50.756	64e3b323-01f1-4823-a1ff-ea2dfc868162
cmr4qujf4004hjxcdzir2hljv	cmqep6tah00oljxp5r8itap6y	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00g0jxp5x3rr3z29_activity5_1783071692749.jpg	image/jpeg	195567	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:41:32.753	ca30b306-675b-434a-8df5-7842ca5a7461
cmr4qwgzn012ojxctrlypqrat	cmqep6tah00orjxp5efmibx3o	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00g2jxp55u0n4faa_activity5_1783071782912.jpg	image/jpeg	183541	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:43:02.915	ba3ef59b-7111-4fc2-9721-551cf82d38fe
cmr4qowln003sjxcd3pqlc1v5	cmqep6tae00kqjxp5brhrwadq	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00eujxp5wceys9yo_activity5_1783071429896.jpg	image/jpeg	209453	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:37:09.899	9e12d7e6-e817-4163-a529-df7b506587b5
cmr4qqnwb012bjxctye5f1mfs	cmqep6taf00lyjxp5a8sswzzg	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00f7jxp5l3oii2qb_activity5_1783071511927.jpg	image/jpeg	207654	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:38:31.931	c7146529-c4c2-4fef-96b4-37e1504afbef
cmr4qrevq003xjxcdrsigpx63	cmqep6tae00l9jxp59m4p4m2r	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00f0jxp5gvfwi04n_activity5_1783071546899.jpg	image/jpeg	225390	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:39:06.903	58e41ec9-4b74-4790-8ad3-efe215244d51
cmr4qrm3m012djxctktjrnmvp	cmqep6taf00m1jxp50bmzdv1r	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00f8jxp55qj3x2vc_activity5_1783071556240.jpg	image/jpeg	210468	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:39:16.259	13287d26-6957-4974-be63-ebc42926191b
cmr4qufs2004fjxcdxw34ltnj	cmqep6tah00p5jxp5qfx8zw2o	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00g6jxp5voah6fkg_activity5_1783071688031.jpg	image/jpeg	192721	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:41:28.034	a7ba3b7a-afa8-467e-9b49-ccb3cb361f3a
cmr4qwwmo012qjxctqfiz0fhv	cmqep6tah00oxjxp527wpufzq	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00g4jxp56txcwtrq_activity5_1783071803181.jpg	image/jpeg	206960	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:43:23.184	1a6a96f8-9be7-44a1-8d4f-3dfc261f89e5
cmr4qy5zi012sjxctg6glvvzh	cmqep6tah00nzjxp58hfzih0t	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fujxp5lzrwcrc9_activity5_1783071861963.jpg	image/jpeg	196979	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:44:21.967	29792b06-44f2-4825-89df-21624937a604
cmr4qyl6w004pjxcdqh8gd9on	cmqep6tag00n8jxp5di8qwinb	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fljxp5cyty19cb_activity5_1783071881669.jpg	image/jpeg	196964	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:44:41.672	aed9d021-28e4-4e29-9d3d-a41e4b8a20c6
cmr4qzxj5012ujxct1lo91sf1	cmqep6tag00mhjxp5xc1b8b4b	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fejxp5o7dl7di4_activity5_1783071944319.jpg	image/jpeg	197577	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:45:44.322	23c84150-1124-4753-ad2b-e19941758b94
cmr4r05m6004tjxcdupa81sba	cmqep6tag00msjxp5octar0qh	1	image.jpg	/api/uploads/worksheets/cmqep6t7x00fhjxp5fpnrj4l7_activity5_1783071954794.jpg	image/jpeg	185936	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:45:54.798	c983a90c-0d93-4120-86eb-2a52a4cdbbb4
cmr4r2t2k004wjxcdsrplqauf	cmqep6tai00qqjxp58ovfu1kj	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gojxp5v1t19fiv_activity3_1783072078505.jpg	image/jpeg	221502	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:47:58.508	9db20f5f-2acd-4f51-9c23-64b89bafe7cc
cmr4r3di9004yjxcdzwao34yv	cmqep6tai00qqjxp58ovfu1kj	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gojxp5v1t19fiv_activity3_1783072104991.jpg	image/jpeg	205213	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:48:24.994	ed7f351d-8ddf-49a2-a7ab-887e98842627
cmr4r42ll0051jxcdsl4f63lc	cmqep6tai00rejxp5iliqozw7	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gwjxp50vs32gfn_activity3_1783072137511.jpg	image/jpeg	180965	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:48:57.514	2059bdf3-b250-49cb-95f4-a241eaadbcf9
cmr4r467y0053jxcd2n0tt9z7	cmqep6tak00t7jxp5c79eljfj	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00hhjxp595rvk6sq_activity3_1783072142199.jpg	image/jpeg	157374	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:49:02.207	8f9a3b1e-262a-4ef1-92cc-a7d43ef9ec93
cmr4r4wjg0134jxctnsfxxzco	cmqep6tai00rejxp5iliqozw7	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gwjxp50vs32gfn_activity3_1783072176313.jpg	image/jpeg	200181	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:49:36.317	85096a51-6d09-4373-b0c7-52f20948be7f
cmr4r5dz40055jxcdoyjuf845	cmqep6tak00t7jxp5c79eljfj	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00hhjxp595rvk6sq_activity3_1783072198909.jpg	image/jpeg	167475	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:49:58.913	258bce99-1e86-4324-87ff-6396268b0021
cmr4r5r9t0057jxcdexh1aycz	cmqf02tx9006fjxopodj5wt87	1	image.jpg	/api/uploads/worksheets/cmqf02twi005vjxoph6si1y7m_activity3_1783072216143.jpg	image/jpeg	255501	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:50:16.146	a99ac0ca-bf48-4ba9-bdce-bcf44a06ae7f
cmr4r61cp0059jxcdubo4do5y	cmqf02tx9006fjxopodj5wt87	2	image.jpg	/api/uploads/worksheets/cmqf02twi005vjxoph6si1y7m_activity3_1783072229207.jpg	image/jpeg	242506	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:50:29.209	ee6a9a5c-b208-4171-b34f-0f68e28cdcb0
cmr4r76vb0136jxctww5u3ksj	cmqep6taj00rmjxp5vkofbybn	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gzjxp5ymu2sdwq_activity3_1783072283012.jpg	image/jpeg	175384	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:51:23.015	89855cd1-90ff-4ab5-b339-686cccbaf9d6
cmr4r7axv0138jxct0phf7zvq	cmqf02txa006jjxop2t5johuq	1	image.jpg	/api/uploads/worksheets/cmqf02twi005wjxop1suc7kpd_activity3_1783072288290.jpg	image/jpeg	211299	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:51:28.292	a5dd014d-cccf-4bb7-a860-12df62ebec9d
cmr4r7knb005cjxcd10vt0rme	cmqep6taj00sxjxp5ko4xmkbz	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00hdjxp51yn11mxr_activity3_1783072300868.jpg	image/jpeg	145581	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:51:40.871	6f9ace68-099a-4bd3-af1c-250d281ed414
cmr4r7suc005ejxcdspt237ts	cmqep6taj00rmjxp5vkofbybn	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gzjxp5ymu2sdwq_activity3_1783072311489.jpg	image/jpeg	173805	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:51:51.492	0b7e7ba6-330e-4b18-8776-df070448b84d
cmr4r87xk013ajxctx6rbobzz	cmqep6taj00sxjxp5ko4xmkbz	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00hdjxp51yn11mxr_activity3_1783072331046.jpg	image/jpeg	168395	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:52:11.049	d986838d-8c39-42e7-8d4a-adc8a2b6e518
cmr4r8a4e013cjxct1a7c5nku	cmqf02txa006jjxop2t5johuq	2	image.jpg	/api/uploads/worksheets/cmqf02twi005wjxop1suc7kpd_activity3_1783072333884.jpg	image/jpeg	208057	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:52:13.887	5e1523d9-b6d9-4820-8e63-1650e37a1e8d
cmr4ra5ts005hjxcd7avd3mtp	cmqep6taj00sijxp5cpdan6yd	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00h9jxp5ov6rpkzw_activity3_1783072421630.jpg	image/jpeg	161206	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:53:41.632	dd4652e7-19b6-4078-907b-6adea34392de
cmr4raxpm005jjxcdkm49zi1p	cmqep6taj00sijxp5cpdan6yd	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00h9jxp5ov6rpkzw_activity3_1783072457767.jpg	image/jpeg	167476	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:54:17.77	611866d8-7f4b-49af-b101-cbbb0fbc6f6c
cmr4rbsv4013gjxctf30kaelh	cmqep6tai00qhjxp5imuvvhe8	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gmjxp5w0cyfz8a_activity3_1783072498141.jpg	image/jpeg	180942	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:54:58.144	941df526-50c0-4f45-a324-d22f57836cb3
cmr4rc950013ijxctnwev4wgq	cmqep6tai00qhjxp5imuvvhe8	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gmjxp5w0cyfz8a_activity3_1783072519233.jpg	image/jpeg	217360	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:55:19.236	1f378f80-3c3e-4b1b-b06c-25fa7cbb487d
cmr4rca0i005mjxcd5rmgkz55	cmqep6taj00sqjxp5609dzmb2	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00hbjxp5na2uvdzn_activity3_1783072520368.jpg	image/jpeg	159564	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:55:20.371	060b78d8-0ff1-4264-a504-47446e4aea9a
cmr4rcqvr005ojxcdf3mmzui8	cmqep6taj00sqjxp5609dzmb2	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00hbjxp5na2uvdzn_activity3_1783072542229.jpg	image/jpeg	158114	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:55:42.232	2a90ae70-59fb-43f8-92ab-de4e4ccab82c
cmr4rd2k5005qjxcdy7h7veq2	cmqep6taj00rujxp501ikz7ac	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00h1jxp5kcbzvnst_activity3_1783072557362.jpg	image/jpeg	175116	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:55:57.365	fcb2adaf-f10b-4802-bbc1-3309df1ab40e
cmr4rdnxa013ljxctotx28dcw	cmqep6taj00rujxp501ikz7ac	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00h1jxp5kcbzvnst_activity3_1783072585050.jpg	image/jpeg	174828	cmq0kyw85007kjx239k25z1ge	2026-07-03 09:56:25.054	8d41ae48-0359-4c01-952f-fe078699c3a5
cmr4rh3o8005ujxcdqx6ziyc9	cmqep6tai00qljxp5ut870xat	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gnjxp50tru9y0t_activity3_1783072745429.jpg	image/jpeg	179214	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:59:05.432	cfff1c54-455b-495d-a2da-be38b6d0a57d
cmr4rhpz3013njxctd2awb6of	cmqep6tai00qljxp5ut870xat	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gnjxp50tru9y0t_activity3_1783072774332.jpg	image/jpeg	218514	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 09:59:34.335	306278bd-a42f-443a-96c1-a36c7f4067bd
cmr4rjx5v005xjxcduss867ks	cmqep6tai00q5jxp52u66o161	1	image.jpg	/api/uploads/worksheets/cmqep6t7y00gjjxp59b9xkcrz_activity3_1783072876961.jpg	image/jpeg	176092	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 10:01:16.963	4ced85e9-e835-4de9-9ffa-632cc507a170
cmr4rk72f013pjxctwxrqkp1m	cmqep6tai00q5jxp52u66o161	2	image.jpg	/api/uploads/worksheets/cmqep6t7y00gjjxp59b9xkcrz_activity3_1783072889796.jpg	image/jpeg	220699	cmq0khs5m000wjx23jyhqhgkv	2026-07-03 10:01:29.799	d834fcdf-17c3-4308-9eea-6e1ea468e409
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: academic_years academic_years_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.academic_years
    ADD CONSTRAINT academic_years_pkey PRIMARY KEY (id);


--
-- Name: activity_progress activity_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_progress
    ADD CONSTRAINT activity_progress_pkey PRIMARY KEY (id);


--
-- Name: counseling_sessions counseling_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.counseling_sessions
    ADD CONSTRAINT counseling_sessions_pkey PRIMARY KEY (id);


--
-- Name: home_visit_photos home_visit_photos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.home_visit_photos
    ADD CONSTRAINT home_visit_photos_pkey PRIMARY KEY (id);


--
-- Name: home_visits home_visits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.home_visits
    ADD CONSTRAINT home_visits_pkey PRIMARY KEY (id);


--
-- Name: password_reset_token password_reset_token_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_token
    ADD CONSTRAINT password_reset_token_email_key UNIQUE (email);


--
-- Name: password_reset_token password_reset_token_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.password_reset_token
    ADD CONSTRAINT password_reset_token_pkey PRIMARY KEY (id);


--
-- Name: phq_results phq_results_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phq_results
    ADD CONSTRAINT phq_results_pkey PRIMARY KEY (id);


--
-- Name: school_admin_invites school_admin_invites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_admin_invites
    ADD CONSTRAINT school_admin_invites_pkey PRIMARY KEY (id);


--
-- Name: school_class_terms school_class_terms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_class_terms
    ADD CONSTRAINT school_class_terms_pkey PRIMARY KEY (id);


--
-- Name: school_classes school_classes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_classes
    ADD CONSTRAINT school_classes_pkey PRIMARY KEY (id);


--
-- Name: school_teacher_roster school_teacher_roster_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_teacher_roster
    ADD CONSTRAINT school_teacher_roster_pkey PRIMARY KEY (id);


--
-- Name: schools schools_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schools
    ADD CONSTRAINT schools_pkey PRIMARY KEY (id);


--
-- Name: student_referrals student_referrals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_referrals
    ADD CONSTRAINT student_referrals_pkey PRIMARY KEY (id);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (id);


--
-- Name: system_admin_whitelist system_admin_whitelist_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_admin_whitelist
    ADD CONSTRAINT system_admin_whitelist_pkey PRIMARY KEY (id);


--
-- Name: teacher_invites teacher_invites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teacher_invites
    ADD CONSTRAINT teacher_invites_pkey PRIMARY KEY (id);


--
-- Name: teachers teachers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teachers
    ADD CONSTRAINT teachers_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: worksheet_uploads worksheet_uploads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.worksheet_uploads
    ADD CONSTRAINT worksheet_uploads_pkey PRIMARY KEY (id);


--
-- Name: academic_years_year_semester_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX academic_years_year_semester_key ON public.academic_years USING btree (year, semester);


--
-- Name: activity_progress_phqResultId_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "activity_progress_phqResultId_status_idx" ON public.activity_progress USING btree ("phqResultId", status);


--
-- Name: activity_progress_studentId_phqResultId_activityNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "activity_progress_studentId_phqResultId_activityNumber_key" ON public.activity_progress USING btree ("studentId", "phqResultId", "activityNumber");


--
-- Name: counseling_sessions_academicYearId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "counseling_sessions_academicYearId_idx" ON public.counseling_sessions USING btree ("academicYearId");


--
-- Name: counseling_sessions_studentId_sessionNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "counseling_sessions_studentId_sessionNumber_key" ON public.counseling_sessions USING btree ("studentId", "sessionNumber");


--
-- Name: home_visit_photos_idempotencyKey_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "home_visit_photos_idempotencyKey_key" ON public.home_visit_photos USING btree ("idempotencyKey");


--
-- Name: home_visits_academicYearId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "home_visits_academicYearId_idx" ON public.home_visits USING btree ("academicYearId");


--
-- Name: home_visits_studentId_visitNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "home_visits_studentId_visitNumber_key" ON public.home_visits USING btree ("studentId", "visitNumber");


--
-- Name: password_reset_token_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX password_reset_token_email_idx ON public.password_reset_token USING btree (email);


--
-- Name: password_reset_token_token_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX password_reset_token_token_idx ON public.password_reset_token USING btree (token);


--
-- Name: password_reset_token_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX password_reset_token_token_key ON public.password_reset_token USING btree (token);


--
-- Name: phq_results_academicYearId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "phq_results_academicYearId_createdAt_idx" ON public.phq_results USING btree ("academicYearId", "createdAt" DESC);


--
-- Name: phq_results_academicYearId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "phq_results_academicYearId_idx" ON public.phq_results USING btree ("academicYearId");


--
-- Name: phq_results_studentId_academicYearId_assessmentRound_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "phq_results_studentId_academicYearId_assessmentRound_idx" ON public.phq_results USING btree ("studentId", "academicYearId", "assessmentRound");


--
-- Name: phq_results_studentId_academicYearId_assessmentRound_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "phq_results_studentId_academicYearId_assessmentRound_key" ON public.phq_results USING btree ("studentId", "academicYearId", "assessmentRound");


--
-- Name: phq_results_studentId_academicYearId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "phq_results_studentId_academicYearId_createdAt_idx" ON public.phq_results USING btree ("studentId", "academicYearId", "createdAt" DESC);


--
-- Name: phq_results_studentId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "phq_results_studentId_createdAt_idx" ON public.phq_results USING btree ("studentId", "createdAt" DESC);


--
-- Name: phq_results_studentId_createdAt_riskLevel_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "phq_results_studentId_createdAt_riskLevel_idx" ON public.phq_results USING btree ("studentId", "createdAt" DESC, "riskLevel");


--
-- Name: school_admin_invites_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX school_admin_invites_email_key ON public.school_admin_invites USING btree (email);


--
-- Name: school_admin_invites_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX school_admin_invites_token_key ON public.school_admin_invites USING btree (token);


--
-- Name: school_class_terms_academicYearId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "school_class_terms_academicYearId_idx" ON public.school_class_terms USING btree ("academicYearId");


--
-- Name: school_class_terms_schoolClassId_academicYearId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "school_class_terms_schoolClassId_academicYearId_key" ON public.school_class_terms USING btree ("schoolClassId", "academicYearId");


--
-- Name: school_classes_schoolId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "school_classes_schoolId_idx" ON public.school_classes USING btree ("schoolId");


--
-- Name: school_classes_schoolId_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "school_classes_schoolId_name_key" ON public.school_classes USING btree ("schoolId", name);


--
-- Name: school_teacher_roster_schoolId_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "school_teacher_roster_schoolId_email_key" ON public.school_teacher_roster USING btree ("schoolId", email);


--
-- Name: school_teacher_roster_schoolId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "school_teacher_roster_schoolId_idx" ON public.school_teacher_roster USING btree ("schoolId");


--
-- Name: student_referrals_fromTeacherUserId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "student_referrals_fromTeacherUserId_idx" ON public.student_referrals USING btree ("fromTeacherUserId");


--
-- Name: student_referrals_studentId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "student_referrals_studentId_key" ON public.student_referrals USING btree ("studentId");


--
-- Name: student_referrals_toTeacherUserId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "student_referrals_toTeacherUserId_idx" ON public.student_referrals USING btree ("toTeacherUserId");


--
-- Name: students_firstName_lastName_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "students_firstName_lastName_idx" ON public.students USING btree ("firstName", "lastName");


--
-- Name: students_nationalId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "students_nationalId_key" ON public.students USING btree ("nationalId");


--
-- Name: students_schoolId_class_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "students_schoolId_class_idx" ON public.students USING btree ("schoolId", class);


--
-- Name: students_studentId_schoolId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "students_studentId_schoolId_key" ON public.students USING btree ("studentId", "schoolId");


--
-- Name: system_admin_whitelist_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX system_admin_whitelist_email_key ON public.system_admin_whitelist USING btree (email);


--
-- Name: teacher_invites_pending_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX teacher_invites_pending_email_key ON public.teacher_invites USING btree (email) WHERE ("acceptedAt" IS NULL);


--
-- Name: teacher_invites_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX teacher_invites_token_key ON public.teacher_invites USING btree (token);


--
-- Name: teachers_userId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "teachers_userId_key" ON public.teachers USING btree ("userId");


--
-- Name: user_sessions_expiresAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "user_sessions_expiresAt_idx" ON public.user_sessions USING btree ("expiresAt");


--
-- Name: user_sessions_revokedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "user_sessions_revokedAt_idx" ON public.user_sessions USING btree ("revokedAt");


--
-- Name: user_sessions_sessionTokenHash_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "user_sessions_sessionTokenHash_key" ON public.user_sessions USING btree ("sessionTokenHash");


--
-- Name: user_sessions_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "user_sessions_userId_idx" ON public.user_sessions USING btree ("userId");


--
-- Name: users_deletedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "users_deletedAt_idx" ON public.users USING btree ("deletedAt");


--
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_email_idx ON public.users USING btree (email);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: worksheet_uploads_activityProgressId_worksheetNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "worksheet_uploads_activityProgressId_worksheetNumber_key" ON public.worksheet_uploads USING btree ("activityProgressId", "worksheetNumber");


--
-- Name: worksheet_uploads_idempotencyKey_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "worksheet_uploads_idempotencyKey_key" ON public.worksheet_uploads USING btree ("idempotencyKey");


--
-- Name: activity_progress activity_progress_phqResultId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_progress
    ADD CONSTRAINT "activity_progress_phqResultId_fkey" FOREIGN KEY ("phqResultId") REFERENCES public.phq_results(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: activity_progress activity_progress_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_progress
    ADD CONSTRAINT "activity_progress_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public.students(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: activity_progress activity_progress_teacherId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_progress
    ADD CONSTRAINT "activity_progress_teacherId_fkey" FOREIGN KEY ("teacherId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: counseling_sessions counseling_sessions_academicYearId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.counseling_sessions
    ADD CONSTRAINT "counseling_sessions_academicYearId_fkey" FOREIGN KEY ("academicYearId") REFERENCES public.academic_years(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: counseling_sessions counseling_sessions_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.counseling_sessions
    ADD CONSTRAINT "counseling_sessions_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: counseling_sessions counseling_sessions_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.counseling_sessions
    ADD CONSTRAINT "counseling_sessions_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public.students(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: home_visit_photos home_visit_photos_homeVisitId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.home_visit_photos
    ADD CONSTRAINT "home_visit_photos_homeVisitId_fkey" FOREIGN KEY ("homeVisitId") REFERENCES public.home_visits(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: home_visits home_visits_academicYearId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.home_visits
    ADD CONSTRAINT "home_visits_academicYearId_fkey" FOREIGN KEY ("academicYearId") REFERENCES public.academic_years(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: home_visits home_visits_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.home_visits
    ADD CONSTRAINT "home_visits_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: home_visits home_visits_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.home_visits
    ADD CONSTRAINT "home_visits_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public.students(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: phq_results phq_results_academicYearId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phq_results
    ADD CONSTRAINT "phq_results_academicYearId_fkey" FOREIGN KEY ("academicYearId") REFERENCES public.academic_years(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: phq_results phq_results_importedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phq_results
    ADD CONSTRAINT "phq_results_importedById_fkey" FOREIGN KEY ("importedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: phq_results phq_results_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phq_results
    ADD CONSTRAINT "phq_results_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public.students(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: school_admin_invites school_admin_invites_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_admin_invites
    ADD CONSTRAINT "school_admin_invites_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: school_class_terms school_class_terms_academicYearId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_class_terms
    ADD CONSTRAINT "school_class_terms_academicYearId_fkey" FOREIGN KEY ("academicYearId") REFERENCES public.academic_years(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: school_class_terms school_class_terms_schoolClassId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_class_terms
    ADD CONSTRAINT "school_class_terms_schoolClassId_fkey" FOREIGN KEY ("schoolClassId") REFERENCES public.school_classes(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: school_classes school_classes_schoolId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_classes
    ADD CONSTRAINT "school_classes_schoolId_fkey" FOREIGN KEY ("schoolId") REFERENCES public.schools(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: school_teacher_roster school_teacher_roster_schoolId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.school_teacher_roster
    ADD CONSTRAINT "school_teacher_roster_schoolId_fkey" FOREIGN KEY ("schoolId") REFERENCES public.schools(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: student_referrals student_referrals_fromTeacherUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_referrals
    ADD CONSTRAINT "student_referrals_fromTeacherUserId_fkey" FOREIGN KEY ("fromTeacherUserId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: student_referrals student_referrals_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_referrals
    ADD CONSTRAINT "student_referrals_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public.students(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: student_referrals student_referrals_toTeacherUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.student_referrals
    ADD CONSTRAINT "student_referrals_toTeacherUserId_fkey" FOREIGN KEY ("toTeacherUserId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: students students_schoolId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.students
    ADD CONSTRAINT "students_schoolId_fkey" FOREIGN KEY ("schoolId") REFERENCES public.schools(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: teacher_invites teacher_invites_invitedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teacher_invites
    ADD CONSTRAINT "teacher_invites_invitedById_fkey" FOREIGN KEY ("invitedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: teacher_invites teacher_invites_schoolId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teacher_invites
    ADD CONSTRAINT "teacher_invites_schoolId_fkey" FOREIGN KEY ("schoolId") REFERENCES public.schools(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: teachers teachers_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.teachers
    ADD CONSTRAINT "teachers_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT "user_sessions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_schoolId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_schoolId_fkey" FOREIGN KEY ("schoolId") REFERENCES public.schools(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: worksheet_uploads worksheet_uploads_activityProgressId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.worksheet_uploads
    ADD CONSTRAINT "worksheet_uploads_activityProgressId_fkey" FOREIGN KEY ("activityProgressId") REFERENCES public.activity_progress(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: worksheet_uploads worksheet_uploads_uploadedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.worksheet_uploads
    ADD CONSTRAINT "worksheet_uploads_uploadedById_fkey" FOREIGN KEY ("uploadedById") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict AsfnlQgPmYjsq9vUK7ZqvLmHRVAPfccjWo2XCdLR6CHmojjhEyKpF58SSge1mkd

